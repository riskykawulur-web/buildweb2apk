#//Based Xova:

#//​Developer:
#​Telegram: https://t.me/policrben
#​Channel: https://t.me/ClanActivee

#//​Peraturan:
#​Dilarang sebar (no share)
#Dilarang jual (no sell)

#//​Catatan:
#Kalau ada yang menyebarkan atau menjual, 
#silakan laporkan ke username Telegram
#developer di atas.