import http from "node:http";
import config from "../config.js";

export function startWebServer() {
  if (!config.web.enabled) return;
  const server = http.createServer((req, res) => {
    if (req.url === "/health") {
      res.writeHead(200, { "content-type": "application/json" });
      return res.end(JSON.stringify({ ok: true, service: "game-center" }));
    }
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    res.end(`<!doctype html><html lang="id"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Game Center</title>
    <style>body{font-family:system-ui;background:#101522;color:#fff;margin:0;padding:24px}main{max-width:620px;margin:auto;background:#1c2638;padding:22px;border-radius:16px}a{color:#8cc8ff}</style>
    <main><h1>WhatsApp Game Center</h1><p>Server web mini-game aktif.</p><p>Game web seperti catur, Snake, Flappy Bird, dan 2048 akan ditambahkan sebagai modul berikutnya.</p><p>Health: <a href="/health">/health</a></p></main></html>`);
  });
  server.listen(config.web.port, config.web.host, () => {
    console.log(`[WEB] Listening on ${config.web.host}:${config.web.port}`);
  });
}
