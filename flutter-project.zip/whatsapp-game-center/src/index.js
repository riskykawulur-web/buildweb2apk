import makeWASocket, { useMultiFileAuthState, DisconnectReason, Browsers, downloadMediaMessage } from "@whiskeysockets/baileys";
import pino from "pino";
import fs from "node:fs";
import path from "node:path";
import config from "../config.js";
import { initDb, ensureUser, run, get, closeDb } from "./db.js";
import { handleCommand } from "./commands.js";
import { startWebServer } from "./web.js";

const logger = pino({ level: "silent" });
let isRequestingCode = false;
let shuttingDown = false;

function cleanNumber(value) {
  return String(value || "").replace(/\D/g, "");
}
function validateConfig() {
  const owner = cleanNumber(config.ownerNumber);
  const pairing = cleanNumber(config.pairingNumber);
  if (!owner || owner.includes("X") || owner.length < 9) throw new Error("Isi config.ownerNumber dengan nomor Owner valid (format 62...).");
  if (!pairing || pairing.includes("X") || pairing.length < 9) throw new Error("Isi config.pairingNumber dengan nomor yang akan ditautkan (format 62...).");
  config.ownerNumber = owner;
  config.pairingNumber = pairing;
}

async function startBot() {
  validateConfig();
  await initDb();
  const ownerJid = `${config.ownerNumber}@s.whatsapp.net`;
  if (!get("SELECT jid FROM staff WHERE jid=?", [ownerJid])) {
    run("INSERT INTO staff(jid,role,created_at) VALUES(?,?,?)", [ownerJid,"founder",Date.now()]);
  }
  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const sock = makeWASocket({
    auth: state,
    logger,
    browser: Browsers.ubuntu("Chrome"),
    printQRInTerminal: false,
    markOnlineOnConnect: false,
    syncFullHistory: false
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr }) => {
    // Meniru alur pairing pada index yang diminta: tunggu event qr sebagai tanda socket siap,
    // lalu minta pairing code resmi dari Baileys. Jangan membuat kode sendiri.
    if (qr && !state.creds.registered && !isRequestingCode) {
      isRequestingCode = true;
      try {
        const code = await sock.requestPairingCode(config.pairingNumber);
        console.log("\n========================================");
        console.log(" WHATSAPP GAME CENTER - PAIRING CODE");
        console.log(` Nomor: ${config.pairingNumber}`);
        console.log(` KODE:  ${code}`);
        console.log("WhatsApp > Perangkat tertaut > Tautkan perangkat");
        console.log("Pilih 'Tautkan dengan nomor telepon saja', lalu masukkan kode di atas.");
        console.log("========================================\n");
      } catch (err) {
        isRequestingCode = false;
        console.error("[PAIRING] Gagal meminta pairing code:", err?.message || err);
      }
    }
    if (connection === "open") {
      isRequestingCode = false;
      console.log("[WA] WhatsApp terhubung. Session tersimpan.");
    }
    if (connection === "close") {
      isRequestingCode = false;
      const code = lastDisconnect?.error?.output?.statusCode;
      console.error("[WA] Koneksi terputus:", code || "unknown");
      if (code !== DisconnectReason.loggedOut && !shuttingDown) {
        setTimeout(() => startBot().catch(e => console.error("[WA] Reconnect error:", e)), 5000);
      } else if (code === DisconnectReason.loggedOut) {
        console.error("[WA] Sesi logout. Hapus folder session hanya jika memang ingin pairing ulang.");
      }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe) continue;
      const chatId = msg.key.remoteJid;
      if (!chatId || chatId === "status@broadcast") continue;
      const sender = msg.key.participant || chatId;
      const isGroup = chatId.endsWith("@g.us");
      const text = msg.message.conversation ||
        msg.message.extendedTextMessage?.text ||
        msg.message.imageMessage?.caption ||
        msg.message.videoMessage?.caption || "";
      try {
        ensureUser(sender, msg.pushName || "");
        // Simpan bukti gambar untuk pembayaran pending dan teruskan ke Owner.
        if (msg.message.imageMessage && !isGroup) {
          const pending = get("SELECT * FROM payments WHERE jid=? AND status='pending' ORDER BY id DESC LIMIT 1", [sender]);
          if (pending) {
            const media = await downloadMediaMessage(msg, "buffer", {}, { logger });
            const dir = "./data/payment-proofs";
            fs.mkdirSync(dir, { recursive: true });
            const proofPath = path.join(dir, `payment-${pending.id}-${Date.now()}.jpg`);
            fs.writeFileSync(proofPath, media);
            run("UPDATE payments SET proof_path=? WHERE id=?", [proofPath, pending.id]);
            await sock.sendMessage(ownerJid, { image: media, caption: `Bukti pembayaran diterima\nTagihan: #${pending.id}\nPengirim: ${sender.split("@")[0]}\nPaket: ${pending.plan.toUpperCase()} ${pending.duration}\nNominal: Rp${pending.amount}\nPeriksa transaksi secara manual sebelum .approvepay ${pending.id}` });
            await sock.sendMessage(chatId, { text: `Bukti gambar diterima untuk tagihan #${pending.id}. Menunggu verifikasi Owner.` }, { quoted: msg });
            continue;
          }
        }
        await handleCommand({ sock, msg, text: text.trim(), sender, chatId, isGroup });
      } catch (err) {
        console.error("[COMMAND]", err);
        await sock.sendMessage(chatId, { text: "Terjadi kesalahan saat menjalankan perintah. Coba lagi." }, { quoted: msg });
      }
    }
  });

  return sock;
}

startWebServer();
startBot().catch(err => {
  console.error("[FATAL]", err);
  process.exit(1);
});

process.on("SIGINT", () => { shuttingDown = true; closeDb(); process.exit(0); });
process.on("SIGTERM", () => { shuttingDown = true; closeDb(); process.exit(0); });
