import fs from "node:fs";
import path from "node:path";
import initSqlJs from "sql.js";
import config from "../config.js";

let SQL;
let db;

const schema = `
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  jid TEXT PRIMARY KEY,
  name TEXT DEFAULT '',
  coins INTEGER NOT NULL DEFAULT 0,
  exp INTEGER NOT NULL DEFAULT 0,
  level INTEGER NOT NULL DEFAULT 1,
  title TEXT DEFAULT 'Newbie',
  membership TEXT NOT NULL DEFAULT 'free',
  membership_until INTEGER,
  daily_limit INTEGER NOT NULL DEFAULT 25,
  daily_points INTEGER NOT NULL DEFAULT 5,
  reset_key TEXT DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS staff (
  jid TEXT PRIMARY KEY,
  role TEXT NOT NULL,
  parent_owner TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  jid TEXT NOT NULL,
  plan TEXT NOT NULL,
  duration TEXT NOT NULL,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  proof_path TEXT,
  created_at INTEGER NOT NULL,
  reviewed_by TEXT,
  reviewed_at INTEGER
);
CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  target TEXT,
  details TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  jid TEXT PRIMARY KEY,
  game TEXT NOT NULL,
  payload TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS ban_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  requester TEXT NOT NULL,
  target TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  reviewed_by TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS bans (
  jid TEXT PRIMARY KEY,
  reason TEXT NOT NULL,
  by_jid TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_users_coins ON users(coins DESC);
CREATE INDEX IF NOT EXISTS idx_users_level ON users(level DESC, exp DESC);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
`;

function persist() {
  const bytes = db.export();
  fs.mkdirSync(path.dirname(config.databaseFile), { recursive: true });
  fs.writeFileSync(config.databaseFile, Buffer.from(bytes));
}

export async function initDb() {
  SQL = await initSqlJs();
  fs.mkdirSync(path.dirname(config.databaseFile), { recursive: true });
  if (fs.existsSync(config.databaseFile)) {
    const bytes = fs.readFileSync(config.databaseFile);
    db = new SQL.Database(bytes);
  } else {
    db = new SQL.Database();
  }
  db.run(schema);
  persist();
}

export function run(sql, params = []) {
  db.run(sql, params);
  persist();
  return { changes: db.getRowsModified(), lastID: db.exec("SELECT last_insert_rowid() AS id")[0]?.values?.[0]?.[0] ?? null };
}
export function get(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const row = stmt.step() ? stmt.getAsObject() : null;
  stmt.free();
  return row;
}
export function all(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}
export function audit(actor, action, target = "", details = "") {
  run("INSERT INTO audit(actor,action,target,details,created_at) VALUES(?,?,?,?,?)",
    [actor, action, target, details, Date.now()]);
}
export function ensureUser(jid, name = "") {
  let u = get("SELECT * FROM users WHERE jid=?", [jid]);
  if (!u) {
    run("INSERT INTO users(jid,name,created_at) VALUES(?,?,?)", [jid, name, Date.now()]);
    u = get("SELECT * FROM users WHERE jid=?", [jid]);
  }
  if (name && u.name !== name) run("UPDATE users SET name=? WHERE jid=?", [name, jid]);
  return get("SELECT * FROM users WHERE jid=?", [jid]);
}
export function closeDb() {
  if (db) { persist(); db.close(); }
}
