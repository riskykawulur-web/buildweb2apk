import config from "../config.js";
import { all, audit, ensureUser, get, run } from "./db.js";
import { answerGame, gameNames, startGame } from "./games.js";

const jidNumber = jid => (jid || "").split("@")[0].split(":")[0];
const normalizeNumber = n => String(n || "").replace(/\D/g, "");
const durationMs = d => {
  const m = String(d || "").match(/^(\d+)(d|h)$/i);
  if (!m) return null;
  return Number(m[1]) * (m[2].toLowerCase() === "d" ? 86400000 : 3600000);
};
const fmt = n => Number(n || 0).toLocaleString("id-ID");
const getRole = jid => get("SELECT role,parent_owner FROM staff WHERE jid=?", [jid])?.role || "player";

function refreshDaily(user) {
  if (user.membership !== "free" && user.membership_until && user.membership_until <= Date.now()) {
    run("UPDATE users SET membership='free',membership_until=NULL WHERE jid=?", [user.jid]);
    user = get("SELECT * FROM users WHERE jid=?", [user.jid]);
  }
  // Effective date rolls over at 06:00 WIB, not at midnight UTC.
  const effectiveDate = new Date(Date.now() + 7 * 3600000 - config.economy.dailyResetHourWIB * 3600000);
  const key = effectiveDate.toISOString().slice(0, 10);
  if (user.reset_key === key) return user;
  const membership = user.membership;
  const limits = membership === "free" ? config.economy.freeDailyLimit : config.membership[membership]?.dailyLimit ?? 25;
  const points = membership === "free" ? config.economy.freeDailyPoints : config.membership[membership]?.dailyPoints ?? 5;
  run("UPDATE users SET daily_limit=?,daily_points=?,reset_key=? WHERE jid=?", [limits, points, key, user.jid]);
  return get("SELECT * FROM users WHERE jid=?", [user.jid]);
}
function canManage(actor, targetRole) {
  const role = getRole(actor);
  if (role === "founder") return true;
  if (role === "owner") return !["founder", "owner"].includes(targetRole);
  return false;
}
function targetFromMessage(msg, args) {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  if (mentioned[0]) return mentioned[0];
  const raw = args[0] || "";
  const num = normalizeNumber(raw.replace("@",""));
  return num ? `${num}@s.whatsapp.net` : null;
}
function parseDuration(args, start = 1) { return args[start] || "30d"; }

export async function handleCommand({ sock, msg, text, sender, chatId, isGroup }) {
  const prefix = config.prefix;
  if (!text.startsWith(prefix)) return false;
  const parts = text.slice(prefix.length).trim().split(/\s+/);
  const cmd = (parts.shift() || "").toLowerCase();
  const args = parts;
  const user = refreshDaily(ensureUser(sender, msg.pushName || ""));
  if (get("SELECT jid FROM bans WHERE jid=?", [sender])) {
    await sock.sendMessage(chatId, { text: "Akses Game Center akun lo sedang dibatasi." }, { quoted: msg });
    return true;
  }
  const reply = async t => sock.sendMessage(chatId, { text: t }, { quoted: msg });
  const staffRole = getRole(sender);

  if (["menu","help"].includes(cmd)) {
    return reply(`🎮 *WHATSAPP GAME CENTER*\n\n.games — daftar game\n.me — profil\n.limit — sisa limit\n.point — poin\n.pay — pembayaran membership\n.topcoin — leaderboard coin\n.toplevel — leaderboard level\n.cancel — batalkan game\n\nGame: .play <nama game>\nJawab langsung di chat setelah pertanyaan muncul.`);
  }
  if (cmd === "games") return reply("🎮 *DAFTAR GAME*\n" + gameNames.map((g,i)=>`${i+1}. ${g}`).join("\n") + "\n\nMain: .play <nama game>");
  if (cmd === "me" || cmd === "profile") {
    const u = get("SELECT * FROM users WHERE jid=?", [sender]);
    const until = u.membership_until ? new Date(u.membership_until).toLocaleString("id-ID") : "-";
    return reply(`👤 *PROFILE*\nNama: ${u.name || msg.pushName || "-"}\nID: ${jidNumber(sender)}\nMembership: ${u.membership.toUpperCase()}\nCoin: ${fmt(u.coins)}\nLevel: ${u.level}\nEXP: ${fmt(u.exp)}\nTitle: ${u.title}\nLimit: ${u.daily_limit < 0 ? "Unlimited" : u.daily_limit}\nPoint: ${u.daily_points < 0 ? "Unlimited" : u.daily_points}\nMasa aktif: ${until}`);
  }
  if (cmd === "limit") return reply(`Limit harian tersisa: ${user.daily_limit < 0 ? "Unlimited" : user.daily_limit}`);
  if (cmd === "point") return reply(`Point harian tersisa: ${user.daily_points < 0 ? "Unlimited" : user.daily_points}`);
  if (cmd === "cancel") { run("DELETE FROM sessions WHERE jid=?", [sender]); return reply("Game aktif dibatalkan."); }
  if (cmd === "play") {
    if (isGroup && ["catur","tic tac toe","snake","flappy bird","2048"].includes(args.join(" ").toLowerCase())) {
      return reply("Game ini dirancang untuk sesi web/pribadi. Untuk versi ini, jalankan dari chat pribadi bot.");
    }
    const result = startGame(sender, args.join(" "), config);
    if (result.error) return reply(result.error);
    if (result.webRequired) return reply(`Game *${result.game}* membutuhkan modul web-game yang belum aktif pada build awal ini.`);
    if (user.daily_limit === 0) return reply("Limit harian lo habis.");
    if (user.daily_limit > 0) run("UPDATE users SET daily_limit=daily_limit-1 WHERE jid=?", [sender]);
    return reply(`🎯 *${args.join(" ").toUpperCase()}*\n${result.question}\n\nKesulitan: ${result.difficulty}\nWaktu: 2 menit\nBalas jawaban lo langsung di chat.`);
  }
  if (cmd === "buypremium") {
    const duration = args[0] || "30d";
    const price = config.premiumCoinPrices[duration];
    if (!price) return reply("Paket coin tidak tersedia. Pilih 7d, 30d, atau 90d.");
    const fresh = get("SELECT * FROM users WHERE jid=?", [sender]);
    if (fresh.coins < price) return reply(`Coin lo belum cukup. Harga Premium ${duration}: ${fmt(price)} coin. Saldo: ${fmt(fresh.coins)} coin.`);
    run("UPDATE users SET coins=coins-? WHERE jid=?", [price, sender]);
    activateMembership(sender, "premium", duration, sender);
    audit(sender, "premium_bought_with_coins", sender, `${duration}:${price}`);
    return reply(`Premium ${duration} berhasil diaktifkan. ${fmt(price)} coin digunakan.`);
  }
  if (cmd === "pay") {
    if (!config.payment.enabled) return reply("Pembayaran sedang dinonaktifkan.");
    const plan = (args[0] || "").toLowerCase();
    const duration = args[1] || "30d";
    if (!["premium","vip","vvip"].includes(plan)) {
      return reply(`💳 *PEMBAYARAN MEMBERSHIP*\nPremium: ${Object.entries(config.prices.premium).map(([d,p])=>`${d} Rp${fmt(p)}`).join(" | ")}\nVIP: ${Object.entries(config.prices.vip).map(([d,p])=>`${d} Rp${fmt(p)}`).join(" | ")}\nVVIP: ${Object.entries(config.prices.vvip).map(([d,p])=>`${d} Rp${fmt(p)}`).join(" | ")}\n\nBuat tagihan: .pay <premium|vip|vvip> <7d|30d|90d>\n\n${config.payment.instructions}`);
    }
    const price = config.prices[plan]?.[duration];
    if (!price || price <= 0) return reply(`Harga ${plan.toUpperCase()} ${duration} belum diatur Owner di config.js.`);
    const created = run("INSERT INTO payments(jid,plan,duration,amount,created_at) VALUES(?,?,?,?,?)", [sender,plan,duration,price,Date.now()]);
    const id = created.lastID;
    await sock.sendMessage(chatId, { image: { url: config.payment.qrisImageUrl }, caption: `Tagihan #${id}\nPaket: ${plan.toUpperCase()} ${duration}\nTotal: Rp${fmt(price)}\n\n${config.payment.instructions}` }, { quoted: msg });
    return true;
  }
  if (cmd === "pendingpay") {
    if (!["founder","owner"].includes(staffRole)) return reply("Perintah ini hanya untuk Owner/Founder.");
    const rows = all("SELECT id,jid,plan,duration,amount,status,proof_path FROM payments WHERE status='pending' ORDER BY id DESC LIMIT 20");
    if (!rows.length) return reply("Belum ada pembayaran pending.");
    return reply("💳 *PENDING PAYMENTS*\n" + rows.map(p => `#${p.id} | ${jidNumber(p.jid)} | ${p.plan.toUpperCase()} ${p.duration} | Rp${fmt(p.amount)} | Bukti: ${p.proof_path ? "sudah diterima" : "belum"}`).join("\n") + "\n\n.approvepay <id> atau .rejectpay <id>");
  }
  if (cmd === "approvepay" || cmd === "rejectpay") {
    if (!["founder","owner"].includes(staffRole)) return reply("Perintah ini hanya untuk Owner/Founder.");
    const id = Number(args[0]);
    const p = get("SELECT * FROM payments WHERE id=? AND status='pending'", [id]);
    if (!p) return reply("Tagihan pending tidak ditemukan.");
    if (cmd === "rejectpay") {
      run("UPDATE payments SET status='rejected',reviewed_by=?,reviewed_at=? WHERE id=?", [sender,Date.now(),id]);
      audit(sender,"payment_rejected",p.jid,`payment=${id}`);
      return reply(`Pembayaran #${id} ditolak.`);
    }
    activateMembership(p.jid,p.plan,p.duration,sender);
    run("UPDATE payments SET status='approved',reviewed_by=?,reviewed_at=? WHERE id=?", [sender,Date.now(),id]);
    audit(sender,"payment_approved",p.jid,`payment=${id}`);
    await sock.sendMessage(p.jid,{text:`Pembayaran #${id} diverifikasi. Membership ${p.plan.toUpperCase()} ${p.duration} aktif.`});
    return reply(`Pembayaran #${id} disetujui.`);
  }
  if (["addpremium","addvip","addvvip","delpremium","delvip","delvvip"].includes(cmd)) {
    if (!["founder","owner"].includes(staffRole)) return reply("Hanya Founder/Owner yang dapat mengubah membership.");
    const target = targetFromMessage(msg,args);
    if (!target) return reply(`Format: .${cmd} @user 30d`);
    const plan = cmd.replace("add","").replace("del","");
    if (cmd.startsWith("del")) {
      run("UPDATE users SET membership='free',membership_until=NULL WHERE jid=?", [target]);
      audit(sender,"membership_removed",target,plan);
      return reply(`Membership ${plan.toUpperCase()} dihapus dari ${jidNumber(target)}.`);
    }
    const duration = parseDuration(args,1);
    if (!durationMs(duration)) return reply("Durasi gunakan format 7d atau 30d.");
    activateMembership(target,plan,duration,sender);
    return reply(`${plan.toUpperCase()} ${duration} diberikan ke ${jidNumber(target)}.`);
  }
  if (cmd === "addowner") {
    if (staffRole !== "founder") return reply("Hanya Founder yang dapat menambahkan Owner.");
    const target = targetFromMessage(msg,args);
    if (!target) return reply("Format: .addowner @user");
    run("INSERT OR REPLACE INTO staff(jid,role,created_at) VALUES(?,?,?)",[target,"owner",Date.now()]);
    audit(sender,"owner_added",target);
    return reply("Owner berhasil ditambahkan.");
  }
  if (cmd === "addadmin") {
    if (!["founder","owner"].includes(staffRole)) return reply("Hanya Founder/Owner yang dapat menambahkan Admin.");
    const target = targetFromMessage(msg,args);
    if (!target) return reply("Format: .addadmin @user");
    const owner = staffRole === "founder" ? sender : sender;
    const count = get("SELECT COUNT(*) AS n FROM staff WHERE role='admin' AND parent_owner=?", [owner]).n;
    if (count >= 2 && staffRole !== "founder") return reply("Setiap Owner maksimal memiliki 2 Admin.");
    run("INSERT OR REPLACE INTO staff(jid,role,parent_owner,created_at) VALUES(?,?,?,?)",[target,"admin",owner,Date.now()]);
    audit(sender,"admin_added",target);
    return reply("Admin berhasil ditambahkan.");
  }
  if (cmd === "banrequest") {
    if (!["vvip","founder","owner"].includes(user.membership) && !["founder","owner","admin"].includes(staffRole)) return reply("Fitur permintaan ban tersedia untuk VVIP dan staff.");
    const target = targetFromMessage(msg,args);
    const reason = args.slice(1).join(" ");
    if (!target || !reason) return reply("Format: .banrequest @user alasan");
    const r = run("INSERT INTO ban_requests(requester,target,reason,created_at) VALUES(?,?,?,?)",[sender,target,reason,Date.now()]);
    audit(sender,"ban_requested",target,reason);
    return reply(`Permintaan ban #${r.lastID} dikirim untuk ditinjau Admin.`);
  }
  if (cmd === "reviewban") {
    if (!["founder","owner","admin"].includes(staffRole)) return reply("Hanya Admin/Owner/Founder.");
    const id = Number(args[0]);
    const decision = args[1];
    const req = get("SELECT * FROM ban_requests WHERE id=? AND status='pending'",[id]);
    if (!req) return reply("Permintaan tidak ditemukan.");
    if (decision === "approve") {
      run("INSERT OR REPLACE INTO bans(jid,reason,by_jid,created_at) VALUES(?,?,?,?)",[req.target,req.reason,sender,Date.now()]);
      run("UPDATE ban_requests SET status='approved',reviewed_by=? WHERE id=?",[sender,id]);
      audit(sender,"ban_approved",req.target,`request=${id}`);
      return reply("Permintaan disetujui. Akses Game Center dibatasi.");
    }
    if (decision === "reject") {
      run("UPDATE ban_requests SET status='rejected',reviewed_by=? WHERE id=?",[sender,id]);
      audit(sender,"ban_rejected",req.target,`request=${id}`);
      return reply("Permintaan ditolak.");
    }
    return reply("Gunakan .reviewban <id> approve|reject");
  }
  if (cmd === "topcoin" || cmd === "toplevel") {
    const rows = cmd === "topcoin" ? all("SELECT jid,coins AS score FROM users ORDER BY coins DESC LIMIT 10") : all("SELECT jid,level AS score FROM users ORDER BY level DESC,exp DESC LIMIT 10");
    return reply(`🏆 *${cmd.toUpperCase()}*\n` + rows.map((r,i)=>`${i+1}. ${jidNumber(r.jid)} — ${fmt(r.score)}`).join("\n"));
  }
  const answer = answerGame(sender,text,config);
  if (answer.correct) return reply(`✅ Benar!\n+${answer.coins} coin\n+${answer.exp} EXP\nLevel: ${answer.level}`);
  if (answer.wrong) return reply(answer.message);
  return false;
}

function activateMembership(jid, plan, duration, actor) {
  ensureUser(jid);
  const ms = durationMs(duration);
  if (!ms) throw new Error("Invalid duration");
  const current = get("SELECT membership_until FROM users WHERE jid=?", [jid]);
  const start = Math.max(Date.now(), current?.membership_until || 0);
  run("UPDATE users SET membership=?,membership_until=? WHERE jid=?", [plan, start+ms, jid]);
  audit(actor,"membership_granted",jid,`${plan}:${duration}`);
}
