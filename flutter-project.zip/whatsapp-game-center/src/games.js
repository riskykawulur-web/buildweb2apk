import { get, run } from "./db.js";

const banks = {
  "asah otak": [
    ["Apa yang punya banyak gigi tetapi tidak bisa menggigit?", "sisir", "easy"],
    ["Semakin diisi semakin ringan. Apakah itu?", "balon", "normal"]
  ],
  "tebak kata": [["Lawan kata 'tinggi'?", "rendah", "easy"], ["Sinonim 'cermat'?", "teliti", "normal"]],
  "tebak bendera": [["Negara dengan bendera merah putih dan lambang Garuda?", "indonesia", "easy"]],
  "tebak negara": [["Negara yang memiliki kota Tokyo?", "jepang", "easy"]],
  "tebak hewan": [["Mamalia terbesar di dunia?", "paus biru", "normal"]],
  "tebak anime": [["Anime tentang kru bajak laut yang mencari harta One Piece?", "one piece", "easy"]],
  "tebak film": [["Film animasi tentang keluarga superhero bernama Parr?", "the incredibles", "normal"]],
  "kuis pengetahuan": [["Planet terbesar di tata surya?", "jupiter", "easy"], ["Proses tumbuhan membuat makanan disebut?", "fotosintesis", "normal"]],
  "matematika": [["Berapakah 12 × 8?", "96", "easy"], ["Berapakah 144 ÷ 12?", "12", "easy"]],
  "tebak emoji": [["Emoji 🐝 + 🍯 menggambarkan apa?", "madu", "easy"]],
  "siapa aku": [["Aku punya halaman tetapi bukan rumah, punya sampul tetapi bukan tubuh. Apakah aku?", "buku", "normal"]],
  "tebak suara": [["Hewan apa yang biasanya berbunyi 'meong'?", "kucing", "easy"]],
  "family 100": [["Sebutkan salah satu alat untuk menulis.", "pulpen", "easy"]],
  "cak lontong": [["Apa yang selalu datang tetapi tidak pernah tiba?", "besok", "normal"]],
  "tebak lagu": [["Lengkapi judul lagu: 'Perfect' dinyanyikan oleh Ed ...", "sheeran", "easy"]],
  "tebak gambar": [["Tebak: mata + hari = ?", "matahari", "normal"]],
  "tebak angka": [["Angka rahasia: 7. Ketik angkanya.", "7", "easy"]],
  "susun kata": [["Susun huruf: K-U-B-U. Menjadi kata?", "buku", "easy"]],
  "sambung kata": [["Kata awal: BUNGA. Balas dengan kata yang dimulai huruf A.", "apa", "easy"]],
  "tebak benda": [["Aku dipakai melihat waktu dan bisa ada di pergelangan tangan.", "jam", "easy"]],
  "tebak profesi": [["Pekerjaan yang mengajar murid di sekolah?", "guru", "easy"]],
  "tebak makanan": [["Makanan khas Indonesia dari kedelai fermentasi?", "tempe", "easy"]],
  "tebak olahraga": [["Olahraga yang memakai raket dan kok?", "bulu tangkis", "easy"]],
  "tebak alat musik": [["Alat musik berdawai yang dimainkan dengan dipetik?", "gitar", "easy"]],
  "tebak teknologi": [["Kepanjangan CPU?", "central processing unit", "normal"]],
  "tebak sejarah": [["Siapa proklamator kemerdekaan Indonesia bersama Mohammad Hatta?", "soekarno", "normal"]],
  "tebak sains": [["Rumus kimia air?", "h2o", "easy"]],
  "tebak geografi": [["Samudra terbesar di dunia?", "pasifik", "normal"]],
  "tebak bahasa": [["Bahasa Inggris dari 'kucing'?", "cat", "easy"]],
  "tebak tumbuhan": [["Bagian tumbuhan yang menyerap air dari tanah?", "akar", "easy"]],
  "tebak transportasi": [["Kendaraan rel yang berjalan di atas rel?", "kereta", "easy"]]
};

export const gameNames = Object.keys(banks).concat([
  "suit", "tic tac toe", "catur", "wordle", "hangman", "2048", "snake", "flappy bird", "memory card", "minesweeper", "puzzle"
]);

const normalize = s => String(s ?? "").toLowerCase().trim().replace(/[^\p{L}\p{N}\s]/gu, "").replace(/\s+/g, " ");

function levelFromExp(exp, base) {
  let level = 1, needed = base;
  while (exp >= needed) { exp -= needed; level++; needed = Math.floor(base * Math.pow(level, 1.18)); }
  return { level, into: exp, needed };
}

export function startGame(jid, game, config) {
  const key = normalize(game);
  const bank = banks[key];
  if (!bank) {
    if (["catur", "tic tac toe", "snake", "flappy bird", "2048", "minesweeper", "memory card", "puzzle"].includes(key)) {
      return { webRequired: true, game: key };
    }
    return { error: "Game tidak ditemukan. Cek .games." };
  }
  const item = bank[Math.floor(Math.random() * bank.length)];
  const difficulty = item[2];
  const expReward = difficulty === "easy" ? 10 : difficulty === "normal" ? 18 : 30;
  run("INSERT OR REPLACE INTO sessions(jid,game,payload,expires_at,updated_at) VALUES(?,?,?,?,?)",
    [jid, key, JSON.stringify({ question: item[0], answer: item[1], difficulty, expReward }), Date.now() + 120000, Date.now()]);
  return { question: item[0], difficulty };
}

export function answerGame(jid, answer, config) {
  const session = get("SELECT * FROM sessions WHERE jid=?", [jid]);
  if (!session) return { error: "Lo belum punya game aktif. Ketik .games." };
  if (session.expires_at < Date.now()) {
    run("DELETE FROM sessions WHERE jid=?", [jid]);
    return { error: "Waktu game habis. Mulai game baru." };
  }
  const data = JSON.parse(session.payload);
  if (normalize(answer) !== normalize(data.answer)) return { wrong: true, message: "Belum tepat. Coba lagi." };
  const user = get("SELECT * FROM users WHERE jid=?", [jid]);
  const tier = user.membership || "free";
  const bonus = config.membership[tier] || { coinBonus: 0, expBonus: 0 };
  const baseCoin = config.economy.coinPerDifficulty[data.difficulty] || 8;
  const coins = Math.floor(baseCoin * (1 + (bonus.coinBonus || 0) / 100));
  const exp = Math.floor(data.expReward * (1 + (bonus.expBonus || 0) / 100));
  const newExp = user.exp + exp;
  const info = levelFromExp(newExp, config.economy.levelBaseExp);
  run("UPDATE users SET coins=coins+?,exp=?,level=? WHERE jid=?", [coins, newExp, info.level, jid]);
  run("DELETE FROM sessions WHERE jid=?", [jid]);
  return { correct: true, coins, exp, level: info.level };
}
