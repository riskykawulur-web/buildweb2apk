# WhatsApp Game Center

Build awal untuk Pterodactyl. Menggunakan Node.js, Baileys, dan SQLite melalui `sql.js`.

## Penting sebelum menjalankan
1. Buka `config.js`.
2. Isi `ownerNumber` dan `pairingNumber` dengan nomor format internasional digit saja, contoh `62812...` (tanpa `+`).
3. Ganti `payment.qrisImageUrl` dengan URL gambar QRIS milik lo.
4. Isi harga Premium/VIP/VVIP di `prices`. Nilai `0` berarti harga belum ditetapkan.
5. Pastikan port `3000` dialokasikan di Pterodactyl bila web status diaktifkan.

## Instalasi Pterodactyl
- Upload isi ZIP ke server.
- Pilih image Node.js 22 atau 24 yang tersedia dan sesuai dependency. Node 23 bisa dipakai hanya jika image yang dipilih tersedia dan dependency berhasil terpasang, tetapi bukan pilihan LTS.
- Startup command: `npm start`
- Install dependency: `npm install`
- Jangan upload folder `node_modules` atau folder `session` ke tempat publik.

## Pairing
Bot menggunakan `useMultiFileAuthState("./session")`. Saat event `qr` muncul dan akun belum terdaftar, bot memanggil `sock.requestPairingCode(config.pairingNumber)` dan menampilkan kode yang dikembalikan Baileys di console.
Masukkan kode itu melalui WhatsApp > Perangkat tertaut > Tautkan perangkat > Tautkan dengan nomor telepon saja.

**Kode harus berasal dari Baileys.** Jangan mengubahnya menjadi kode acak seperti `GWOC-BPMK`, karena kode hasil generate sendiri tidak bisa dipakai menautkan WhatsApp. Tampilan persis kode mengikuti versi Baileys yang terpasang.

## Perintah
- `.menu`, `.help`, `.games`, `.play <nama>`
- `.me`, `.profile`, `.limit`, `.point`
- `.pay` atau `.pay premium 30d`
- `.buypremium 7d|30d|90d` (pakai coin)
- `.pendingpay`, `.approvepay <id>`, `.rejectpay <id>`
- `.addpremium @user 30d`, `.addvip @user 30d`, `.addvvip @user 30d`
- `.delpremium @user`, `.delvip @user`, `.delvvip @user`
- `.addowner @user` (Founder)
- `.addadmin @user` (Owner/Founder)
- `.banrequest @user alasan`, `.reviewban <id> approve|reject`
- `.topcoin`, `.toplevel`, `.cancel`

## Batas build awal
- Game berbasis pertanyaan/chat pada `src/games.js` sudah memiliki bank pertanyaan awal dan bisa dimainkan.
- Catur, Snake, Flappy Bird, 2048, Minesweeper, Memory Card, Puzzle, dan Tic Tac Toe baru terdaftar sebagai kebutuhan web-game; engine interaktifnya belum disertakan dalam build awal ini.
- Verifikasi pembayaran masih manual oleh Founder/Owner. Gambar bukti yang dikirim sebagai foto pribadi disimpan di `data/payment-proofs` dan diteruskan ke Owner; bukti itu tidak otomatis membuktikan transaksi valid.
- Ini belum dites dengan akun WhatsApp sungguhan atau panel Pterodactyl. Tes sintaks lokal dapat dilakukan dengan `npm run check` setelah dependency terpasang.

## Security
- Jangan bagikan folder `session`, file database, atau nomor Owner ke publik.
- Gunakan akun WhatsApp khusus bot jika memungkinkan.
- Jangan menerima bukti pembayaran sebagai pembayaran sah tanpa memeriksa mutasi/riwayat transaksi di aplikasi pembayaran.
- Backup `data/gamecenter.sqlite` dan `session` secara privat.
