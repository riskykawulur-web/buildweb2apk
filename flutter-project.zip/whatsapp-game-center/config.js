// Isi nomor dengan format internasional tanpa +, spasi, atau tanda baca.
const config = {
  // Nomor Owner utama (Founder awal).
  ownerNumber: "628XXXXXXXXXX",

  // Nomor WhatsApp yang akan ditautkan sebagai perangkat bot.
  pairingNumber: "628XXXXXXXXXX",

  // Prefix command.
  prefix: ".",

  // Database SQLite (sql.js) disimpan ke file ini.
  databaseFile: "./data/gamecenter.sqlite",

  // Link gambar QRIS. Ganti dengan URL gambar QRIS milik lo.
  payment: {
    enabled: true,
    qrisImageUrl: "https://example.com/qris.jpg",
    instructions: "Scan QRIS, lalu kirim screenshot bukti pembayaran ke bot. Membership aktif setelah Owner memverifikasi."
  },

  // Harga Rupiah. Isi angka sesuai harga final; 0 berarti belum dijual.
  prices: {
    premium: {
      "7d": 0,
      "30d": 0,
      "90d": 0
    },
    vip: {
      "1d": 0,
      "7d": 0,
      "30d": 0
    },
    vvip: {
      "1d": 0,
      "7d": 0,
      "30d": 0
    }
  },

  // Premium dapat dibeli dengan coin sesuai ketentuan awal.
  premiumCoinPrices: { "7d": 300, "30d": 900, "90d": 1300 },

  // Membership benefits dapat disesuaikan.
  membership: {
    premium: { dailyLimit: 50, dailyPoints: 10, expBonus: 0, coinBonus: 0 },
    vip: { dailyLimit: -1, dailyPoints: 50, expBonus: 15, coinBonus: 10 },
    vvip: { dailyLimit: -1, dailyPoints: -1, expBonus: 30, coinBonus: 20 }
  },

  economy: {
    dailyResetHourWIB: 6,
    freeDailyLimit: 25,
    freeDailyPoints: 5,
    vipDailyPoints: 50,
    levelBaseExp: 100,
    coinPerDifficulty: { easy: 8, normal: 15, hard: 30, expert: 55 }
  },

  web: {
    enabled: true,
    host: "0.0.0.0",
    port: 3000,
    publicBaseUrl: "http://YOUR_SERVER_IP:3000"
  },

  // Jangan taruh token rahasia / password di repo publik.
  ownerCanManageAdmins: true
};

export default config;
