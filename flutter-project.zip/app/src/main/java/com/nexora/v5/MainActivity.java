package com.nexora.v5;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){
  super.onCreate(b); getWindow().setStatusBarColor(0xFF080B18); getWindow().setNavigationBarColor(0xFF050711);
  WebView w=new WebView(this); w.setBackgroundColor(0xFF080B18); w.setWebViewClient(new WebViewClient());
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  w.loadUrl("file:///android_asset/index.html"); setContentView(w);
 }
 @Override public void onBackPressed(){ super.onBackPressed(); }
}