package com.example.whatsappguard

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 20)
    private val pink = Color.rgb(255, 59, 92)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 190, 200)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "WHATSAPP GUARD"
            textSize = 25f
            setTextColor(pink)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 6)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Pusat panduan keamanan WhatsApp"
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 22)
        }
        root.addView(subtitle)

        val warning = TextView(this).apply {
            text = "Perlindungan akun dimulai dari pengaturan WhatsApp dan kebiasaan aman. Aplikasi ini tidak memindai atau mengubah WhatsApp."
            textSize = 14f
            setTextColor(white)
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(42, 25, 34))
        }
        root.addView(warning)

        addSection(root, "1. Aktifkan verifikasi dua langkah",
            "WhatsApp → Setelan → Akun → Verifikasi dua langkah. Buat PIN yang tidak mudah ditebak dan tambahkan email pemulihan.")
        addSection(root, "2. Periksa perangkat tertaut",
            "WhatsApp → Perangkat tertaut. Keluarkan perangkat yang tidak kamu kenal.")
        addSection(root, "3. Batasi privasi",
            "Setelan → Privasi. Atur foto profil, info, status, dan grup agar hanya kontak yang kamu percaya yang dapat melihat atau menambahkan kamu.")
        addSection(root, "4. Hindari file dan tautan mencurigakan",
            "Jangan memasang APK dari pengirim tidak dikenal. Jangan bagikan kode OTP, PIN, atau kode verifikasi.")
        addSection(root, "5. Perbarui aplikasi",
            "Perbarui WhatsApp hanya melalui Google Play Store dan pasang pembaruan sistem Vivo jika tersedia.")

        val note = TextView(this).apply {
            text = "Jika mengalami gangguan: simpan bukti, blokir dan laporkan akun pelaku, lalu hubungi orang tepercaya."
            textSize = 13f
            setTextColor(muted)
            setPadding(4, 22, 4, 8)
        }
        root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addSection(root: LinearLayout, heading: String, body: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.rgb(30, 30, 37))
        }
        val h = TextView(this).apply {
            text = heading
            textSize = 17f
            setTextColor(pink)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val b = TextView(this).apply {
            text = body
            textSize = 14f
            setTextColor(white)
            setPadding(0, 8, 0, 0)
        }
        card.addView(h)
        card.addView(b)
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 12, 0, 0)
        root.addView(card, lp)
    }
}
