MIYABI SIMULATOR (aman)

Cara pakai:
1. Ekstrak ZIP.
2. Buka index.html di Chrome Android.
3. Untuk ikon di layar utama: menu Chrome (⋮) > Tambahkan ke layar utama / Install app (jika tersedia).

Ini adalah demo antarmuka lokal. Tidak terhubung ke WhatsApp, tidak mengirim pesan,
tidak melakukan spam, dan tidak membuat perangkat atau aplikasi orang lain crash.

Catatan: Paket ini bukan APK Android. Untuk APK native, buka proyek ini di Android Studio
dan bungkus sebagai aplikasi WebView/PWA; proses build membutuhkan Android SDK.
