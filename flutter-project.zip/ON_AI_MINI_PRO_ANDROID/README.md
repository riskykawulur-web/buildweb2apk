# ON AI MINI PRO — Android Studio (Kotlin)

Aplikasi Android native menggunakan Kotlin + Jetpack Compose, tema Black Red Cyber, terhubung ke AI online melalui backend Node.js.

## A. Buka project Android
1. Ekstrak ZIP.
2. Buka Android Studio → **Open** → pilih folder `ON_AI_MINI_PRO_ANDROID`.
3. Tunggu Gradle Sync selesai.
4. Hubungkan HP Android dengan USB debugging atau gunakan emulator.
5. Klik **Run** untuk menjalankan aplikasi.

Gunakan Android Studio versi yang mendukung Android Gradle Plugin 8.7.3 dan JDK 17.

## B. Siapkan backend AI (wajib untuk AI online)
API key tidak boleh ditaruh di APK. APK dapat dibongkar sehingga key bisa dicuri. Backend ini menyimpan API key dengan aman di environment variable.

1. Upload folder `backend` ke hosting yang mendukung Node.js dan HTTPS.
2. Di hosting, jalankan `npm install`.
3. Atur environment variables:
   - `OPENAI_API_KEY` = API key milikmu
   - `OPENAI_MODEL` = model yang tersedia pada akun API (default di contoh: `gpt-5.5`; ubah bila tidak tersedia)
   - `PORT` biasanya disediakan otomatis oleh hosting.
4. Jalankan `npm start`.
5. Pastikan endpoint `https://DOMAIN-MU/api/health` merespons JSON `{"ok":true,"configured":true}`.

Penggunaan API dapat dikenakan biaya sesuai harga dan pemakaian akun API. ChatGPT berlangganan dan API billing merupakan hal terpisah.

## C. Hubungkan APK ke backend
Buka:
`app/src/main/java/com/onai/minipro/ApiClient.kt`

Ganti:
```kotlin
private const val BASE_URL = "https://GANTI-DENGAN-DOMAIN-BACKEND-KAMU"
```
dengan domain HTTPS backend milikmu, tanpa garis miring di akhir. Contoh format:
```kotlin
private const val BASE_URL = "https://on-ai-backend.example.com"
```
Contoh domain di atas hanya format; gunakan domain hosting milikmu sendiri.

Lalu Gradle Sync dan jalankan ulang aplikasi.

## D. Buat APK
1. Android Studio → **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
2. Setelah selesai klik **Locate** pada notifikasi build.
3. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
4. Untuk distribusi umum, buat signed release melalui **Build > Generate Signed Bundle / APK**.

## Fitur
- AI online lewat OpenAI Responses API.
- Chat dengan konteks beberapa pesan terakhir.
- Pilihan mata pelajaran.
- Jawaban pilihan ganda, essay, dan soal hitungan dengan penjelasan.
- Tombol chat baru dan status loading/error.
- UI Kotlin native dengan Jetpack Compose.

## Catatan penting
- Project ini adalah source code awal yang perlu dikonfigurasi dan dibuild di Android Studio; APK tidak dibuat otomatis di sini.
- Backend harus selalu online agar AI bisa menjawab.
- Gunakan HTTPS, batasi akses endpoint, pasang autentikasi/rate limiting lebih lanjut, dan pantau biaya API sebelum membagikan aplikasi.
- AI bisa keliru; periksa jawaban dengan buku dan guru.
