import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;
const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.use(helmet());
app.use(express.json({ limit: "100kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20 }));

const instructions = `
Kamu adalah ON AI MINI PRO, asisten belajar sekolah berbahasa Indonesia.
Bantu siswa memahami pelajaran dan mengerjakan latihan dengan teliti.
Jawab sesuai tingkat sekolah, jelas, ringkas tetapi cukup lengkap.
Pilihan ganda: tulis huruf dan isi jawaban serta alasan singkat.
Essay: jawab terstruktur dan langsung sesuai pertanyaan.
Soal hitungan: tulis rumus, substitusi, proses, hasil, dan satuan.
Jika soal tidak lengkap atau ambigu, minta bagian yang kurang; jangan mengarang.
Jika tidak yakin, nyatakan ketidakpastian. Utamakan pemahaman konsep.
`;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(client) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) return res.status(503).json({ error: "API belum dikonfigurasi pada server." });
    const { messages, subject = "Umum" } = req.body ?? {};
    if (!Array.isArray(messages) || messages.length < 1 || messages.length > 20) {
      return res.status(400).json({ error: "Format pesan tidak valid." });
    }
    const input = messages.map(m => ({
      role: m?.role === "assistant" ? "assistant" : "user",
      content: typeof m?.content === "string" ? m.content.slice(0, 6000) : ""
    })).filter(m => m.content.trim());
    if (!input.length || input.at(-1).role !== "user") {
      return res.status(400).json({ error: "Pertanyaan tidak ditemukan." });
    }
    const result = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions: `${instructions}\nMata pelajaran: ${String(subject).slice(0, 80)}.`,
      input
    });
    res.json({ answer: result.output_text || "Belum ada jawaban. Silakan coba lagi." });
  } catch (e) {
    console.error(e?.message || e);
    res.status(500).json({ error: "Gagal menghubungi AI. Periksa API key, billing, model, dan koneksi server." });
  }
});

app.listen(port, () => console.log(`ON AI backend aktif pada port ${port}`));
