package com.onai.minipro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ApiClient {
    // GANTI dengan URL HTTPS backend Node.js milikmu setelah di-deploy.
    // Jangan masukkan API Key OpenAI ke aplikasi Android.
    private const val BASE_URL = "https://GANTI-DENGAN-DOMAIN-BACKEND-KAMU"
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun ask(messages: List<ChatMessage>, subject: String): String = withContext(Dispatchers.IO) {
        require(!BASE_URL.contains("GANTI-DENGAN")) {
            "URL backend belum diatur. Ubah BASE_URL di ApiClient.kt menjadi URL HTTPS backend kamu."
        }

        val arr = JSONArray()
        messages.takeLast(12).forEach { msg ->
            arr.put(JSONObject().put("role", msg.role).put("content", msg.content))
        }
        val payload = JSONObject()
            .put("messages", arr)
            .put("subject", subject)
            .toString()

        val request = Request.Builder()
            .url("$BASE_URL/api/chat")
            .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("Accept", "application/json")
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
            if (!response.isSuccessful) {
                throw IllegalStateException(json.optString("error", "Server error: ${response.code}"))
            }
            json.optString("answer").ifBlank { "AI tidak mengirim jawaban. Coba lagi." }
        }
    }
}
