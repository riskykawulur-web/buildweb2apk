package com.onai.minipro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Background = Color(0xFF09090D)
private val Panel = Color(0xFF15151D)
private val Red = Color(0xFFFF2945)
private val Muted = Color(0xFFAAAAB5)

data class ChatMessage(val role: String, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OnAiApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnAiApp() {
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf<ChatMessage>() }
    var prompt by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("Umum") }
    var expanded by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val subjects = listOf("Umum", "Biologi", "Matematika", "Ekonomi", "Geografi",
        "Sejarah", "Bahasa Indonesia", "Bahasa Inggris", "Fisika", "Kimia", "PAI")

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            background = Background,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF260A12), Background, Background)))
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.size(48.dp).background(
                        Brush.linearGradient(listOf(Red, Color(0xFF780018))),
                        RoundedCornerShape(14.dp)
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("ON", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("ON AI MINI PRO", fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                    Text("SMART SCHOOL ASSISTANT", fontSize = 10.sp, color = Muted, letterSpacing = 1.5.sp)
                }
                Text("● ONLINE AI", color = Color(0xFFFF8390), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(22.dp))
            Text("BELAJAR LEBIH MUDAH.", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Tanyakan pelajaranmu.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Dapatkan jawaban dan penjelasan langkah demi langkah.", color = Muted, fontSize = 12.sp)

            Spacer(Modifier.height(14.dp))
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Mata pelajaran") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Red, unfocusedBorderColor = Color(0xFF393943),
                        focusedLabelColor = Red, cursorColor = Red
                    )
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    subjects.forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { subject = it; expanded = false })
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("PERCAKAPAN", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { messages.clear(); error = null }) {
                    Icon(Icons.Default.Add, null, tint = Red)
                    Text("Chat baru", color = Red, fontSize = 12.sp)
                }
            }

            Surface(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                color = Color(0xCC101017),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30303A))
            ) {
                if (messages.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(22.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("✦", color = Red, fontSize = 42.sp)
                        Text("Halo! Aku ON AI.", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Kirim soal atau pertanyaan sekolahmu. Aku akan membantu menjelaskan agar kamu memahami materinya.",
                            color = Muted, fontSize = 13.sp
                        )
                        Spacer(Modifier.height(14.dp))
                        Text("Contoh: Jelaskan keanekaragaman hayati.", color = Color(0xFFFF8996), fontSize = 12.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        reverseLayout = false,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        itemsIndexed(messages) { _, msg ->
                            val isUser = msg.role == "user"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                            ) {
                                Surface(
                                    color = if (isUser) Color(0xFF761328) else Color(0xFF20202A),
                                    shape = RoundedCornerShape(14.dp),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp, if (isUser) Color(0xFFB92B45) else Color(0xFF373743)
                                    ),
                                    modifier = Modifier.fillMaxWidth(0.9f)
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(
                                            if (isUser) "KAMU" else "ON AI MINI PRO",
                                            color = Color(0xFFFF8996), fontSize = 9.sp, fontWeight = FontWeight.Bold
                                        )
                                        Spacer(Modifier.height(5.dp))
                                        Text(msg.content, color = Color.White, fontSize = 13.sp, lineHeight = 19.sp)
                                    }
                                }
                            }
                        }
                        if (loading) item {
                            Text("ON AI sedang berpikir...", color = Red, fontSize = 12.sp)
                        }
                    }
                }
            }

            if (error != null) {
                Text(error!!, color = Color(0xFFFF8996), fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp))
            }

            Spacer(Modifier.height(10.dp))
            Surface(
                color = Panel,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF383843))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.weight(1f).padding(10.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = Brush.verticalGradient(listOf(Red, Red)),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            if (prompt.isNotBlank() && !loading) {
                                val q = prompt.trim()
                                prompt = ""
                                submitQuestion(q, subject, messages, scope, { loading = it }, { error = it })
                            }
                        }),
                        decorationBox = { inner ->
                            Box {
                                if (prompt.isEmpty()) Text("Ketik pertanyaan sekolah...", color = Muted, fontSize = 13.sp)
                                inner()
                            }
                        }
                    )
                    Button(
                        onClick = {
                            if (prompt.isNotBlank() && !loading) {
                                val q = prompt.trim()
                                prompt = ""
                                submitQuestion(q, subject, messages, scope, { loading = it }, { error = it })
                            }
                        },
                        enabled = !loading && prompt.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Color(0xFF64202B)),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Kirim", tint = Color.White)
                    }
                }
            }
            Text(
                "Gunakan sebagai teman belajar dan periksa kembali dengan buku pelajaran.",
                color = Color(0xFF777783), fontSize = 9.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

private fun submitQuestion(
    question: String,
    subject: String,
    messages: MutableList<ChatMessage>,
    scope: kotlinx.coroutines.CoroutineScope,
    setLoading: (Boolean) -> Unit,
    setError: (String?) -> Unit
) {
    messages.add(ChatMessage("user", question))
    setLoading(true)
    setError(null)
    scope.launch {
        try {
            val answer = ApiClient.ask(messages.toList(), subject)
            messages.add(ChatMessage("assistant", answer))
        } catch (e: Exception) {
            setError(e.message ?: "Gagal menghubungi server. Periksa koneksi.")
        } finally {
            setLoading(false)
        }
    }
}
