import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== IMPORT BUY ACCOUNT ====================
import 'buy_account.dart';

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;
  String? androidId;

  // Loading overlay
  bool _showLoadingOverlay = false;
  bool _showSuccess = false;
  String _loadingText = "Mengecek akun di database...";

  late VideoPlayerController _bgController;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    initLogin();

    _bgController = VideoPlayerController.asset('assets/videos/background.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _bgController.setLooping(true);
        _bgController.setVolume(0);
        _bgController.play();
      });

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
    _fadeController.forward();
  }

  @override
  void dispose() {
    _bgController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        "$baseUrl/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true && mounted) {
          Navigator.pushReplacementNamed(
            context,
            '/splash',
            arguments: {
              'username': savedUser,
              'password': savedPass,
              'role': data['role'],
              'key': data['key'],
              'expiredDate': data['expiredDate'],
              'listBug': data['listBug'] ?? [],
              'listPayload': data['listPayload'] ?? [],
              'listDDoS': data['listDDoS'] ?? [],
              'news': data['news'] ?? [],
            },
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }

    setState(() {
      isLoading = true;
      _showLoadingOverlay = true;
      _showSuccess = false;
      _loadingText = "Mengecek akun di database...";
    });

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/api/auth/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        setState(() {
          isLoading = false;
          _showLoadingOverlay = false;
        });
        _showAlert("⛔ Access Expired",
            "Your access has expired.\nPlease renew it.",
            showContact: true);
        return;
      } else if (validData['valid'] != true) {
        setState(() {
          isLoading = false;
          _showLoadingOverlay = false;
        });
        _showAlert("🚫 Login Failed", "Invalid username or password.",
            showContact: true);
        return;
      }

      // ===== 5 detik cek database =====
      await Future.delayed(const Duration(seconds: 5));

      if (!mounted) return;
      setState(() {
        _showSuccess = true;
        _loadingText = "Akun terdaftar";
      });

      await Future.delayed(const Duration(milliseconds: 900));

      final prefs = await SharedPreferences.getInstance();
      prefs.setString("username", username);
      prefs.setString("password", password);
      prefs.setString("key", validData['key']);

      if (mounted) {
        Navigator.pushReplacementNamed(
          context,
          '/splash',
          arguments: {
            'username': username,
            'password': password,
            'role': validData['role'],
            'key': validData['key'],
            'expiredDate': validData['expiredDate'],
            'listBug': validData['listBug'] ?? [],
            'listPayload': validData['listPayload'] ?? [],
            'listDDoS': validData['listDDoS'] ?? [],
            'news': validData['news'] ?? [],
          },
        );
      }
    } catch (_) {
      setState(() {
        isLoading = false;
        _showLoadingOverlay = false;
      });
      _showAlert("🌐 Connection Error", "Failed to connect to the server.");
    }
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: title.contains("Error") || title.contains("Failed")
                    ? const Color(0xFFFF6B8A)
                    : title.contains("Expired")
                        ? const Color(0xFFFFD700)
                        : MioColors.blue,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                title.contains("Error") || title.contains("Failed")
                    ? Icons.error_outline
                    : title.contains("Expired")
                        ? Icons.timer_off
                        : Icons.info_outline,
                color: MioColors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: MioColors.ink,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: TextStyle(
            color: MioColors.ink.withOpacity(0.7),
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Rajdhani',
          ),
        ),
        actions: [
          if (showContact)
            TextButton.icon(
              onPressed: () async {
                final uri = Uri.parse("tg://resolve?domain=RaldzzXyz");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(Uri.parse("https://t.me/Rizzisreal01"),
                      mode: LaunchMode.externalApplication);
                }
              },
              icon: const Icon(Icons.message, size: 16, color: MioColors.white),
              label: const Text(
                "Contact Admin",
                style: TextStyle(
                  color: MioColors.white,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
              style: TextButton.styleFrom(
                backgroundColor: MioColors.deepBlue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: MioColors.blue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: MioColors.white,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _goToBuyAccount() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const BuyAccountPage(),
      ),
    );
  }

  // ==================== GLASS INPUT ====================
  Widget _glassInput({
    required String hint,
    required TextEditingController controller,
    required IconData icon,
    bool isPassword = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: MioColors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: MioColors.white.withOpacity(0.35), width: 1.5),
      ),
      child: TextField(
        controller: controller,
        obscureText: isPassword,
        style: const TextStyle(
          color: MioColors.white,
          fontSize: 15,
          fontWeight: FontWeight.w600,
          fontFamily: 'Rajdhani',
        ),
        cursorColor: MioColors.white,
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: MioColors.white.withOpacity(0.85), size: 20),
          hintText: hint,
          hintStyle: TextStyle(
            color: MioColors.white.withOpacity(0.65),
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w600,
          ),
          filled: false,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
        ),
      ),
    );
  }

  // ==================== GLASS BUTTON ====================
  Widget _glassButton({
    required String label,
    required VoidCallback onTap,
    required Color bg,
    bool isLoading = false,
    IconData? icon,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: MioColors.deepBlue.withOpacity(0.35),
              offset: const Offset(0, 6),
              blurRadius: 14,
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    color: MioColors.white,
                    strokeWidth: 2.5,
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, color: MioColors.white, size: 18),
                      const SizedBox(width: 10),
                    ],
                    Text(
                      label,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.6,
                        color: MioColors.white,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  // ==================== LOADING OVERLAY ====================
  Widget _loadingOverlay() {
    return Positioned.fill(
      child: Container(
        color: MioColors.deepBlue.withOpacity(0.65),
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 34),
            margin: const EdgeInsets.symmetric(horizontal: 40),
            decoration: BoxDecoration(
              color: MioColors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border:
                  Border.all(color: MioColors.white.withOpacity(0.35), width: 1.5),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (!_showSuccess) ...[
                  const SizedBox(
                    width: 46,
                    height: 46,
                    child: CircularProgressIndicator(
                      color: MioColors.white,
                      strokeWidth: 3,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    _loadingText,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: MioColors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 1,
                    ),
                  ),
                ] else ...[
                  const Icon(
                    Icons.verified_rounded,
                    color: MioColors.lightBlue,
                    size: 56,
                  ),
                  const SizedBox(height: 14),
                  Text(
                    _loadingText,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: MioColors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          // ===== BACKGROUND VIDEO FULLSCREEN =====
          Positioned.fill(
            child: _bgController.value.isInitialized
                ? SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _bgController.value.size.width,
                        height: _bgController.value.size.height,
                        child: VideoPlayer(_bgController),
                      ),
                    ),
                  )
                : Container(color: MioColors.deepBlue),
          ),

          // ===== DARK OVERLAY =====
          Positioned.fill(
            child: Container(
              color: MioColors.deepBlue.withOpacity(0.55),
            ),
          ),

          // ===== CONTENT (FIXED, NO SCROLL) =====
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // ===== BACK BUTTON =====
                    Align(
                      alignment: Alignment.centerLeft,
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pushReplacementNamed(context, '/');
                        },
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: MioColors.white.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: MioColors.white.withOpacity(0.35),
                                width: 1.5),
                          ),
                          child: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            color: MioColors.white,
                            size: 18,
                          ),
                        ),
                      ),
                    ),

                    const Spacer(flex: 2),

                    // ===== HEADER =====
                    const Text(
                      "ENTER TO",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: MioColors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 3,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "USERNAME & PASSWORD",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: MioColors.white.withOpacity(0.85),
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 2,
                      ),
                    ),

                    const SizedBox(height: 40),

                    // ===== USERNAME =====
                    _glassInput(
                      hint: "USERNAME",
                      controller: userController,
                      icon: Icons.person_outline_rounded,
                    ),
                    const SizedBox(height: 16),

                    // ===== PASSWORD =====
                    _glassInput(
                      hint: "PASSWORD",
                      controller: passController,
                      icon: Icons.lock_outline_rounded,
                      isPassword: true,
                    ),

                    const SizedBox(height: 28),

                    // ===== LOGIN BUTTON =====
                    _glassButton(
                      label: "LOGIN TO APK",
                      icon: Icons.login_rounded,
                      onTap: login,
                      bg: MioColors.deepBlue,
                      isLoading: isLoading,
                    ),

                    const SizedBox(height: 28),

                    // ===== BELUM PUNYA AKSES =====
                    Center(
                      child: Text(
                        "BELUM PUNYA AKSES?",
                        style: TextStyle(
                          color: MioColors.white.withOpacity(0.85),
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 2,
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // ===== BUY ACCOUNT BUTTON =====
                    _glassButton(
                      label: "BUY ACCOUNT",
                      icon: Icons.shopping_cart_outlined,
                      onTap: _goToBuyAccount,
                      bg: MioColors.blue,
                    ),

                    const Spacer(flex: 2),
                  ],
                ),
              ),
            ),
          ),

          // ===== LOADING OVERLAY =====
          if (_showLoadingOverlay) _loadingOverlay(),
        ],
      ),
    );
  }
}