import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'login_page.dart';

// ==================== HAIMIYA MIO PALETTE (SILVER / BLUE) ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color telegram = Color(0xFF4A90D9);
  static const Color whatsapp = Color(0xFF3FAE6B);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  late VideoPlayerController _videoController;

  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  void _navigateToLogin() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const LoginPage()),
    );
  }

  Future<void> _launchUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  // ==================== REUSABLE UI HELPERS (MODERN) ====================

  Widget _modernCard({
    required Widget child,
    Color bg = MioColors.white,
    EdgeInsets padding = const EdgeInsets.all(18),
    double radius = 18,
  }) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.10),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _primaryButton({
    required String label,
    required VoidCallback onTap,
    IconData? icon,
    Color bg = MioColors.deepBlue,
    Color fg = MioColors.white,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: MioColors.deepBlue.withOpacity(0.35),
              offset: const Offset(0, 6),
              blurRadius: 14,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, color: fg, size: 20),
              const SizedBox(width: 10),
            ],
            Text(
              label,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.6,
                color: fg,
                fontFamily: 'Rajdhani',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _socialTile({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.35),
                offset: const Offset(0, 4),
                blurRadius: 10,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: MioColors.white, size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: MioColors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.ice,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(18, 22, 18, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ===== PROFILE CARD (BG IMAGE) =====
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  image: const DecorationImage(
                    image: AssetImage('assets/images/background.png'),
                    fit: BoxFit.cover,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: MioColors.deepBlue.withOpacity(0.15),
                      offset: const Offset(0, 6),
                      blurRadius: 16,
                    ),
                  ],
                ),
                child: Center(
                  child: Container(
                    width: 96,
                    height: 96,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: MioColors.deepBlue, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: MioColors.deepBlue.withOpacity(0.25),
                          offset: const Offset(0, 6),
                          blurRadius: 16,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/profil.jpg',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: MioColors.silver,
                          child: const Icon(
                            Icons.person,
                            size: 44,
                            color: MioColors.deepBlue,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 18),

              // ===== VIDEO BANNER =====
              Container(
                width: double.infinity,
                height: 210,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                      color: MioColors.deepBlue.withOpacity(0.20),
                      offset: const Offset(0, 8),
                      blurRadius: 18,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: _videoController.value.isInitialized
                      ? FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _videoController.value.size.width,
                            height: _videoController.value.size.height,
                            child: VideoPlayer(_videoController),
                          ),
                        )
                      : Container(
                          color: MioColors.lightBlue,
                          child: const Center(
                            child: CircularProgressIndicator(
                              color: MioColors.deepBlue,
                              strokeWidth: 3,
                            ),
                          ),
                        ),
                ),
              ),

              const SizedBox(height: 24),

              // ===== TITLE RZYN + INFO App =====
              Column(
                children: [
                  const Text(
                    "R Z Y N",
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      color: MioColors.deepBlue,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 6,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: MioColors.blue,
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: MioColors.blue.withOpacity(0.35),
                          offset: const Offset(0, 3),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.info_outline_rounded,
                          size: 14,
                          color: MioColors.white,
                        ),
                        SizedBox(width: 6),
                        Text(
                          "INFO App",
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: MioColors.white,
                            letterSpacing: 2,
                            fontFamily: 'Rajdhani',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 22),

              // ===== INFO CARD =====
              _modernCard(
                bg: MioColors.white,
                child: const Text(
                  "App RZYN di buat secara niat memulai dari Juli tanggal 20 2026 selalu Support Tu Tim RZYN",
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: MioColors.ink,
                    height: 1.6,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ),

              const SizedBox(height: 22),

              // ===== ENTER TO LOGIN =====
              _primaryButton(
                label: "ENTER TO LOGIN",
                icon: Icons.login_rounded,
                onTap: _navigateToLogin,
                bg: MioColors.deepBlue,
              ),

              const SizedBox(height: 28),

              // ===== FOLLOW TO TIM RZYN =====
              const Center(
                child: Text(
                  "FOLLOW TO TIM RZYN",
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: MioColors.deepBlue,
                    letterSpacing: 3,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // ===== SOCIAL CARD =====
              _modernCard(
                bg: MioColors.white,
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    _socialTile(
                      icon: Icons.telegram,
                      label: "Telegram",
                      color: MioColors.telegram,
                      onTap: () => _launchUrl("https://t.me/RXTcommunitygen1"),
                    ),
                    const SizedBox(width: 12),
                    _socialTile(
                      icon: Icons.message_outlined,
                      label: "WhatsApp",
                      color: MioColors.whatsapp,
                      onTap: () => _launchUrl(
                        "https://whatsapp.com/channel/0029VbC6tAE4yltIJOYGCS1e",
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}