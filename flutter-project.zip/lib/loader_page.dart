// RZYN by @Rizzisreal01
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'package:xml/xml.dart';
import 'package:glaze_nav_bar/glaze_nav_bar.dart';
import 'dart:io';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== IMPORTS HALAMAN ====================
import 'tols/telegram.dart';
import 'admin/admin_page.dart';
import 'admin/seller_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'menu/menu.dart';
import 'rat/devices_panel.dart';
import 'tols/ddos_panel.dart';
import 'sender_page.dart';
import 'spams_page.dart';
import 'spam/spam_otp.dart';
import 'public_page.dart';
import 'profile_page.dart';

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const SizedBox.shrink();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final PageController _mediaPageController =
      PageController(viewportFraction: 0.92);
  final PageController _newsPageController =
      PageController(viewportFraction: 0.92);

  int _currentMediaIndex = 0;
  int _currentNewsIndex = 0;

  Timer? _mediaAutoSlideTimer;
  Timer? _newsAutoSlideTimer;

  List<Map<String, dynamic>> _activityLogs = [];
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  VideoPlayerController? _videoController;
  bool _isVideoInitialized = false;

  int _totalUsers = 0;
  int _senderActive = 0;
  bool _isLoadingStats = false;

  // ===== BATERAI & DEVICE =====
  final Battery _battery = Battery();
  int _batteryLevel = 0;
  String _androidVersion = '-';
  String _androidModel = '-';
  StreamSubscription<BatteryState>? _batteryStateSub;

  // ===== BERITA RSS =====
  List<Map<String, String>> _rssNews = [];
  bool _isLoadingRss = false;

  // ===== MEDIA =====
  final List<Map<String, dynamic>> _mediaItems = [
    {
      'image': 'https://files.catbox.moe/nl8u02.jpeg',
      'title': 'NEW UI TAMPILAN 2026',
      'desc': 'spesial dev @Rizzisreal01',
    },
    {
      'image': 'https://files.catbox.moe/k85urd.jpeg',
      'title': 'UPDATE BUG GACOR 2026',
      'desc': 'main project 1 X•Miyabi',
    },
  ];

  // ===== BTC =====
  final List<double> _btcPrices = [];
  double _currentBTCPrice = 118240.34;
  double _btcHigh = 118240.34;
  double _btcLow = 118240.34;
  double _btcVolume = 42133.45;
  double _btcFunding = 0.0064;
  String _btcChange = '+0.00';
  bool _isPriceUp = true;
  Timer? _btcTimer;
  final Random _random = Random();

  // ===== AUDIO =====
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isMusicPlaying = false;
  String _currentMusicTitle = '';
  int _currentMusicIndex = 0;
  late AnimationController _spinController;

  final List<Map<String, String>> _musicList = [
    {
      'title': 'BIRDS OF A FEATHER',
      'url':
          'https://www.image2url.com/r2/default/audio/1782960521468-e6386e2c-a1c7-4ebc-836a-1131829870f3.mp3'
    },
    {
      'title': 'The one that got',
      'url':
          'https://cdn.imageurlgenerator.com/uploads/eaee7c37-6ea8-4d43-bf69-88dd63621169.mp3'
    },
    {
      'title': 'Hindia',
      'url':
          'https://cdn.imageurlgenerator.com/uploads/5d3d9c92-aa68-472b-aeab-5c511a8a6af6.mp3'
    },
    {
      'title': 'Blank Space',
      'url':
          'https://www.image2url.com/r2/default/audio/1787296942224-7376e10b-8c1e-4a89-b6bf-c95d077e9bcc.m4a'
    },
  ];

  // ===== TYPING =====
  String _displayText = '';
  int _typingIndex = 0;
  Timer? _typingTimer;
  final String _fullText = 'RZYN';
  bool _isTypingForward = true;

  File? _profileImage;

  String _currentTime = '';
  Timer? _clockTimer;

  // ==================== ROLE GUARD ====================
  static const List<String> _adminRoles = [
    'dev',
    'high_pt',
    'pt',
    'helper',
    'admin',
  ];

  static const List<String> _resellerRoles = [
    'dev',
    'high_pt',
    'pt',
    'helper',
    'admin',
    'reseller',
  ];

  bool get _canAccessAdminPage =>
      _adminRoles.contains(role.toLowerCase().trim());

  bool get _canAccessResellerPage =>
      _resellerRoles.contains(role.toLowerCase().trim());

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation =
        CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _controller.forward();

    _spinController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat();

    _selectedPage = _buildHomePage();

    _initAndroidIdAndConnect();
    _fetchActivityLogs();
    _initializeVideo();
    _fetchStats();
    _startMediaAutoSlide();
    _startNewsAutoSlide();
    _initBTCChart();
    _startTypingAnimation();
    _loadProfileImage();
    _startClock();
    _fetchRssNews();
    _initBatteryAndDevice();

    _audioPlayer.onPlayerComplete.listen((event) {
      _playNextMusic();
    });
  }

  // ==================== BATTERY & DEVICE ====================
  Future<void> _initBatteryAndDevice() async {
    try {
      final level = await _battery.batteryLevel;
      final android = await DeviceInfoPlugin().androidInfo;
      if (mounted) {
        setState(() {
          _batteryLevel = level;
          _androidVersion = 'Android ${android.version.release}';
          _androidModel = android.model;
        });
      }
      _batteryStateSub = _battery.onBatteryStateChanged.listen((state) async {
        final lvl = await _battery.batteryLevel;
        if (mounted) setState(() => _batteryLevel = lvl);
      });
    } catch (e) {
      print('Battery/Device error: $e');
    }
  }

  // ==================== RSS ====================
  Future<void> _fetchRssNews() async {
    setState(() => _isLoadingRss = true);
    try {
      final res = await http.get(
        Uri.parse('https://feed.liputan6.com/rss/news'),
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36',
        },
      );
      if (res.statusCode == 200) {
        final doc = XmlDocument.parse(res.body);
        final items = doc.findAllElements('item');
        final List<Map<String, String>> parsed = [];
        for (final item in items.take(15)) {
          final title = item.findElements('title').firstOrNull?.text ?? '';
          final link = item.findElements('link').firstOrNull?.text ?? '';
          final desc = item.findElements('description').firstOrNull?.text ?? '';
          final media = item
                  .findElements('media:content')
                  .firstOrNull
                  ?.getAttribute('url') ??
              item
                  .findElements('enclosure')
                  .firstOrNull
                  ?.getAttribute('url') ??
              '';
          final image = media.isNotEmpty ? media : _extractImage(desc);
          parsed.add({'title': title, 'link': link, 'image': image});
        }
        if (mounted) setState(() => _rssNews = parsed);
      }
    } catch (e) {
      print('RSS error: $e');
    }
    if (mounted) setState(() => _isLoadingRss = false);
  }

  String _extractImage(String html) {
    final match = RegExp(r'<img[^>]+src="([^"]+)"').firstMatch(html);
    return match?.group(1) ?? '';
  }

  // ==================== LOAD PROFILE ====================
  Future<void> _loadProfileImage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final imagePath = prefs.getString('profile_image_${widget.username}');
      if (imagePath != null && imagePath.isNotEmpty) {
        final file = File(imagePath);
        if (await file.exists()) {
          setState(() => _profileImage = file);
        }
      }
    } catch (e) {
      print('Error loading profile image: $e');
    }
  }

  // ==================== CLOCK ====================
  void _startClock() {
    _updateClock();
    _clockTimer =
        Timer.periodic(const Duration(seconds: 1), (_) => _updateClock());
  }

  void _updateClock() {
    final now = DateTime.now();
    final time =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
    if (mounted) setState(() => _currentTime = time);
  }

  // ==================== TYPING ====================
  void _startTypingAnimation() {
    _typingTimer?.cancel();
    _typingIndex = 0;
    _displayText = '';
    _isTypingForward = true;

    _typingTimer = Timer.periodic(const Duration(milliseconds: 400), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        if (_isTypingForward) {
          _typingIndex++;
          _displayText = _fullText.substring(0, _typingIndex);
          if (_typingIndex >= _fullText.length) _isTypingForward = false;
        } else {
          _typingIndex--;
          _displayText = _fullText.substring(0, _typingIndex);
          if (_typingIndex <= 0) _isTypingForward = true;
        }
      });
    });
  }

  // ==================== AUDIO ====================
  void _playMusic(int index) async {
    if (index < 0 || index >= _musicList.length) return;
    try {
      await _audioPlayer.stop();
      _currentMusicIndex = index;
      _currentMusicTitle = _musicList[index]['title'] ?? '';
      await _audioPlayer.play(UrlSource(_musicList[index]['url']!));
      setState(() => _isMusicPlaying = true);
    } catch (e) {
      print('Error playing music: $e');
    }
  }

  void _playNextMusic() {
    final next = (_currentMusicIndex + 1) % _musicList.length;
    _playMusic(next);
  }

  void _toggleMusic() {
    if (_isMusicPlaying) {
      _audioPlayer.stop();
      setState(() => _isMusicPlaying = false);
    } else {
      if (_currentMusicTitle.isEmpty) {
        _playMusic(0);
      } else {
        _playMusic(_currentMusicIndex);
      }
    }
  }

  void _showMusicMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: MioColors.ice,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '🎵 Pilih Lagu',
              style: TextStyle(
                color: MioColors.ink,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                fontFamily: 'Rajdhani',
              ),
            ),
            const SizedBox(height: 16),
            ..._musicList.asMap().entries.map((entry) {
              final idx = entry.key;
              final music = entry.value;
              final isActive = _isMusicPlaying && _currentMusicIndex == idx;
              return ListTile(
                onTap: () {
                  Navigator.pop(context);
                  _playMusic(idx);
                },
                leading: Icon(
                  isActive ? Icons.play_circle : Icons.music_note,
                  color: isActive ? MioColors.deepBlue : MioColors.softInk,
                ),
                title: Text(
                  music['title'] ?? '',
                  style: TextStyle(
                    color: isActive ? MioColors.deepBlue : MioColors.ink,
                    fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
                    fontFamily: 'Rajdhani',
                  ),
                ),
                trailing: isActive
                    ? const Icon(Icons.graphic_eq, color: MioColors.green)
                    : null,
              );
            }),
          ],
        ),
      ),
    );
  }

  // ==================== BTC ====================
  void _initBTCChart() {
    _btcPrices.clear();
    double price = 118240.34;
    double trend = 0;
    for (int i = 0; i < 100; i++) {
      trend += (_random.nextDouble() - 0.5) * 20;
      trend = trend.clamp(-40, 40);
      price += trend + (_random.nextDouble() - 0.5) * 30;
      if (price < 115000) price = 115000 + _random.nextDouble() * 300;
      if (price > 122000) price = 122000 - _random.nextDouble() * 300;
      _btcPrices.add(price);
    }
    _currentBTCPrice = _btcPrices.last;
    _btcHigh = _btcPrices.reduce(max);
    _btcLow = _btcPrices.reduce(min);

    _btcTimer = Timer.periodic(const Duration(milliseconds: 100), (_) {
      _updateBTCChart();
    });
  }

  void _updateBTCChart() {
    final momentum = (_random.nextDouble() - 0.5) * 40;
    final volatility = 25 + _random.nextDouble() * 40;
    double newPrice =
        _currentBTCPrice + momentum + (_random.nextDouble() - 0.5) * volatility;
    if (newPrice < 115000) newPrice = 115000 + _random.nextDouble() * 150;
    if (newPrice > 122000) newPrice = 122000 - _random.nextDouble() * 150;
    newPrice += (_random.nextDouble() - 0.5) * 3;

    _btcPrices.add(newPrice);
    if (_btcPrices.length > 250) _btcPrices.removeAt(0);
    _currentBTCPrice = newPrice;
    if (newPrice > _btcHigh) _btcHigh = newPrice;
    if (newPrice < _btcLow) _btcLow = newPrice;

    if (_btcPrices.length > 10) {
      final old = _btcPrices[_btcPrices.length - 10];
      final change = ((newPrice - old) / old) * 100;
      _isPriceUp = change >= 0;
      _btcChange = (change >= 0 ? '+' : '') + change.toStringAsFixed(2);
    }
    _btcVolume += (_random.nextDouble() - 0.5) * 60;
    _btcVolume = _btcVolume.clamp(40000, 45000);
    _btcFunding += (_random.nextDouble() - 0.5) * 0.0004;
    _btcFunding = _btcFunding.clamp(0.005, 0.015);

    if (mounted) setState(() {});
  }

  // ==================== MEDIA SLIDE ====================
  void _startMediaAutoSlide() {
    _mediaAutoSlideTimer?.cancel();
    if (_mediaItems.length <= 1) return;
    _mediaAutoSlideTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (!mounted) return timer.cancel();
      setState(() {
        _currentMediaIndex = (_currentMediaIndex + 1) % _mediaItems.length;
        _mediaPageController.animateToPage(
          _currentMediaIndex,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      });
    });
  }

  void _startNewsAutoSlide() {
    _newsAutoSlideTimer?.cancel();
    if (newsList.length <= 1) return;
    _newsAutoSlideTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (!mounted) return timer.cancel();
      setState(() {
        _currentNewsIndex = (_currentNewsIndex + 1) % newsList.length;
        _newsPageController.animateToPage(
          _currentNewsIndex,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      });
    });
  }

  // ==================== STATS ====================
  Future<void> _fetchStats() async {
    setState(() => _isLoadingStats = true);
    try {
      final userRes = await http.get(
        Uri.parse('$baseUrl/api/user/listUsers?key=$sessionKey'),
      );
      if (userRes.statusCode == 200) {
        final d = jsonDecode(userRes.body);
        if (d['valid'] == true && d['users'] != null) {
          setState(() => _totalUsers = d['users'].length);
        }
      }
      final senderRes = await http.get(
        Uri.parse('$baseUrl/api/whatsapp/mySender?key=$sessionKey'),
      );
      if (senderRes.statusCode == 200) {
        final d = jsonDecode(senderRes.body);
        if (d['valid'] == true && d['senders'] != null) {
          setState(() => _senderActive = d['senders'].length);
        }
      }
    } catch (e) {
      print('Error fetching stats: $e');
    }
    if (mounted) setState(() => _isLoadingStats = false);
  }

  // ==================== VIDEO ====================
  void _initializeVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/banerUi.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _isVideoInitialized = true);
        _videoController?.setLooping(true);
        _videoController?.setVolume(1.0);
        _videoController?.play();
      }).catchError((_) {
        if (mounted) setState(() => _isVideoInitialized = false);
      });
  }

  // ==================== WEBSOCKET ====================
  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('$baseUrl'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession(
                "Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
    }, onError: (_) {});
  }

  Future<void> _fetchActivityLogs() async {
    setState(() {
      _isLoadingActivityLogs = true;
      _hasActivityLogsError = false;
    });
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/api/user/getActivityLogs?key=$sessionKey'),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['logs'] != null) {
          setState(() {
            _activityLogs = List<Map<String, dynamic>>.from(data['logs']);
            _isLoadingActivityLogs = false;
          });
        } else {
          setState(() {
            _isLoadingActivityLogs = false;
            _hasActivityLogsError = true;
          });
        }
      } else {
        setState(() {
          _isLoadingActivityLogs = false;
          _hasActivityLogsError = true;
        });
      }
    } catch (e) {
      setState(() {
        _isLoadingActivityLogs = false;
        _hasActivityLogsError = true;
      });
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text("⚠️ Session Expired",
            style: TextStyle(
                color: MioColors.ink,
                fontWeight: FontWeight.w800,
                fontFamily: 'Rajdhani')),
        content: Text(message,
            style: const TextStyle(
                color: MioColors.softInk, fontFamily: 'Rajdhani')),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            style: TextButton.styleFrom(backgroundColor: MioColors.deepBlue),
            child: const Text("OK",
                style: TextStyle(
                    color: MioColors.white,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Rajdhani')),
          ),
        ],
      ),
    );
  }

  // ==================== TAB ====================
  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
      _controller.reset();
      _controller.forward();
      if (index == 0) {
        _selectedPage = _buildHomePage();
      } else if (index == 1) {
        _selectedPage = SpamOtpPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        );
      } else if (index == 2) {
        _selectedPage = MenuPage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          role: role,
          expiredDate: expiredDate,
          listBug: listBug,
          listPayload: listPayload,
        );
      } else if (index == 3) {
        _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role);
      } else if (index == 4) {
        _selectedPage = ProfilePage(
          username: username,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      }
    });
  }

  void _selectFromDrawer(String page) {
    Navigator.pop(context);

    // ===== GUARD ADMIN PAGE =====
    if (page == 'admin' && !_canAccessAdminPage) {
      _showNoAccess('ADMIN PAGE');
      return;
    }

    // ===== GUARD RESELLER PAGE =====
    if (page == 'reseller' && !_canAccessResellerPage) {
      _showNoAccess('RESELLER PAGE');
      return;
    }

    setState(() {
      if (page == 'reseller') {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (page == 'admin') {
        _selectedPage = AdminPage(sessionKey: sessionKey, role: role);
      } else if (page == 'sender') {
        _selectedPage = SenderPage(sessionKey: sessionKey);
      } else if (page == 'rat') {
        _selectedPage = DevicesPanelPage(
          username: username,
          sessionKey: sessionKey,
          role: role,
        );
      }
    });
  }

  // ===== POPUP NO ACCESS =====
  void _showNoAccess(String pageName) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: MioColors.red.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.lock_rounded,
                color: MioColors.red,
                size: 18,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                pageName,
                style: const TextStyle(
                  color: MioColors.ink,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Rajdhani',
                  fontSize: 14,
                ),
              ),
            ),
          ],
        ),
        content: Text(
          'Role "${role.toUpperCase()}" tidak punya akses ke halaman ini.',
          style: const TextStyle(
            color: MioColors.softInk,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: MioColors.deepBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              "OK",
              style: TextStyle(
                color: MioColors.white,
                fontWeight: FontWeight.w800,
                fontFamily: 'Rajdhani',
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== CARD HELPERS ====================
  Widget _mioCard({
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(16),
    double radius = 16,
    Color bg = MioColors.white,
    double shadow = 4,
    EdgeInsets? margin,
  }) {
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.15),
            offset: Offset(0, shadow),
            blurRadius: 12,
          ),
        ],
      ),
      child: child,
    );
  }

  Color _getRoleColor() {
    switch (role.toLowerCase()) {
      case 'dev':
        return MioColors.red;
      case 'high_pt':
        return const Color(0xFF9333EA);
      case 'pt':
        return const Color(0xFF7C3AED);
      case 'helper':
        return MioColors.green;
      case 'admin':
        return MioColors.blue;
      case 'reseller':
        return MioColors.yellow;
      case 'vip':
        return const Color(0xFFF59E0B);
      case 'member':
        return MioColors.softInk;
      default:
        return MioColors.softInk;
    }
  }

  // ==================== MY ACCOUNT CARD ====================
  Widget _buildMyAccountCard() {
    return _mioCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: MioColors.deepBlue, width: 3),
              boxShadow: [
                BoxShadow(
                  color: MioColors.deepBlue.withValues(alpha: 0.25),
                  offset: const Offset(0, 6),
                  blurRadius: 12,
                ),
              ],
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : Image.asset(
                      'assets/images/profil.jpg',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: MioColors.silver,
                        child: const Icon(Icons.person,
                            color: MioColors.deepBlue, size: 40),
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildAccountField('USERNAME', username),
              Container(width: 1, height: 36, color: MioColors.silver),
              _buildAccountField('ROLE', role.toUpperCase(),
                  color: _getRoleColor()),
              Container(width: 1, height: 36, color: MioColors.silver),
              _buildAccountField(
                  'MASA AKTIF', expiredDate.split(' ').first),
            ],
          ),
          const SizedBox(height: 14),
          Container(height: 1, color: MioColors.silver),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Row(
                children: [
                  Icon(
                    _batteryLevel > 80
                        ? Icons.battery_full
                        : _batteryLevel > 40
                            ? Icons.battery_5_bar
                            : Icons.battery_2_bar,
                    color: MioColors.green,
                    size: 18,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'Baterai: $_batteryLevel%',
                    style: const TextStyle(
                      color: MioColors.ink,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  const Icon(Icons.android, color: MioColors.green, size: 18),
                  const SizedBox(width: 6),
                  Text(
                    _androidVersion,
                    style: const TextStyle(
                      color: MioColors.ink,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAccountField(String label, String value, {Color? color}) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: MioColors.softInk,
            fontSize: 9,
            fontWeight: FontWeight.w700,
            fontFamily: 'Rajdhani',
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: color ?? MioColors.deepBlue,
            fontSize: 13,
            fontWeight: FontWeight.w900,
            fontFamily: 'Rajdhani',
          ),
        ),
      ],
    );
  }

  // ==================== VIDEO CARD ====================
  Widget _buildVideoCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Stack(
        alignment: Alignment.center,
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: _isVideoInitialized && _videoController != null
                ? VideoPlayer(_videoController!)
                : Container(
                    color: MioColors.silver,
                    child: const Center(
                      child: CircularProgressIndicator(
                        color: MioColors.deepBlue,
                        strokeWidth: 2,
                      ),
                    ),
                  ),
          ),
          Positioned.fill(
            child: Center(
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: MioColors.deepBlue.withValues(alpha: 0.7),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text(
                  'BUG X RAT',
                  style: TextStyle(
                    color: MioColors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 3,
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 12,
            right: 12,
            child: GestureDetector(
              onTap: () {
                if (_videoController == null) return;
                setState(() {
                  if (_videoController!.value.isPlaying) {
                    _videoController!.pause();
                  } else {
                    _videoController!.play();
                  }
                });
              },
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: MioColors.white.withValues(alpha: 0.9),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _videoController?.value.isPlaying ?? false
                      ? Icons.pause
                      : Icons.play_arrow,
                  color: MioColors.deepBlue,
                  size: 20,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== SERVER / STATUS / DATA CARD ====================
  Widget _buildServerStatusCard() {
    return _mioCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildServerItem(
            icon: Icons.dns_rounded,
            label: 'SERVER',
            value: 'AKTIF',
            color: MioColors.green,
          ),
          Container(width: 1, height: 40, color: MioColors.silver),
          _buildServerItem(
            icon: Icons.verified_user_rounded,
            label: 'STATUS',
            value: 'AMAN',
            color: MioColors.green,
          ),
          Container(width: 1, height: 40, color: MioColors.silver),
          _buildServerItem(
            icon: Icons.storage_rounded,
            label: 'DATA',
            value: 'BACKUP',
            color: MioColors.deepBlue,
          ),
        ],
      ),
    );
  }

  Widget _buildServerItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: const TextStyle(
            color: MioColors.softInk,
            fontSize: 9,
            fontWeight: FontWeight.w700,
            fontFamily: 'Rajdhani',
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 11,
            fontWeight: FontWeight.w900,
            fontFamily: 'Rajdhani',
          ),
        ),
      ],
    );
  }

  // ==================== PANEL & VPS ====================
  Widget _buildPanelVpsCard() {
    return Row(
      children: [
        Expanded(
          child: _buildStatusCard(
            title: 'PANEL',
            status: 'ONLINE',
            detail: 'RAM: 5.7GB',
            color: MioColors.green,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildStatusCard(
            title: 'VPS',
            status: 'ONLINE',
            detail: 'CPU: ${(_random.nextInt(60) + 20)}%',
            color: MioColors.blue,
          ),
        ),
      ],
    );
  }

  Widget _buildStatusCard({
    required String title,
    required String status,
    required String detail,
    required Color color,
  }) {
    return _mioCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: MioColors.ink,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              fontFamily: 'Rajdhani',
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                        color: color.withValues(alpha: 0.5), blurRadius: 6),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Text(
                status,
                style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            detail,
            style: const TextStyle(
              color: MioColors.softInk,
              fontSize: 10,
              fontWeight: FontWeight.w600,
              fontFamily: 'Rajdhani',
            ),
          ),
        ],
      ),
    );
  }

  // ==================== STATS CARD ====================
  Widget _buildStatsCard() {
    return Row(
      children: [
        Expanded(
          child: _mioCard(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text(
                  'TOTAL USER',
                  style: TextStyle(
                    color: MioColors.softInk,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _isLoadingStats ? '...' : '$_totalUsers',
                  style: const TextStyle(
                    color: MioColors.deepBlue,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _mioCard(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text(
                  'SENDER',
                  style: TextStyle(
                    color: MioColors.softInk,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _isLoadingStats ? '...' : '$_senderActive',
                  style: const TextStyle(
                    color: MioColors.deepBlue,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ==================== RSS NEWS ====================
  Widget _buildRssNews() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'BERITA TERKINI',
            style: TextStyle(
              color: MioColors.ink,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              fontFamily: 'Rajdhani',
              letterSpacing: 1.5,
            ),
          ),
        ),
        const SizedBox(height: 10),
        if (_isLoadingRss)
          _mioCard(
            padding: const EdgeInsets.all(20),
            child: const Center(
              child: CircularProgressIndicator(color: MioColors.deepBlue),
            ),
          )
        else if (_rssNews.isEmpty)
          _mioCard(
            padding: const EdgeInsets.all(20),
            child: const Center(
              child: Text(
                'Tidak ada berita',
                style:
                    TextStyle(color: MioColors.softInk, fontFamily: 'Rajdhani'),
              ),
            ),
          )
        else
          SizedBox(
            height: 185,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: _rssNews.length,
              itemBuilder: (context, index) {
                final item = _rssNews[index];
                final imgUrl = item['image'] ?? '';
                return GestureDetector(
                  onTap: () async {
                    final uri = Uri.parse(item['link'] ?? '');
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri,
                          mode: LaunchMode.externalApplication);
                    }
                  },
                  child: Container(
                    width: 170,
                    margin: const EdgeInsets.only(right: 12),
                    child: _mioCard(
                      padding: EdgeInsets.zero,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: imgUrl.isNotEmpty
                                  ? Image.network(
                                      imgUrl,
                                      fit: BoxFit.cover,
                                      headers: const {
                                        'User-Agent':
                                            'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
                                      },
                                      loadingBuilder:
                                          (context, child, progress) {
                                        if (progress == null) return child;
                                        return Container(
                                          color: MioColors.silver,
                                          child: const Center(
                                            child: SizedBox(
                                              width: 20,
                                              height: 20,
                                              child:
                                                  CircularProgressIndicator(
                                                color: MioColors.deepBlue,
                                                strokeWidth: 2,
                                              ),
                                            ),
                                          ),
                                        );
                                      },
                                      errorBuilder: (_, __, ___) => Container(
                                        color: MioColors.silver,
                                        child: const Center(
                                          child: Icon(
                                            Icons.broken_image,
                                            color: MioColors.softInk,
                                            size: 28,
                                          ),
                                        ),
                                      ),
                                    )
                                  : Container(
                                      color: MioColors.silver,
                                      child: const Center(
                                        child: Icon(
                                          Icons.image,
                                          color: MioColors.softInk,
                                          size: 28,
                                        ),
                                      ),
                                    ),
                            ),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 8),
                              color: Colors.black,
                              child: Text(
                                item['title'] ?? '',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Rajdhani',
                                  height: 1.3,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  // ==================== MEDIA ====================
  Widget _buildMediaCarousel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'Media',
            style: TextStyle(
              color: MioColors.ink,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              fontFamily: 'Rajdhani',
              letterSpacing: 1.5,
            ),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 170,
          child: PageView.builder(
            controller: _mediaPageController,
            itemCount: _mediaItems.length,
            onPageChanged: (i) => setState(() => _currentMediaIndex = i),
            itemBuilder: (context, index) {
              final item = _mediaItems[index];
              return _mioCard(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                padding: EdgeInsets.zero,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        item['image'] ?? '',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) =>
                            Container(color: MioColors.silver),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              MioColors.deepBlue.withValues(alpha: 0.8),
                              Colors.transparent,
                            ],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 12,
                        left: 12,
                        right: 12,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['title'] ?? '',
                              style: const TextStyle(
                                color: MioColors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                            Text(
                              item['desc'] ?? '',
                              style: TextStyle(
                                color:
                                    MioColors.white.withValues(alpha: 0.85),
                                fontSize: 11,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ==================== QUICK ACTIONS ====================
  Widget _buildQuickActions() {
    final actions = <Map<String, dynamic>>[
      // ===== ADMIN PAGE: dev, high_pt, pt, helper, admin =====
      if (_canAccessAdminPage)
        {
          'icon': Icons.admin_panel_settings,
          'title': 'Admin Page',
          'subtitle': 'Full control panel',
          'color': const Color(0xFFD32F2F),
          'onTap': () => setState(() {
                _selectedPage = AdminPage(sessionKey: sessionKey, role: role);
              }),
        },
      // ===== RESELLER PAGE: dev, high_pt, pt, helper, admin, reseller =====
      if (_canAccessResellerPage)
        {
          'icon': Icons.store,
          'title': 'Seller Page',
          'subtitle': 'Manage resellers',
          'color': const Color(0xFF2E86DE),
          'onTap': () => setState(() {
                _selectedPage = SellerPage(keyToken: sessionKey);
              }),
        },
      {
        'icon': FontAwesomeIcons.comments,
        'title': 'Public Chat',
        'subtitle': 'Community chat',
        'color': const Color(0xFF22A06B),
        'onTap': () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PublicChatPage(username: username),
              ),
            ),
      },
      {
        'icon': Icons.phone_android,
        'title': 'Sender',
        'subtitle': 'WA sender panel',
        'color': const Color(0xFFF59E0B),
        'onTap': () => setState(() {
              _selectedPage = SenderPage(sessionKey: sessionKey);
            }),
      },
      {
        'icon': FontAwesomeIcons.whatsapp,
        'title': 'WA Spam',
        'subtitle': 'Report WA spam',
        'color': const Color(0xFFEC4899),
        'onTap': () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ReportWaPage(
                  sessionKey: sessionKey,
                  username: username,
                  role: role,
                ),
              ),
            ),
      },
      {
        'icon': FontAwesomeIcons.telegram,
        'title': 'Group All Buyer',
        'subtitle': 'Join buyer group',
        'color': const Color(0xFF229ED9),
        'onTap': () async {
          final uri = Uri.parse("tg://resolve?domain=nullxteam");
          if (await canLaunchUrl(uri)) {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          } else {
            await launchUrl(Uri.parse("https://t.me/+I5F7uH-EfCBiMzdl"),
                mode: LaunchMode.externalApplication);
          }
        },
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'Quick Actions',
            style: TextStyle(
              color: MioColors.ink,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              fontFamily: 'Rajdhani',
              letterSpacing: 1.5,
            ),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 165,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: actions.length,
            itemBuilder: (context, index) {
              final a = actions[index];
              return Container(
                width: 240,
                margin: const EdgeInsets.only(right: 12),
                child: _buildQuickAccessCard(
                  icon: a['icon'],
                  title: a['title'],
                  subtitle: a['subtitle'],
                  color: a['color'],
                  onTap: a['onTap'],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildQuickAccessCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, color.withValues(alpha: 0.75)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.35),
              offset: const Offset(0, 8),
              blurRadius: 14,
            ),
          ],
        ),
        child: Stack(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.25),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: Colors.white, size: 22),
            ),
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.25),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'OPEN',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.85),
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== NEWS CAROUSEL ====================
  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'News',
            style: TextStyle(
              color: MioColors.ink,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              fontFamily: 'Rajdhani',
              letterSpacing: 1.5,
            ),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 170,
          child: PageView.builder(
            controller: _newsPageController,
            itemCount: newsList.length,
            onPageChanged: (i) => setState(() => _currentNewsIndex = i),
            itemBuilder: (context, index) {
              final item = newsList[index];
              final imageUrl = item['image'] ?? '';
              final title = item['title'] ?? 'Server Info';
              final desc = item['desc'] ?? '';
              return _mioCard(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                padding: EdgeInsets.zero,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (imageUrl.isNotEmpty)
                        Image.network(imageUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                Container(color: MioColors.silver))
                      else
                        Container(color: MioColors.silver),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              MioColors.deepBlue.withValues(alpha: 0.8),
                              Colors.transparent,
                            ],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 12,
                        left: 12,
                        right: 12,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: const TextStyle(
                                color: MioColors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                            Text(
                              desc,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color:
                                    MioColors.white.withValues(alpha: 0.85),
                                fontSize: 11,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ==================== RECENT ACTIVITY ====================
  Widget _buildRecentActivity() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Recent Activity',
              style: TextStyle(
                color: MioColors.ink,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                fontFamily: 'Rajdhani',
                letterSpacing: 1.5,
              ),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _selectedPage = _buildActivityLogsPage();
                });
              },
              style: TextButton.styleFrom(
                backgroundColor: MioColors.deepBlue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text(
                'View All',
                style: TextStyle(
                  color: MioColors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        if (_isLoadingActivityLogs)
          _mioCard(
            padding: const EdgeInsets.all(20),
            child: const Center(
              child: CircularProgressIndicator(color: MioColors.deepBlue),
            ),
          )
        else if (_hasActivityLogsError)
          _mioCard(
            padding: const EdgeInsets.all(20),
            child: const Center(
              child: Text(
                'Failed to load activity logs',
                style:
                    TextStyle(color: MioColors.softInk, fontFamily: 'Rajdhani'),
              ),
            ),
          )
        else if (_activityLogs.isEmpty)
          _mioCard(
            padding: const EdgeInsets.all(20),
            child: const Center(
              child: Text(
                'No activity logs',
                style:
                    TextStyle(color: MioColors.softInk, fontFamily: 'Rajdhani'),
              ),
            ),
          )
        else
          ..._activityLogs.take(3).map((log) {
            final timestamp =
                DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _mioCard(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _getActivityColor(log['activity'])
                            .withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(_getActivityIcon(log['activity']),
                          color: _getActivityColor(log['activity']), size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            log['activity'] ?? 'Unknown',
                            style: const TextStyle(
                              color: MioColors.ink,
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              fontFamily: 'Rajdhani',
                            ),
                          ),
                          if (log['details'] != null &&
                              log['details']['target'] != null)
                            Text(
                              'Target: ${log['details']['target']}',
                              style: const TextStyle(
                                color: MioColors.softInk,
                                fontSize: 11,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                        ],
                      ),
                    ),
                    Text(
                      _formatDateTime(timestamp),
                      style: const TextStyle(
                        color: MioColors.softInk,
                        fontSize: 11,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
      ],
    );
  }

  Widget _buildActivityLogsPage() {
    return RefreshIndicator(
      color: MioColors.deepBlue,
      backgroundColor: MioColors.ice,
      onRefresh: () async => _fetchActivityLogs(),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _activityLogs.length,
        itemBuilder: (context, index) {
          final log = _activityLogs[index];
          final timestamp =
              DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _mioCard(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(_getActivityIcon(log['activity']),
                          color: _getActivityColor(log['activity']), size: 18),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          log['activity'] ?? 'Unknown',
                          style: const TextStyle(
                            color: MioColors.ink,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Rajdhani',
                          ),
                        ),
                      ),
                      Text(
                        _formatDateTime(timestamp),
                        style: const TextStyle(
                          color: MioColors.softInk,
                          fontSize: 11,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Color _getActivityColor(String? activity) {
    if (activity == null) return MioColors.softInk;
    if (activity.contains('Bug') ||
        activity.contains('Attack') ||
        activity.contains('Delete') ||
        activity.contains('Failed')) return MioColors.red;
    if (activity.contains('Call')) return MioColors.yellow;
    if (activity.contains('Create') || activity.contains('Add'))
      return MioColors.green;
    if (activity.contains('Edit') || activity.contains('Change'))
      return MioColors.blue;
    if (activity.contains('Cooldown')) return const Color(0xFF9333EA);
    return MioColors.softInk;
  }

  IconData _getActivityIcon(String? activity) {
    if (activity == null) return Icons.info;
    if (activity.contains('Bug') || activity.contains('Attack'))
      return Icons.bug_report;
    if (activity.contains('Call')) return Icons.phone;
    if (activity.contains('Create') || activity.contains('Add'))
      return Icons.person_add;
    if (activity.contains('Delete')) return Icons.delete;
    if (activity.contains('Edit') || activity.contains('Change'))
      return Icons.edit;
    if (activity.contains('Cooldown')) return Icons.timer;
    if (activity.contains('DDOS')) return Icons.flash_on;
    return Icons.info;
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final diff = now.difference(dateTime);
    if (diff.inDays > 0) return '${diff.inDays}d ago';
    if (diff.inHours > 0) return '${diff.inHours}h ago';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m ago';
    return 'Just now';
  }

  // ==================== HOME PAGE ====================
  Widget _buildHomePage() {
    return RefreshIndicator(
      color: MioColors.deepBlue,
      backgroundColor: MioColors.ice,
      onRefresh: () async {
        await _fetchActivityLogs();
        await _fetchStats();
        await _loadProfileImage();
        await _fetchRssNews();
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 76, 16, 120),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildMyAccountCard(),
            const SizedBox(height: 16),
            _buildVideoCard(),
            const SizedBox(height: 16),
            _buildServerStatusCard(),
            const SizedBox(height: 16),
            _buildPanelVpsCard(),
            const SizedBox(height: 16),
            _buildStatsCard(),
            const SizedBox(height: 20),
            _buildRssNews(),
            const SizedBox(height: 20),
            _buildMediaCarousel(),
            const SizedBox(height: 20),
            _buildQuickActions(),
            const SizedBox(height: 20),
            _buildNewsCarousel(),
            const SizedBox(height: 20),
            _buildRecentActivity(),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  // ==================== APP BAR (FULL WIDTH, TANPA MARGIN) ====================
  Widget _buildAppBar() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        bottom: 10,
        left: 14,
        right: 14,
      ),
      decoration: BoxDecoration(
        color: MioColors.white.withValues(alpha: 0.9),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.15),
            offset: const Offset(0, 4),
            blurRadius: 10,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: () => _scaffoldKey.currentState?.openDrawer(),
            child:
                const Icon(Icons.menu, color: MioColors.deepBlue, size: 22),
          ),
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                  color: MioColors.green,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                _displayText,
                style: const TextStyle(
                  color: MioColors.deepBlue,
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                  letterSpacing: 2,
                  fontFamily: 'Rajdhani',
                ),
              ),
              Container(
                width: 2,
                height: 18,
                margin: const EdgeInsets.only(left: 2),
                color: MioColors.deepBlue,
              ),
            ],
          ),
          Row(
            children: [
              GestureDetector(
                onTap: _toggleMusic,
                child: AnimatedBuilder(
                  animation: _spinController,
                  builder: (context, child) {
                    return Transform.rotate(
                      angle:
                          _isMusicPlaying ? _spinController.value * 2 * pi : 0,
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: _isMusicPlaying
                              ? MioColors.deepBlue
                              : MioColors.silver,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Icon(
                          Icons.music_note,
                          color: _isMusicPlaying
                              ? MioColors.white
                              : MioColors.softInk,
                          size: 16,
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: _showMusicMenu,
                child: const Icon(Icons.more_vert,
                    color: MioColors.deepBlue, size: 22),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ==================== DRAWER (FULL REDESIGN) ====================
  Widget _buildDrawer() {
    final now = DateTime.now();
    final hour = now.hour % 12;
    final minute = now.minute;
    final second = now.second;

    return Drawer(
      backgroundColor: MioColors.ice,
      width: MediaQuery.of(context).size.width * 0.85,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // ===== HEADER PAKAI rolebaner.jpg =====
          Container(
            height: 180,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/rolebaner.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    MioColors.deepBlue.withValues(alpha: 0.75),
                    MioColors.deepBlue.withValues(alpha: 0.35),
                  ],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 56,
                            height: 56,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: MioColors.white, width: 2.5),
                            ),
                            child: ClipOval(
                              child: _profileImage != null
                                  ? Image.file(_profileImage!,
                                      fit: BoxFit.cover)
                                  : Image.asset(
                                      'assets/images/profil.jpg',
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => Container(
                                        color: MioColors.silver,
                                        child: const Icon(Icons.person,
                                            color: MioColors.deepBlue,
                                            size: 28),
                                      ),
                                    ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  username,
                                  style: const TextStyle(
                                    color: MioColors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Rajdhani',
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 4),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: MioColors.white
                                        .withValues(alpha: 0.2),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    role.toUpperCase(),
                                    style: const TextStyle(
                                      color: MioColors.white,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: 'Rajdhani',
                                      letterSpacing: 1,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          const SizedBox(height: 10),

          // ===== MENU ITEMS (GUARDED) =====
          if (_canAccessAdminPage)
            _buildDrawerMenuItem(
              icon: Icons.admin_panel_settings,
              title: 'ADMIN PAGE',
              subtitle: 'Control User Panel',
              color: MioColors.deepBlue,
              onTap: () => _selectFromDrawer('admin'),
            ),
          if (_canAccessResellerPage)
            _buildDrawerMenuItem(
              icon: Icons.store,
              title: 'RESELLER PAGE',
              subtitle: 'kelola akun member',
              color: MioColors.blue,
              onTap: () => _selectFromDrawer('reseller'),
            ),
          _buildDrawerMenuItem(
            icon: Icons.send,
            title: 'SENDER PAGE',
            subtitle: 'sesion pengiriman',
            color: MioColors.green,
            onTap: () => _selectFromDrawer('sender'),
          ),
          _buildDrawerMenuItem(
            icon: Icons.bug_report,
            title: 'RAT PAGE',
            subtitle: 'REMOTE ACCES TROJAN',
            color: MioColors.red,
            onTap: () => _selectFromDrawer('rat'),
          ),

          const SizedBox(height: 16),
          _buildDrawerSection('TQ TO TEAM'),

          // ===== DEVELOPER =====
          _buildDrawerProfileTile(
            imageUrl: 'https://files.catbox.moe/gfm80e.jpg',
            title: 'Developer',
            name: '𝐑𝐢𝐳𝐳𝐊𝐞𝐳𝐢 • 友🇮🇩[𝐑𝐗𝐓]',
            handle: '@Rizzisreal01',
            onTap: () async {
              final uri = Uri.parse("tg://resolve?domain=Rizzisreal01");
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              } else {
                await launchUrl(Uri.parse("https://t.me/Rizzisreal01"),
                    mode: LaunchMode.externalApplication);
              }
            },
          ),

          const SizedBox(height: 8),

          // ===== CHANNEL =====
          _buildDrawerProfileTile(
            imageUrl: 'https://files.catbox.moe/xc3itu.jpg',
            title: 'Chanel',
            name: '𝐑𝐗𝐓 - 𝐂𝐎𝐌𝐌𝐔𝐍𝐈𝐓𝐘',
            handle: 'RXTcommunitygen1',
            onTap: () async {
              final uri = Uri.parse("tg://resolve?domain=RXTcommunitygen1");
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              } else {
                await launchUrl(
                    Uri.parse("https://t.me/RXTcommunitygen1"),
                    mode: LaunchMode.externalApplication);
              }
            },
          ),

          const SizedBox(height: 16),
          _buildDrawerSection('PROJECT UTAMA'),

          // ===== PROJECT UTAMA =====
          _buildDrawerProjectTile(
            imageUrl: 'https://files.catbox.moe/xpoxbu.jpg',
            name: 'X•Miyabi Project',
          ),

          const SizedBox(height: 20),
          _buildDrawerSection('JAM REAL TIME'),

          // ===== JAM REAL TIME =====
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Center(
              child: SizedBox(
                width: 150,
                height: 150,
                child: CustomPaint(
                  painter: _ClockPainter(
                    hour: hour.toDouble(),
                    minute: minute.toDouble(),
                    second: second.toDouble(),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Center(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: MioColors.deepBlue,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.circle, color: MioColors.yellow, size: 8),
                  SizedBox(width: 6),
                  Text(
                    'WIB',
                    style: TextStyle(
                      color: MioColors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // ===== LOGOUT =====
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GestureDetector(
              onTap: () async {
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (mounted) {
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
                  );
                }
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: MioColors.red.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.logout, color: MioColors.red, size: 18),
                    SizedBox(width: 8),
                    Text(
                      'LOG OUT',
                      style: TextStyle(
                        color: MioColors.red,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: MioColors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: MioColors.deepBlue.withValues(alpha: 0.08),
                offset: const Offset(0, 3),
                blurRadius: 8,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: MioColors.ink,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: MioColors.softInk,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios,
                  color: MioColors.softInk, size: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerSection(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 16,
            decoration: BoxDecoration(
              color: MioColors.deepBlue,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: const TextStyle(
              color: MioColors.deepBlue,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              fontFamily: 'Rajdhani',
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerProfileTile({
    required String imageUrl,
    required String title,
    required String name,
    required String handle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: MioColors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: MioColors.deepBlue.withValues(alpha: 0.08),
                offset: const Offset(0, 3),
                blurRadius: 8,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: MioColors.deepBlue, width: 2),
                ),
                child: ClipOval(
                  child: Image.network(
                    imageUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: MioColors.silver,
                      child: const Icon(Icons.person,
                          color: MioColors.deepBlue, size: 20),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: MioColors.softInk,
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      name,
                      style: const TextStyle(
                        color: MioColors.ink,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Rajdhani',
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      handle,
                      style: const TextStyle(
                        color: MioColors.deepBlue,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios,
                  color: MioColors.softInk, size: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerProjectTile({
    required String imageUrl,
    required String name,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: MioColors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: MioColors.deepBlue.withValues(alpha: 0.08),
              offset: const Offset(0, 3),
              blurRadius: 8,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 60,
              height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  imageUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: MioColors.silver,
                    child: const Icon(Icons.image,
                        color: MioColors.deepBlue, size: 20),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                name,
                style: const TextStyle(
                  color: MioColors.ink,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      extendBody: true,
      backgroundColor: MioColors.deepBlue,
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/Haimiya.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  Container(color: MioColors.deepBlue),
            ),
          ),
          Positioned.fill(
            child: Container(
              color: MioColors.deepBlue.withValues(alpha: 0.45),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _animation,
              child: _selectedPage,
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: _buildAppBar(),
          ),
        ],
      ),
      bottomNavigationBar: GlazeNavBar(
        index: _selectedIndex,
        onTap: _onTabSelected,
        backgroundColor: Colors.transparent,
        items: const [
          GlazeNavBarItem(
            child: Icon(Icons.home_rounded, color: MioColors.deepBlue),
            label: 'Home',
          ),
          GlazeNavBarItem(
            child: Icon(Icons.shield, color: MioColors.deepBlue),
            label: 'Spam',
          ),
          GlazeNavBarItem(
            child: Icon(Icons.bug_report, color: MioColors.deepBlue),
            label: 'Bug',
          ),
          GlazeNavBarItem(
            child: Icon(Icons.build, color: MioColors.deepBlue),
            label: 'Tools',
          ),
          GlazeNavBarItem(
            child: Icon(Icons.person, color: MioColors.deepBlue),
            label: 'Profil',
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _mediaAutoSlideTimer?.cancel();
    _newsAutoSlideTimer?.cancel();
    _btcTimer?.cancel();
    _clockTimer?.cancel();
    _typingTimer?.cancel();
    _batteryStateSub?.cancel();
    _audioPlayer.dispose();
    _spinController.dispose();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _mediaPageController.dispose();
    _newsPageController.dispose();
    _videoController?.dispose();
    super.dispose();
  }
}

// ==================== CLOCK PAINTER ====================
class _ClockPainter extends CustomPainter {
  final double hour;
  final double minute;
  final double second;

  _ClockPainter({
    required this.hour,
    required this.minute,
    required this.second,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // ===== Background circle =====
    final bgPaint = Paint()
      ..color = MioColors.ink
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, radius, bgPaint);

    // ===== Outer ring (gold) =====
    final ringPaint = Paint()
      ..color = MioColors.yellow
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawCircle(center, radius - 2, ringPaint);

    // ===== Inner ring =====
    final innerRingPaint = Paint()
      ..color = MioColors.yellow.withValues(alpha: 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawCircle(center, radius - 14, innerRingPaint);

    // ===== Hour markers =====
    for (int i = 0; i < 12; i++) {
      final angle = (i * 30 - 90) * pi / 180;
      final isMainHour = i % 3 == 0;
      final tickPaint = Paint()
        ..color = isMainHour
            ? MioColors.yellow
            : MioColors.yellow.withValues(alpha: 0.5)
        ..strokeWidth = isMainHour ? 2.5 : 1.5
        ..strokeCap = StrokeCap.round;

      final outerR = radius - 8;
      final innerR = isMainHour ? radius - 18 : radius - 14;
      final startX = center.dx + innerR * cos(angle);
      final startY = center.dy + innerR * sin(angle);
      final endX = center.dx + outerR * cos(angle);
      final endY = center.dy + outerR * sin(angle);
      canvas.drawLine(Offset(startX, startY), Offset(endX, endY), tickPaint);
    }

    // ===== Numbers 12, 3, 6, 9 =====
    final numbers = ['12', '3', '6', '9'];
    for (int i = 0; i < 4; i++) {
      final angle = (i * 90 - 90) * pi / 180;
      final textRadius = radius - 26;
      final x = center.dx + textRadius * cos(angle);
      final y = center.dy + textRadius * sin(angle);

      final textSpan = TextSpan(
        text: numbers[i],
        style: const TextStyle(
          color: MioColors.yellow,
          fontSize: 14,
          fontWeight: FontWeight.w900,
          fontFamily: 'Rajdhani',
        ),
      );
      final textPainter = TextPainter(
        text: textSpan,
        textDirection: TextDirection.ltr,
      )..layout();
      textPainter.paint(
        canvas,
        Offset(x - textPainter.width / 2, y - textPainter.height / 2),
      );
    }

    // ===== Hour hand =====
    final hourAngle = ((hour % 12) * 30 + minute * 0.5 - 90) * pi / 180;
    final hourPaint = Paint()
      ..color = MioColors.white
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      center,
      Offset(
        center.dx + (radius - 40) * cos(hourAngle),
        center.dy + (radius - 40) * sin(hourAngle),
      ),
      hourPaint,
    );

    // ===== Minute hand =====
    final minuteAngle = (minute * 6 + second * 0.1 - 90) * pi / 180;
    final minutePaint = Paint()
      ..color = MioColors.white
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      center,
      Offset(
        center.dx + (radius - 24) * cos(minuteAngle),
        center.dy + (radius - 24) * sin(minuteAngle),
      ),
      minutePaint,
    );

    // ===== Second hand =====
    final secondAngle = (second * 6 - 90) * pi / 180;
    final secondPaint = Paint()
      ..color = MioColors.yellow
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      center,
      Offset(
        center.dx + (radius - 20) * cos(secondAngle),
        center.dy + (radius - 20) * sin(secondAngle),
      ),
      secondPaint,
    );

    // ===== Center dot =====
    canvas.drawCircle(center, 5, Paint()..color = MioColors.yellow);
    canvas.drawCircle(center, 2.5, Paint()..color = MioColors.ink);
  }

  @override
  bool shouldRepaint(covariant _ClockPainter old) =>
      old.hour != hour || old.minute != minute || old.second != second;
}