import 'package:flutter/material.dart';
import 'tols/chat_ai_page.dart';
import 'tols/nik_check_page.dart';
import 'tols/phone_lookup.dart';
import 'tols/subdomain_finder_page.dart';
import 'tols/anime.dart';
import 'tols/unban_page.dart';
import 'tols/run_html.dart';

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color purple = Color(0xFF9333EA);
  static const Color pink = Color(0xFFEC4899);
  static const Color orange = Color(0xFFF59E0B);
  static const Color teal = Color(0xFF14B8A6);
}

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final List<Map<String, dynamic>> _tools = [
    {
      'icon': Icons.chat,
      'label': 'Chat AI',
      'description': 'AI-powered conversation assistant',
      'color': MioColors.purple,
    },
    {
      'icon': Icons.badge,
      'label': 'NIK Check',
      'description': 'Validate Indonesian identity numbers',
      'color': MioColors.blue,
    },
    {
      'icon': Icons.phone,
      'label': 'Phone Lookup',
      'description': 'Find information about phone numbers',
      'color': MioColors.green,
    },
    {
      'icon': Icons.language,
      'label': 'Subdomain Finder',
      'description': 'Discover subdomains of any domain',
      'color': MioColors.yellow,
    },
    {
      'icon': Icons.movie_filter_outlined,
      'label': 'Anime',
      'description': 'Tempat Nya Para Wibu Marathon Anime',
      'color': MioColors.pink,
    },
    {
      'icon': Icons.lock_open,
      'label': 'Unban WA',
      'description': 'Unban WhatsApp number',
      'color': MioColors.teal,
    },
    {
      'icon': Icons.code,
      'label': 'Run HTML',
      'description': 'HTML code runner & preview',
      'color': MioColors.orange,
    },
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  void _navigateToTool(String toolName) {
    Widget page;
    switch (toolName) {
      case 'Chat AI':
        page = ChatAIPage(sessionKey: widget.sessionKey);
        break;
      case 'NIK Check':
        page = NIKCheckPage(sessionKey: widget.sessionKey);
        break;
      case 'Phone Lookup':
        page = PhoneLookupPage(sessionKey: widget.sessionKey);
        break;
      case 'Anime':
        page = const HomeAnimePage();
        break;
      case 'Subdomain Finder':
        page = SubdomainFinderPage(sessionKey: widget.sessionKey);
        break;
      case 'Unban WA':
        page = UnbanPage(
          username: '',
          sessionKey: widget.sessionKey,
        );
        break;
      case 'Run HTML':
        page = const RunHtmlPage();
        break;
      default:
        return;
    }

    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => page,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(1.0, 0.0);
          const end = Offset.zero;
          const curve = Curves.easeInOut;
          var tween =
              Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
          return SlideTransition(
              position: animation.drive(tween), child: child);
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          // ===== BACKGROUND IMAGE FULLSCREEN =====
          Positioned.fill(
            child: Image.asset(
              'assets/images/Haimiya.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  Container(color: MioColors.deepBlue),
            ),
          ),
          // ===== OVERLAY =====
          Positioned.fill(
            child: Container(
              color: MioColors.deepBlue.withOpacity(0.55),
            ),
          ),
          // ===== CONTENT =====
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // ===== HEADER CARD =====
                      _buildHeaderCard(),
                      const SizedBox(height: 20),

                      // ===== GRID TOOLS =====
                      GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _tools.length,
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 0.95,
                        ),
                        itemBuilder: (context, index) {
                          final tool = _tools[index];
                          return _buildToolCard(
                            icon: tool['icon'],
                            label: tool['label'],
                            description: tool['description'],
                            color: tool['color'],
                            onTap: () => _navigateToTool(tool['label']),
                          );
                        },
                      ),

                      const SizedBox(height: 20),

                      // ===== FOOTER =====
                      Center(
                        child: Column(
                          children: [
                            Container(
                              width: 40,
                              height: 2,
                              color: MioColors.white.withOpacity(0.6),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              "flutter by @Rizzisreal01",
                              style: TextStyle(
                                fontSize: 9,
                                letterSpacing: 2,
                                color: MioColors.white,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'Nevera',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== HEADER CARD ====================
  Widget _buildHeaderCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      decoration: BoxDecoration(
        color: MioColors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.25),
            offset: const Offset(0, 8),
            blurRadius: 18,
          ),
        ],
      ),
      child: Column(
        children: [
          // ===== FOTO BULAT DI TENGAH =====
          Container(
            width: 84,
            height: 84,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: MioColors.deepBlue, width: 3),
              boxShadow: [
                BoxShadow(
                  color: MioColors.deepBlue.withOpacity(0.25),
                  offset: const Offset(0, 6),
                  blurRadius: 12,
                ),
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/icon.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: MioColors.silver,
                  child: const Icon(Icons.build,
                      color: MioColors.deepBlue, size: 38),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),

          // ===== STATS ROW =====
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildHeaderField(
                'TOTAL TOOLS',
                '${_tools.length}',
                color: MioColors.deepBlue,
              ),
              Container(width: 1, height: 36, color: MioColors.silver),
              _buildHeaderField(
                'STATUS',
                'AKTIF',
                color: MioColors.green,
              ),
              Container(width: 1, height: 36, color: MioColors.silver),
              _buildHeaderField(
                'SERVER',
                'TERHUBUNG',
                color: MioColors.green,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderField(String label, String value, {Color? color}) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: MioColors.softInk,
            fontSize: 9,
            fontWeight: FontWeight.w700,
            fontFamily: 'Nevera',
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: color ?? MioColors.deepBlue,
            fontSize: 13,
            fontWeight: FontWeight.w900,
            fontFamily: 'Nevera',
          ),
        ),
      ],
    );
  }

  // ==================== TOOL CARD (GRID) ====================
  Widget _buildToolCard({
    required IconData icon,
    required String label,
    required String description,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: MioColors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: MioColors.deepBlue.withOpacity(0.15),
              offset: const Offset(0, 6),
              blurRadius: 12,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ===== ICON BOX =====
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 26),
            ),
            const Spacer(),

            // ===== TITLE =====
            Text(
              label,
              style: const TextStyle(
                color: MioColors.ink,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                fontFamily: 'Nevera',
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),

            // ===== DESC =====
            Text(
              description,
              style: const TextStyle(
                color: MioColors.softInk,
                fontSize: 10,
                fontWeight: FontWeight.w600,
                fontFamily: 'Nevera',
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}