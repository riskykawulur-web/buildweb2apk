import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

class SenderPage extends StatefulWidget {
  final String sessionKey;

  const SenderPage({super.key, required this.sessionKey});

  @override
  State<SenderPage> createState() => _SenderPageState();
}

class _SenderPageState extends State<SenderPage>
    with TickerProviderStateMixin {
  Map<String, dynamic> connections = {"private": [], "global": []};
  bool isLoading = false;
  String _currentFilter = "all";

  @override
  void initState() {
    super.initState();
    _fetchSenders();
  }

  Widget _buildBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/Haimiya.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: MioColors.deepBlue),
          ),
        ),
        Positioned.fill(
          child: Container(color: MioColors.deepBlue.withOpacity(0.55)),
        ),
      ],
    );
  }

  Widget _mioCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 16,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.18),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }

  // ==================== API FUNCTIONS ====================
  Future<void> _fetchSenders() async {
    if (isLoading) return;
    setState(() => isLoading = true);

    try {
      final res = await http.get(
        Uri.parse("$baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}"),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            connections = data["connections"] ?? {"private": [], "global": []};
          });
        } else {
          _showErrorSnackBar(data['message'] ?? "Failed to fetch senders");
        }
      } else {
        _showErrorSnackBar("Failed to fetch senders");
      }
    } catch (e) {
      debugPrint("Error fetching senders: $e");
      _showErrorSnackBar("Failed to fetch senders. Please try again.");
    }

    setState(() => isLoading = false);
  }

  Future<void> _addSender(String number, bool isGlobal) async {
    if (number.isEmpty) {
      _showErrorSnackBar("Phone number cannot be empty");
      return;
    }

    try {
      final url =
          "$baseUrl/api/whatsapp/getPairing?key=${widget.sessionKey}&number=$number" +
              (isGlobal ? "&isGlobal=true" : "");

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final res = jsonDecode(response.body);
        if (res['valid'] == true) {
          _showPairingCodeDialog(number, res['pairingCode'], isGlobal);
          _fetchSenders();
        } else {
          _showErrorSnackBar("Failed: ${res['message'] ?? 'Unknown error'}");
        }
      } else {
        _showErrorSnackBar("Failed to get pairing code");
      }
    } catch (e) {
      debugPrint("Error adding sender: $e");
      _showErrorSnackBar("An error occurred. Please try again.");
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            color: MioColors.white,
            fontFamily: 'Rajdhani',
          ),
        ),
        backgroundColor: MioColors.pink,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            color: MioColors.white,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: MioColors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  // ==================== PAIRING CODE DIALOG ====================
  void _showPairingCodeDialog(String number, String code, bool isGlobal) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: MioColors.deepBlue,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.phonelink_lock,
                        color: MioColors.white, size: 24),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "Pairing Code",
                    style: TextStyle(
                      color: MioColors.ink,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              _mioCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Text(
                          "Number: ",
                          style: TextStyle(
                            color: MioColors.softInk,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Rajdhani',
                          ),
                        ),
                        Text(
                          number,
                          style: const TextStyle(
                            color: MioColors.ink,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Rajdhani',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: isGlobal
                            ? MioColors.deepBlue.withOpacity(0.15)
                            : MioColors.ice,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        isGlobal ? "GLOBAL SENDER" : "PRIVATE SENDER",
                        style: TextStyle(
                          color: isGlobal
                              ? MioColors.deepBlue
                              : MioColors.softInk,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: MioColors.ice,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        code,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: MioColors.deepBlue,
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 4,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              _mioCard(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "📱 Cara Menghubungkan:",
                      style: TextStyle(
                        color: MioColors.ink,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                    const SizedBox(height: 8),
                    _tutorialStep("1", "Buka WhatsApp di HP Anda"),
                    _tutorialStep("2", "Tap titik 3 di pojok kanan atas"),
                    _tutorialStep("3", "Pilih 'Tautkan Perangkat'"),
                    _tutorialStep("4", "Masukkan kode di atas"),
                    _tutorialStep("5", "Bot akan otomatis terhubung 🟢"),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: code));
                        _showSuccessSnackBar("Pairing code copied!");
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: MioColors.ice,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Center(
                          child: Text(
                            "📋 Copy",
                            style: TextStyle(
                              color: MioColors.ink,
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              fontFamily: 'Rajdhani',
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: MioColors.deepBlue,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Center(
                          child: Text(
                            "DONE",
                            style: TextStyle(
                              color: MioColors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              fontFamily: 'Rajdhani',
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tutorialStep(String step, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: MioColors.deepBlue.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Center(
              child: Text(
                step,
                style: const TextStyle(
                  color: MioColors.deepBlue,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                color: MioColors.ink,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily: 'Rajdhani',
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showAddSenderDialog(bool isGlobal) {
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: isGlobal ? MioColors.deepBlue : MioColors.purple,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      isGlobal ? Icons.public : Icons.lock,
                      color: MioColors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isGlobal ? "Add Global Sender" : "Add Private Sender",
                        style: const TextStyle(
                          color: MioColors.ink,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                      Text(
                        isGlobal
                            ? "Dapat digunakan semua orang"
                            : "Hanya untuk pribadi",
                        style: const TextStyle(
                          color: MioColors.softInk,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                keyboardType: TextInputType.phone,
                style: const TextStyle(
                  color: MioColors.ink,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Rajdhani',
                ),
                cursorColor: MioColors.deepBlue,
                decoration: InputDecoration(
                  hintText: "Enter phone number",
                  hintStyle: TextStyle(
                    color: MioColors.softInk.withOpacity(0.7),
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.w600,
                  ),
                  filled: true,
                  fillColor: MioColors.ice,
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                        const BorderSide(color: MioColors.deepBlue, width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  prefixIcon:
                      const Icon(Icons.phone, color: MioColors.deepBlue),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      child: const Text(
                        "Cancel",
                        style: TextStyle(
                          color: MioColors.softInk,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: () async {
                      Navigator.pop(context);
                      final number = controller.text.trim();
                      await _addSender(number, isGlobal);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 12),
                      decoration: BoxDecoration(
                        color:
                            isGlobal ? MioColors.deepBlue : MioColors.purple,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        "Add Sender",
                        style: TextStyle(
                          color: MioColors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 13,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== FILTER ====================
  List<dynamic> _getFilteredSenders() {
    switch (_currentFilter) {
      case "private":
        return connections["private"] ?? [];
      case "global":
        return connections["global"] ?? [];
      default:
        return [
          ...connections["private"] ?? [],
          ...connections["global"] ?? []
        ];
    }
  }

  int _getSenderCount() {
    switch (_currentFilter) {
      case "private":
        return connections["private"]?.length ?? 0;
      case "global":
        return connections["global"]?.length ?? 0;
      default:
        return (connections["private"]?.length ?? 0) +
            (connections["global"]?.length ?? 0);
    }
  }

  int _getTotalSenderCount() {
    return (connections["private"]?.length ?? 0) +
        (connections["global"]?.length ?? 0);
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    final totalSenders = _getTotalSenderCount();

    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                _buildAddSenderMenu(),
                const SizedBox(height: 8),
                _buildFilterChips(),
                Expanded(
                  child: isLoading
                      ? const Center(
                          child:
                              CircularProgressIndicator(color: MioColors.white))
                      : totalSenders == 0
                          ? _buildEmptyState()
                          : _buildSenderList(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: MioColors.deepBlue,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.phone_android,
              color: MioColors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            "My Senders (${_getSenderCount()})",
            style: const TextStyle(
              color: MioColors.white,
              fontSize: 20,
              fontWeight: FontWeight.w900,
              fontFamily: 'Rajdhani',
              letterSpacing: 1,
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: _fetchSenders,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: MioColors.white.withOpacity(0.9),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.refresh,
                color: MioColors.deepBlue,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddSenderMenu() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => _showAddSenderDialog(false),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                decoration: BoxDecoration(
                  color: MioColors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: MioColors.deepBlue.withOpacity(0.15),
                      offset: const Offset(0, 4),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: MioColors.ice,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.lock_outline,
                          color: MioColors.deepBlue, size: 22),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      "PRIVATE",
                      style: TextStyle(
                        color: MioColors.ink,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 1,
                      ),
                    ),
                    const Text(
                      "Pribadi",
                      style: TextStyle(
                        color: MioColors.softInk,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: GestureDetector(
              onTap: () => _showAddSenderDialog(true),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                decoration: BoxDecoration(
                  color: MioColors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: MioColors.deepBlue.withOpacity(0.15),
                      offset: const Offset(0, 4),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: MioColors.deepBlue.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.public,
                          color: MioColors.deepBlue, size: 22),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      "GLOBAL",
                      style: TextStyle(
                        color: MioColors.deepBlue,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 1,
                      ),
                    ),
                    const Text(
                      "Semua orang",
                      style: TextStyle(
                        color: MioColors.softInk,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChips() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildFilterChip("All", "all"),
            const SizedBox(width: 8),
            _buildFilterChip("Private", "private"),
            const SizedBox(width: 8),
            _buildFilterChip("Global", "global"),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, String filter) {
    final isSelected = _currentFilter == filter;

    return GestureDetector(
      onTap: () {
        setState(() {
          _currentFilter = filter;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? MioColors.deepBlue : MioColors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: MioColors.deepBlue.withOpacity(0.3),
                    offset: const Offset(0, 4),
                    blurRadius: 10,
                  ),
                ]
              : null,
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? MioColors.white : MioColors.ink,
            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
            fontSize: 12,
            fontFamily: 'Rajdhani',
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: MioColors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(
              Icons.phone_disabled,
              color: MioColors.softInk,
              size: 50,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            "No senders found",
            style: TextStyle(
              color: MioColors.white,
              fontSize: 18,
              fontFamily: 'Rajdhani',
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Add a sender to get started",
            style: TextStyle(
              color: MioColors.white.withOpacity(0.7),
              fontSize: 13,
              fontWeight: FontWeight.w600,
              fontFamily: 'Rajdhani',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderList() {
    final filteredSenders = _getFilteredSenders();

    if (filteredSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.filter_list_off,
              color: MioColors.white.withOpacity(0.5),
              size: 40,
            ),
            const SizedBox(height: 12),
            Text(
              "No senders in '${_currentFilter.toUpperCase()}'",
              style: TextStyle(
                color: MioColors.white.withOpacity(0.7),
                fontSize: 14,
                fontWeight: FontWeight.w600,
                fontFamily: 'Rajdhani',
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchSenders,
      color: MioColors.deepBlue,
      backgroundColor: MioColors.white,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: filteredSenders.length,
        itemBuilder: (context, index) {
          final sender = filteredSenders[index];
          final isGlobal = sender['dev'] == "global" ||
              sender['role'] == "high admin";

          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _mioCard(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: isGlobal
                          ? MioColors.deepBlue.withOpacity(0.15)
                          : MioColors.ice,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.phone,
                      color:
                          isGlobal ? MioColors.deepBlue : MioColors.softInk,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          sender['sessionName'] ?? 'Unknown',
                          style: const TextStyle(
                            color: MioColors.ink,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Rajdhani',
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          "Type: ${sender['type'] ?? 'N/A'}",
                          style: const TextStyle(
                            color: MioColors.softInk,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Rajdhani',
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (isGlobal)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: MioColors.deepBlue.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        "VIP",
                        style: TextStyle(
                          color: MioColors.deepBlue,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  const SizedBox(width: 8),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: MioColors.green.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      "Active",
                      style: TextStyle(
                        color: MioColors.green,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}