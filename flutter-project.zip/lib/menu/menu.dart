import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ==================== IMPORTS BUG PAGES ====================
import '../bug/home_page.dart';
import '../bug/custom_bug.dart';
import '../bug/bug_group.dart';

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color purple = Color(0xFF9333EA);
  static const Color orange = Color(0xFFF59E0B);
  static const Color teal = Color(0xFF14B8A6);
}

class MenuPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;

  const MenuPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
  });

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  late PageController _pageController;
  int _currentPage = 0;

  final List<Map<String, dynamic>> _menuItems = [
    {
      'title': 'Bug',
      'icon': FontAwesomeIcons.whatsapp,
      'color': MioColors.green,
      'desc': 'WhatsApp Bug Attack',
      'route': 'bug',
    },
    {
      'title': 'Custom Bug',
      'icon': FontAwesomeIcons.biohazard, // ← GANTI dari squareWhatsapp
      'color': MioColors.purple,
      'desc': 'Custom Payload Attack',
      'route': 'custom',
    },
    {
      'title': 'Group Bug',
      'icon': FontAwesomeIcons.users,
      'color': MioColors.blue,
      'desc': 'Group Join & Attack',
      'route': 'group',
    },
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.82);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _navigateToPage(String route) {
    switch (route) {
      case 'bug':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => AttackPage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              listBug: widget.listBug,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
        break;
      case 'custom':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => CustomAttackPage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              listPayload: widget.listPayload,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
        break;
      case 'group':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => GroupBugPage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/Haimiya.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  Container(color: MioColors.deepBlue),
            ),
          ),
          Positioned.fill(
            child: Container(
              color: MioColors.deepBlue.withOpacity(0.55),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                children: [
                  _buildHeaderCard(),
                  const SizedBox(height: 20),

                  // ===== PAGEVIEW CARDS (FOKUS DI TENGAH) =====
                  SizedBox(
                    height: 440,
                    child: PageView.builder(
                      controller: _pageController,
                      onPageChanged: (index) {
                        setState(() => _currentPage = index);
                      },
                      itemCount: _menuItems.length,
                      itemBuilder: (context, index) {
                        final item = _menuItems[index];
                        final isActive = _currentPage == index;
                        return AnimatedScale(
                          scale: isActive ? 1.0 : 0.85,
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeOutCubic,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: _buildMenuCard(item, isActive),
                          ),
                        );
                      },
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ===== INDICATOR DOTS =====
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      _menuItems.length,
                      (index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        height: 8,
                        width: _currentPage == index ? 28 : 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: _currentPage == index
                              ? MioColors.white
                              : MioColors.white.withOpacity(0.4),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ===== COPYRIGHT =====
                  Column(
                    children: [
                      Container(
                        width: 40,
                        height: 2,
                        color: MioColors.white.withOpacity(0.6),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "flutter by @Rizzisreal01",
                        style: TextStyle(
                          fontSize: 9,
                          letterSpacing: 2,
                          color: MioColors.white,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Nevera',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== HEADER CARD ====================
  Widget _buildHeaderCard() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: MioColors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.25),
            offset: const Offset(0, 8),
            blurRadius: 18,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: Image.asset(
              'assets/images/menu.jpg',
              height: 150,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                height: 150,
                color: MioColors.silver,
                child: const Center(
                  child:
                      Icon(Icons.image, color: MioColors.softInk, size: 40),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildHeaderField('USERNAME', widget.username),
                Container(width: 1, height: 34, color: MioColors.silver),
                _buildHeaderField(
                  'ROLE',
                  widget.role.toUpperCase(),
                  color: _getRoleColor(),
                ),
                Container(width: 1, height: 34, color: MioColors.silver),
                _buildHeaderField(
                  'EXP',
                  widget.expiredDate.split(' ').first,
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
            child: Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEC4899),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text(
                    'Bug Menu Anti Limit',
                    style: TextStyle(
                      color: MioColors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Nevera',
                    ),
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: MioColors.deepBlue,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.close,
                      color: MioColors.white,
                      size: 18,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderField(String label, String value, {Color? color}) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: MioColors.softInk,
            fontSize: 9,
            fontWeight: FontWeight.w700,
            fontFamily: 'Nevera',
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: color ?? MioColors.deepBlue,
            fontSize: 13,
            fontWeight: FontWeight.w900,
            fontFamily: 'Nevera',
          ),
        ),
      ],
    );
  }

  Color _getRoleColor() {
    switch (widget.role.toLowerCase()) {
      case 'dev':
        return MioColors.red;
      case 'high_pt':
        return MioColors.purple;
      case 'pt':
        return const Color(0xFF7C3AED);
      case 'helper':
        return MioColors.green;
      case 'admin':
        return MioColors.blue;
      case 'reseller':
        return MioColors.yellow;
      case 'vip':
        return MioColors.orange;
      case 'member':
        return MioColors.softInk;
      default:
        return MioColors.softInk;
    }
  }

  // ==================== MENU CARD (FOKUS) ====================
  Widget _buildMenuCard(Map<String, dynamic> item, bool isActive) {
    return GestureDetector(
      onTap: () => _navigateToPage(item['route']),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          color: MioColors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: isActive ? item['color'] : item['color'].withOpacity(0.15),
            width: isActive ? 3 : 2,
          ),
          boxShadow: [
            BoxShadow(
              color: isActive
                  ? item['color'].withOpacity(0.4)
                  : MioColors.deepBlue.withOpacity(0.1),
              offset: Offset(0, isActive ? 10 : 4),
              blurRadius: isActive ? 24 : 10,
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: EdgeInsets.all(isActive ? 30 : 24),
              decoration: BoxDecoration(
                color: item['color'].withOpacity(isActive ? 0.18 : 0.10),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: item['color'].withOpacity(isActive ? 0.5 : 0.2),
                  width: isActive ? 3 : 2,
                ),
              ),
              child: Icon(
                item['icon'],
                color: item['color'],
                size: isActive ? 78 : 62,
              ),
            ),
            const SizedBox(height: 22),
            Text(
              item['title'],
              style: TextStyle(
                color: MioColors.ink,
                fontSize: isActive ? 24 : 20,
                fontWeight: FontWeight.w900,
                fontFamily: 'Nevera',
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                item['desc'],
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: MioColors.softInk,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Nevera',
                ),
              ),
            ),
            const SizedBox(height: 18),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
              decoration: BoxDecoration(
                color: item['color'].withOpacity(0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "Tap to open",
                    style: TextStyle(
                      color: item['color'],
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Nevera',
                    ),
                  ),
                  const SizedBox(width: 6),
                  Icon(
                    Icons.arrow_forward,
                    color: item['color'],
                    size: 14,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}