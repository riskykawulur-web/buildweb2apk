import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

class CustomAttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listPayload;
  final String role;
  final String expiredDate;

  const CustomAttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listPayload,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<CustomAttackPage> createState() => _CustomAttackPageState();
}

class _CustomAttackPageState extends State<CustomAttackPage>
    with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final qtyController = TextEditingController(text: "5");
  final delayController = TextEditingController(text: "100");

  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // ===== VIDEO LANDING =====
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  // ===== VIDEO SPLASH =====
  VideoPlayerController? _splashController;
  bool _splashInitialized = false;
  bool _showSplash = false;

  List<String> selectedBugs = [];
  String _senderType = "global";
  bool _isSending = false;
  bool _isProcessing = false;
  Map<String, String> _senderTypeLimits = {};
  int _activeStep = 0;

  Map<String, dynamic> _connections = {"private": [], "global": []};
  bool _isLoadingSenders = false;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeVideoController();
    _setSenderTypeLimits();
    _setDefaultBugs();
    _startAnimations();
    _fetchSendersCount();
  }

  Future<void> _fetchSendersCount() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(
        Uri.parse("$baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}"),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _connections = data["connections"] ?? {"private": [], "global": []};
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching senders count: $e");
    }
    setState(() => _isLoadingSenders = false);
  }

  int _getGlobalCount() => _connections["global"]?.length ?? 0;
  int _getPrivateCount() => _connections["private"]?.length ?? 0;

  void _initializeAnimations() {
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _setSenderTypeLimits() {
    _senderTypeLimits = {
      "global": "Max Qty: 10, Delay: 500ms (Fixed)",
      "private": "Max Qty: 200, Min Delay: 10ms",
    };
  }

  void _setDefaultBugs() {
    if (widget.listPayload.isNotEmpty) {
      selectedBugs.add(widget.listPayload[0]['bug_id']);
    }
  }

  // ===== VIDEO LANDING =====
  void _initializeVideoController() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _videoInitialized = true;
            });
            _videoController.setLooping(true);
            _videoController.play();
            _videoController.setVolume(0);
          }
        }).catchError((error) {
          print('Video initialization error: $error');
          if (mounted) {
            setState(() {
              _videoError = true;
            });
          }
        });
    } catch (e) {
      print('Video controller creation error: $e');
      if (mounted) {
        setState(() {
          _videoError = true;
        });
      }
    }
  }

  // ===== VIDEO SPLASH =====
  void _showSplashVideo() {
    try {
      _splashController = VideoPlayerController.asset('assets/videos/splash.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _splashInitialized = true;
              _showSplash = true;
            });

            _splashController!.setLooping(false);
            _splashController!.play();
            _splashController!.setVolume(1.0);

            _splashController!.addListener(() {
              if (_splashController!.value.position >=
                  _splashController!.value.duration) {
                _splashController!.pause();
                _closeSplashAndSend();
              }
            });
          }
        }).catchError((error) {
          print('Splash video initialization error: $error');
          _closeSplashAndSend();
        });
    } catch (e) {
      print('Splash video creation error: $e');
      _closeSplashAndSend();
    }
  }

  void _closeSplashAndSend() {
    setState(() {
      _showSplash = false;
      _isProcessing = true;
    });

    Future.delayed(const Duration(milliseconds: 500), () {
      _sendCustomBug();
    });
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _toggleBugSelection(String bugId) {
    setState(() {
      if (selectedBugs.contains(bugId)) {
        selectedBugs.remove(bugId);
      } else {
        selectedBugs.add(bugId);
      }
    });
  }

  Future<void> _sendCustomBug() async {
    if (_isSending) return;

    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;
    final qty = int.tryParse(qtyController.text) ?? 1;
    final delay = int.tryParse(delayController.text) ?? 100;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number",
          "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
      setState(() {
        _isSending = false;
        _isProcessing = false;
        _activeStep = 0;
      });
      return;
    }

    if (selectedBugs.isEmpty) {
      _showAlert("❌ No Payload Selected",
          "Please select at least one payload to send.");
      setState(() {
        _isSending = false;
        _isProcessing = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      final bugsParam = selectedBugs.join(',');
      final res = await http.get(Uri.parse(
          "$baseUrl/api/whatsapp/customBug?key=$key&target=$target&bug=$bugsParam&qty=$qty&delay=$delay&senderType=$_senderType"));
      final data = jsonDecode(res.body);

      if (data["valid"] == false) {
        _showAlert("❌ Failed", data["message"] ?? "Failed to send custom bug.");
      } else {
        setState(() {
          _activeStep = 2;
        });
        _showSuccessPopup(target, data["details"]);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
        _isProcessing = false;
        if (_activeStep != 2) _activeStep = 0;
      });
    }
  }

  void _showSuccessPopup(String target, Map<String, dynamic> details) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => CustomSuccessDialog(
        target: target,
        details: details,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() {
            _activeStep = 0;
          });
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    setState(() {
      _isSending = false;
      _isProcessing = false;
      _activeStep = 0;
    });

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: title.contains("Invalid") || title.contains("Failed")
                    ? MioColors.red.withValues(alpha: 0.15)
                    : MioColors.deepBlue.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                title.contains("Invalid") || title.contains("Failed")
                    ? Icons.error_outline
                    : Icons.info_outline,
                color: title.contains("Invalid") || title.contains("Failed")
                    ? MioColors.red
                    : MioColors.deepBlue,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: MioColors.ink,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Nevera',
                ),
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: MioColors.softInk,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Nevera',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: MioColors.deepBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              "OK",
              style: TextStyle(
                color: MioColors.white,
                fontFamily: 'Nevera',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/Haimiya.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: MioColors.deepBlue),
          ),
        ),
        Positioned.fill(
          child: Container(color: MioColors.deepBlue.withValues(alpha: 0.55)),
        ),
      ],
    );
  }

  // ==================== MIO CARD ====================
  Widget _mioCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 16,
    EdgeInsets padding = const EdgeInsets.all(16),
    EdgeInsets? margin,
  }) {
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.18),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }

  // ==================== SPLASH OVERLAY ====================
  Widget _buildSplashOverlay() {
    if (!_showSplash || !_splashInitialized || _splashController == null) {
      return const SizedBox.shrink();
    }

    return Container(
      color: Colors.black.withValues(alpha: 0.92),
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: Container(
          width: 340,
          height: 500,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: MioColors.deepBlue, width: 3),
            boxShadow: [
              BoxShadow(
                color: MioColors.deepBlue.withValues(alpha: 0.5),
                blurRadius: 24,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(13),
            child: VideoPlayer(_splashController!),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final allowedRoles = ["dev", "high_pt", "pt", "vip"];
    if (!allowedRoles.contains(widget.role.toLowerCase())) {
      return Scaffold(
        backgroundColor: MioColors.deepBlue,
        body: Stack(
          children: [
            _buildBackground(),
            const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    FontAwesomeIcons.lock,
                    color: MioColors.pink,
                    size: 50,
                  ),
                  SizedBox(height: 16),
                  Text(
                    "ACCESS DENIED",
                    style: TextStyle(
                      color: MioColors.pink,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Nevera',
                      letterSpacing: 2,
                    ),
                  ),
                  SizedBox(height: 8),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 32),
                    child: Text(
                      "This feature is only available for Dev, high_pt, member, and Admin users",
                      style: TextStyle(
                        color: MioColors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Nevera',
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ===== TITLE =====
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: MioColors.purple,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: MioColors.purple.withValues(alpha: 0.4),
                              offset: const Offset(0, 6),
                              blurRadius: 14,
                            ),
                          ],
                        ),
                        child: const Icon(
                          FontAwesomeIcons.bug,
                          color: MioColors.white,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Custom Bug",
                        style: TextStyle(
                          color: MioColors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Nevera',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // ===== USER CARD =====
                  _mioCard(
                    child: Row(
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: MioColors.purple,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.asset(
                              'assets/images/icon.jpg',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Icon(
                                Icons.person,
                                color: MioColors.white,
                                size: 26,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.username,
                                style: const TextStyle(
                                  color: MioColors.ink,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Nevera',
                                ),
                              ),
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  Text(
                                    "EXP: ${widget.expiredDate.split(' ').first}",
                                    style: const TextStyle(
                                      color: MioColors.softInk,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      fontFamily: 'Nevera',
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: MioColors.purple
                                          .withValues(alpha: 0.15),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      widget.role.toUpperCase(),
                                      style: const TextStyle(
                                        color: MioColors.purple,
                                        fontSize: 8,
                                        fontWeight: FontWeight.w800,
                                        fontFamily: 'Nevera',
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== VIDEO =====
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      width: double.infinity,
                      height: 180,
                      color: MioColors.silver,
                      child: _videoInitialized && !_videoError
                          ? Stack(
                              alignment: Alignment.center,
                              children: [
                                FittedBox(
                                  fit: BoxFit.cover,
                                  child: SizedBox(
                                    width: _videoController.value.size.width,
                                    height: _videoController.value.size.height,
                                    child: VideoPlayer(_videoController),
                                  ),
                                ),
                                Positioned(
                                  bottom: 10,
                                  right: 10,
                                  child: GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        if (_videoController.value.isPlaying) {
                                          _videoController.pause();
                                        } else {
                                          _videoController.play();
                                        }
                                      });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: const BoxDecoration(
                                        color: MioColors.white,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(
                                        _videoController.value.isPlaying
                                            ? Icons.pause
                                            : Icons.play_arrow,
                                        color: MioColors.deepBlue,
                                        size: 20,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            )
                          : const Center(
                              child: CircularProgressIndicator(
                                color: MioColors.deepBlue,
                                strokeWidth: 2,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== PROGRESS =====
                  _mioCard(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                    child: Row(
                      children: [
                        _buildStep(0, "Input", Icons.edit, _activeStep),
                        _buildLine(_activeStep > 0),
                        _buildStep(1, "Process", Icons.settings, _activeStep),
                        _buildLine(_activeStep > 1),
                        _buildStep(
                            2, "Complete", Icons.check_circle, _activeStep),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== TARGET INPUT =====
                  _mioCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Target Number",
                          style: TextStyle(
                            color: MioColors.ink,
                            fontFamily: 'Nevera',
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextField(
                          controller: targetController,
                          style: const TextStyle(
                            color: MioColors.ink,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Nevera',
                          ),
                          cursorColor: MioColors.deepBlue,
                          decoration: InputDecoration(
                            hintText: "e.g. +62xxxxxxxxx",
                            hintStyle: TextStyle(
                              color: MioColors.softInk.withValues(alpha: 0.7),
                              fontFamily: 'Nevera',
                              fontWeight: FontWeight.w600,
                            ),
                            filled: true,
                            fillColor: MioColors.ice,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                  color: MioColors.deepBlue, width: 2),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 14, horizontal: 16),
                            prefixIcon: const Icon(
                              FontAwesomeIcons.phone,
                              color: MioColors.deepBlue,
                              size: 18,
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          "Use international format without 0 or +",
                          style: TextStyle(
                            color: MioColors.softInk.withValues(alpha: 0.7),
                            fontSize: 11,
                            fontFamily: 'Nevera',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== PAYLOAD SELECTION =====
                  _mioCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Text(
                              "Select Payloads",
                              style: TextStyle(
                                color: MioColors.ink,
                                fontFamily: 'Nevera',
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: MioColors.deepBlue
                                    .withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                "${selectedBugs.length} selected",
                                style: const TextStyle(
                                  color: MioColors.deepBlue,
                                  fontSize: 10,
                                  fontFamily: 'Nevera',
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          height: 80,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            physics: const BouncingScrollPhysics(),
                            itemCount: widget.listPayload.length,
                            itemBuilder: (context, index) {
                              final bug = widget.listPayload[index];
                              final bugId = bug['bug_id'];
                              final bugName = bug['bug_name'];
                              final isSelected = selectedBugs.contains(bugId);

                              return GestureDetector(
                                onTap: () => _toggleBugSelection(bugId),
                                child: Container(
                                  width: 120,
                                  margin: const EdgeInsets.only(right: 10),
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? MioColors.deepBlue
                                        : MioColors.ice,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: isSelected
                                          ? MioColors.deepBlue
                                          : MioColors.silver,
                                      width: 2,
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        FontAwesomeIcons.virus,
                                        color: isSelected
                                            ? MioColors.white
                                            : MioColors.softInk,
                                        size: 18,
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        bugName,
                                        style: TextStyle(
                                          color: isSelected
                                              ? MioColors.white
                                              : MioColors.ink,
                                          fontSize: 10,
                                          fontWeight: isSelected
                                              ? FontWeight.w800
                                              : FontWeight.w600,
                                          fontFamily: 'Nevera',
                                        ),
                                        textAlign: TextAlign.center,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== SENDER TYPE =====
                  _mioCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Sender Type",
                          style: TextStyle(
                            color: MioColors.ink,
                            fontFamily: 'Nevera',
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            _buildSenderOption(
                              "Global",
                              FontAwesomeIcons.globe,
                              _senderType == "global",
                              _getGlobalCount(),
                              _senderTypeLimits["global"]!,
                              () => setState(() => _senderType = "global"),
                            ),
                            const SizedBox(width: 12),
                            _buildSenderOption(
                              "Private",
                              FontAwesomeIcons.user,
                              _senderType == "private",
                              _getPrivateCount(),
                              _senderTypeLimits["private"]!,
                              () => setState(() => _senderType = "private"),
                            ),
                          ],
                        ),
                        if (_senderType == "global")
                          const Padding(
                            padding: EdgeInsets.only(top: 8),
                            child: Row(
                              children: [
                                Icon(
                                  FontAwesomeIcons.infoCircle,
                                  color: MioColors.softInk,
                                  size: 12,
                                ),
                                SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    "Note: Delay is fixed at 500ms for Global sender",
                                    style: TextStyle(
                                      color: MioColors.softInk,
                                      fontSize: 11,
                                      fontFamily: 'Nevera',
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== QUANTITY & DELAY =====
                  _mioCard(
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Quantity",
                                style: TextStyle(
                                  color: MioColors.ink,
                                  fontFamily: 'Nevera',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 12,
                                ),
                              ),
                              const SizedBox(height: 4),
                              TextField(
                                controller: qtyController,
                                keyboardType: TextInputType.number,
                                style: const TextStyle(
                                  color: MioColors.ink,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Nevera',
                                ),
                                cursorColor: MioColors.deepBlue,
                                decoration: InputDecoration(
                                  hintText: "1-200",
                                  hintStyle: TextStyle(
                                    color: MioColors.softInk
                                        .withValues(alpha: 0.7),
                                    fontFamily: 'Nevera',
                                    fontWeight: FontWeight.w600,
                                  ),
                                  filled: true,
                                  fillColor: MioColors.ice,
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: BorderSide.none,
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: BorderSide.none,
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                        color: MioColors.deepBlue, width: 2),
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(
                                      vertical: 10, horizontal: 12),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Delay (ms)",
                                style: TextStyle(
                                  color: MioColors.ink,
                                  fontFamily: 'Nevera',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 12,
                                ),
                              ),
                              const SizedBox(height: 4),
                              TextField(
                                controller: delayController,
                                keyboardType: TextInputType.number,
                                enabled: _senderType == "private",
                                style: TextStyle(
                                  color: _senderType == "private"
                                      ? MioColors.ink
                                      : MioColors.softInk,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Nevera',
                                ),
                                cursorColor: MioColors.deepBlue,
                                decoration: InputDecoration(
                                  hintText: "10-1000",
                                  hintStyle: TextStyle(
                                    color: MioColors.softInk.withValues(
                                        alpha: _senderType == "private"
                                            ? 0.7
                                            : 0.4),
                                    fontFamily: 'Nevera',
                                    fontWeight: FontWeight.w600,
                                  ),
                                  filled: true,
                                  fillColor: _senderType == "private"
                                      ? MioColors.ice
                                      : MioColors.ice.withValues(alpha: 0.5),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: BorderSide.none,
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: BorderSide.none,
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                        color: MioColors.deepBlue, width: 2),
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(
                                      vertical: 10, horizontal: 12),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== STATUS =====
                  _mioCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "System Status",
                          style: TextStyle(
                            color: MioColors.ink,
                            fontFamily: 'Nevera',
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            _statusItem(
                                FontAwesomeIcons.server, "Server", true),
                            _statusItem(FontAwesomeIcons.shieldAlt,
                                "Security", true),
                            _statusItem(FontAwesomeIcons.database,
                                "Database", true),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // ===== SEND BUTTON =====
                  GestureDetector(
                    onTap:
                        (_isSending || _isProcessing) ? null : _showSplashVideo,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(
                        color: (_isSending || _isProcessing)
                            ? MioColors.silver
                            : MioColors.deepBlue,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: (_isSending || _isProcessing)
                            ? null
                            : [
                                BoxShadow(
                                  color:
                                      MioColors.deepBlue.withValues(alpha: 0.4),
                                  offset: const Offset(0, 8),
                                  blurRadius: 16,
                                ),
                              ],
                      ),
                      child: Center(
                        child: (_isSending || _isProcessing)
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  color: MioColors.white,
                                  strokeWidth: 2.5,
                                ),
                              )
                            : const Text(
                                "SEND CUSTOM PAYLOAD",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 2,
                                  color: MioColors.white,
                                  fontFamily: 'Nevera',
                                ),
                              ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ===== FOOTER =====
                  _mioCard(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        const Icon(
                          FontAwesomeIcons.exclamationTriangle,
                          color: MioColors.pink,
                          size: 14,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            "Custom attack with multiple payloads. Use responsibly.",
                            style: TextStyle(
                              color: MioColors.softInk,
                              fontSize: 11,
                              fontFamily: 'Nevera',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== COPYRIGHT =====
                  Column(
                    children: [
                      Container(
                        width: 40,
                        height: 2,
                        color: MioColors.white.withValues(alpha: 0.6),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                        style: TextStyle(
                          fontSize: 9,
                          letterSpacing: 2,
                          color: MioColors.white,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Nevera',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          // ===== SPLASH OVERLAY =====
          if (_showSplash) _buildSplashOverlay(),
        ],
      ),
    );
  }

  Widget _buildSenderOption(String label, IconData icon, bool selected,
      int count, String limit, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: selected ? MioColors.deepBlue : MioColors.ice,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: selected ? MioColors.deepBlue : MioColors.silver,
              width: 2,
            ),
          ),
          child: Column(
            children: [
              Icon(
                icon,
                color: selected ? MioColors.white : MioColors.softInk,
                size: 22,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: selected ? MioColors.white : MioColors.ink,
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                  fontFamily: 'Nevera',
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 2),
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: selected
                      ? MioColors.white.withValues(alpha: 0.2)
                      : MioColors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  _isLoadingSenders ? "..." : "$count Sender",
                  style: TextStyle(
                    color: selected ? MioColors.white : MioColors.softInk,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Nevera',
                  ),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                limit,
                style: TextStyle(
                  color: selected
                      ? MioColors.white.withValues(alpha: 0.7)
                      : MioColors.softInk.withValues(alpha: 0.7),
                  fontSize: 8,
                  fontFamily: 'Nevera',
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStep(int step, String label, IconData icon, int active) {
    final isActive = active >= step;
    final isCurrent = active == step;
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: isActive ? MioColors.deepBlue : MioColors.ice,
              shape: BoxShape.circle,
              border: Border.all(
                color: isActive ? MioColors.deepBlue : MioColors.silver,
                width: isCurrent ? 3 : 2,
              ),
              boxShadow: isActive
                  ? [
                      BoxShadow(
                        color: MioColors.deepBlue.withValues(alpha: 0.3),
                        offset: const Offset(0, 4),
                        blurRadius: 8,
                      ),
                    ]
                  : null,
            ),
            child: Icon(
              icon,
              color: isActive ? MioColors.white : MioColors.softInk,
              size: 16,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isActive ? MioColors.deepBlue : MioColors.softInk,
              fontSize: 9,
              fontFamily: 'Nevera',
              fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLine(bool active) {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        color: active ? MioColors.deepBlue : MioColors.silver,
      ),
    );
  }

  Widget _statusItem(IconData icon, String label, bool isOnline) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isOnline
                ? MioColors.green.withValues(alpha: 0.15)
                : MioColors.ice,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: isOnline ? MioColors.green : MioColors.softInk,
            size: 18,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: isOnline ? MioColors.ink : MioColors.softInk,
            fontSize: 9,
            fontFamily: 'Nevera',
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 2),
        Container(
          width: 30,
          height: 2,
          color: isOnline ? MioColors.green : MioColors.silver,
        ),
      ],
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _videoController.dispose();
    _splashController?.dispose();
    targetController.dispose();
    qtyController.dispose();
    delayController.dispose();
    super.dispose();
  }
}

// ==================== SUCCESS DIALOG ====================
class CustomSuccessDialog extends StatefulWidget {
  final String target;
  final Map<String, dynamic> details;
  final VoidCallback onDismiss;

  const CustomSuccessDialog({
    super.key,
    required this.target,
    required this.details,
    required this.onDismiss,
  });

  @override
  State<CustomSuccessDialog> createState() => _CustomSuccessDialogState();
}

class _CustomSuccessDialogState extends State<CustomSuccessDialog>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );
    _fadeController.forward();
    _scaleController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: ScaleTransition(
          scale: _scaleAnimation,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: MioColors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: MioColors.deepBlue.withValues(alpha: 0.25),
                  offset: const Offset(0, 8),
                  blurRadius: 20,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: MioColors.green.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(
                    FontAwesomeIcons.checkDouble,
                    color: MioColors.green,
                    size: 40,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  "CUSTOM ATTACK SENT!",
                  style: TextStyle(
                    color: MioColors.ink,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Nevera',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: MioColors.ice,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      _detailRow("Target", widget.target),
                      _detailRow("Sender Type",
                          widget.details["senderType"] ?? "N/A"),
                      _detailRow("Payloads",
                          (widget.details["bugs"] ?? 0).toString()),
                      _detailRow("Quantity",
                          (widget.details["qty"] ?? 1).toString()),
                      _detailRow(
                          "Delay", "${widget.details["delay"] ?? 100}ms"),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: widget.onDismiss,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: MioColors.deepBlue,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: MioColors.deepBlue.withValues(alpha: 0.35),
                          offset: const Offset(0, 6),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Text(
                        "DONE",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: MioColors.white,
                          fontFamily: 'Nevera',
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 90,
            child: Text(
              "$label:",
              style: const TextStyle(
                color: MioColors.softInk,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                fontFamily: 'Nevera',
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: MioColors.ink,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily: 'Nevera',
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}