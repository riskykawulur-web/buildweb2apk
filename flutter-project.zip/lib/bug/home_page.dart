import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with TickerProviderStateMixin {
  final targetController = TextEditingController();

  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // ===== VIDEO LANDING =====
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  // ===== VIDEO SPLASH (INTRO) =====
  VideoPlayerController? _splashController;
  bool _splashInitialized = false;
  bool _showSplash = false;

  String selectedBugId = "";
  String selectedBugName = "";
  bool _isSending = false;
  bool _isSuccess = false;
  int _activeStep = 0;
  bool _isProcessing = false;

  // ===== COOLDOWN LOCK =====
  // true = user harus tekan DONE dulu sebelum bisa kirim lagi
  bool _isCooldown = false;

  // ===== POPUP LOCK (biar cooldown tidak nimpa popup sukses) =====
  bool _isDialogOpen = false;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeVideoController();
    _setDefaultBug();
    _startAnimations();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _setDefaultBug() {
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
      selectedBugName = widget.listBug[0]['bug_name'] ?? '';
    }
  }

  // ===== VIDEO LANDING =====
  void _initializeVideoController() {
    try {
      _videoController =
          VideoPlayerController.asset('assets/videos/landing.mp4')
            ..initialize().then((_) {
              if (mounted) {
                setState(() {
                  _videoInitialized = true;
                });
                _videoController.setLooping(true);
                _videoController.play();
                _videoController.setVolume(0);
              }
            }).catchError((error) {
              print('Video initialization error: $error');
              if (mounted) {
                setState(() {
                  _videoError = true;
                });
              }
            });
    } catch (e) {
      print('Video controller creation error: $e');
      if (mounted) {
        setState(() {
          _videoError = true;
        });
      }
    }
  }

  // ===== VIDEO SPLASH (INTRO) =====
  void _showSplashVideo() {
    // ===== BLOKIR KALAU MASIH COOLDOWN / DIALOG TERBUKA =====
    if (_isCooldown || _isDialogOpen) return;

    try {
      _splashController =
          VideoPlayerController.asset('assets/videos/splash.mp4')
            ..initialize().then((_) {
              if (mounted) {
                setState(() {
                  _splashInitialized = true;
                  _showSplash = true;
                });

                _splashController!.setLooping(false);
                _splashController!.play();
                _splashController!.setVolume(1.0);

                _splashController!.addListener(() {
                  if (_splashController!.value.position >=
                      _splashController!.value.duration) {
                    _splashController!.pause();
                    _closeSplashAndSend();
                  }
                });
              }
            }).catchError((error) {
              print('Splash video initialization error: $error');
              _closeSplashAndSend();
            });
    } catch (e) {
      print('Splash video creation error: $e');
      _closeSplashAndSend();
    }
  }

  void _closeSplashAndSend() {
    if (!mounted) return;
    setState(() {
      _showSplash = false;
      _isProcessing = true;
      _activeStep = 1;
    });

    Future.delayed(const Duration(milliseconds: 500), () {
      _executeSendBug();
    });
  }

  // ==================== SEND BUG ====================
  void _executeSendBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number",
          "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
      setState(() {
        _isSending = false;
        _isProcessing = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/api/whatsapp/sendBug?key=$key&target=$target&bug=$selectedBugId"));
      final data = jsonDecode(res.body);

      if (!mounted) return;

      // ===== COOLDOWN =====
      if (data["cooldown"] == true) {
        setState(() {
          _isSending = false;
          _isProcessing = false;
          _activeStep = 0;
        });
        // Tampilkan alert cooldown HANYA kalau tidak ada dialog lain terbuka
        if (!_isDialogOpen) {
          _showAlert("⏳ Cooldown",
              "Tunggu beberapa saat sebelum mengirim lagi.");
        }
      } else if (data["senderOn"] == false) {
        setState(() {
          _isSending = false;
          _isProcessing = false;
          _activeStep = 0;
        });
        _showAlert("⚠️ Gagal",
            "Gagal mengirim bug. Sender Kosong, add dulu di sender.");
      } else if (data["valid"] == false) {
        setState(() {
          _isSending = false;
          _isProcessing = false;
          _activeStep = 0;
        });
        _showAlert("❌ Key Invalid",
            "Session key tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() {
          _isSending = false;
          _isProcessing = false;
          _activeStep = 0;
        });
        _showAlert("⚠️ Gagal",
            "Gagal mengirim bug. Mungkin server sedang maintenance.");
      } else {
        // ===== SUKSES =====
        // Set cooldown lock → user harus DONE dulu
        // _activeStep tetap di 2 → progress bar di posisi Complete
        setState(() {
          _activeStep = 2;
          _isSuccess = true;
          _isSending = false;
          _isProcessing = false;
          _isCooldown = true;
        });
        _showSuccessPopup(target);
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isSending = false;
        _isProcessing = false;
        _activeStep = 0;
      });
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _showSuccessPopup(String target) {
    _isDialogOpen = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => SuccessDialog(
        target: target,
        bugName: selectedBugName,
        onDismiss: () {
          Navigator.of(context).pop();
          _isDialogOpen = false;
          if (!mounted) return;
          // ===== BARU RESET SETELAH DONE DITEKAN =====
          setState(() {
            _isSuccess = false;
            _isCooldown = false;
            _activeStep = 0;
          });
        },
      ),
    ).whenComplete(() {
      _isDialogOpen = false;
    });
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    if (_isDialogOpen) return; // jangan tumpuk dialog

    _isDialogOpen = true;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: title.contains("Invalid") ||
                        title.contains("Gagal") ||
                        title.contains("Error")
                    ? MioColors.red.withValues(alpha: 0.15)
                    : MioColors.deepBlue.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                title.contains("Invalid") ||
                        title.contains("Gagal") ||
                        title.contains("Error")
                    ? Icons.error_outline
                    : Icons.info_outline,
                color: title.contains("Invalid") ||
                        title.contains("Gagal") ||
                        title.contains("Error")
                    ? MioColors.red
                    : MioColors.deepBlue,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: MioColors.ink,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Nevera',
                ),
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: MioColors.softInk,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Nevera',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: MioColors.deepBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              "OK",
              style: TextStyle(
                color: MioColors.white,
                fontFamily: 'Nevera',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    ).whenComplete(() {
      _isDialogOpen = false;
    });
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/Haimiya.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: MioColors.deepBlue),
          ),
        ),
        Positioned.fill(
          child: Container(color: MioColors.deepBlue.withValues(alpha: 0.55)),
        ),
      ],
    );
  }

  // ==================== MIO CARD ====================
  Widget _mioCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 16,
    EdgeInsets padding = const EdgeInsets.all(16),
    EdgeInsets? margin,
  }) {
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.18),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }

  // ==================== SPLASH OVERLAY ====================
  Widget _buildSplashOverlay() {
    if (!_showSplash || !_splashInitialized || _splashController == null) {
      return const SizedBox.shrink();
    }

    return Container(
      color: Colors.black.withValues(alpha: 0.92),
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: Container(
          width: 340,
          height: 500,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: MioColors.deepBlue, width: 3),
            boxShadow: [
              BoxShadow(
                color: MioColors.deepBlue.withValues(alpha: 0.5),
                blurRadius: 24,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(13),
            child: VideoPlayer(_splashController!),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ===== TITLE =====
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: MioColors.deepBlue,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color:
                                      MioColors.deepBlue.withValues(alpha: 0.4),
                                  offset: const Offset(0, 6),
                                  blurRadius: 14,
                                ),
                              ],
                            ),
                            child: const Icon(
                              FontAwesomeIcons.whatsapp,
                              color: MioColors.white,
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Text(
                            "Bug Attack",
                            style: TextStyle(
                              color: MioColors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Nevera',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // ===== USER CARD =====
                      _mioCard(
                        child: Row(
                          children: [
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                color: MioColors.deepBlue,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  'assets/images/icon.jpg',
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => const Icon(
                                    Icons.person,
                                    color: MioColors.white,
                                    size: 26,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    widget.username,
                                    style: const TextStyle(
                                      color: MioColors.ink,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: 'Nevera',
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Row(
                                    children: [
                                      Text(
                                        "EXP: ${widget.expiredDate.split(' ').first}",
                                        style: const TextStyle(
                                          color: MioColors.softInk,
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          fontFamily: 'Nevera',
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 3),
                                        decoration: BoxDecoration(
                                          color: MioColors.deepBlue
                                              .withValues(alpha: 0.15),
                                          borderRadius:
                                              BorderRadius.circular(6),
                                        ),
                                        child: Text(
                                          widget.role.toUpperCase(),
                                          style: const TextStyle(
                                            color: MioColors.deepBlue,
                                            fontSize: 9,
                                            fontWeight: FontWeight.w800,
                                            fontFamily: 'Nevera',
                                            letterSpacing: 1,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== VIDEO LANDING =====
                      ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Container(
                          width: double.infinity,
                          height: 180,
                          color: MioColors.silver,
                          child: _videoInitialized && !_videoError
                              ? Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    FittedBox(
                                      fit: BoxFit.cover,
                                      child: SizedBox(
                                        width:
                                            _videoController.value.size.width,
                                        height:
                                            _videoController.value.size.height,
                                        child:
                                            VideoPlayer(_videoController),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 10,
                                      right: 10,
                                      child: GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            if (_videoController
                                                .value.isPlaying) {
                                              _videoController.pause();
                                            } else {
                                              _videoController.play();
                                            }
                                          });
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.all(8),
                                          decoration: const BoxDecoration(
                                            color: MioColors.white,
                                            shape: BoxShape.circle,
                                          ),
                                          child: Icon(
                                            _videoController.value.isPlaying
                                                ? Icons.pause
                                                : Icons.play_arrow,
                                            color: MioColors.deepBlue,
                                            size: 20,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              : const Center(
                                  child: CircularProgressIndicator(
                                    color: MioColors.deepBlue,
                                    strokeWidth: 2,
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== PROGRESS =====
                      _mioCard(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 14),
                        child: Row(
                          children: [
                            _buildStep(0, "Input", Icons.edit, _activeStep),
                            _buildLine(_activeStep > 0),
                            _buildStep(1, "Process", Icons.settings,
                                _activeStep),
                            _buildLine(_activeStep > 1),
                            _buildStep(2, "Complete",
                                Icons.check_circle, _activeStep),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== TARGET INPUT =====
                      _mioCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Target Number",
                              style: TextStyle(
                                color: MioColors.ink,
                                fontFamily: 'Nevera',
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: targetController,
                              style: const TextStyle(
                                color: MioColors.ink,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Nevera',
                              ),
                              cursorColor: MioColors.deepBlue,
                              decoration: InputDecoration(
                                hintText: "e.g. +62xxxxxxxxx",
                                hintStyle: TextStyle(
                                  color: MioColors.softInk
                                      .withValues(alpha: 0.7),
                                  fontFamily: 'Nevera',
                                  fontWeight: FontWeight.w600,
                                ),
                                filled: true,
                                fillColor: MioColors.ice,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide.none,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide.none,
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(
                                      color: MioColors.deepBlue, width: 2),
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                    vertical: 14, horizontal: 16),
                                prefixIcon: const Icon(
                                  FontAwesomeIcons.phone,
                                  color: MioColors.deepBlue,
                                  size: 18,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              "Use international format without 0 or +",
                              style: TextStyle(
                                color: MioColors.softInk,
                                fontSize: 11,
                                fontFamily: 'Nevera',
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== BUG TYPE SELECTION =====
                      _mioCard(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Select Bug Type",
                              style: TextStyle(
                                color: MioColors.ink,
                                fontFamily: 'Nevera',
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 10),
                            SizedBox(
                              height: 100,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                physics: const BouncingScrollPhysics(),
                                itemCount: widget.listBug.length,
                                itemBuilder: (context, index) {
                                  final bug = widget.listBug[index];
                                  final isSelected =
                                      selectedBugId == bug['bug_id'];
                                  final bugName = bug['bug_name'] ?? '';
                                  final bugId = bug['bug_id'] ?? '';

                                  return GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        selectedBugId = bugId;
                                        selectedBugName = bugName;
                                      });
                                    },
                                    child: Container(
                                      width: 180,
                                      margin: const EdgeInsets.only(right: 12),
                                      padding: const EdgeInsets.all(14),
                                      decoration: BoxDecoration(
                                        color: isSelected
                                            ? MioColors.deepBlue
                                            : MioColors.ice,
                                        borderRadius:
                                            BorderRadius.circular(16),
                                        border: Border.all(
                                          color: isSelected
                                              ? MioColors.deepBlue
                                              : MioColors.silver,
                                          width: 2,
                                        ),
                                        boxShadow: isSelected
                                            ? [
                                                BoxShadow(
                                                  color: MioColors.deepBlue
                                                      .withValues(alpha: 0.35),
                                                  offset: const Offset(0, 6),
                                                  blurRadius: 12,
                                                ),
                                              ]
                                            : null,
                                      ),
                                      child: Row(
                                        children: [
                                          Icon(
                                            FontAwesomeIcons.virus,
                                            color: isSelected
                                                ? MioColors.white
                                                : MioColors.softInk,
                                            size: 26,
                                          ),
                                          const SizedBox(width: 10),
                                          Expanded(
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  bugName,
                                                  style: TextStyle(
                                                    color: isSelected
                                                        ? MioColors.white
                                                        : MioColors.ink,
                                                    fontSize: 13,
                                                    fontWeight:
                                                        FontWeight.w800,
                                                    fontFamily: 'Nevera',
                                                  ),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                                const SizedBox(height: 4),
                                                Container(
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                      horizontal: 8,
                                                      vertical: 2),
                                                  decoration: BoxDecoration(
                                                    color: isSelected
                                                        ? MioColors.white
                                                            .withValues(
                                                                alpha: 0.2)
                                                        : MioColors.white,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            6),
                                                  ),
                                                  child: Text(
                                                    "#$bugId",
                                                    style: TextStyle(
                                                      color: isSelected
                                                          ? MioColors.white
                                                          : MioColors.softInk,
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      fontFamily: 'Nevera',
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== STATUS =====
                      _mioCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "System Status",
                              style: TextStyle(
                                color: MioColors.ink,
                                fontFamily: 'Nevera',
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _statusItem(
                                    Icons.dns_rounded, "Server", true),
                                _statusItem(Icons.verified_user_rounded,
                                    "Security", true),
                                _statusItem(Icons.storage_rounded,
                                    "Database", true),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // ===== SEND BUTTON =====
                      GestureDetector(
                        // ===== BLOKIR KALAU COOLDOWN / DIALOG AKTIF =====
                        onTap: (_isSending ||
                                _isProcessing ||
                                _isCooldown ||
                                _isDialogOpen)
                            ? null
                            : _showSplashVideo,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            color: (_isSending ||
                                    _isProcessing ||
                                    _isCooldown ||
                                    _isDialogOpen)
                                ? MioColors.silver
                                : MioColors.deepBlue,
                            borderRadius: BorderRadius.circular(14),
                            boxShadow: (_isSending ||
                                    _isProcessing ||
                                    _isCooldown ||
                                    _isDialogOpen)
                                ? null
                                : [
                                    BoxShadow(
                                      color: MioColors.deepBlue
                                          .withValues(alpha: 0.4),
                                      offset: const Offset(0, 8),
                                      blurRadius: 16,
                                    ),
                                  ],
                          ),
                          child: Center(
                            child: (_isSending ||
                                    _isProcessing ||
                                    _isCooldown ||
                                    _isDialogOpen)
                                ? const SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                      color: MioColors.white,
                                      strokeWidth: 2.5,
                                    ),
                                  )
                                : const Text(
                                    "SEND BUG",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 2,
                                      color: MioColors.white,
                                      fontFamily: 'Nevera',
                                    ),
                                  ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),

                      // ===== FOOTER =====
                      _mioCard(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            const Icon(
                              FontAwesomeIcons.exclamationTriangle,
                              color: MioColors.pink,
                              size: 14,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                "Use this tool responsibly. We are not responsible for any misuse.",
                                style: TextStyle(
                                  color: MioColors.softInk,
                                  fontSize: 11,
                                  fontFamily: 'Nevera',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== COPYRIGHT =====
                      Column(
                        children: [
                          Container(
                            width: 40,
                            height: 2,
                            color: MioColors.white.withValues(alpha: 0.6),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            "© 2026 X•RZYN v2 PROJECT • ALL RIGHTS RESERVED",
                            style: TextStyle(
                              fontSize: 9,
                              letterSpacing: 2,
                              color: MioColors.white,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Nevera',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          // ===== SPLASH OVERLAY =====
          if (_showSplash) _buildSplashOverlay(),
        ],
      ),
    );
  }

  Widget _buildStep(int step, String label, IconData icon, int active) {
    final isActive = active >= step;
    final isCurrent = active == step;
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: isActive ? MioColors.deepBlue : MioColors.ice,
              shape: BoxShape.circle,
              border: Border.all(
                color: isActive ? MioColors.deepBlue : MioColors.silver,
                width: isCurrent ? 3 : 2,
              ),
              boxShadow: isActive
                  ? [
                      BoxShadow(
                        color: MioColors.deepBlue.withValues(alpha: 0.3),
                        offset: const Offset(0, 4),
                        blurRadius: 8,
                      ),
                    ]
                  : null,
            ),
            child: Icon(icon,
                color: isActive ? MioColors.white : MioColors.softInk,
                size: 16),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isActive ? MioColors.deepBlue : MioColors.softInk,
              fontSize: 9,
              fontFamily: 'Nevera',
              fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLine(bool active) {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        color: active ? MioColors.deepBlue : MioColors.silver,
      ),
    );
  }

  Widget _statusItem(IconData icon, String label, bool isOnline) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isOnline
                ? MioColors.green.withValues(alpha: 0.15)
                : MioColors.ice,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon,
              color: isOnline ? MioColors.green : MioColors.softInk,
              size: 18),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: isOnline ? MioColors.ink : MioColors.softInk,
            fontSize: 9,
            fontFamily: 'Nevera',
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 2),
        Container(
          width: 30,
          height: 2,
          color: isOnline ? MioColors.green : MioColors.silver,
        ),
      ],
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _videoController.dispose();
    _splashController?.dispose();
    targetController.dispose();
    super.dispose();
  }
}

// ==================== SUCCESS DIALOG ====================
class SuccessDialog extends StatefulWidget {
  final String target;
  final String bugName;
  final VoidCallback onDismiss;

  const SuccessDialog({
    super.key,
    required this.target,
    required this.bugName,
    required this.onDismiss,
  });

  @override
  State<SuccessDialog> createState() => _SuccessDialogState();
}

class _SuccessDialogState extends State<SuccessDialog>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );
    _fadeController.forward();
    _scaleController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: ScaleTransition(
          scale: _scaleAnimation,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: MioColors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: MioColors.deepBlue.withValues(alpha: 0.25),
                  offset: const Offset(0, 8),
                  blurRadius: 20,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // ===== ICON SUKSES =====
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: MioColors.green.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(
                    Icons.check_circle,
                    color: MioColors.green,
                    size: 44,
                  ),
                ),
                const SizedBox(height: 16),

                // ===== TITLE =====
                const Text(
                  "BUG SUKSES",
                  style: TextStyle(
                    color: MioColors.ink,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Nevera',
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 18),

                // ===== TARGET NUMBER =====
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: MioColors.ice,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.phone,
                          color: MioColors.deepBlue, size: 18),
                      const SizedBox(width: 10),
                      const Text(
                        "Number",
                        style: TextStyle(
                          color: MioColors.softInk,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Nevera',
                        ),
                      ),
                      const Spacer(),
                      Flexible(
                        child: Text(
                          widget.target,
                          style: const TextStyle(
                            color: MioColors.ink,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Nevera',
                          ),
                          textAlign: TextAlign.right,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // ===== TYPE BUG =====
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: MioColors.ice,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.bug_report,
                          color: MioColors.deepBlue, size: 18),
                      const SizedBox(width: 10),
                      const Text(
                        "Type Bug",
                        style: TextStyle(
                          color: MioColors.softInk,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Nevera',
                        ),
                      ),
                      const Spacer(),
                      Flexible(
                        child: Text(
                          widget.bugName.isNotEmpty
                              ? widget.bugName
                              : widget.target,
                          style: const TextStyle(
                            color: MioColors.ink,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Nevera',
                          ),
                          textAlign: TextAlign.right,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // ===== DONE =====
                GestureDetector(
                  onTap: widget.onDismiss,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: MioColors.deepBlue,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: MioColors.deepBlue.withValues(alpha: 0.35),
                          offset: const Offset(0, 6),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Text(
                        "DONE",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: MioColors.white,
                          fontFamily: 'Nevera',
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}