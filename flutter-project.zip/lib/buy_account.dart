import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

// ==================== HAIMIYA MIO PALETTE (SILVER / BLUE) ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
  static const Color yellow = Color(0xFFFACC15);
  static const Color black = Color(0xFF1A1A1A);
}

class BuyAccountPage extends StatelessWidget {
  const BuyAccountPage({super.key});

  final List<Map<String, dynamic>> priceList = const [
    {
      'title': 'MEMBER HARIAN',
      'price': '10K',
      'duration': '10 Hari',
      'color': MioColors.softInk,
      'role': 'MEMBER',
    },
    {
      'title': 'MEMBER',
      'price': '15K',
      'duration': 'PERMANEN',
      'color': MioColors.softInk,
      'role': 'MEMBER',
    },
    {
      'title': 'RESELLER',
      'price': '20K',
      'duration': 'PERMANEN',
      'color': MioColors.blue,
      'role': 'RESELLER',
    },
    {
      'title': 'VIP',
      'price': '25K',
      'duration': 'PERMANEN',
      'color': MioColors.yellow,
      'role': 'VIP',
    },
    {
      'title': 'HELPER',
      'price': '30K',
      'duration': 'PERMANEN',
      'color': MioColors.green,
      'role': 'HELPER',
    },
    {
      'title': 'ADMIN',
      'price': '35K',
      'duration': 'PERMANEN',
      'color': MioColors.blue,
      'role': 'ADMIN',
    },
    {
      'title': 'PT',
      'price': '40K',
      'duration': 'PERMANEN',
      'color': MioColors.purple,
      'role': 'PT',
    },
    {
      'title': 'HIGH PT',
      'price': '50K',
      'duration': 'PERMANEN',
      'color': MioColors.purple,
      'role': 'HIGH_PT',
    },
  ];

  final List<String> bugList = const [
    'For Close',
    'Buldo Crash Delay',
    'Freeze',
    'Blank Pack',
    'Crash Spam',
    'Delay Invis',
    'Crash Spam B0kep',
  ];

  final List<String> fiturList = const [
    'SPAM OTP',
    'SPAM WA',
    'CUSTOM BUG',
    'GROUP BUG',
    'DDOS PANEL',
    'SENDER',
  ];

  Future<void> _contactWA(
      BuildContext context, String title, String price) async {
    final message = 'Bang RizzKezi beli apk RZYN harga $price role $title';
    final encodedMessage = Uri.encodeComponent(message);
    final url = 'https://wa.me/6287876074328?text=$encodedMessage';

    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        final fallbackUri = Uri.parse('https://wa.me/6287876074328');
        if (await canLaunchUrl(fallbackUri)) {
          await launchUrl(fallbackUri, mode: LaunchMode.externalApplication);
        }
      }
    } catch (e) {
      // ignore
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.ice,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(18, 22, 18, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ===== HEADER =====
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: MioColors.deepBlue,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: MioColors.deepBlue.withValues(alpha: 0.35),
                          offset: const Offset(0, 4),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.shopping_cart_rounded,
                      color: MioColors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "R Z Y N",
                    style: TextStyle(
                      color: MioColors.deepBlue,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Nevera',
                      letterSpacing: 4,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: MioColors.pink,
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: MioColors.pink.withValues(alpha: 0.35),
                          offset: const Offset(0, 3),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: const Text(
                      'NEW PROJECT',
                      style: TextStyle(
                        color: MioColors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Nevera',
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Padding(
                padding: const EdgeInsets.only(left: 2),
                child: Text(
                  "Pilih paket yang sesuai dengan kebutuhan Anda",
                  style: TextStyle(
                    color: MioColors.softInk,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Nevera',
                  ),
                ),
              ),
              const SizedBox(height: 18),

              // ===== PRICE LIST =====
              ...priceList.map((item) {
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: _buildPriceCard(
                    title: item['title']!,
                    price: item['price']!,
                    duration: item['duration']!,
                    color: item['color']!,
                    onTap: () =>
                        _contactWA(context, item['title']!, item['price']!),
                  ),
                );
              }).toList(),

              const SizedBox(height: 16),

              // ===== DIVIDER =====
              Container(
                height: 1,
                color: MioColors.deepBlue.withValues(alpha: 0.15),
              ),
              const SizedBox(height: 16),

              // ===== BUG LIST =====
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: MioColors.pink.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.bug_report_rounded,
                      color: MioColors.pink,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    "Bug WhatsApp",
                    style: TextStyle(
                      color: MioColors.deepBlue,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Nevera',
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: bugList.map((bug) {
                  return Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: MioColors.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: MioColors.pink.withValues(alpha: 0.5),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: MioColors.deepBlue.withValues(alpha: 0.08),
                          offset: const Offset(0, 3),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                    child: Text(
                      bug,
                      style: const TextStyle(
                        color: MioColors.ink,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Nevera',
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 18),

              // ===== FITUR TAMBAHAN =====
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: MioColors.purple.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.star_rounded,
                      color: MioColors.purple,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    "Fitur Tambahan",
                    style: TextStyle(
                      color: MioColors.deepBlue,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Nevera',
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: fiturList.map((fitur) {
                  return Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: MioColors.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: MioColors.purple.withValues(alpha: 0.5),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: MioColors.deepBlue.withValues(alpha: 0.08),
                          offset: const Offset(0, 3),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                    child: Text(
                      fitur,
                      style: const TextStyle(
                        color: MioColors.purple,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Nevera',
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 18),

              // ===== DIVIDER =====
              Container(
                height: 1,
                color: MioColors.deepBlue.withValues(alpha: 0.15),
              ),
              const SizedBox(height: 16),

              // ===== INFO ORDER =====
              _modernCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.info_outline_rounded,
                          color: MioColors.blue,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          "Cara Order",
                          style: TextStyle(
                            color: MioColors.deepBlue,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Nevera',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "1. Pilih paket yang diinginkan\n"
                      "2. Klik paket tersebut\n"
                      "3. Otomatis terhubung ke WhatsApp\n"
                      "4. Pesan otomatis terisi\n"
                      "5. Kirim pesan untuk lanjutkan",
                      style: TextStyle(
                        color: MioColors.softInk,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Nevera',
                        height: 1.7,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // ===== COPYRIGHT =====
              Center(
                child: Column(
                  children: [
                    Container(
                      width: 40,
                      height: 2,
                      color: MioColors.deepBlue.withValues(alpha: 0.4),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                      style: TextStyle(
                        fontSize: 9,
                        letterSpacing: 2,
                        color: MioColors.softInk,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Nevera',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== PRICE CARD ====================
  Widget _buildPriceCard({
    required String title,
    required String price,
    required String duration,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: MioColors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withValues(alpha: 0.6),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: MioColors.deepBlue.withValues(alpha: 0.10),
              offset: const Offset(0, 5),
              blurRadius: 12,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                Icons.verified_rounded,
                color: color,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: MioColors.deepBlue,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Nevera',
                      letterSpacing: 0.8,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Text(
                        price,
                        style: TextStyle(
                          color: color,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Nevera',
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          duration,
                          style: TextStyle(
                            color: color,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Nevera',
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: MioColors.deepBlue,
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                    color: MioColors.deepBlue.withValues(alpha: 0.35),
                    offset: const Offset(0, 3),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: const Icon(
                Icons.arrow_forward_ios_rounded,
                color: MioColors.white,
                size: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== MODERN CARD ====================
  Widget _modernCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 18,
    EdgeInsets padding = const EdgeInsets.all(18),
  }) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.10),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }
}