import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

// Import DashboardPage dari loader_page.dart
import 'loader_page.dart';

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
}

class SplashPage extends StatefulWidget {
  final Map<String, dynamic> data;

  const SplashPage({super.key, required this.data});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with TickerProviderStateMixin {
  late VideoPlayerController _bgController;

  late AnimationController _textFadeController;
  late Animation<double> _textFadeAnimation;

  late AnimationController _loadingController;
  late Animation<double> _loadingAnimation;

  Timer? _navigationTimer;

  @override
  void initState() {
    super.initState();

    _bgController = VideoPlayerController.asset('assets/videos/background.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _bgController.setLooping(true);
        _bgController.setVolume(1.0);
        _bgController.play();
      });

    _textFadeController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    _textFadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _textFadeController, curve: Curves.easeOut),
    );

    _loadingController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    );
    _loadingAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _loadingController, curve: Curves.easeInOut),
    );

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
    _startAnimations();
  }

  void _startAnimations() {
    _textFadeController.forward();
    _loadingController.forward();

    _navigationTimer = Timer(const Duration(seconds: 10), () {
      _navigateToDashboard();
    });
  }

  void _navigateToDashboard() {
    _textFadeController.stop();
    _loadingController.stop();
    _navigationTimer?.cancel();

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => DashboardPage(
            username: widget.data['username'] ?? '',
            password: widget.data['password'] ?? '',
            role: widget.data['role'] ?? 'user',
            expiredDate: widget.data['expiredDate'] ?? '-',
            sessionKey: widget.data['key'] ?? '',
            listBug: List<Map<String, dynamic>>.from(widget.data['listBug'] ?? []),
            listPayload:
                List<Map<String, dynamic>>.from(widget.data['listPayload'] ?? []),
            listDDoS: List<Map<String, dynamic>>.from(widget.data['listDDoS'] ?? []),
            news: List<Map<String, dynamic>>.from(widget.data['news'] ?? []),
          ),
        ),
      );
    }
  }

  String _getPercentage(double value) {
    final percent = (value * 100).toInt();
    return "$percent%";
  }

  @override
  void dispose() {
    _bgController.dispose();
    _textFadeController.dispose();
    _loadingController.dispose();
    _navigationTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ===== BACKGROUND VIDEO =====
          _bgController.value.isInitialized
              ? FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _bgController.value.size.width,
                    height: _bgController.value.size.height,
                    child: VideoPlayer(_bgController),
                  ),
                )
              : Container(color: MioColors.deepBlue),

          // ===== DARK OVERLAY BIAR TEKS KEBACA =====
          Container(
            color: MioColors.deepBlue.withOpacity(0.55),
          ),

          // ===== KONTEN UTAMA =====
          SafeArea(
            child: FadeTransition(
              opacity: _textFadeAnimation,
              child: Column(
                children: [
                  const Spacer(flex: 3),

                  // ===== TITLE =====
                  const Text(
                    "R Z Y N Project",
                    style: TextStyle(
                      fontFamily: 'Nevera',
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      color: MioColors.white,
                      letterSpacing: 4,
                    ),
                  ),
                  const SizedBox(height: 10),

                  // ===== SUBTITLE =====
                  Text(
                    "by Power @Rizzisreal01",
                    style: TextStyle(
                      fontFamily: 'Nevera',
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: MioColors.white.withOpacity(0.85),
                      letterSpacing: 1.5,
                    ),
                  ),

                  const Spacer(flex: 3),

                  // ===== INITIALIZING (TANPA CARD) =====
                  AnimatedBuilder(
                    animation: _loadingAnimation,
                    builder: (context, child) {
                      final progress = _loadingAnimation.value;
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text(
                            "Initializing",
                            style: TextStyle(
                              fontFamily: 'Nevera',
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: MioColors.white,
                              letterSpacing: 3,
                            ),
                          ),
                          const SizedBox(height: 14),

                          // ===== PROGRESS BAR TIPIS =====
                          Container(
                            width: 240,
                            height: 3,
                            decoration: BoxDecoration(
                              color: MioColors.white.withOpacity(0.25),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: FractionallySizedBox(
                              alignment: Alignment.centerLeft,
                              widthFactor: progress,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: MioColors.lightBlue,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),

                          // ===== PERSENTASE =====
                          Text(
                            _getPercentage(progress),
                            style: TextStyle(
                              fontFamily: 'Nevera',
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: MioColors.white.withOpacity(0.8),
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      );
                    },
                  ),

                  const Spacer(flex: 2),
                ],
              ),
            ),
          ),

          // ===== SKIP BUTTON =====
          Positioned(
            top: 50,
            right: 25,
            child: GestureDetector(
              onTap: _navigateToDashboard,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: MioColors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: MioColors.white.withOpacity(0.35),
                    width: 1.5,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Text(
                      "SKIP",
                      style: TextStyle(
                        color: MioColors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        fontFamily: 'Nevera',
                      ),
                    ),
                    SizedBox(width: 6),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: MioColors.white,
                      size: 12,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}