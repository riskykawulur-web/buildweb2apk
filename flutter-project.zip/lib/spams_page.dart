import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

class ReportWaPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const ReportWaPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ReportWaPage> createState() => _ReportWaPageState();
}

class _ReportWaPageState extends State<ReportWaPage> {
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _amountController =
      TextEditingController(text: "5");
  final ScrollController _logScrollController = ScrollController();

  bool _isAttacking = false;
  bool _isLoadingSenders = false;
  List<dynamic> _privateSenders = [];
  List<dynamic> _globalSenders = [];
  String _selectedSenderType = "global";
  List<String> _logs = [];
  int _successCount = 0;
  int _failCount = 0;

  final String _spamText =
      "MAKLO AMPAS MAKLO AMPAS YATIM TOLOL BEGO REDUP AJA LU ANJ MATI AJA ANAK BABI🤪😹😹🤪🖕🖕";
  final String _spamImage =
      "https://cdn.phototourl.com/free/2026-07-21-1f2b70c7-3163-4291-ad0e-f09c90c7ceec.jpg";

  Widget _buildBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/Haimiya.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: MioColors.deepBlue),
          ),
        ),
        Positioned.fill(
          child: Container(color: MioColors.deepBlue.withOpacity(0.55)),
        ),
      ],
    );
  }

  Widget _mioCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 16,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.18),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _mioButton({
    required String label,
    required VoidCallback onTap,
    Color bg = MioColors.deepBlue,
    Color textColor = MioColors.white,
    double fontSize = 14,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: bg.withOpacity(0.35),
              offset: const Offset(0, 6),
              blurRadius: 14,
            ),
          ],
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
              color: textColor,
              fontFamily: 'Nevera',
            ),
          ),
        ),
      ),
    );
  }

  Widget _mioInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool isNumber = false,
    double flex = 1,
  }) {
    return Expanded(
      flex: flex.toInt(),
      child: TextField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.phone,
        style: const TextStyle(
          color: MioColors.ink,
          fontSize: 14,
          fontWeight: FontWeight.w600,
          fontFamily: 'Nevera',
        ),
        cursorColor: MioColors.deepBlue,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
            color: MioColors.softInk.withOpacity(0.7),
            fontFamily: 'Nevera',
            fontWeight: FontWeight.w600,
          ),
          prefixIcon: Icon(icon, color: MioColors.deepBlue, size: 18),
          filled: true,
          fillColor: MioColors.ice,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: MioColors.deepBlue, width: 2),
          ),
          contentPadding:
              const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchSenders();
  }

  @override
  void dispose() {
    _targetController.dispose();
    _amountController.dispose();
    _logScrollController.dispose();
    super.dispose();
  }

  Future<void> _fetchSenders() async {
    setState(() => _isLoadingSenders = true);
    _addLog("[SYSTEM] Authenticating as ${widget.username}...");

    try {
      final uri = Uri.parse(
          "$baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}");
      final response = await http.get(uri);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final connections = data['connections'];

          setState(() {
            _privateSenders = connections['private'] ?? [];
            _globalSenders = connections['global'] ?? [];
          });

          final total = _privateSenders.length + _globalSenders.length;
          _addLog("[ACCESS GRANTED] $total Agents Loaded.");
          _addLog("  └─ Global: ${_globalSenders.length} Agents");
          _addLog("  └─ Private: ${_privateSenders.length} Agents");
        } else {
          _addLog("[ERROR] Session Expired / Invalid Key.");
        }
      } else {
        _addLog("[ERROR] Server Offline (Status: ${response.statusCode})");
      }
    } catch (e) {
      _addLog("[FATAL] Connection Failed: $e");
    } finally {
      setState(() => _isLoadingSenders = false);
    }
  }

  Future<void> _executeSpam() async {
    final List<dynamic> selectedSenders = _selectedSenderType == "global"
        ? _globalSenders
        : _privateSenders;

    if (selectedSenders.isEmpty) {
      _showSnack("No ${_selectedSenderType.toUpperCase()} senders available!",
          MioColors.pink);
      return;
    }

    if (_targetController.text.isEmpty) {
      _showSnack("Target number is required!", MioColors.pink);
      return;
    }

    int totalAmount = int.tryParse(_amountController.text) ?? 5;
    if (totalAmount < 1) totalAmount = 1;
    if (totalAmount > 50) totalAmount = 50;

    setState(() {
      _isAttacking = true;
      _successCount = 0;
      _failCount = 0;
      _logs.clear();
      _addLog("[SYSTEM] 🚀 STARTING SPAM ATTACK");
      _addLog("[TARGET] ${_targetController.text}");
      _addLog("[AMOUNT] $totalAmount Messages");
      _addLog("[SENDER TYPE] ${_selectedSenderType.toUpperCase()}");
      _addLog("[AGENTS] ${selectedSenders.length} Active");
      _addLog("─" * 30);
    });

    for (int i = 0; i < totalAmount; i++) {
      if (!_isAttacking) break;

      var sender = selectedSenders[i % selectedSenders.length];
      String senderNum = sender['owner'] ?? 'Unknown';

      try {
        final textResponse = await http.post(
          Uri.parse("$baseUrl/api/whatsapp/spamText"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "key": widget.sessionKey,
            "target": _targetController.text,
            "sender_number": senderNum,
            "message": _spamText,
          }),
        );

        if (textResponse.statusCode == 200) {
          final textData = jsonDecode(textResponse.body);
          if (textData['success'] == true) {
            _addLog("[${i + 1}] 📝 TEXT SENT via $senderNum");
            setState(() => _successCount++);
          } else {
            _addLog(
                "[${i + 1}] ❌ TEXT FAILED: ${textData['message'] ?? 'Unknown error'}");
            setState(() => _failCount++);
            continue;
          }
        } else {
          _addLog("[${i + 1}] ❌ TEXT FAILED (HTTP ${textResponse.statusCode})");
          setState(() => _failCount++);
          continue;
        }

        await Future.delayed(const Duration(milliseconds: 500));

        final imageResponse = await http.post(
          Uri.parse("$baseUrl/api/whatsapp/spamImage"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "key": widget.sessionKey,
            "target": _targetController.text,
            "sender_number": senderNum,
            "image_url": _spamImage,
            "caption": "MAKLO AMPAS! 🤪🖕",
          }),
        );

        if (imageResponse.statusCode == 200) {
          final imageData = jsonDecode(imageResponse.body);
          if (imageData['success'] == true) {
            _addLog("[${i + 1}] 🖼️ IMAGE SENT via $senderNum");
            setState(() => _successCount++);
          } else {
            _addLog(
                "[${i + 1}] ❌ IMAGE FAILED: ${imageData['message'] ?? 'Unknown error'}");
            setState(() => _failCount++);
          }
        } else {
          _addLog(
              "[${i + 1}] ❌ IMAGE FAILED (HTTP ${imageResponse.statusCode})");
          setState(() => _failCount++);
        }

        await Future.delayed(const Duration(milliseconds: 300));
      } catch (e) {
        _addLog("[${i + 1}] 💀 ERROR: $e");
        setState(() => _failCount++);
      }
    }

    setState(() {
      _isAttacking = false;
      _addLog("─" * 30);
      _addLog("[SYSTEM] ✅ SPAM COMPLETED");
      _addLog("  └─ Success: $_successCount");
      _addLog("  └─ Failed: $_failCount");
      _addLog("  └─ Total: ${_successCount + _failCount}");
    });
  }

  void _addLog(String log) {
    if (!mounted) return;
    setState(() {
      _logs.add(log);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_logScrollController.hasClients) {
          _logScrollController.animateTo(
            _logScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    });
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
        msg,
        style: const TextStyle(
          color: MioColors.white,
          fontFamily: 'Nevera',
          fontWeight: FontWeight.w600,
        ),
      ),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
    ));
  }

  Widget _buildSenderTypeSelector() {
    final int globalCount = _globalSenders.length;
    final int privateCount = _privateSenders.length;

    return _mioCard(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedSenderType = "global"),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: _selectedSenderType == "global"
                      ? MioColors.deepBlue.withOpacity(0.15)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          FontAwesomeIcons.globe,
                          color: _selectedSenderType == "global"
                              ? MioColors.deepBlue
                              : MioColors.softInk,
                          size: 16,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "GLOBAL",
                          style: TextStyle(
                            color: _selectedSenderType == "global"
                                ? MioColors.deepBlue
                                : MioColors.softInk,
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            fontFamily: 'Nevera',
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 2),
                      decoration: BoxDecoration(
                        color: _selectedSenderType == "global"
                            ? MioColors.deepBlue.withOpacity(0.15)
                            : MioColors.ice,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        "$globalCount AGENTS",
                        style: TextStyle(
                          color: _selectedSenderType == "global"
                              ? MioColors.deepBlue
                              : MioColors.softInk,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Nevera',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedSenderType = "private"),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: _selectedSenderType == "private"
                      ? MioColors.purple.withOpacity(0.15)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.lock_outline,
                          color: _selectedSenderType == "private"
                              ? MioColors.purple
                              : MioColors.softInk,
                          size: 16,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "PRIVATE",
                          style: TextStyle(
                            color: _selectedSenderType == "private"
                                ? MioColors.purple
                                : MioColors.softInk,
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            fontFamily: 'Nevera',
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 2),
                      decoration: BoxDecoration(
                        color: _selectedSenderType == "private"
                            ? MioColors.purple.withOpacity(0.15)
                            : MioColors.ice,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        "$privateCount AGENTS",
                        style: TextStyle(
                          color: _selectedSenderType == "private"
                              ? MioColors.purple
                              : MioColors.softInk,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Nevera',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogs() {
    return Container(
      height: 200,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: MioColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.15),
            offset: const Offset(0, 6),
            blurRadius: 14,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  Icon(Icons.terminal, color: MioColors.deepBlue, size: 16),
                  SizedBox(width: 8),
                  Text(
                    "> SYSTEM LOGS",
                    style: TextStyle(
                      color: MioColors.deepBlue,
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                      fontFamily: 'Nevera',
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
              if (_isAttacking)
                const SizedBox(
                  height: 14,
                  width: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: MioColors.green,
                  ),
                )
              else if (_logs.isNotEmpty)
                GestureDetector(
                  onTap: () => setState(() => _logs.clear()),
                  child: const Text(
                    "Clear",
                    style: TextStyle(
                      color: MioColors.pink,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Nevera',
                    ),
                  ),
                ),
            ],
          ),
          const Divider(height: 12, color: MioColors.silver),
          Expanded(
            child: ListView.builder(
              controller: _logScrollController,
              itemCount: _logs.length,
              itemBuilder: (context, index) {
                final log = _logs[index];
                Color textColor;
                if (log.contains("ERROR") ||
                    log.contains("FAILED") ||
                    log.contains("❌") ||
                    log.contains("FATAL")) {
                  textColor = MioColors.pink;
                } else if (log.contains("SUCCESS") ||
                    log.contains("SENT") ||
                    log.contains("✅")) {
                  textColor = MioColors.green;
                } else if (log.contains("🚀") ||
                    log.contains("STARTING") ||
                    log.contains("COMPLETED")) {
                  textColor = MioColors.deepBlue;
                } else if (log.contains("─")) {
                  textColor = MioColors.softInk.withOpacity(0.3);
                } else {
                  textColor = MioColors.softInk;
                }
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 1),
                  child: Text(
                    log,
                    style: TextStyle(
                      color: textColor,
                      fontSize: 10,
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalSenders = _privateSenders.length + _globalSenders.length;

    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: MioColors.deepBlue,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.shield,
                          color: MioColors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Spam Panel",
                        style: TextStyle(
                          color: MioColors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Nevera',
                          letterSpacing: 1,
                        ),
                      ),
                      const Spacer(),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: MioColors.white.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.circle,
                                    color: MioColors.green, size: 6),
                                const SizedBox(width: 4),
                                Text(
                                  "$totalSenders AGENTS",
                                  style: const TextStyle(
                                    color: MioColors.white,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Nevera',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          GestureDetector(
                            onTap: _fetchSenders,
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: MioColors.white.withOpacity(0.9),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(
                                Icons.refresh,
                                color: MioColors.deepBlue,
                                size: 18,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 4),
                    child: Text(
                      "WhatsApp Spam with Text & Image",
                      style: TextStyle(
                        color: MioColors.white.withOpacity(0.85),
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Nevera',
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  _mioCard(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: MioColors.deepBlue,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.asset(
                              'assets/images/icon.jpg',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Icon(
                                Icons.person,
                                color: MioColors.white,
                                size: 24,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.username,
                                style: const TextStyle(
                                  color: MioColors.ink,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Nevera',
                                  fontSize: 14,
                                ),
                              ),
                              Text(
                                "ROLE: ${widget.role.toUpperCase()}",
                                style: const TextStyle(
                                  color: MioColors.softInk,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Nevera',
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  _buildSenderTypeSelector(),
                  const SizedBox(height: 12),

                  _mioCard(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        _mioInput(
                          controller: _targetController,
                          hint: "Target (e.g. 628xx)",
                          icon: Icons.phone,
                          flex: 3,
                        ),
                        const SizedBox(width: 10),
                        _mioInput(
                          controller: _amountController,
                          hint: "Qty",
                          icon: Icons.numbers,
                          isNumber: true,
                          flex: 1,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  _mioButton(
                    label: _isAttacking ? "🛑 STOP SPAM" : "🚀 LAUNCH SPAM",
                    onTap: _isAttacking
                        ? () => setState(() => _isAttacking = false)
                        : _executeSpam,
                    bg: _isAttacking ? MioColors.pink : MioColors.deepBlue,
                    textColor: MioColors.white,
                    fontSize: 14,
                  ),
                  const SizedBox(height: 12),

                  Expanded(child: _buildLogs()),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}