import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// ==================== IMPORT BASEURL ====================
import '../../server/domain_server.dart' show baseUrl;

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  final _newUser = TextEditingController();
  final _newPass = TextEditingController();
  final _days = TextEditingController();
  final _editUser = TextEditingController();
  final _editDays = TextEditingController();
  bool loading = false;

  Widget _buildBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/Haimiya.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) =>
                Container(color: MioColors.deepBlue),
          ),
        ),
        Positioned.fill(
          child: Container(
            color: MioColors.deepBlue.withOpacity(0.55),
          ),
        ),
      ],
    );
  }

  Widget _mioCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 16,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.18),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _mioButton({
    required String label,
    required VoidCallback onTap,
    bool isLoading = false,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: MioColors.deepBlue,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: MioColors.deepBlue.withOpacity(0.3),
              offset: const Offset(0, 6),
              blurRadius: 14,
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    color: MioColors.white,
                    strokeWidth: 2.5,
                  ),
                )
              : Text(
                  label,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                    color: MioColors.white,
                    fontFamily: 'Rajdhani',
                  ),
                ),
        ),
      ),
    );
  }

  Widget _mioInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    bool isNumber = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      style: const TextStyle(
        color: MioColors.ink,
        fontSize: 14,
        fontWeight: FontWeight.w600,
        fontFamily: 'Rajdhani',
      ),
      cursorColor: MioColors.deepBlue,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
          color: MioColors.softInk.withOpacity(0.7),
          fontFamily: 'Rajdhani',
          fontWeight: FontWeight.w600,
        ),
        prefixIcon: Icon(icon, color: MioColors.deepBlue, size: 20),
        filled: true,
        fillColor: MioColors.ice,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: MioColors.deepBlue, width: 2),
        ),
        contentPadding:
            const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      ),
    );
  }

  Future<void> _create() async {
    final u = _newUser.text.trim();
    final p = _newPass.text.trim();
    final d = _days.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      return _showNotification("Semua field wajib diisi", isError: true);
    }
    setState(() => loading = true);
    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/api/user/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d"));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _showNotification("Akun berhasil dibuat!");
        _newUser.clear();
        _newPass.clear();
        _days.clear();
        Navigator.pop(context);
      } else {
        _showNotification(
            data['message'] ?? 'Gagal membuat akun.', isError: true);
      }
    } catch (e) {
      _showNotification("Terjadi kesalahan: ${e.toString()}", isError: true);
    }
    setState(() => loading = false);
  }

  Future<void> _edit() async {
    final u = _editUser.text.trim();
    final d = _editDays.text.trim();
    if (u.isEmpty || d.isEmpty) {
      return _showNotification("Username dan durasi wajib diisi",
          isError: true);
    }
    setState(() => loading = true);
    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/api/user/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _showNotification("Durasi berhasil diperbarui.");
        _editUser.clear();
        _editDays.clear();
        Navigator.pop(context);
      } else {
        _showNotification(data['message'] ?? 'Gagal mengubah durasi.',
            isError: true);
      }
    } catch (e) {
      _showNotification("Terjadi kesalahan: ${e.toString()}", isError: true);
    }
    setState(() => loading = false);
  }

  void _showNotification(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: MioColors.white,
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  color: MioColors.white,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? MioColors.pink : MioColors.deepBlue,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _showCreateAccountDialog() {
    _newUser.clear();
    _newPass.clear();
    _days.clear();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: MioColors.purple.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.person_add,
                        color: MioColors.purple, size: 24),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "BUAT USER BARU",
                    style: TextStyle(
                      color: MioColors.ink,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                "Role: MEMBER",
                style: TextStyle(
                  color: MioColors.softInk,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Rajdhani',
                ),
              ),
              const SizedBox(height: 20),

              _mioInput(
                controller: _newUser,
                hint: "contoh: jokowiddo",
                icon: Icons.person_outline,
              ),
              const SizedBox(height: 14),
              _mioInput(
                controller: _newPass,
                hint: "contoh: 123",
                icon: Icons.lock_outline,
                obscure: true,
              ),
              const SizedBox(height: 14),
              _mioInput(
                controller: _days,
                hint: "contoh: 30",
                icon: Icons.calendar_today,
                isNumber: true,
              ),
              const SizedBox(height: 20),

              _mioButton(
                label: "BUAT AKUN",
                onTap: _create,
                isLoading: loading,
              ),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: loading ? null : () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: MioColors.ice,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Text(
                      "BATAL",
                      style: TextStyle(
                        color: MioColors.ink,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showEditDurationDialog() {
    _editUser.clear();
    _editDays.clear();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: MioColors.blue.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.edit_calendar,
                        color: MioColors.blue, size: 24),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "UBAH DURASI HARI",
                    style: TextStyle(
                      color: MioColors.ink,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                "Perpanjang durasi akun",
                style: TextStyle(
                  color: MioColors.softInk,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Rajdhani',
                ),
              ),
              const SizedBox(height: 20),

              _mioInput(
                controller: _editUser,
                hint: "ketik username nya",
                icon: Icons.person_outline,
              ),
              const SizedBox(height: 14),
              _mioInput(
                controller: _editDays,
                hint: "batas 30 hari untuk reseller",
                icon: Icons.calendar_today,
                isNumber: true,
              ),
              const SizedBox(height: 12),

              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: MioColors.ice,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.info_outline,
                      color: MioColors.deepBlue,
                      size: 14,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        "UNLIMITED UNTUK SELAIN RESELLER",
                        style: TextStyle(
                          color: MioColors.deepBlue,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              _mioButton(
                label: "UBAH DURASI",
                onTap: _edit,
                isLoading: loading,
              ),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: loading ? null : () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: MioColors.ice,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Text(
                      "BATAL",
                      style: TextStyle(
                        color: MioColors.ink,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: MioColors.deepBlue,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.storefront,
                            color: MioColors.white, size: 22),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Reseller Panel",
                        style: TextStyle(
                          color: MioColors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 4),
                    child: Text(
                      "Kelola akun pelanggan dengan mudah",
                      style: TextStyle(
                        color: MioColors.white.withOpacity(0.85),
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  GestureDetector(
                    onTap: _showCreateAccountDialog,
                    child: _mioCard(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: MioColors.purple.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.person_add,
                                color: MioColors.purple, size: 24),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  "BUAT USER BARU",
                                  style: TextStyle(
                                    color: MioColors.ink,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Rajdhani',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                Text(
                                  "Role: MEMBER",
                                  style: TextStyle(
                                    color: MioColors.softInk,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Rajdhani',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.arrow_forward_ios,
                              color: MioColors.softInk, size: 14),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),

                  GestureDetector(
                    onTap: _showEditDurationDialog,
                    child: _mioCard(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: MioColors.blue.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.edit_calendar,
                                color: MioColors.blue, size: 24),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  "UBAH DURASI HARI",
                                  style: TextStyle(
                                    color: MioColors.ink,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Rajdhani',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                Text(
                                  "Perpanjang durasi akun",
                                  style: TextStyle(
                                    color: MioColors.softInk,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Rajdhani',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.arrow_forward_ios,
                              color: MioColors.softInk, size: 14),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}