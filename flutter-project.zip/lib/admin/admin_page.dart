import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/services.dart';

// ==================== IMPORT BASEURL ====================
import '../../server/domain_server.dart' show baseUrl;

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

class AdminPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const AdminPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage>
    with SingleTickerProviderStateMixin {
  // ===== CONTROLLERS =====
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _expiredController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _deleteController = TextEditingController();

  // ===== STATE =====
  bool _isLoading = false;
  bool _isCreating = false;
  bool _isDeleting = false;
  bool _isLoadingTotal = false;
  bool _isSearching = false;
  bool _isSuccess = false;

  String _selectedCreateRole = 'MEMBER';
  String _currentUserRole = 'member';
  String _message = '';
  String _createdUsername = '';
  String _createdPassword = '';
  String _createdExpired = '';

  int _totalUsers = 0;
  int currentPage = 1;
  int itemsPerPage = 20;

  List<dynamic> _userList = [];
  List<dynamic> _filteredUserList = [];

  final List<String> allRoles = [
    'DEV', 'HIGH_PT', 'PT', 'HELPER', 'ADMIN', 'RESELLER', 'VIP', 'MEMBER'
  ];
  String selectedRole = 'MEMBER';

  // ===== ANIMATION =====
  late AnimationController _popupController;
  late Animation<double> _popupScale;
  late Animation<double> _popupFade;

  List<String> get _availableRoles {
    switch (_currentUserRole.toLowerCase()) {
      case 'dev':
        return ['MEMBER', 'RESELLER', 'VIP', 'HELPER', 'ADMIN', 'PT', 'HIGH_PT', 'DEV'];
      case 'high_pt':
        return ['MEMBER', 'RESELLER', 'VIP', 'HELPER', 'ADMIN', 'PT', 'HIGH_PT'];
      case 'pt':
        return ['MEMBER', 'RESELLER', 'VIP', 'HELPER', 'ADMIN'];
      case 'helper':
        return ['MEMBER', 'RESELLER', 'VIP', 'ADMIN'];
      case 'admin':
        return ['MEMBER', 'RESELLER', 'VIP'];
      case 'reseller':
        return ['MEMBER', 'RESELLER'];
      case 'vip':
        return ['MEMBER', 'VIP'];
      default:
        return ['MEMBER'];
    }
  }

  bool get _canDeleteUser {
    final role = _currentUserRole.toLowerCase();
    return role == 'dev' || role == 'high_pt';
  }

  @override
  void initState() {
    super.initState();
    _popupController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _popupScale = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _popupController, curve: Curves.elasticOut),
    );
    _popupFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _popupController, curve: Curves.easeIn),
    );
    _fetchData();
  }

  @override
  void dispose() {
    _popupController.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    _expiredController.dispose();
    _searchController.dispose();
    _deleteController.dispose();
    super.dispose();
  }

  // ==================== FETCH DATA ====================
  Future<void> _fetchData() async {
    setState(() => _isLoadingTotal = true);
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/user/listUsers?key=${widget.sessionKey}'),
      );
      final data = jsonDecode(response.body);
      if (data['valid'] == true && data['authorized'] == true) {
        final users = data['users'] ?? [];
        setState(() {
          _userList = users;
          _filteredUserList = users;
          _totalUsers = users.length;
          _isLoadingTotal = false;
          _currentUserRole = widget.role.toLowerCase();
        });
        _filterAndPaginate();
      } else {
        setState(() => _isLoadingTotal = false);
      }
    } catch (e) {
      setState(() => _isLoadingTotal = false);
    }
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      final searchQuery = _searchController.text.trim().toLowerCase();
      _filteredUserList = _userList.where((u) {
        final roleMatch =
            (u['role'] ?? 'member').toUpperCase() == selectedRole;
        final searchMatch = searchQuery.isEmpty ||
            (u['username'] ?? '').toLowerCase().contains(searchQuery);
        return roleMatch && searchMatch;
      }).toList();
    });
  }

  void _searchUser(String query) {
    setState(() {
      _isSearching = query.isNotEmpty;
      _filterAndPaginate();
    });
  }

  List<dynamic> _getCurrentPageData() {
    if (_filteredUserList.isEmpty) return [];
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return _filteredUserList.sublist(
      start,
      end > _filteredUserList.length ? _filteredUserList.length : end,
    );
  }

  int get totalPages => (_filteredUserList.length / itemsPerPage).ceil();

  int _countByRole(String role) {
    return _userList
        .where((u) => (u['role'] ?? '').toUpperCase() == role)
        .length;
  }

  // ==================== TOAST ====================
  void _showToast(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            color: MioColors.white,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: isError ? MioColors.pink : MioColors.deepBlue,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ==================== CREATE USER ====================
  Future<void> _createUser() async {
    final username = _usernameController.text.trim();
    final password = _passwordController.text.trim();
    final expired = _expiredController.text.trim();

    if (username.isEmpty) {
      _showToast('❌ Isi username dulu!', isError: true);
      return;
    }
    if (password.isEmpty) {
      _showToast('❌ Isi password dulu!', isError: true);
      return;
    }
    if (expired.isEmpty) {
      _showToast('❌ Isi durasi expired dulu!', isError: true);
      return;
    }

    setState(() {
      _isCreating = true;
      _message = '';
      _isSuccess = false;
    });

    try {
      final url = Uri.parse(
        '$baseUrl/api/user/userAdd?key=${widget.sessionKey}&username=$username&password=$password&day=$expired&role=${_selectedCreateRole.toLowerCase()}',
      );
      final response = await http.get(url);
      final data = jsonDecode(response.body);

      if (data['created'] == true) {
        setState(() {
          _isSuccess = true;
          _createdUsername = username;
          _createdPassword = password;
          _createdExpired = expired;
          _message = '✅ Akun berhasil dibuat!';
        });
        _popupController.forward(from: 0.0);
        _showToast('✅ Akun $username berhasil dibuat!');
        _fetchData();

        Future.delayed(const Duration(seconds: 10), () {
          if (mounted) {
            setState(() {
              _isSuccess = false;
              _usernameController.clear();
              _passwordController.clear();
              _expiredController.clear();
              _selectedCreateRole = 'MEMBER';
            });
            _popupController.reset();
          }
        });
      } else if (data['message']?.contains('already exists') == true ||
          data['message']?.contains('Username sudah digunakan') == true) {
        _showToast('❌ Username "$username" sudah ada di database!', isError: true);
        setState(() {
          _message = '❌ Username "$username" sudah ada di database!';
          _isSuccess = false;
        });
      } else {
        setState(() {
          _message = '❌ Gagal: ${data['message'] ?? 'Unknown error'}';
        });
        _showToast('❌ Gagal membuat akun', isError: true);
      }
    } catch (e) {
      setState(() {
        _message = '❌ Error: ${e.toString()}';
      });
      _showToast('❌ Error: ${e.toString()}', isError: true);
    } finally {
      setState(() {
        _isCreating = false;
      });
    }
  }

  // ==================== DELETE USER ====================
  Future<void> _deleteUser(String username) async {
    if (username.isEmpty) {
      _showToast('❌ Masukkan username yang akan dihapus!', isError: true);
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: MioColors.pink.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.warning, color: MioColors.pink, size: 20),
            ),
            const SizedBox(width: 10),
            const Text(
              'Hapus Akun?',
              style: TextStyle(
                color: MioColors.ink,
                fontWeight: FontWeight.w900,
                fontFamily: 'Rajdhani',
                fontSize: 16,
              ),
            ),
          ],
        ),
        content: Text(
          'Yakin ingin menghapus akun "$username"?',
          style: TextStyle(
            color: MioColors.softInk,
            fontFamily: 'Rajdhani',
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            style: TextButton.styleFrom(
              backgroundColor: MioColors.silver,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              'BATAL',
              style: TextStyle(
                color: MioColors.ink,
                fontWeight: FontWeight.w800,
                fontFamily: 'Rajdhani',
                fontSize: 12,
              ),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(
              backgroundColor: MioColors.pink,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              'HAPUS',
              style: TextStyle(
                color: MioColors.white,
                fontWeight: FontWeight.w800,
                fontFamily: 'Rajdhani',
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => _isDeleting = true);

    try {
      final response = await http.get(
        Uri.parse(
            '$baseUrl/api/user/deleteUser?key=${widget.sessionKey}&username=$username'),
      );
      final data = jsonDecode(response.body);

      if (data['deleted'] == true) {
        _showToast('✅ Akun $username berhasil dihapus!');
        _fetchData();
      } else {
        _showToast('❌ Gagal: ${data['message'] ?? 'Unknown error'}',
            isError: true);
      }
    } catch (e) {
      _showToast('❌ Error: ${e.toString()}', isError: true);
    } finally {
      setState(() => _isDeleting = false);
    }
  }

  // ==================== COPY & SHARE ====================
  void _copyAll() {
    final text =
        'Username: $_createdUsername\nPassword: $_createdPassword\nExpired: $_createdExpired';
    Clipboard.setData(ClipboardData(text: text));
    _showToast('✅ Semua data berhasil disalin!');
  }

  void _shareResult() {
    final text =
        '✅ Akun berhasil dibuat!\n\nUsername: $_createdUsername\nPassword: $_createdPassword\nExpired: $_createdExpired';
    Clipboard.setData(ClipboardData(text: text));
    _showToast('✅ Data berhasil disalin, silakan bagikan!');
  }

  // ==================== ROLE COLOR ====================
  Color _getRoleColor(String role) {
    switch (role.toUpperCase()) {
      case 'DEV':
        return MioColors.red;
      case 'HIGH_PT':
        return MioColors.purple;
      case 'PT':
        return const Color(0xFF7C3AED);
      case 'HELPER':
        return MioColors.green;
      case 'ADMIN':
        return MioColors.blue;
      case 'RESELLER':
        return MioColors.yellow;
      case 'VIP':
        return const Color(0xFFF59E0B);
      case 'MEMBER':
        return MioColors.softInk;
      default:
        return MioColors.softInk;
    }
  }

  // ==================== HELPERS ====================
  Widget _mioCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 16,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.18),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _mioButton({
    required String label,
    required VoidCallback onTap,
    Color bg = MioColors.deepBlue,
    Color textColor = MioColors.white,
    double fontSize = 13,
    bool isLoading = false,
    bool isDanger = false,
  }) {
    final buttonColor = isDanger ? MioColors.pink : bg;
    final buttonTextColor = isDanger ? MioColors.white : textColor;

    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: buttonColor,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: MioColors.deepBlue.withOpacity(0.25),
              offset: const Offset(0, 4),
              blurRadius: 10,
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    color: buttonTextColor,
                    strokeWidth: 2,
                  ),
                )
              : Text(
                  label,
                  style: TextStyle(
                    fontSize: fontSize,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                    color: buttonTextColor,
                    fontFamily: 'Rajdhani',
                  ),
                ),
        ),
      ),
    );
  }

  Widget _mioInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    bool isNumber = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      style: const TextStyle(
        color: MioColors.ink,
        fontSize: 14,
        fontWeight: FontWeight.w600,
        fontFamily: 'Rajdhani',
      ),
      cursorColor: MioColors.deepBlue,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
          color: MioColors.softInk.withOpacity(0.7),
          fontFamily: 'Rajdhani',
          fontWeight: FontWeight.w600,
        ),
        prefixIcon: Icon(icon, color: MioColors.deepBlue, size: 18),
        filled: true,
        fillColor: MioColors.ice,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: MioColors.deepBlue, width: 2),
        ),
        contentPadding:
            const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
      ),
    );
  }

  Widget _buildBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/Haimiya.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) =>
                Container(color: MioColors.deepBlue),
          ),
        ),
        Positioned.fill(
          child: Container(
            color: MioColors.deepBlue.withOpacity(0.55),
          ),
        ),
      ],
    );
  }

  // ==================== SUCCESS POPUP ====================
  Widget _buildSuccessPopup() {
    return AnimatedBuilder(
      animation: _popupController,
      builder: (context, child) {
        return FadeTransition(
          opacity: _popupFade,
          child: ScaleTransition(
            scale: _popupScale,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: MioColors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: MioColors.green.withOpacity(0.3),
                    blurRadius: 24,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: MioColors.green.withOpacity(0.15),
                      border: Border.all(color: MioColors.green, width: 2),
                    ),
                    child: const Icon(Icons.check,
                        color: MioColors.green, size: 36),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    '✅ AKUN BERHASIL DIBUAT!',
                    style: TextStyle(
                      color: MioColors.ink,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: MioColors.ice,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildInfoRow('👤 Username', _createdUsername),
                        const SizedBox(height: 4),
                        _buildInfoRow('🔑 Password', _createdPassword),
                        const SizedBox(height: 4),
                        _buildInfoRow('📅 Expired', _createdExpired),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: _copyAll,
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: MioColors.ice,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Center(
                              child: Text(
                                '📋 SALIN',
                                style: TextStyle(
                                  color: MioColors.ink,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Rajdhani',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: GestureDetector(
                          onTap: _shareResult,
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: MioColors.deepBlue,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Center(
                              child: Text(
                                '📤 BAGIKAN',
                                style: TextStyle(
                                  color: MioColors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Rajdhani',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: MioColors.softInk,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            fontFamily: 'Rajdhani',
          ),
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              color: MioColors.ink,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              fontFamily: 'Rajdhani',
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: _isLoadingTotal
                ? const Center(
                    child: CircularProgressIndicator(color: MioColors.white),
                  )
                : SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // ===== HEADER =====
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: MioColors.deepBlue,
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(
                                    color:
                                        MioColors.deepBlue.withOpacity(0.4),
                                    offset: const Offset(0, 6),
                                    blurRadius: 14,
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.admin_panel_settings,
                                color: MioColors.white,
                                size: 22,
                              ),
                            ),
                            const SizedBox(width: 12),
                            const Text(
                              "Admin Panel",
                              style: TextStyle(
                                color: MioColors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Rajdhani',
                                letterSpacing: 1,
                              ),
                            ),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: _getRoleColor(widget.role)
                                    .withOpacity(0.2),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color:
                                      _getRoleColor(widget.role).withOpacity(0.5),
                                  width: 1.5,
                                ),
                              ),
                              child: Text(
                                widget.role.toUpperCase(),
                                style: TextStyle(
                                  color: _getRoleColor(widget.role),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Rajdhani',
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Padding(
                          padding: const EdgeInsets.only(left: 4),
                          child: Text(
                            "Kelola user & role dengan mudah",
                            style: TextStyle(
                              color: MioColors.white.withOpacity(0.85),
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Rajdhani',
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),

                        // ===== BANNER =====
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.asset(
                            'assets/images/rolebaner.jpg',
                            width: double.infinity,
                            height: 120,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              width: double.infinity,
                              height: 120,
                              color: MioColors.deepBlue,
                              child: const Center(
                                child: Text(
                                  "ADMIN PANEL",
                                  style: TextStyle(
                                    color: MioColors.white,
                                    fontSize: 24,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Rajdhani',
                                    letterSpacing: 4,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),

                        // ===== DELETE USER CARD =====
                        if (_canDeleteUser)
                          Row(
                            children: [
                              Expanded(
                                child: GestureDetector(
                                  onTap: () {
                                    _deleteController.clear();
                                    _showDeleteUserDialog();
                                  },
                                  child: _mioCard(
                                    padding: const EdgeInsets.all(16),
                                    child: Column(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.all(12),
                                          decoration: BoxDecoration(
                                            color: MioColors.pink
                                                .withOpacity(0.15),
                                            borderRadius:
                                                BorderRadius.circular(12),
                                          ),
                                          child: const Icon(
                                            Icons.person_remove,
                                            color: MioColors.pink,
                                            size: 28,
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        const Text(
                                          "Delete User",
                                          style: TextStyle(
                                            color: MioColors.ink,
                                            fontSize: 13,
                                            fontWeight: FontWeight.w800,
                                            fontFamily: 'Rajdhani',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),

                        const SizedBox(height: 16),

                        // ===== TOTAL ALL USER =====
                        _mioCard(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    "TOTAL ALL USER",
                                    style: TextStyle(
                                      color: MioColors.ink,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: 'Rajdhani',
                                      letterSpacing: 1,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 14, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: MioColors.deepBlue,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Text(
                                      "$_totalUsers USERS",
                                      style: const TextStyle(
                                        color: MioColors.white,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: 'Rajdhani',
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: allRoles.map((role) {
                                  final count = _countByRole(role);
                                  return Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: _getRoleColor(role)
                                          .withOpacity(0.12),
                                      borderRadius:
                                          BorderRadius.circular(20),
                                      border: Border.all(
                                        color: _getRoleColor(role)
                                            .withOpacity(0.3),
                                        width: 1,
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Container(
                                          width: 6,
                                          height: 6,
                                          decoration: BoxDecoration(
                                            color: _getRoleColor(role),
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        Text(
                                          "$role $count",
                                          style: TextStyle(
                                            color: _getRoleColor(role),
                                            fontSize: 10,
                                            fontWeight: FontWeight.w700,
                                            fontFamily: 'Rajdhani',
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // ===== CREATE NEW USER FORM =====
                        _mioCard(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "CREATE NEW USER",
                                style: TextStyle(
                                  color: MioColors.ink,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Rajdhani',
                                  letterSpacing: 1,
                                ),
                              ),
                              const SizedBox(height: 12),
                              _mioInput(
                                controller: _usernameController,
                                hint: "Username",
                                icon: Icons.person_outline,
                              ),
                              const SizedBox(height: 10),
                              _mioInput(
                                controller: _passwordController,
                                hint: "Password",
                                icon: Icons.lock_outline,
                                obscure: true,
                              ),
                              const SizedBox(height: 10),
                              _mioInput(
                                controller: _expiredController,
                                hint: "Masa Aktif (hari)",
                                icon: Icons.calendar_today,
                                isNumber: true,
                              ),
                              const SizedBox(height: 10),
                              Wrap(
                                spacing: 6,
                                runSpacing: 6,
                                children: _availableRoles.map((role) {
                                  final isSelected =
                                      _selectedCreateRole == role;
                                  return GestureDetector(
                                    onTap: () => setState(
                                        () => _selectedCreateRole = role),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: isSelected
                                            ? _getRoleColor(role)
                                            : MioColors.ice,
                                        borderRadius:
                                            BorderRadius.circular(16),
                                        border: Border.all(
                                          color: isSelected
                                              ? _getRoleColor(role)
                                              : MioColors.silver,
                                          width: isSelected ? 2 : 1,
                                        ),
                                      ),
                                      child: Text(
                                        role,
                                        style: TextStyle(
                                          color: isSelected
                                              ? MioColors.white
                                              : MioColors.ink,
                                          fontSize: 10,
                                          fontWeight: isSelected
                                              ? FontWeight.w800
                                              : FontWeight.w600,
                                          fontFamily: 'Rajdhani',
                                        ),
                                      ),
                                    ),
                                  );
                                }).toList(),
                              ),
                              const SizedBox(height: 14),
                              _mioButton(
                                label: "CREATE USER",
                                onTap: _createUser,
                                bg: MioColors.deepBlue,
                                textColor: MioColors.white,
                                isLoading: _isCreating,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        if (_isSuccess) _buildSuccessPopup(),

                        // ===== CARI USERNAME =====
                        _mioCard(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "CARI USERNAME",
                                style: TextStyle(
                                  color: MioColors.ink,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Rajdhani',
                                  letterSpacing: 1,
                                ),
                              ),
                              const SizedBox(height: 10),
                              _mioInput(
                                controller: _searchController,
                                hint: "Cari username...",
                                icon: Icons.search,
                              ),
                              const SizedBox(height: 10),
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Row(
                                  children: allRoles.map((role) {
                                    final isSelected = selectedRole == role;
                                    return GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          selectedRole = role;
                                          _filterAndPaginate();
                                        });
                                      },
                                      child: Container(
                                        margin:
                                            const EdgeInsets.only(right: 6),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 12, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: isSelected
                                              ? _getRoleColor(role)
                                              : MioColors.ice,
                                          borderRadius:
                                              BorderRadius.circular(16),
                                          border: Border.all(
                                            color: isSelected
                                                ? _getRoleColor(role)
                                                : MioColors.silver,
                                            width: 1,
                                          ),
                                        ),
                                        child: Text(
                                          role,
                                          style: TextStyle(
                                            color: isSelected
                                                ? MioColors.white
                                                : MioColors.ink,
                                            fontSize: 10,
                                            fontWeight: isSelected
                                                ? FontWeight.w800
                                                : FontWeight.w600,
                                            fontFamily: 'Rajdhani',
                                          ),
                                        ),
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // ===== USER LIST =====
                        if (_filteredUserList.isEmpty)
                          _mioCard(
                            padding: const EdgeInsets.all(32),
                            child: const Center(
                              child: Text(
                                "Tidak ada user dengan role ini",
                                style: TextStyle(
                                  color: MioColors.softInk,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Rajdhani',
                                ),
                              ),
                            ),
                          )
                        else
                          _mioCard(
                            padding: EdgeInsets.zero,
                            child: Column(
                              children: [
                                ..._getCurrentPageData().map((user) {
                                  final username =
                                      user['username'] ?? 'N/A';
                                  final role = (user['role'] ?? 'member')
                                      .toUpperCase();
                                  final parent =
                                      user['parent'] ?? 'SYSTEM';
                                  return Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 14, vertical: 10),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                          color: MioColors.silver
                                              .withOpacity(0.6),
                                        ),
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 32,
                                          height: 32,
                                          decoration: BoxDecoration(
                                            color: _getRoleColor(role)
                                                .withOpacity(0.15),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: Center(
                                            child: Text(
                                              username
                                                  .substring(0, 1)
                                                  .toUpperCase(),
                                              style: TextStyle(
                                                color: _getRoleColor(role),
                                                fontSize: 14,
                                                fontWeight: FontWeight.w900,
                                                fontFamily: 'Rajdhani',
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          flex: 2,
                                          child: Text(
                                            username,
                                            style: const TextStyle(
                                              color: MioColors.ink,
                                              fontSize: 13,
                                              fontWeight: FontWeight.w700,
                                              fontFamily: 'Rajdhani',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: _getRoleColor(role)
                                                .withOpacity(0.15),
                                            borderRadius:
                                                BorderRadius.circular(6),
                                          ),
                                          child: Text(
                                            role,
                                            style: TextStyle(
                                              color: _getRoleColor(role),
                                              fontSize: 9,
                                              fontWeight: FontWeight.w800,
                                              fontFamily: 'Rajdhani',
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        Text(
                                          parent,
                                          style: const TextStyle(
                                            color: MioColors.softInk,
                                            fontSize: 10,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: 'Rajdhani',
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ],
                            ),
                          ),

                        // ===== PAGINATION =====
                        if (totalPages > 1)
                          Padding(
                            padding: const EdgeInsets.only(top: 12),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                GestureDetector(
                                  onTap: currentPage > 1
                                      ? () =>
                                          setState(() => currentPage--)
                                      : null,
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: currentPage > 1
                                          ? MioColors.white
                                          : MioColors.white
                                              .withOpacity(0.3),
                                      borderRadius:
                                          BorderRadius.circular(10),
                                    ),
                                    child: Icon(
                                      Icons.chevron_left,
                                      color: currentPage > 1
                                          ? MioColors.deepBlue
                                          : MioColors.softInk,
                                      size: 20,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  "Page $currentPage of $totalPages",
                                  style: const TextStyle(
                                    color: MioColors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'Rajdhani',
                                  ),
                                ),
                                const SizedBox(width: 12),
                                GestureDetector(
                                  onTap: currentPage < totalPages
                                      ? () =>
                                          setState(() => currentPage++)
                                      : null,
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: currentPage < totalPages
                                          ? MioColors.white
                                          : MioColors.white
                                              .withOpacity(0.3),
                                      borderRadius:
                                          BorderRadius.circular(10),
                                    ),
                                    child: Icon(
                                      Icons.chevron_right,
                                      color: currentPage < totalPages
                                          ? MioColors.deepBlue
                                          : MioColors.softInk,
                                      size: 20,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  // ==================== DIALOGS ====================
  void _showDeleteUserDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: MioColors.pink.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.person_remove,
                        color: MioColors.pink, size: 22),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "Delete User",
                    style: TextStyle(
                      color: MioColors.ink,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                "Hapus user dari database secara permanen",
                style: TextStyle(
                  color: MioColors.softInk,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Rajdhani',
                ),
              ),
              const SizedBox(height: 16),
              _mioInput(
                controller: _deleteController,
                hint: "Masukkan username",
                icon: Icons.person_outline,
              ),
              const SizedBox(height: 20),
              _mioButton(
                label: "DELETE USER",
                onTap: () => _deleteUser(_deleteController.text.trim()),
                bg: MioColors.pink,
                textColor: MioColors.white,
                isDanger: true,
                isLoading: _isDeleting,
              ),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: _isDeleting ? null : () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: MioColors.ice,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Text(
                      "BATAL",
                      style: TextStyle(
                        color: MioColors.ink,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}