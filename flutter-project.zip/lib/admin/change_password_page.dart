import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// ==================== IMPORT BASEURL ====================
import '../../server/domain_server.dart' show baseUrl;

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color pink = Color(0xFFEC4899);
  static const Color yellow = Color(0xFFFACC15); // ← DITAMBAH
}

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading = false;

  Widget _buildBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/Haimiya.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) =>
                Container(color: MioColors.deepBlue),
          ),
        ),
        Positioned.fill(
          child: Container(
            color: MioColors.deepBlue.withOpacity(0.55),
          ),
        ),
      ],
    );
  }

  Widget _mioCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 16,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.18),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _mioInput({
    required String hint,
    required TextEditingController controller,
    required IconData icon,
    bool obscure = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      style: const TextStyle(
        color: MioColors.ink,
        fontSize: 14,
        fontWeight: FontWeight.w600,
        fontFamily: 'Rajdhani',
      ),
      cursorColor: MioColors.deepBlue,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
          color: MioColors.softInk.withOpacity(0.7),
          fontFamily: 'Rajdhani',
          fontWeight: FontWeight.w600,
        ),
        prefixIcon: Icon(icon, color: MioColors.deepBlue, size: 20),
        filled: true,
        fillColor: MioColors.ice,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: MioColors.deepBlue, width: 2),
        ),
        contentPadding:
            const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      ),
    );
  }

  Widget _mioButton({
    required String label,
    required VoidCallback onTap,
    bool isLoading = false,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: MioColors.deepBlue,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: MioColors.deepBlue.withOpacity(0.3),
              offset: const Offset(0, 6),
              blurRadius: 14,
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    color: MioColors.white,
                    strokeWidth: 2.5,
                  ),
                )
              : Text(
                  label,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                    color: MioColors.white,
                    fontFamily: 'Rajdhani',
                  ),
                ),
        ),
      ),
    );
  }

  Future<void> _changePassword() async {
    final oldPass = oldPassCtrl.text.trim();
    final newPass = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage("All fields are required");
      return;
    }

    if (newPass != confirmPass) {
      _showMessage("New password doesn't match confirmation");
      return;
    }

    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/api/user/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "key": widget.sessionKey,
        },
      );

      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _showMessage("Password changed successfully", isSuccess: true);
      } else {
        _showMessage(data['message'] ?? "Failed to change password");
      }
    } catch (e) {
      _showMessage("Server error: $e");
    }

    setState(() => isLoading = false);
  }

  void _showMessage(String msg, {bool isSuccess = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: isSuccess
                    ? MioColors.green.withOpacity(0.15)
                    : MioColors.yellow.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                isSuccess ? Icons.check_circle : Icons.warning,
                color: isSuccess ? MioColors.green : MioColors.yellow,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              isSuccess ? "Success" : "Info",
              style: TextStyle(
                color: isSuccess ? MioColors.green : MioColors.ink,
                fontSize: 16,
                fontWeight: FontWeight.w800,
                fontFamily: 'Rajdhani',
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: MioColors.softInk,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Rajdhani',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: MioColors.deepBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: MioColors.white,
                fontWeight: FontWeight.w800,
                fontFamily: 'Rajdhani',
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: MioColors.deepBlue,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.lock_reset,
                            color: MioColors.white, size: 22),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Change Password",
                        style: TextStyle(
                          color: MioColors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 4),
                    child: Text(
                      "Secure your account with a new password",
                      style: TextStyle(
                        color: MioColors.white.withOpacity(0.85),
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  _mioCard(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        _mioInput(
                          hint: "Old Password",
                          controller: oldPassCtrl,
                          icon: Icons.lock_outline,
                          obscure: true,
                        ),
                        const SizedBox(height: 16),
                        _mioInput(
                          hint: "New Password",
                          controller: newPassCtrl,
                          icon: Icons.lock_outline,
                          obscure: true,
                        ),
                        const SizedBox(height: 16),
                        _mioInput(
                          hint: "Confirm Password",
                          controller: confirmPassCtrl,
                          icon: Icons.lock_outline,
                          obscure: true,
                        ),
                        const SizedBox(height: 24),
                        _mioButton(
                          label: "CHANGE PASSWORD",
                          onTap: _changePassword,
                          isLoading: isLoading,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  Column(
                    children: [
                      Container(
                        width: 40,
                        height: 2,
                        color: MioColors.white.withOpacity(0.6),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "© 2026 X•RZYN v2 PROJECT • ALL RIGHTS RESERVED",
                        style: TextStyle(
                          fontSize: 9,
                          letterSpacing: 2,
                          color: MioColors.white,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}