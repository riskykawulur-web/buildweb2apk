import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../server/domain_server.dart' show baseUrl;
import 'control_panel.dart';

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────
class DevicesPanelPage extends StatefulWidget {
  final String? username;
  final String? sessionKey;
  final String? role;

  const DevicesPanelPage({
    super.key,
    this.username,
    this.sessionKey,
    this.role,
  });

  @override
  State<DevicesPanelPage> createState() => _DevicesPanelPageState();
}

class _DevicesPanelPageState extends State<DevicesPanelPage> {
  // ─── STATE ───
  List<Map<String, dynamic>> _devices = [];
  String? _sessionKey;
  String _userRole = 'user';
  String _username = 'PANXX';
  String _userUid = '-';
  bool _isLoadingUid = true;
  Timer? _pollingTimer;
  bool _isLoading = true;
  String? _errorMessage;

  // ─── ROLE YANG DIIZINKAN ───
  static const List<String> _allowedRoles = [
    'dev',
    'high_pt',
    'pt',
    'admin',
  ];

  @override
  void initState() {
    super.initState();
    _bootSequence();
  }

  Future<void> _bootSequence() async {
    final prefs = await SharedPreferences.getInstance();
    _sessionKey = widget.sessionKey ?? prefs.getString("key");
    _userRole = (widget.role ?? prefs.getString("role") ?? 'user')
        .toLowerCase()
        .trim();
    _username = widget.username ?? prefs.getString("username") ?? 'PANXX';

    if (_sessionKey != null) {
      await _fetchUidWithRetry();
      await _fetchDevices();
    } else {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _isLoadingUid = false;
        });
      }
    }

    _pollingTimer?.cancel();
    _pollingTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      _fetchDevices();
    });
  }

  // ===== AMBIL UID DENGAN RETRY =====
  Future<void> _fetchUidWithRetry() async {
    for (int attempt = 1; attempt <= 3; attempt++) {
      final ok = await _fetchUid();
      if (ok) return;
      await Future.delayed(const Duration(milliseconds: 800));
    }
  }

  Future<bool> _fetchUid() async {
    if (_sessionKey == null) return false;

    if (mounted) setState(() => _isLoadingUid = true);

    try {
      final response = await http.get(
        Uri.parse("$baseUrl/api/user/uid?key=$_sessionKey"),
        headers: {
          "x-auth-token": _sessionKey!,
          "Content-Type": "application/json",
        },
      );

      debugPrint("[UID] status=${response.statusCode} body=${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final uid = (data['uid'] ?? data['pairId'] ?? '').toString();

        if (uid.isNotEmpty) {
          if (mounted) {
            setState(() {
              _userUid = uid;
              _isLoadingUid = false;
            });
          }
          return true;
        }
      }

      if (mounted) setState(() => _isLoadingUid = false);
      return false;
    } catch (e) {
      debugPrint("Fetch UID error: $e");
      if (mounted) setState(() => _isLoadingUid = false);
      return false;
    }
  }

  // ===== AMBIL DAFTAR DEVICE (SAFE PARSE) =====
  Future<void> _fetchDevices() async {
    if (_sessionKey == null) return;

    try {
      final response = await http.get(
        Uri.parse("$baseUrl/api/list-targets"),
        headers: {"x-auth-token": _sessionKey!},
      );

      debugPrint("[DEVICES] status=${response.statusCode} body=${response.body}");

      if (!mounted) return;

      // ===== CEK STATUS =====
      if (response.statusCode != 200) {
        setState(() {
          _isLoading = false;
          _errorMessage = "Server error ${response.statusCode}";
        });
        return;
      }

      // ===== SAFE PARSE JSON =====
      dynamic decoded;
      try {
        decoded = jsonDecode(response.body);
      } catch (e) {
        debugPrint("JSON parse error: $e");
        setState(() {
          _isLoading = false;
          _errorMessage = "Response bukan JSON yang valid";
        });
        return;
      }

      // ===== VALIDASI HARUS LIST =====
      if (decoded is! List) {
        debugPrint("Response bukan List: ${decoded.runtimeType}");
        setState(() {
          _isLoading = false;
          _devices = [];
          _errorMessage = null;
        });
        return;
      }

      // ===== KONVERSI KE List<Map<String, dynamic>> =====
      final List<Map<String, dynamic>> parsed = [];
      for (final item in decoded) {
        if (item is Map) {
          parsed.add(Map<String, dynamic>.from(item));
        }
      }

      setState(() {
        _devices = parsed;
        _isLoading = false;
        _errorMessage = null;
      });
    } catch (e) {
      debugPrint("Fetch devices error: $e");
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = "Gagal konek ke server";
        });
      }
    }
  }

  // ===== COPY UID =====
  void _copyUid() {
    if (_userUid.isEmpty || _userUid == '-') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("UID belum tersedia. Tekan refresh dulu."),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }
    Clipboard.setData(ClipboardData(text: _userUid));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("UID disalin: $_userUid"),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ===== BUKA CONTROL PANEL =====
  void _openControl(Map<String, dynamic> device) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ControlPanelPage(
          device: device,
          sessionKey: _sessionKey,
          username: _username,
          role: _userRole,
        ),
      ),
    ).then((_) {
      _fetchDevices();
    });
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    super.dispose();
  }

  // ====================================================================
  // BUILD
  // ====================================================================
  @override
  Widget build(BuildContext context) {
    // ===== ROLE GUARD =====
    if (!_allowedRoles.contains(_userRole)) {
      return _buildAccessDenied();
    }

    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          // ===== BACKGROUND IMAGE FULLSCREEN =====
          Positioned.fill(
            child: Image.asset(
              'assets/images/Haimiya.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  Container(color: MioColors.deepBlue),
            ),
          ),
          // ===== OVERLAY =====
          Positioned.fill(
            child: Container(
              color: MioColors.deepBlue.withValues(alpha: 0.55),
            ),
          ),
          // ===== CONTENT =====
          SafeArea(
            top: false,
            child: Column(
              children: [
                _buildTopBar(),
                Expanded(
                  child: RefreshIndicator(
                    color: MioColors.deepBlue,
                    onRefresh: () async {
                      await _fetchUidWithRetry();
                      await _fetchDevices();
                    },
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(
                        parent: BouncingScrollPhysics(),
                      ),
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _buildWelcomeCard(),
                          const SizedBox(height: 20),
                          _buildSectionHeader("DAFTAR DEVICE"),
                          const SizedBox(height: 10),
                          if (_isLoading)
                            _buildLoadingCard()
                          else if (_errorMessage != null)
                            _buildErrorCard()
                          else if (_devices.isEmpty)
                            _buildEmptyDeviceCard()
                          else
                            ..._devices.asMap().entries.map((entry) {
                              return _buildDeviceCard(entry.value, entry.key);
                            }),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── ACCESS DENIED ───
  Widget _buildAccessDenied() {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/Haimiya.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  Container(color: MioColors.deepBlue),
            ),
          ),
          Positioned.fill(
            child: Container(
              color: MioColors.deepBlue.withValues(alpha: 0.7),
            ),
          ),
          SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(28),
                  decoration: BoxDecoration(
                    color: MioColors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: MioColors.deepBlue.withValues(alpha: 0.3),
                        offset: const Offset(0, 8),
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: MioColors.red.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: const Icon(
                          Icons.lock_rounded,
                          color: MioColors.red,
                          size: 48,
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Text(
                        "FITUR TERKUNCI",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: MioColors.red,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Nevera',
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        width: 60,
                        height: 2,
                        color: MioColors.silver,
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        "ONLY DEV HIGH PT PT ADMIN",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: MioColors.deepBlue,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Nevera',
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Role kamu: ${_userRole.toUpperCase()}",
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: MioColors.softInk,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Nevera',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── TOP BAR ───
  Widget _buildTopBar() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        bottom: 10,
        left: 8,
        right: 8,
      ),
      decoration: BoxDecoration(
        color: MioColors.white.withValues(alpha: 0.9),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.15),
            offset: const Offset(0, 4),
            blurRadius: 10,
          ),
        ],
      ),
      child: Row(
        children: [
          const SizedBox(width: 44),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: MioColors.deepBlue,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.devices_rounded,
                color: MioColors.white, size: 18),
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.refresh_rounded,
                color: MioColors.deepBlue, size: 22),
            onPressed: () async {
              await _fetchUidWithRetry();
              await _fetchDevices();
            },
          ),
        ],
      ),
    );
  }

  // ─── WELCOME CARD ───
  Widget _buildWelcomeCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: MioColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.2),
            offset: const Offset(0, 6),
            blurRadius: 14,
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            "WELCOME TO RAT",
            style: TextStyle(
              color: MioColors.deepBlue,
              fontSize: 22,
              fontWeight: FontWeight.w900,
              letterSpacing: 3,
              fontFamily: 'Nevera',
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: MioColors.ice,
              borderRadius: BorderRadius.circular(12),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(9),
              child: Image.asset(
                'assets/images/rolebaner.jpg',
                height: 140,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  height: 140,
                  alignment: Alignment.center,
                  color: MioColors.silver,
                  child: const Icon(
                    Icons.smart_toy_rounded,
                    size: 60,
                    color: MioColors.deepBlue,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          _buildUidCard(),
        ],
      ),
    );
  }

  // ─── UID CARD ───
  Widget _buildUidCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: MioColors.ice,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: MioColors.deepBlue.withValues(alpha: 0.2),
          width: 1.5,
        ),
      ),
      child: Column(
        children: [
          const Text(
            "UID ANDA",
            style: TextStyle(
              color: MioColors.softInk,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
              fontFamily: 'Nevera',
            ),
          ),
          const SizedBox(height: 8),
          if (_isLoadingUid)
            const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(
                color: MioColors.deepBlue,
                strokeWidth: 2,
              ),
            )
          else
            SelectableText(
              _userUid,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: MioColors.deepBlue,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
                fontFamily: 'Nevera',
              ),
            ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _isLoadingUid ? null : _copyUid,
                  icon: const Icon(Icons.copy_rounded, size: 16),
                  label: const Text(
                    "SALIN UID",
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                      fontFamily: 'Nevera',
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: MioColors.deepBlue,
                    foregroundColor: MioColors.white,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 0,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _isLoadingUid ? null : _fetchUidWithRetry,
                  icon: const Icon(Icons.refresh_rounded, size: 16),
                  label: const Text(
                    "REFRESH",
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                      fontFamily: 'Nevera',
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: MioColors.green,
                    foregroundColor: MioColors.white,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 0,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── SECTION HEADER ───
  Widget _buildSectionHeader(String title) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: MioColors.deepBlue,
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(Icons.devices_rounded,
              color: MioColors.white, size: 14),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: MioColors.white,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              fontFamily: 'Nevera',
            ),
          ),
        ),
      ],
    );
  }

  // ─── LOADING CARD ───
  Widget _buildLoadingCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: MioColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.15),
            offset: const Offset(0, 6),
            blurRadius: 14,
          ),
        ],
      ),
      child: Column(
        children: [
          const SizedBox(
            width: 40,
            height: 40,
            child: CircularProgressIndicator(
                color: MioColors.deepBlue, strokeWidth: 3),
          ),
          const SizedBox(height: 14),
          const Text(
            "MEMUAT DEVICE...",
            style: TextStyle(
              color: MioColors.softInk,
              fontSize: 12,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
              fontFamily: 'Nevera',
            ),
          ),
        ],
      ),
    );
  }

  // ─── ERROR CARD ───
  Widget _buildErrorCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: MioColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.15),
            offset: const Offset(0, 6),
            blurRadius: 14,
          ),
        ],
      ),
      child: Column(
        children: [
          const Icon(Icons.error_outline_rounded,
              size: 50, color: MioColors.red),
          const SizedBox(height: 12),
          Text(
            _errorMessage ?? "Terjadi kesalahan",
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: MioColors.softInk,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              fontFamily: 'Nevera',
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                _isLoading = true;
                _errorMessage = null;
              });
              _fetchDevices();
            },
            icon: const Icon(Icons.refresh_rounded, size: 16),
            label: const Text("COBA LAGI"),
            style: ElevatedButton.styleFrom(
              backgroundColor: MioColors.deepBlue,
              foregroundColor: MioColors.white,
            ),
          ),
        ],
      ),
    );
  }

  // ─── EMPTY CARD ───
  Widget _buildEmptyDeviceCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: MioColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.15),
            offset: const Offset(0, 6),
            blurRadius: 14,
          ),
        ],
      ),
      child: const Column(
        children: [
          Icon(Icons.phone_android_rounded,
              size: 50, color: MioColors.softInk),
          SizedBox(height: 12),
          Text(
            "Belum ada device terhubung",
            style: TextStyle(
              color: MioColors.softInk,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              fontFamily: 'Nevera',
            ),
          ),
        ],
      ),
    );
  }

  // ─── DEVICE CARD ───
  Widget _buildDeviceCard(Map<String, dynamic> device, int index) {
    final bool isOnline = device['online'] == true ||
        device['status'] == 'Online' ||
        device['status'] == 'online';
    final Color statusColor = isOnline ? MioColors.green : MioColors.red;

    final String displayName =
        (device['name'] ?? device['model'] ?? 'Unknown Device').toString();
    final int battery = (device['battery'] is int)
        ? device['battery']
        : int.tryParse('${device['battery'] ?? 0}') ?? 0;
    final String androidVersion =
        (device['androidVersion'] ?? '?').toString();
    final int sdkVersion = (device['sdkVersion'] is int)
        ? device['sdkVersion']
        : int.tryParse('${device['sdkVersion'] ?? 0}') ?? 0;
    final String number = (index + 1).toString().padLeft(2, '0');

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: MioColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withValues(alpha: 0.15),
            offset: const Offset(0, 6),
            blurRadius: 14,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: MioColors.deepBlue.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.phone_android_rounded,
                  color: MioColors.deepBlue,
                  size: 26,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            displayName,
                            style: const TextStyle(
                              color: MioColors.ink,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Nevera',
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: statusColor,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            isOnline ? "ONLINE" : "OFFLINE",
                            style: const TextStyle(
                              color: MioColors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                              fontFamily: 'Nevera',
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "Android $androidVersion  -  SDK $sdkVersion",
                      style: const TextStyle(
                        color: MioColors.softInk,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Nevera',
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.battery_charging_full_rounded,
                          size: 14,
                          color: battery > 20
                              ? MioColors.green
                              : MioColors.red,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          "Baterai $battery%",
                          style: const TextStyle(
                            color: MioColors.ink,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Nevera',
                          ),
                        ),
                        const Spacer(),
                        Text(
                          "#$number",
                          style: const TextStyle(
                            color: MioColors.softInk,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Nevera',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 1,
            color: MioColors.silver,
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _openControl(Map<String, dynamic>.from(device)),
              icon: const Icon(Icons.play_arrow_rounded, size: 20),
              label: const Text(
                "CONTROL",
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                  fontSize: 14,
                  fontFamily: 'Nevera',
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    isOnline ? MioColors.deepBlue : MioColors.softInk,
                foregroundColor: MioColors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }
}