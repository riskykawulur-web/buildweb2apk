import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

// ==================== IMPORT HALAMAN ====================
import 'landing_page.dart';
import 'buy_account.dart';

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

class SebelumLandingPage extends StatefulWidget {
  const SebelumLandingPage({super.key});

  @override
  State<SebelumLandingPage> createState() => _SebelumLandingPageState();
}

class _SebelumLandingPageState extends State<SebelumLandingPage>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _bgController;
  bool _bgReady = false;

  // ===== RING ANIMATION (mengecil-membesar) =====
  late AnimationController _ringController;
  late Animation<double> _ringScale;

  @override
  void initState() {
    super.initState();

    // Video background
    _bgController = VideoPlayerController.asset('assets/videos/haimiya.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _bgReady = true);
        _bgController.setLooping(true);
        _bgController.setVolume(1.0);
        _bgController.play();
      }).catchError((e) {
        debugPrint('BG VIDEO error: $e');
      });

    // Ring animation (mengecil-membesar)
    _ringController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _ringScale = Tween<double>(begin: 0.85, end: 1.05).animate(
      CurvedAnimation(parent: _ringController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _bgController.dispose();
    _ringController.dispose();
    super.dispose();
  }

  // ==================== NAVIGASI ====================
  void _goToLanding() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const LandingPage()),
    );
  }

  void _goToBuyAccount() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const BuyAccountPage()),
    );
  }

  // ==================== SUPPORT ADMIN ====================
  Future<void> _openTiktok() async {
    final uri = Uri.parse('https://www.tiktok.com/@rizzisreal02');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tidak bisa membuka TikTok')),
      );
    }
  }

  Future<void> _openInstagram() async {
    final uri = Uri.parse('https://www.instagram.com/rizzisreal01');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tidak bisa membuka Instagram')),
      );
    }
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: _bgReady
              ? FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _bgController.value.size.width,
                    height: _bgController.value.size.height,
                    child: VideoPlayer(_bgController),
                  ),
                )
              : Container(color: MioColors.deepBlue),
        ),
        // ===== OVERLAY =====
        Positioned.fill(
          child: Container(
            color: MioColors.deepBlue.withValues(alpha: 0.55),
          ),
        ),
      ],
    );
  }

  // ==================== CARD ====================
  Widget _mioCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 20,
    EdgeInsets padding = const EdgeInsets.all(18),
    EdgeInsets? margin,
    bool transparent = false,
    Color? borderColor,
    double borderWidth = 1.8,
  }) {
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: transparent ? Colors.transparent : bg,
        borderRadius: BorderRadius.circular(radius),
        border: transparent
            ? Border.all(
                color: (borderColor ?? MioColors.deepBlue)
                    .withValues(alpha: 0.9),
                width: borderWidth,
              )
            : null,
        boxShadow: [
          BoxShadow(
            color: (transparent ? (borderColor ?? MioColors.deepBlue) : bg)
                .withValues(alpha: 0.25),
            offset: const Offset(0, 8),
            blurRadius: 18,
          ),
        ],
      ),
      child: child,
    );
  }

  // ==================== BUTTON (TRANSPARAN) ====================
  Widget _mioButton({
    required String label,
    required VoidCallback onTap,
    Color bg = MioColors.deepBlue,
    Color fg = MioColors.white,
    IconData? icon,
    double fontSize = 15,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          // ===== BACKGROUND TRANSPARAN =====
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: bg.withValues(alpha: 0.9),
            width: 1.8,
          ),
          boxShadow: [
            BoxShadow(
              color: bg.withValues(alpha: 0.25),
              offset: const Offset(0, 6),
              blurRadius: 14,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, color: fg, size: 20),
              const SizedBox(width: 10),
            ],
            Text(
              label,
              style: TextStyle(
                fontSize: fontSize,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.6,
                color: fg,
                fontFamily: 'Rajdhani',
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: constraints.maxHeight,
                    ),
                    child: IntrinsicHeight(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
                        child: Column(
                          children: [
                            const SizedBox(height: 20),

                            // ===== PROFIL BULAT + RING ANIMASI =====
                            _buildProfileRing(),

                            // ===== SPACER KE BAWAH =====
                            const SizedBox(height: 60),

                            // ===== VPS & SERVER (2 CARD TERPISAH, TRANSPARAN) =====
                            _buildVpsServerRow(),

                            // ===== JARAK LEBIH KE BAWAH UNTUK BUTTON =====
                            const SizedBox(height: 70),

                            // ===== ENTER TO MASUK (TRANSPARAN) =====
                            _mioButton(
                              label: "ENTER TO MASUK",
                              icon: Icons.login_rounded,
                              onTap: _goToLanding,
                              bg: MioColors.deepBlue,
                            ),

                            const SizedBox(height: 16),

                            // ===== BUY ROLE (TRANSPARAN) =====
                            _mioButton(
                              label: "BUY ROLE",
                              icon: Icons.shopping_cart_rounded,
                              onTap: _goToBuyAccount,
                              bg: MioColors.pink,
                            ),

                            // ===== DORONG CARD KE BAWAH =====
                            const Spacer(),

                            const SizedBox(height: 24),

                            // ===== SUPPORT ADMIN =====
                            _mioCard(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(
                                          color: MioColors.deepBlue
                                              .withValues(alpha: 0.15),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        child: const Icon(
                                          Icons.support_agent_rounded,
                                          color: MioColors.deepBlue,
                                          size: 18,
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      const Expanded(
                                        child: Text(
                                          "SUPPORT ADMIN",
                                          style: TextStyle(
                                            color: MioColors.ink,
                                            fontSize: 14,
                                            fontWeight: FontWeight.w900,
                                            fontFamily: 'Rajdhani',
                                            letterSpacing: 1.0,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 16),
                                  Row(
                                    children: [
                                      // ===== TIKTOK =====
                                      Expanded(
                                        child: _socialButton(
                                          label: 'TikTok',
                                          icon: Icons.music_note_rounded,
                                          color: MioColors.ink,
                                          onTap: _openTiktok,
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      // ===== INSTAGRAM =====
                                      Expanded(
                                        child: _socialButton(
                                          label: 'Instagram',
                                          icon: Icons.camera_alt_rounded,
                                          color: MioColors.pink,
                                          onTap: _openInstagram,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 8),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ==================== SOCIAL BUTTON ====================
  Widget _socialButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
        decoration: BoxDecoration(
          color: MioColors.ice,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color.withValues(alpha: 0.4),
            width: 1.5,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 13,
                fontWeight: FontWeight.w800,
                fontFamily: 'Rajdhani',
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== PROFIL RING ====================
  Widget _buildProfileRing() {
    return AnimatedBuilder(
      animation: _ringScale,
      builder: (context, child) {
        return Transform.scale(
          scale: _ringScale.value,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // ===== GLOW RING (berdenyut) =====
              Container(
                width: 130,
                height: 130,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: MioColors.blue.withValues(alpha: 0.6),
                      blurRadius: 30,
                      spreadRadius: 4,
                    ),
                  ],
                ),
              ),

              // ===== RING BORDER BIRU =====
              Container(
                width: 116,
                height: 116,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: MioColors.blue, width: 4),
                ),
              ),

              // ===== FOTO PROFIL =====
              Container(
                width: 104,
                height: 104,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/profil.jpg',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: MioColors.silver,
                      child: const Icon(
                        Icons.person,
                        color: MioColors.deepBlue,
                        size: 50,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ==================== VPS & SERVER ROW (2 CARD TERPISAH, TRANSPARAN) ====================
  Widget _buildVpsServerRow() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ===== CARD VPS (TRANSPARAN) =====
        Expanded(
          child: _mioCard(
            transparent: true,
            borderColor: MioColors.deepBlue,
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: MioColors.white.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.memory_rounded,
                    color: MioColors.white,
                    size: 22,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "VPS",
                  style: TextStyle(
                    color: MioColors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: MioColors.green,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 5),
                    const Text(
                      "STABIL",
                      style: TextStyle(
                        color: MioColors.green,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),

        const SizedBox(width: 12),

        // ===== CARD SERVER (TRANSPARAN) =====
        Expanded(
          child: _mioCard(
            transparent: true,
            borderColor: MioColors.green,
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: MioColors.white.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.dns_rounded,
                    color: MioColors.white,
                    size: 22,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "SERVER",
                  style: TextStyle(
                    color: MioColors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: MioColors.green,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 5),
                    const Text(
                      "TERHUBUNG",
                      style: TextStyle(
                        color: MioColors.green,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}