import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== IMPORT CHANGE PASSWORD ====================
import 'admin/change_password_page.dart';

// ==================== IMPORT LOGIN PAGE ====================
import 'login_page.dart';

// ==================== HAIMIYA MIO PALETTE ====================
class MioColors {
  static const Color ice = Color(0xFFEAF2FB);
  static const Color silver = Color(0xFFD6E4F5);
  static const Color lightBlue = Color(0xFFA9C7F0);
  static const Color blue = Color(0xFF5B8DEF);
  static const Color deepBlue = Color(0xFF1E3A8A);
  static const Color ink = Color(0xFF1B2A4A);
  static const Color softInk = Color(0xFF5A6B8C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color green = Color(0xFF22C55E);
  static const Color red = Color(0xFFEF4444);
  static const Color yellow = Color(0xFFFACC15);
  static const Color pink = Color(0xFFEC4899);
  static const Color purple = Color(0xFF9333EA);
}

class ProfilePage extends StatefulWidget {
  final String username;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool _isLoading = true;
  bool _showPassword = false;
  String _password = "••••••••";
  String _key = "";
  String _uid = "-";

  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _fetchUserData();
    _fetchUid();
    _loadProfileImage();
  }

  Widget _buildBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/Haimiya.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) =>
                Container(color: MioColors.deepBlue),
          ),
        ),
        Positioned.fill(
          child: Container(
            color: MioColors.deepBlue.withOpacity(0.55),
          ),
        ),
      ],
    );
  }

  Widget _mioCard({
    required Widget child,
    Color bg = MioColors.white,
    double radius = 18,
    EdgeInsets padding = const EdgeInsets.all(18),
    EdgeInsets? margin,
  }) {
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: MioColors.deepBlue.withOpacity(0.18),
            offset: const Offset(0, 6),
            blurRadius: 16,
          ),
        ],
      ),
      child: child,
    );
  }

  Future<void> _loadProfileImage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final imagePath = prefs.getString('profile_image_${widget.username}');
      if (imagePath != null && imagePath.isNotEmpty) {
        final file = File(imagePath);
        if (await file.exists()) {
          if (mounted) setState(() => _profileImage = file);
        }
      }
    } catch (e) {
      debugPrint('Error loading profile image: $e');
    }
  }

  Future<void> _saveProfileImage(File image) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('profile_image_${widget.username}', image.path);
    } catch (e) {
      debugPrint('Error saving profile image: $e');
    }
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 85,
      );
      if (image != null) {
        final File file = File(image.path);
        setState(() => _profileImage = file);
        await _saveProfileImage(file);
      }
    } catch (e) {
      debugPrint('Error picking image: $e');
    }
  }

  Future<void> _fetchUserData() async {
    setState(() => _isLoading = true);
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/user/myInfo?key=${widget.sessionKey}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          if (mounted) {
            setState(() {
              _password = data['password'] ?? "••••••••";
              _key = data['key'] ?? widget.sessionKey;
              _isLoading = false;
            });
          }
        } else {
          if (mounted) setState(() => _isLoading = false);
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      debugPrint('Error fetching user data: $e');
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _fetchUid() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/user/uid?key=${widget.sessionKey}'),
        headers: {
          'x-auth-token': widget.sessionKey,
          'Content-Type': 'application/json',
        },
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final uid = (data['uid'] ?? data['pairId'] ?? '-').toString();
        if (mounted) setState(() => _uid = uid.isNotEmpty ? uid : '-');
      }
    } catch (e) {
      debugPrint('Error fetching UID: $e');
    }
  }

  void _navigateToChangePassword() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChangePasswordPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: MioColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: MioColors.pink.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child:
                  const Icon(Icons.logout, color: MioColors.pink, size: 20),
            ),
            const SizedBox(width: 12),
            const Text(
              "Logout",
              style: TextStyle(
                color: MioColors.ink,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                fontFamily: 'Nevera',
              ),
            ),
          ],
        ),
        content: const Text(
          "Are you sure you want to logout?",
          style: TextStyle(
            color: MioColors.softInk,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Nevera',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: MioColors.silver,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              "Cancel",
              style: TextStyle(
                color: MioColors.ink,
                fontFamily: 'Nevera',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            style: TextButton.styleFrom(
              backgroundColor: MioColors.pink,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              "Yes, Logout",
              style: TextStyle(
                color: MioColors.white,
                fontFamily: 'Nevera',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _copyUid() {
    if (_uid.isEmpty || _uid == '-') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("UID belum tersedia")),
      );
      return;
    }
    Clipboard.setData(ClipboardData(text: _uid));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("UID disalin: $_uid")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MioColors.deepBlue,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ===== HEADER =====
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: MioColors.deepBlue,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: MioColors.deepBlue.withOpacity(0.35),
                              offset: const Offset(0, 6),
                              blurRadius: 14,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.person,
                          color: MioColors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "My Profile",
                        style: TextStyle(
                          color: MioColors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Nevera',
                          letterSpacing: 1,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _getRoleColor().withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: _getRoleColor().withOpacity(0.5),
                            width: 1.5,
                          ),
                        ),
                        child: Text(
                          widget.role.toUpperCase(),
                          style: TextStyle(
                            color: _getRoleColor(),
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Nevera',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // ===== PROFILE CARD =====
                  _mioCard(
                    padding: const EdgeInsets.all(22),
                    child: Column(
                      children: [
                        GestureDetector(
                          onTap: _pickImage,
                          child: Stack(
                            children: [
                              Container(
                                width: 110,
                                height: 110,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: MioColors.deepBlue, width: 3),
                                  boxShadow: [
                                    BoxShadow(
                                      color: MioColors.deepBlue
                                          .withOpacity(0.25),
                                      offset: const Offset(0, 6),
                                      blurRadius: 14,
                                    ),
                                  ],
                                ),
                                child: ClipOval(
                                  child: _profileImage != null
                                      ? Image.file(
                                          _profileImage!,
                                          width: 110,
                                          height: 110,
                                          fit: BoxFit.cover,
                                        )
                                      : Image.asset(
                                          'assets/images/icon.jpg',
                                          width: 110,
                                          height: 110,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) =>
                                              Container(
                                            color: MioColors.silver,
                                            child: const Icon(
                                              Icons.person,
                                              color: MioColors.deepBlue,
                                              size: 55,
                                            ),
                                          ),
                                        ),
                                ),
                              ),
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: MioColors.deepBlue,
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: MioColors.white, width: 2.5),
                                  ),
                                  child: const Icon(
                                    Icons.camera_alt,
                                    color: MioColors.white,
                                    size: 16,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        GestureDetector(
                          onTap: _pickImage,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 5),
                            decoration: BoxDecoration(
                              color: MioColors.ice,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Text(
                              "Tap to change photo",
                              style: TextStyle(
                                color: MioColors.softInk,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Nevera',
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),

                        Text(
                          widget.username,
                          style: const TextStyle(
                            color: MioColors.ink,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Nevera',
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 6),

                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 6),
                          decoration: BoxDecoration(
                            color: _getRoleColor().withOpacity(0.15),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: _getRoleColor().withOpacity(0.4),
                              width: 1.5,
                            ),
                          ),
                          child: Text(
                            widget.role.toUpperCase(),
                            style: TextStyle(
                              color: _getRoleColor(),
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              fontFamily: 'Nevera',
                              letterSpacing: 1,
                            ),
                          ),
                        ),

                        const SizedBox(height: 18),
                        Container(height: 1, color: MioColors.silver),
                        const SizedBox(height: 18),

                        if (_isLoading)
                          const SizedBox(
                            height: 80,
                            child: Center(
                              child: CircularProgressIndicator(
                                color: MioColors.deepBlue,
                              ),
                            ),
                          )
                        else ...[
                          _buildInfoRow(
                              Icons.person, "Username", widget.username),
                          _buildInfoRow(Icons.admin_panel_settings, "Role",
                              widget.role.toUpperCase()),
                          _buildInfoRow(Icons.calendar_today, "Expired",
                              widget.expiredDate),
                          _buildPasswordRow(),
                          _buildInfoRow(Icons.vpn_key, "Session Key",
                              _key.length > 20
                                  ? "${_key.substring(0, 15)}..."
                                  : _key),
                          _buildUidRow(),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ===== CHANGE PASSWORD =====
                  GestureDetector(
                    onTap: _navigateToChangePassword,
                    child: _mioCard(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: MioColors.deepBlue.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(
                              Icons.lock_reset,
                              color: MioColors.deepBlue,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  "Change Password",
                                  style: TextStyle(
                                    color: MioColors.ink,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Nevera',
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  "Update your account password",
                                  style: TextStyle(
                                    color: MioColors.softInk,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Nevera',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(
                            Icons.arrow_forward_ios,
                            color: MioColors.softInk,
                            size: 14,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),

                  // ===== LOGOUT =====
                  GestureDetector(
                    onTap: _showLogoutDialog,
                    child: _mioCard(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: MioColors.pink.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(
                              Icons.logout,
                              color: MioColors.pink,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  "Logout",
                                  style: TextStyle(
                                    color: MioColors.pink,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Nevera',
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  "Sign out from your account",
                                  style: TextStyle(
                                    color: MioColors.softInk,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Nevera',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(
                            Icons.arrow_forward_ios,
                            color: MioColors.pink,
                            size: 14,
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  Column(
                    children: [
                      Container(
                        width: 40,
                        height: 2,
                        color: MioColors.white.withOpacity(0.6),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "© 2026 X•RZYN v2 PROJECT • ALL RIGHTS RESERVED",
                        style: TextStyle(
                          fontSize: 9,
                          letterSpacing: 2,
                          color: MioColors.white,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Nevera',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== INFO ROW (RAPI) ====================
  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: MioColors.ice,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: MioColors.deepBlue, size: 18),
          const SizedBox(width: 10),
          SizedBox(
            width: 110,
            child: Text(
              label,
              style: const TextStyle(
                color: MioColors.softInk,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                fontFamily: 'Nevera',
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: MioColors.ink,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                fontFamily: 'Nevera',
              ),
              textAlign: TextAlign.right,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  // ==================== PASSWORD ROW (RAPI) ====================
  Widget _buildPasswordRow() {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: MioColors.ice,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.lock, color: MioColors.deepBlue, size: 18),
          const SizedBox(width: 10),
          const SizedBox(
            width: 110,
            child: Text(
              "Password",
              style: TextStyle(
                color: MioColors.softInk,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                fontFamily: 'Nevera',
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() => _showPassword = !_showPassword);
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    _showPassword ? _password : "••••••••",
                    style: TextStyle(
                      color:
                          _showPassword ? MioColors.deepBlue : MioColors.ink,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Nevera',
                    ),
                  ),
                  const SizedBox(width: 6),
                  Icon(
                    _showPassword
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: MioColors.deepBlue,
                    size: 16,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== UID ROW (RAPI) ====================
  Widget _buildUidRow() {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: MioColors.ice,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.fingerprint,
              color: MioColors.deepBlue, size: 18),
          const SizedBox(width: 10),
          const SizedBox(
            width: 110,
            child: Text(
              "UID",
              style: TextStyle(
                color: MioColors.softInk,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                fontFamily: 'Nevera',
              ),
            ),
          ),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Flexible(
                  child: SelectableText(
                    _uid,
                    style: const TextStyle(
                      color: MioColors.deepBlue,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Nevera',
                    ),
                    textAlign: TextAlign.right,
                    maxLines: 1,
                  ),
                ),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: _copyUid,
                  child: const Icon(
                    Icons.copy_rounded,
                    color: MioColors.deepBlue,
                    size: 16,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor() {
    switch (widget.role.toLowerCase()) {
      case 'dev':
        return MioColors.red;
      case 'pendiri':
        return MioColors.red;
      case 'high_pt':
        return MioColors.purple;
      case 'pt':
        return const Color(0xFF7C3AED);
      case 'helper':
        return MioColors.green;
      case 'admin':
        return MioColors.blue;
      case 'reseller':
        return MioColors.yellow;
      case 'vip':
        return const Color(0xFFF59E0B);
      case 'member':
        return MioColors.softInk;
      default:
        return MioColors.blue;
    }
  }
}