# Notif Bar Music (Spotify, gaya Dynamic Island)

## Cara pasang
1. Di terminal: `flutter create --org com.example --project-name notifbar notif_bar_music`
2. Timpa/tambahkan file dari folder ini:
   - `lib/main.dart`
   - `android/app/src/main/kotlin/com/example/notifbar/MainActivity.kt` (ganti yang lama)
   - `android/app/src/main/kotlin/com/example/notifbar/IslandService.kt` (baru)
3. Edit `android/app/src/main/AndroidManifest.xml`:

   Di atas `<application>` tambahkan:
   ```xml
   <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
   ```
   Di dalam `<application>` (sejajar `<activity>`) tambahkan:
   ```xml
   <service
       android:name=".IslandService"
       android:label="Notif Bar Music"
       android:exported="true"
       android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">
       <intent-filter>
           <action android:name="android.service.notification.NotificationListenerService"/>
       </intent-filter>
   </service>
   ```
4. Jalankan: `flutter run` (atau `flutter build apk --release`).

## Cara pakai
1. Buka aplikasi, aktifkan **dua izin** (overlay dan akses notifikasi).
2. Nyalakan saklar "Aktifkan bar musik".
3. Putar lagu di Spotify. Pil muncul di atas layar (cover + equalizer merah).
4. Ketuk pil untuk membuka kartu (judul, artis, progres, prev/play/next).

## Catatan
- Jika package berbeda dari `com.example.notifbar`, ubah baris `package` di kedua file Kotlin dan folder-nya.
- Jika pil tidak muncul setelah aplikasi ditutup, kunci aplikasi di recent apps dan matikan optimasi baterai.
- Android 13+: tidak perlu izin notifikasi tambahan, cukup "Akses notifikasi" di pengaturan.
