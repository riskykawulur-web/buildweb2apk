import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const NotifBarApp());

class NotifBarApp extends StatelessWidget {
  const NotifBarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Notif Bar Music',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF1A0508),
        colorScheme: const ColorScheme.dark(primary: Color(0xFFD61010)),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  static const _ch = MethodChannel('notifbar');
  bool overlay = false, listener = false, enabled = true;
  double top = 28;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    final o = await _ch.invokeMethod<bool>('hasOverlay') ?? false;
    final l = await _ch.invokeMethod<bool>('hasListener') ?? false;
    final e = await _ch.invokeMethod<bool>('getEnabled') ?? true;
    final t = await _ch.invokeMethod<int>('getTop') ?? 28;
    if (!mounted) return;
    setState(() {
      overlay = o;
      listener = l;
      enabled = e;
      top = t.toDouble();
    });
  }

  Widget _perm(String title, String sub, bool ok, String method) {
    return Card(
      color: const Color(0xFF2A0A0E),
      child: ListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(sub),
        trailing: ok
            ? const Icon(Icons.check_circle, color: Colors.greenAccent)
            : FilledButton(
                onPressed: () => _ch.invokeMethod(method),
                child: const Text('Aktifkan'),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ready = overlay && listener;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notif Bar Music'),
        backgroundColor: Colors.transparent,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _perm('Tampil di atas aplikasi lain', 'Supaya bar bisa muncul di atas layar',
              overlay, 'openOverlaySettings'),
          _perm('Akses notifikasi', 'Supaya bisa membaca lagu Spotify yang diputar',
              listener, 'openListenerSettings'),
          const SizedBox(height: 8),
          Card(
            color: const Color(0xFF2A0A0E),
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text('Aktifkan bar musik'),
                  subtitle: Text(ready ? 'Putar lagu di Spotify' : 'Aktifkan 2 izin dulu'),
                  value: enabled,
                  onChanged: ready
                      ? (v) {
                          setState(() => enabled = v);
                          _ch.invokeMethod('setEnabled', v);
                        }
                      : null,
                ),
                ListTile(
                  title: Text('Jarak dari atas: ${top.round()} dp'),
                  subtitle: Slider(
                    min: 0,
                    max: 120,
                    value: top,
                    onChanged: (v) => setState(() => top = v),
                    onChangeEnd: (v) => _ch.invokeMethod('setTop', v.round()),
                  ),
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              'Tips: ketuk pil untuk membuka kartu kontrol. Saat ganti lagu, kartu '
              'otomatis terbuka sebentar. Di HP Oppo/Vivo/Xiaomi, izinkan juga '
              '"Autostart" dan matikan hemat baterai untuk aplikasi ini.',
              style: TextStyle(color: Colors.white60),
            ),
          ),
        ],
      ),
    );
  }
}
