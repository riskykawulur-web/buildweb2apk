package com.example.notifbar

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "notifbar")
            .setMethodCallHandler { call, result ->
                val prefs = IslandService.prefs(this)
                when (call.method) {
                    "hasOverlay" -> result.success(Settings.canDrawOverlays(this))
                    "hasListener" -> {
                        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                        result.success(flat.contains(packageName))
                    }
                    "openOverlaySettings" -> {
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")))
                        result.success(null)
                    }
                    "openListenerSettings" -> {
                        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                        result.success(null)
                    }
                    "getEnabled" -> result.success(prefs.getBoolean("enabled", true))
                    "setEnabled" -> {
                        prefs.edit().putBoolean("enabled", call.arguments as Boolean).apply()
                        IslandService.instance?.refresh()
                        result.success(null)
                    }
                    "getTop" -> result.success(prefs.getInt("top", 28))
                    "setTop" -> {
                        prefs.edit().putInt("top", (call.arguments as Number).toInt()).apply()
                        IslandService.instance?.refresh()
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
