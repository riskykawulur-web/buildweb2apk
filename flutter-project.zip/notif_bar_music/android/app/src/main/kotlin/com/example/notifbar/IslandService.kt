package com.example.notifbar

import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.sin

class EqView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(214, 16, 16) }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 800
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { invalidate() }
    }
    var active = false
        set(v) {
            field = v
            if (v) { if (!anim.isRunning) anim.start() } else anim.cancel()
            invalidate()
        }

    override fun onDraw(c: Canvas) {
        val n = 5
        val w = width / (n * 2f - 1)
        for (i in 0 until n) {
            val f = if (active)
                0.35f + 0.65f * abs(sin(anim.animatedFraction * 2 * Math.PI + i * 1.3)).toFloat()
            else 0.3f
            val h = height * f
            c.drawRoundRect(i * 2 * w, (height - h) / 2, i * 2 * w + w, (height + h) / 2, w / 2, w / 2, p)
        }
    }

    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
}

class IslandService : NotificationListenerService() {
    companion object {
        var instance: IslandService? = null
        const val SPOTIFY = "com.spotify.music"
        fun prefs(c: Context) = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var msm: MediaSessionManager
    private var ctrl: MediaController? = null

    private var card: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var expanded = false
    private var lastTitle: String? = null

    private lateinit var art: ImageView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var eq: EqView
    private lateinit var bar: ProgressBar
    private lateinit var controls: LinearLayout
    private lateinit var btnPlay: ImageButton

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            val t = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            if (t != null && t != lastTitle && lastTitle != null) autoExpand()
            lastTitle = t
            update()
        }
        override fun onPlaybackStateChanged(state: PlaybackState?) = update()
    }

    private val collapseRun = Runnable { setExpanded(false) }
    private val hideRun = Runnable { removeCard() }
    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            h.postDelayed(this, 500)
        }
    }

    override fun onListenerConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val cn = ComponentName(this, IslandService::class.java)
        msm.addOnActiveSessionsChangedListener({ pick(it) }, cn)
        pick(msm.getActiveSessions(cn))
        h.post(tick)
    }

    override fun onListenerDisconnected() {
        h.removeCallbacksAndMessages(null)
        ctrl?.unregisterCallback(cb)
        ctrl = null
        removeCard()
        instance = null
    }

    fun refresh() = h.post { update() }

    private fun pick(list: List<MediaController>?) {
        val c = list?.firstOrNull { it.packageName == SPOTIFY }
        if (c?.sessionToken != ctrl?.sessionToken) {
            ctrl?.unregisterCallback(cb)
            ctrl = c
            c?.registerCallback(cb)
            lastTitle = c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
        }
        update()
    }

    private fun autoExpand() {
        setExpanded(true)
        h.removeCallbacks(collapseRun)
        h.postDelayed(collapseRun, 4000)
    }

    private fun update() {
        val enabled = prefs(this).getBoolean("enabled", true)
        val md = ctrl?.metadata
        val st = ctrl?.playbackState
        if (!enabled || ctrl == null || md == null) { removeCard(); return }
        val playing = st?.state == PlaybackState.STATE_PLAYING

        if (card == null) buildCard()
        params?.let { p ->
            val y = dp(prefs(this).getInt("top", 28))
            if (p.y != y && card != null) {
                p.y = y
                try { wm.updateViewLayout(card, p) } catch (_: Exception) {}
            }
        }
        title.text = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Judul Musik"
        artist.text = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (bmp != null) art.setImageBitmap(bmp)
        eq.active = playing
        btnPlay.setImageResource(
            if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )
        h.removeCallbacks(hideRun)
        if (!playing) h.postDelayed(hideRun, 15000)
        updateProgress()
    }

    private fun updateProgress() {
        val c = ctrl ?: return
        if (card == null || !expanded) return
        val dur = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val st = c.playbackState ?: return
        var pos = st.position
        if (st.state == PlaybackState.STATE_PLAYING) {
            pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        bar.max = 1000
        bar.progress = if (dur > 0) (pos * 1000 / dur).toInt().coerceIn(0, 1000) else 0
    }

    private fun icon(res: Int, onClick: () -> Unit) = ImageButton(this).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE)
        background = null
        setPadding(dp(18), dp(8), dp(18), dp(8))
        setOnClickListener { onClick() }
    }

    private fun buildCard() {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(30).toFloat()
            }
            setPadding(dp(10), dp(8), dp(14), dp(8))
            minimumWidth = dp(170)
            setOnClickListener {
                h.removeCallbacks(collapseRun)
                setExpanded(!expanded)
            }
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        art = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.DKGRAY)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
        }
        row.addView(art, LinearLayout.LayoutParams(dp(36), dp(36)))

        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
        }
        title = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        artist = TextView(this).apply {
            setTextColor(Color.LTGRAY); textSize = 13f; maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        texts.addView(title); texts.addView(artist)
        row.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        eq = EqView(this)
        row.addView(eq, LinearLayout.LayoutParams(dp(26), dp(22)))
        c.addView(row)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.DKGRAY)
        }
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(bar, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(12) })
            val btns = LinearLayout(this@IslandService).apply {
                gravity = Gravity.CENTER
                addView(icon(android.R.drawable.ic_media_previous) { ctrl?.transportControls?.skipToPrevious() })
                btnPlay = icon(android.R.drawable.ic_media_pause) {
                    if (ctrl?.playbackState?.state == PlaybackState.STATE_PLAYING)
                        ctrl?.transportControls?.pause() else ctrl?.transportControls?.play()
                }
                addView(btnPlay)
                addView(icon(android.R.drawable.ic_media_next) { ctrl?.transportControls?.skipToNext() })
            }
            addView(btns)
            visibility = View.GONE
        }
        c.addView(controls)

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(prefs(this@IslandService).getInt("top", 28))
        }
        try { wm.addView(c, p) } catch (e: Exception) { return }
        card = c; params = p; expanded = false
    }

    private fun setExpanded(v: Boolean) {
        val c = card ?: return
        val p = params ?: return
        expanded = v
        title.visibility = if (v) View.VISIBLE else View.GONE
        artist.visibility = if (v) View.VISIBLE else View.GONE
        controls.visibility = if (v) View.VISIBLE else View.GONE
        p.width = if (v) resources.displayMetrics.widthPixels - dp(24)
        else WindowManager.LayoutParams.WRAP_CONTENT
        (c.background as GradientDrawable).cornerRadius = dp(if (v) 34 else 30).toFloat()
        try { wm.updateViewLayout(c, p) } catch (_: Exception) {}
        updateProgress()
    }

    private fun removeCard() {
        card?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        card = null; params = null; expanded = false
    }
}
