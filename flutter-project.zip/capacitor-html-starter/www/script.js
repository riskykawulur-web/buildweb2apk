(() => {
  const input = document.getElementById("name");
  const button = document.getElementById("saveButton");
  const status = document.getElementById("status");
  const STORAGE_KEY = "aplikasiku.nama";

  try {
    const savedName = localStorage.getItem(STORAGE_KEY);
    if (savedName) {
      input.value = savedName;
      status.textContent = `Nama tersimpan: ${savedName}`;
    }
  } catch (error) {
    status.textContent = "Penyimpanan lokal tidak tersedia di perangkat ini.";
  }

  button.addEventListener("click", () => {
    const name = input.value.trim();
    if (!name) {
      status.textContent = "Isi nama terlebih dahulu.";
      input.focus();
      return;
    }

    try {
      localStorage.setItem(STORAGE_KEY, name);
      status.textContent = `Nama tersimpan: ${name}`;
    } catch (error) {
      status.textContent = "Nama belum bisa disimpan. Periksa izin penyimpanan browser.";
    }
  });
})();
