# AplikasiKu — HTML + Capacitor

Starter sederhana untuk mengubah aplikasi HTML/CSS/JavaScript menjadi proyek Android.

## Persiapan
- Node.js versi 20 atau lebih baru
- Android Studio dan Android SDK
- Java/JDK yang didukung oleh versi Android Gradle Plugin yang dipasang Android Studio

## Membuat proyek Android
Buka terminal di folder proyek, lalu jalankan:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio akan terbuka. Tunggu Gradle selesai melakukan sinkronisasi, lalu jalankan aplikasi di emulator atau perangkat Android.

## Setelah mengubah HTML/CSS/JS
Jalankan:

```bash
npx cap sync android
```

Lalu build APK melalui Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Kustomisasi
- Ubah nama aplikasi pada `capacitor.config.json` (`appName`).
- Ubah ID aplikasi pada `capacitor.config.json` (`appId`) sebelum rilis.
- Edit tampilan di folder `www/`.

Ini adalah template awal, bukan APK jadi. Pengujian tetap diperlukan pada perangkat/emulator sasaran.
