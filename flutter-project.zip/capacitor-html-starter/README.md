# AplikasiKu — HTML + Capacitor

Starter sederhana untuk mengubah aplikasi HTML/CSS/JavaScript menjadi proyek Android.

## Persiapan
- Node.js versi 20 atau lebih baru
- Android Studio dan Android SDK
- Java/JDK yang didukung oleh versi Android Gradle Plugin yang dipasang Android Studio

## Membuat proyek Android
Buka terminal di folder proyek, lalu jalankan:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio akan terbuka. Tunggu Gradle selesai melakukan sinkronisasi, lalu jalankan aplikasi di emulator atau perangkat Android.

## Setelah mengubah HTML/CSS/JS
Jalankan:

```bash
npx cap sync android
```

Lalu build APK melalui Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Kustomisasi
- Ubah nama aplikasi pada `capacitor.config.json` (`appName`).
- Ubah ID aplikasi pada `capacitor.config.json` (`appId`) sebelum rilis.
- Edit tampilan di folder `www/`.

Ini adalah template awal, bukan APK jadi. Pengujian tetap diperlukan pada perangkat/emulator sasaran.


## Build APK Debug otomatis melalui GitHub Actions
ZIP ini menyertakan workflow `.github/workflows/build-debug-apk.yml`.

1. Buat repository baru di GitHub.
2. Upload/commit seluruh isi folder proyek ke branch `main`.
3. Buka tab **Actions** pada repository. Workflow bernama **Build Android Debug APK** akan berjalan otomatis setelah push.
4. Setelah selesai, buka hasil workflow dan unduh artifact **AplikasiKu-debug-apk**.
5. Ekstrak artifact untuk mendapatkan `app-debug.apk`, lalu pindahkan ke HP Android untuk diuji.

Kamu juga bisa menjalankan workflow manual dari **Actions > Build Android Debug APK > Run workflow**.

Build otomatis ini membutuhkan akun/repository GitHub dan koneksi internet. APK debug hanya untuk pengujian; jangan gunakan sebagai APK rilis publik.
