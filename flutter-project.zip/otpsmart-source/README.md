# OTP Smart — Source Code Lengkap

Aplikasi client untuk layanan otpsmart.com (Nokos / OTP, SMM Panel, cek saldo).
Terdiri dari **web app** (HTML + CSS + JS murni) yang dibungkus menjadi **APK Android** via WebView.

## Struktur Folder

```
otpsmart-source/
├── webapp/                  # Aplikasi web (bisa dibuka langsung di browser)
│   ├── index.html           # Struktur halaman + bottom nav
│   ├── css/style.css        # Semua styling (tema gelap, mobile-first)
│   └── js/app.js            # Logika: API call, order nomor, polling OTP, SMM
└── android/                 # Project Android Studio (untuk build APK)
    ├── build.gradle         # Top-level gradle
    ├── settings.gradle
    └── app/
        ├── build.gradle     # Config APK (applicationId, minSdk 21, targetSdk 34)
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/com/otpsmart/app/MainActivity.java   # WebView + matikan CORS
            ├── res/         # layout, strings, styles, ikon launcher (4 density)
            └── assets/      # Copy dari webapp/ (dimuat WebView via file:///android_asset)
```

## Cara Pakai Web App (tanpa build APK)
Buka `webapp/index.html` di browser. Karena CORS browser memblokir API call dari `file://`,
jalankan dulu local server: `python3 -m http.server` lalu buka `http://localhost:8000/webapp/`.
Atau langsung pakai APK yang sudah jadi (OTPSmart-Nokos.apk) — CORS sudah dimatikan di WebView.

## Cara Build APK (Android Studio)
1. Buka folder `android/` di Android Studio.
2. Tunggu gradle sync selesai.
3. Menu **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
4. APK ada di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Fitur
- Dashboard: saldo, profil, referral, transaksi terakhir
- Order Nokos: cari layanan → pilih operator/negara (lihat harga) → order → kode OTP auto-refresh tiap 5 detik
- Aksi: salin nomor, salin OTP, cancel, resend
- Riwayat transaksi lengkap
- SMM Panel: 7261 layanan, cari & order langsung
- API key tersimpan di localStorage perangkat (bisa diganti di tab Profil)

## API Endpoint yang dipakai
- `GET  /api/v1/profile` — profil + saldo
- `GET  /api/v1/services` — daftar layanan OTP
- `GET  /api/v1/services/{id}/operators` — operator/negara + harga
- `POST /api/v1/order` — order nomor (body: service_id, operator_id)
- `GET  /api/v1/order/{id}` — cek status + kode OTP (field: sn, target, status)
- `POST /api/v1/order/{id}/cancel` — batalkan order
- `POST /api/v1/order/{id}/resend` — minta OTP ulang
- `GET  /api/v1/transactions` — riwayat transaksi
- `GET  /api/v1/smm/services` — daftar layanan SMM
