(function(){
"use strict";
var API_BASE = "https://otpsmart.com/api/v1";
var DEFAULT_KEY = "16741|m6TuOWPL8ssHbc8yk6BbHVdANRnhNn09NNBMj4SD1169ce23";
var LS_KEY = "otpsmart_key_v1";
var LS_ORDERS = "otpsmart_active_orders_v1";
var apiKey = localStorage.getItem(LS_KEY) || DEFAULT_KEY;
var activeOrders = JSON.parse(localStorage.getItem(LS_ORDERS) || "[]");
var pollTimer = null;
var servicesCache = null;
var smmCache = null;
var currentService = null;

function $(id){return document.getElementById(id)}
function esc(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function fmt(n){return Number(n||0).toLocaleString("id-ID",{maximumFractionDigits:0})}
function toast(msg,err){
  var t=$("toast"); t.textContent=msg; t.className=err?"err":""; t.classList.remove("hidden");
  clearTimeout(t._h); t._h=setTimeout(function(){t.classList.add("hidden")},3000);
}
function api(path,opts){
  opts=opts||{};
  var headers={"Accept":"application/json","Authorization":"Bearer "+apiKey};
  if(opts.body){headers["Content-Type"]="application/json"}
  return fetch(API_BASE+path,{method:opts.method||"GET",headers:headers,body:opts.body?JSON.stringify(opts.body):undefined})
    .then(function(r){return r.json().then(function(d){
      if(!r.ok || d.success===false){throw new Error(d.message||("HTTP "+r.status))}
      return d;
    })});
}
function saveOrders(){localStorage.setItem(LS_ORDERS,JSON.stringify(activeOrders))}
function copyText(t){
  if(navigator.clipboard){navigator.clipboard.writeText(t).then(function(){toast("Disalin: "+t)})}
  else{var ta=document.createElement("textarea");ta.value=t;document.body.appendChild(ta);ta.select();try{document.execCommand("copy");toast("Disalin: "+t)}catch(e){}ta.remove()}
}

/* ---------- NAV ---------- */
var currentPage="home";
function go(page){
  currentPage=page;
  ["home","order","history","smm","profile"].forEach(function(p){$("page-"+p).classList.toggle("hidden",p!==page)});
  document.querySelectorAll(".nav-item").forEach(function(n){n.classList.toggle("active",n.dataset.page===page)});
  if(page==="home") loadHome();
  if(page==="order"){ if(!servicesCache) loadServices(); showOrderStep("services"); renderActiveOrders(); }
  if(page==="history") loadTransactions();
  if(page==="smm"){ if(!smmCache) loadSmm(); }
  if(page==="profile") loadProfile();
  window.scrollTo(0,0);
}
document.querySelectorAll(".nav-item").forEach(function(n){n.addEventListener("click",function(){go(n.dataset.page)})});
document.querySelectorAll("[data-goto]").forEach(function(b){b.addEventListener("click",function(){go(b.dataset.goto)})});

/* ---------- PROFILE / BALANCE ---------- */
function loadProfile(){
  api("/profile").then(function(d){
    var u=d.data;
    $("prof-name").textContent=u.username;
    $("prof-email").textContent=u.email;
    $("prof-ref").textContent=u.referral_code||"-";
    if(u.avatar_url){$("prof-avatar").innerHTML='<img src="'+esc(u.avatar_url)+'" alt="">';$("avatar").innerHTML='<img src="'+esc(u.avatar_url)+'" alt="">'}
    $("set-apikey").value=apiKey;
  }).catch(function(e){toast("Gagal load profil: "+e.message,true)});
}
$("btn-save-key").addEventListener("click",function(){
  apiKey=$("set-apikey").value.trim();
  if(!apiKey){toast("API key tidak boleh kosong",true);return}
  localStorage.setItem(LS_KEY,apiKey);
  toast("API key disimpan");
  loadHome();
});
$("copy-ref").addEventListener("click",function(){copyText($("prof-ref").textContent)});

/* ---------- HOME ---------- */
function loadHome(){
  api("/profile").then(function(d){
    var u=d.data;
    $("bal-value").textContent="Rp "+fmt(u.balance);
    $("bal-username").textContent="@"+u.username;
    $("bal-email").textContent=u.email;
    if(u.avatar_url){$("avatar").innerHTML='<img src="'+esc(u.avatar_url)+'" alt="">'}
  }).catch(function(e){$("bal-value").textContent="Gagal";toast(e.message,true)});
  renderActiveOrders($("home-active"));
  api("/transactions").then(function(d){
    var txs=d.data.slice(0,5);
    var html=txs.map(function(t){return txHtml(t)}).join("");
    $("home-tx").innerHTML=html||'<div class="empty">Belum ada transaksi</div>';
  }).catch(function(){$("home-tx").innerHTML='<div class="empty">Gagal memuat</div>'});
}
function txHtml(t){
  var neg=t.type==="purchase"||t.amount<0;
  var icon=neg?"📱":"💰";
  var bg=neg?"var(--accent-soft)":"var(--accent2-soft)";
  var cl=neg?"neg":"pos";
  var sign=neg?"-":"+";
  return '<div class="tx-item"><div class="tx-icon" style="background:'+bg+'">'+icon+'</div>'+
    '<div class="tx-body"><div class="tx-name">'+esc(t.description||t.type)+'</div>'+
    '<div class="tx-desc">'+(t.created_at?t.created_at.slice(0,16).replace("T"," "):"")+' · '+esc(t.status||"")+'</div></div>'+
    '<div class="tx-amount '+cl+'">'+sign+'Rp '+fmt(Math.abs(t.amount))+'</div></div>';
}

/* ---------- SERVICES / ORDER ---------- */
function showOrderStep(step){
  ["services","operators","active"].forEach(function(s){$("order-step-"+s).classList.toggle("hidden",s!==step)});
}
function loadServices(){
  $("svc-list").innerHTML='<div class="loading"><span class="spinner"></div><div>Memuat layanan...</div></div>';
  api("/services").then(function(d){
    servicesCache=d.data;
    renderServices("");
  }).catch(function(e){$("svc-list").innerHTML='<div class="empty">Gagal: '+esc(e.message)+'</div>'});
}
function renderServices(q){
  if(!servicesCache)return;
  q=(q||"").toLowerCase();
  var list=servicesCache.filter(function(s){return !q||s.name.toLowerCase().indexOf(q)>=0||s.id.toLowerCase().indexOf(q)>=0}).slice(0,80);
  var html=list.map(function(s){
    return '<div class="list-item" data-svc="'+esc(s.id)+'"><div><div class="list-name">'+esc(s.name.trim())+'</div><div class="list-sub">ID: '+esc(s.id)+'</div></div><div class="list-price"><span class="s">Pilih →</span></div></div>';
  }).join("");
  $("svc-list").innerHTML=html||'<div class="empty">Layanan tidak ditemukan</div>';
  $("svc-list").querySelectorAll("[data-svc]").forEach(function(el){
    el.addEventListener("click",function(){pickService(el.dataset.svc)});
  });
}
$("svc-search").addEventListener("input",function(){renderServices(this.value)});

function pickService(svcId){
  currentService=servicesCache.find(function(s){return s.id===svcId});
  $("op-svc-name").textContent=currentService?currentService.name.trim():svcId;
  showOrderStep("operators");
  $("op-list").innerHTML='<div class="loading"><span class="spinner"></div><div>Memuat operator & harga...</div></div>';
  api("/services/"+svcId+"/operators").then(function(d){
    var ops=d.data.filter(function(o){return o.status==="active"});
    var html=ops.map(function(o){
      return '<div class="list-item" data-op="'+esc(o.operator_id)+'"><div><div class="list-name">'+esc(o.operator_name)+'</div><div class="list-sub">'+esc(o.status)+'</div></div><div class="list-price"><div class="p">Rp '+fmt(o.price)+'</div><div class="s">Order →</div></div></div>';
    }).join("");
    $("op-list").innerHTML=html||'<div class="empty">Tidak ada operator aktif untuk layanan ini</div>';
    $("op-list").querySelectorAll("[data-op]").forEach(function(el){
      el.addEventListener("click",function(){placeOrder(svcId,el.dataset.op)});
    });
  }).catch(function(e){$("op-list").innerHTML='<div class="empty">Gagal: '+esc(e.message)+'</div>'});
}
$("btn-back-svc").addEventListener("click",function(){showOrderStep("services")});

function placeOrder(svcId,opId){
  toast("Memproses order...");
  api("/order",{method:"POST",body:{service_id:svcId,operator_id:opId}}).then(function(d){
    var o=d.data;
    activeOrders.unshift({id:o.id,phone:o.phone||o.target||o.number||"",service:currentService?currentService.name.trim():svcId,service_id:svcId,created:Date.now(),code:"",status:"waiting"});
    saveOrders();
    toast("Nomor berhasil dipesan!");
    showOrderStep("active");
    renderActiveOrders();
    startPolling();
  }).catch(function(e){toast("Gagal order: "+e.message,true)});
}

/* ---------- ACTIVE ORDERS / OTP POLLING ---------- */
function renderActiveOrders(container){
  container=container||$("active-list");
  if(!activeOrders.length){
    container.innerHTML='<div class="empty">Belum ada pesanan aktif.<br>Pilih layanan di tab Nokos untuk order nomor.</div>';
    return;
  }
  var html=activeOrders.map(function(o,i){
    var done=o.status==="received"||o.status==="completed"||o.status==="success";
    var cancelled=o.status==="cancelled"||o.status==="canceled";
    var stCls=done?"done":(cancelled?"":"waiting");
    var stTxt=cancelled?"Dibatalkan":(done?"Selesai":"Menunggu OTP");
    return '<div class="order-card" data-oid="'+o.id+'">'+
      '<span class="order-status '+stCls+'">'+stTxt+'</span>'+
      '<div class="order-service">'+esc(o.service)+' · ID #'+o.id+'</div>'+
      (o.phone?'<div class="order-phone">'+esc(o.phone)+' <button class="copy-btn" data-copy="'+esc(o.phone)+'">Salin</button></div>':'')+
      '<div class="otp-box">'+
        (o.code?'<div class="otp-code">'+esc(o.code)+'</div><div class="otp-hint">Kode OTP diterima · ketuk untuk menyalin</div>':'<div class="otp-wait">Menunggu kode OTP masuk...<br>Otomatis cek setiap 5 detik</div>')+
      '</div>'+
      '<div class="order-actions">'+
        (o.code?'<button class="btn btn-primary" data-copy="'+esc(o.code)+'">Salin OTP</button>':'<button class="btn btn-secondary" data-refresh="'+o.id+'">Cek Sekarang</button>')+
        '<button class="btn btn-secondary" data-resend="'+o.id+'">Resend</button>'+
        '<button class="btn btn-danger" data-cancel="'+o.id+'">Batal</button>'+
      '</div></div>';
  }).join("");
  container.innerHTML=html;
  container.querySelectorAll("[data-copy]").forEach(function(b){b.addEventListener("click",function(){copyText(b.dataset.copy)})});
  container.querySelectorAll("[data-cancel]").forEach(function(b){b.addEventListener("click",function(){cancelOrder(b.dataset.cancel)})});
  container.querySelectorAll("[data-resend]").forEach(function(b){b.addEventListener("click",function(){resendOrder(b.dataset.resend)})});
  container.querySelectorAll("[data-refresh]").forEach(function(b){b.addEventListener("click",function(){pollOrder(b.dataset.refresh)})});
}

function pollOrder(oid){
  api("/order/"+oid).then(function(d){
    var o=d.data;
    var idx=activeOrders.findIndex(function(x){return x.id==oid});
    if(idx<0)return;
    if(o.phone||o.target||o.number)activeOrders[idx].phone=o.phone||o.target||o.number;
    if(o.sn||o.code||o.otp)activeOrders[idx].code=o.sn||o.code||o.otp;
    if(o.status)activeOrders[idx].status=o.status;
    if(o.detail){
      if(o.detail.target)activeOrders[idx].phone=o.detail.target;
      if(o.detail.sn)activeOrders[idx].code=o.detail.sn;
      if(o.detail.order_status)activeOrders[idx].status=o.detail.order_status;
    }
    saveOrders();
    if(currentPage==="order"||currentPage==="home")renderActiveOrders(currentPage==="home"?$("home-active"):$("active-list"));
  }).catch(function(e){
    // jika order tidak ditemukan, anggap selesai/hapus dari aktif
    if(/tidak ditemukan/.test(e.message)){
      activeOrders=activeOrders.filter(function(x){return x.id!=oid});
      saveOrders();
      if(currentPage==="order")renderActiveOrders();
    }
  });
}
function pollAll(){activeOrders.forEach(function(o){pollOrder(o.id)})}
function startPolling(){if(pollTimer)clearInterval(pollTimer);pollTimer=setInterval(pollAll,5000)}
function stopPolling(){if(pollTimer){clearInterval(pollTimer);pollTimer=null}}

function cancelOrder(oid){
  if(!confirm("Batalkan pesanan #"+oid+"? Saldo akan dikembalikan jika belum dapat OTP."))return;
  api("/order/"+oid+"/cancel",{method:"POST"}).then(function(d){
    toast(d.message||"Pesanan dibatalkan");
    activeOrders=activeOrders.filter(function(x){return x.id!=oid});
    saveOrders();
    renderActiveOrders();
    if(currentPage==="home")renderActiveOrders($("home-active"));
  }).catch(function(e){toast("Gagal: "+e.message,true)});
}
function resendOrder(oid){
  api("/order/"+oid+"/resend",{method:"POST"}).then(function(d){toast(d.message||"Resend diminta")}).catch(function(e){toast("Gagal: "+e.message,true)});
}

/* ---------- TRANSACTIONS ---------- */
function loadTransactions(){
  $("tx-list").innerHTML='<div class="loading"><span class="spinner"></div></div>';
  api("/transactions").then(function(d){
    var html=d.data.map(function(t){return txHtml(t)}).join("");
    $("tx-list").innerHTML=html||'<div class="empty">Belum ada transaksi</div>';
  }).catch(function(e){$("tx-list").innerHTML='<div class="empty">Gagal: '+esc(e.message)+'</div>'});
}

/* ---------- SMM ---------- */
function loadSmm(){
  $("smm-list").innerHTML='<div class="loading"><span class="spinner"></div><div>Memuat layanan SMM...</div></div>';
  api("/smm/services").then(function(d){
    smmCache=d.data;
    renderSmm("");
  }).catch(function(e){$("smm-list").innerHTML='<div class="empty">Gagal: '+esc(e.message)+'</div>'});
}
function renderSmm(q){
  if(!smmCache)return;
  q=(q||"").toLowerCase();
  var list=smmCache.filter(function(s){return !q||s.name.toLowerCase().indexOf(q)>=0||(s.category||"").toLowerCase().indexOf(q)>=0}).slice(0,60);
  var html=list.map(function(s){
    return '<div class="list-item" data-smm="'+s.id+'"><div style="flex:1;min-width:0"><div class="list-name" style="white-space:normal">'+esc(s.name)+'</div>'+
      '<div class="list-sub">'+esc(s.category||"")+' · Min '+fmt(s.min_order)+' · Max '+fmt(s.max_order)+'</div></div>'+
      '<div class="list-price"><div class="p">Rp '+fmt(s.price_per_1000)+'</div><div class="s">/1000</div></div></div>';
  }).join("");
  $("smm-list").innerHTML=html||'<div class="empty">Tidak ditemukan</div>';
  $("smm-list").querySelectorAll("[data-smm]").forEach(function(el){
    el.addEventListener("click",function(){openSmmOrder(parseInt(el.dataset.smm))});
  });
}
$("smm-search").addEventListener("input",function(){renderSmm(this.value)});

function openSmmOrder(svcId){
  var s=smmCache.find(function(x){return x.id===svcId});
  if(!s)return;
  var sheet=document.createElement("div");
  sheet.className="sheet-overlay";
  sheet.innerHTML='<div class="sheet"><div class="sheet-handle"></div><h3>Order SMM</h3>'+
    '<div class="card" style="margin-bottom:14px"><div style="font-weight:700;font-size:14px;margin-bottom:6px">'+esc(s.name)+'</div>'+
    '<div style="font-size:12px;color:var(--muted)">'+esc(s.category||"")+' · Harga Rp '+fmt(s.price_per_1000)+'/1000 · Min '+fmt(s.min_order)+'</div></div>'+
    '<div class="field"><label>Link / Target</label><input id="smm-target" placeholder="https://..."></div>'+
    '<div class="field"><label>Jumlah</label><input id="smm-qty" type="number" placeholder="Min '+s.min_order+'" value="'+s.min_order+'"></div>'+
    '<div id="smm-total" style="font-size:14px;font-weight:700;margin-bottom:14px;color:var(--accent)">Total: Rp 0</div>'+
    '<button class="btn btn-primary" id="smm-submit" style="width:100%">Order Sekarang</button></div>';
  sheet.addEventListener("click",function(e){if(e.target===sheet)sheet.remove()});
  $("sheet-root").appendChild(sheet);
  var qtyEl=sheet.querySelector("#smm-qty");
  qtyEl.addEventListener("input",function(){
    var q=parseInt(qtyEl.value)||0;
    sheet.querySelector("#smm-total").textContent="Total: Rp "+fmt((q/1000)*s.price_per_1000);
  });
  qtyEl.dispatchEvent(new Event("input"));
  sheet.querySelector("#smm-submit").addEventListener("click",function(){
    var target=sheet.querySelector("#smm-target").value.trim();
    var qty=parseInt(qtyEl.value);
    if(!target){toast("Link target wajib diisi",true);return}
    if(!qty||qty<s.min_order){toast("Jumlah minimal "+s.min_order,true);return}
    // SMM order endpoint — try common patterns
    api("/smm/order",{method:"POST",body:{service:s.id,target:target,quantity:qty}}).then(function(d){
      sheet.remove(); toast("Order SMM berhasil! ID: "+(d.data&&d.data.id||""));
    }).catch(function(e){
      // fallback: /order with smm params
      api("/order",{method:"POST",body:{type:"smm",service_id:s.id,target:target,quantity:qty}}).then(function(d2){
        sheet.remove(); toast("Order SMM berhasil!");
      }).catch(function(e2){toast("Gagal order SMM: "+e2.message,true)});
    });
  });
}

/* ---------- INIT ---------- */
loadHome();
if(activeOrders.length){startPolling();pollAll()}
})();