package com.raiderfoxx.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(16, 19, 31))
        }

        val heading = TextView(this).apply {
            text = "RAIDER FOXX"
            textSize =  thirtyTwo()
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }

        val tagline = TextView(this).apply {
            text = "YOUR APP STARTS HERE"
            textSize = 13f
            setTextColor(Color.rgb(255, 145, 55))
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
            setPadding(0, 14, 0, 0)
        }

        screen.addView(heading)
        screen.addView(tagline)
        setContentView(screen)
    }

    private fun thirtyTwo(): Float = 32f
}
