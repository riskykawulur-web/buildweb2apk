# RAIDER FOXX — Base Android Project

Project starter Android Studio menggunakan Kotlin.

## Membuat APK
1. Ekstrak file ZIP.
2. Buka folder `RaiderFoxx_New` di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

- App name: Raider Foxx
- Application ID: com.raiderfoxx.app
- Minimum Android: 6.0 (API 23)

Ini adalah source project, bukan APK yang sudah dikompilasi.
