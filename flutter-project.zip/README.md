# STRIKE MOBILE — Godot 4 FPS prototype

Prototype FPS Android original, dibuat dengan Godot 4 dan renderer Compatibility untuk perangkat kelas bawah.

## Isi prototype
- First-person controller: WASD + mouse di PC.
- Kontrol sentuh Android: joystick kiri, drag kanan untuk melihat, tombol FIRE/JUMP/RELOAD.
- Hitscan rifle, ammo 30, reload, recoil visual sederhana.
- Bot AI sederhana yang mengejar dan menyerang pemain.
- Team Deathmatch: target 20 eliminasi.
- Battle Royale mini: 12 bot, zona aman menyusut, bertahan dan eliminasi semua bot.
- Map 3D low-poly dari primitive mesh, tanpa aset eksternal.

## Menjalankan
1. Install Godot 4.x.
2. Extract ZIP.
3. Godot Project Manager → Import → pilih `project.godot`.
4. Tekan F6/F5 untuk menjalankan.

## Build Android
1. Install Android build template/export template dari Godot.
2. Atur Android SDK/JDK di Editor Settings → Export → Android.
3. Project → Export → Add Android.
4. Package name contoh: `com.example.strikemobile`.
5. Export APK.

## Kontrol
PC:
- WASD bergerak
- Mouse melihat
- Klik kiri menembak
- R reload
- Space lompat
- Esc lepas mouse

Android:
- Area kiri bawah: gerak
- Drag area kanan: melihat
- FIRE / RELOAD / JUMP
- MODE berganti TDM dan Battle Royale

## Catatan
Ini prototype awal, bukan game komersial siap rilis. AI, animasi, networking multiplayer, audio, menu, dan optimasi lanjutan belum termasuk. Battle Royale pada prototype ini adalah mode survival melawan bot offline, bukan 100 pemain online.
