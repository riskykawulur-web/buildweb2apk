WHATSAPP GUARD - proyek Android sederhana

Isi:
- Aplikasi panduan keamanan WhatsApp berbahasa Indonesia.
- Tidak mengakses isi WhatsApp, tidak memindai pesan, dan tidak memblokir malware.
- Tidak meminta izin sensitif.

Cara membuat APK:
1. Buka proyek ini di Android Studio pada komputer.
2. Tunggu Gradle selesai disinkronkan.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.

Target minimum Android 6.0; cocok untuk Vivo Android 11.
