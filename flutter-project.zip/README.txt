NEXORA V5.0 - Android WebView project
Build: Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
The web panel uses localStorage for demo registration and activity history.
SEND BUG is a local-only simulation. It does not attack, spam, lock, crash, or send payloads to real numbers/groups.
Member purchase link is Telegram @DENZ; configure a real membership/backend system separately if required.
