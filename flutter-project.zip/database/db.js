/**
 * Xova Database Layer
 * Pure JS, no native deps — aman untuk banyak user + concurrent write.
 * - Atomic write (tmp + rename)
 * - Write queue (serial, anti corrupt)
 * - In-memory cache
 * - Media blob disimpan file terpisah (tidak bloat JSON)
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DB_DIR = path.join(__dirname);
const MEDIA_DIR = path.join(DB_DIR, "media");
const DATA_DIR = path.join(DB_DIR, "data");

const FILES = {
  users: path.join(DATA_DIR, "users.json"),
  akses: path.join(DATA_DIR, "akses.json"),
  userSessions: path.join(DATA_DIR, "user_sessions.json"),
  chat: path.join(DATA_DIR, "chat_messages.json"),
  statuses: path.join(DATA_DIR, "statuses.json"),
  pendingInvites: path.join(DATA_DIR, "pending_invites.json"),
};

const DEFAULTS = {
  users: [],
  akses: { owners: [], akses: [], resellers: [], pts: [], moderators: [] },
  userSessions: {},
  chat: [],
  statuses: [],
  pendingInvites: {},
};

// Ensure dirs
for (const dir of [DB_DIR, MEDIA_DIR, DATA_DIR]) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

// ─── Cache + Write Queue ───────────────────────────────────────────
const cache = Object.create(null);
const writeQueues = Object.create(null); // name -> Promise chain
const dirty = Object.create(null);

function ensureFile(name) {
  const file = FILES[name];
  if (!fs.existsSync(file)) {
    atomicWriteSync(file, DEFAULTS[name]);
  }
}

function atomicWriteSync(filePath, data) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const tmp = filePath + ".tmp." + process.pid + "." + Date.now();
  const json = JSON.stringify(data, null, 2);
  fs.writeFileSync(tmp, json, "utf-8");
  // fsync via open+sync if possible
  try {
    const fd = fs.openSync(tmp, "r+");
    fs.fsyncSync(fd);
    fs.closeSync(fd);
  } catch (_) {}
  fs.renameSync(tmp, filePath);
}

function readCollection(name) {
  if (cache[name] !== undefined) return cache[name];
  ensureFile(name);
  try {
    const raw = fs.readFileSync(FILES[name], "utf-8");
    const data = JSON.parse(raw);
    cache[name] = data;
    return data;
  } catch (e) {
    console.error(`[DB] Failed read ${name}, using default:`, e.message);
    cache[name] = structuredClone
      ? structuredClone(DEFAULTS[name])
      : JSON.parse(JSON.stringify(DEFAULTS[name]));
    return cache[name];
  }
}

function enqueueWrite(name, mutator) {
  if (!writeQueues[name]) writeQueues[name] = Promise.resolve();
  writeQueues[name] = writeQueues[name]
    .then(() => {
      const current = readCollection(name);
      const next = mutator(current);
      cache[name] = next;
      atomicWriteSync(FILES[name], next);
      return next;
    })
    .catch((err) => {
      console.error(`[DB] Write error ${name}:`, err.message);
      // invalidate cache on failure
      delete cache[name];
      throw err;
    });
  return writeQueues[name];
}

function writeSync(name, data) {
  cache[name] = data;
  atomicWriteSync(FILES[name], data);
}

// ─── Media blobs (status photo/video, chat photo) ──────────────────
function saveMedia(bufferOrBase64, extHint) {
  let buf;
  let ext = extHint || "bin";
  if (typeof bufferOrBase64 === "string") {
    const m = bufferOrBase64.match(/^data:([^;]+);base64,(.+)$/);
    if (m) {
      const mime = m[1];
      if (mime.includes("jpeg") || mime.includes("jpg")) ext = "jpg";
      else if (mime.includes("png")) ext = "png";
      else if (mime.includes("webp")) ext = "webp";
      else if (mime.includes("gif")) ext = "gif";
      else if (mime.includes("mp4")) ext = "mp4";
      else if (mime.includes("webm")) ext = "webm";
      else if (mime.includes("video")) ext = "mp4";
      buf = Buffer.from(m[2], "base64");
    } else {
      buf = Buffer.from(bufferOrBase64, "base64");
    }
  } else {
    buf = bufferOrBase64;
  }
  const id = crypto.randomBytes(12).toString("hex");
  const filename = `${id}.${ext}`;
  const full = path.join(MEDIA_DIR, filename);
  fs.writeFileSync(full, buf);
  return filename; // relative id
}

function mediaPath(filename) {
  if (!filename) return null;
  return path.join(MEDIA_DIR, filename);
}

function readMediaBase64(filename, mimeFallback) {
  if (!filename) return null;
  const full = path.join(MEDIA_DIR, filename);
  if (!fs.existsSync(full)) return null;
  const buf = fs.readFileSync(full);
  const ext = path.extname(filename).toLowerCase();
  let mime = mimeFallback || "application/octet-stream";
  if (ext === ".jpg" || ext === ".jpeg") mime = "image/jpeg";
  else if (ext === ".png") mime = "image/png";
  else if (ext === ".webp") mime = "image/webp";
  else if (ext === ".gif") mime = "image/gif";
  else if (ext === ".mp4") mime = "video/mp4";
  else if (ext === ".webm") mime = "video/webm";
  return `data:${mime};base64,${buf.toString("base64")}`;
}

function deleteMedia(filename) {
  if (!filename) return;
  try {
    const full = path.join(MEDIA_DIR, filename);
    if (fs.existsSync(full)) fs.unlinkSync(full);
  } catch (_) {}
}

// ─── Migration from old root/legacy JSON ───────────────────────────
function migrateLegacy() {
  const root = path.join(__dirname, "..");
  const legacyMap = [
    { name: "users", candidates: [path.join(DB_DIR, "user.json"), path.join(root, "database", "user.json")] },
    { name: "akses", candidates: [path.join(DB_DIR, "akses.json")] },
    { name: "userSessions", candidates: [path.join(root, "user_sessions.json")] },
    { name: "chat", candidates: [path.join(root, "chat_messages.json")] },
    { name: "statuses", candidates: [path.join(root, "statuses.json")] },
    { name: "pendingInvites", candidates: [path.join(root, "pending_invites.json")] },
  ];

  for (const { name, candidates } of legacyMap) {
    ensureFile(name);
    // only migrate if new file is empty/default
    let current;
    try {
      current = JSON.parse(fs.readFileSync(FILES[name], "utf-8"));
    } catch {
      current = DEFAULTS[name];
    }
    const isEmpty =
      (Array.isArray(current) && current.length === 0) ||
      (typeof current === "object" && !Array.isArray(current) && Object.keys(current).length === 0) ||
      (name === "akses" &&
        Array.isArray(current.owners) &&
        current.owners.length === 0 &&
        Array.isArray(current.akses) &&
        current.akses.length === 0);

    if (!isEmpty) continue;

    for (const cand of candidates) {
      if (!fs.existsSync(cand)) continue;
      try {
        let data = JSON.parse(fs.readFileSync(cand, "utf-8"));
        // Fix broken user.json like [1095391385]
        if (name === "users") {
          if (!Array.isArray(data)) data = [];
          data = data
            .filter((u) => u && typeof u === "object" && u.username)
            .map((u) => ({
              username: String(u.username),
              key: String(u.key || ""),
              expired: Number(u.expired) || 0,
            }));
        }
        if (name === "akses") {
          if (!data || typeof data !== "object") data = DEFAULTS.akses;
          data.owners = data.owners || [];
          data.akses = data.akses || [];
          data.resellers = data.resellers || [];
          data.pts = data.pts || [];
          data.moderators = data.moderators || [];
        }
        writeSync(name, data);
        console.log(`[DB] Migrated legacy ${path.basename(cand)} → data/${name}.json`);
        break;
      } catch (e) {
        console.error(`[DB] Migrate skip ${cand}:`, e.message);
      }
    }
  }
}

// ─── Users API ─────────────────────────────────────────────────────
function getUsers() {
  const users = readCollection("users");
  if (!Array.isArray(users)) return [];
  // sanitize
  return users.filter((u) => u && typeof u === "object" && u.username);
}

function saveUsers(users) {
  const clean = (Array.isArray(users) ? users : [])
    .filter((u) => u && typeof u === "object" && u.username)
    .map((u) => ({
      username: String(u.username),
      key: String(u.key || ""),
      expired: Number(u.expired) || 0,
    }));
  writeSync("users", clean);
}

function findUser(username) {
  return getUsers().find((u) => u.username === username) || null;
}

function upsertUser(user) {
  const users = getUsers();
  const idx = users.findIndex((u) => u.username === user.username);
  if (idx >= 0) users[idx] = { ...users[idx], ...user };
  else users.push(user);
  saveUsers(users);
  return users;
}

function deleteUser(username) {
  const users = getUsers().filter((u) => u.username !== username);
  saveUsers(users);
  return users;
}

// ─── Akses / Roles ─────────────────────────────────────────────────
function loadAkses() {
  let data = readCollection("akses");
  if (!data || typeof data !== "object") data = { ...DEFAULTS.akses };
  if (!data.owners) data.owners = [];
  if (!data.akses) data.akses = [];
  if (!data.resellers) data.resellers = [];
  if (!data.pts) data.pts = [];
  if (!data.moderators) data.moderators = [];
  cache.akses = data;
  return data;
}

function saveAkses(data) {
  const clean = {
    owners: (data.owners || []).map(String),
    akses: (data.akses || []).map(String),
    resellers: (data.resellers || []).map(String),
    pts: (data.pts || []).map(String),
    moderators: (data.moderators || []).map(String),
  };
  writeSync("akses", clean);
}

// ─── User sessions (WA senders per panel user) ─────────────────────
function loadUserSessions() {
  const data = readCollection("userSessions");
  return data && typeof data === "object" ? data : {};
}

function saveUserSessions(data) {
  writeSync("userSessions", data && typeof data === "object" ? data : {});
}

// ─── Chat ──────────────────────────────────────────────────────────
function loadChatMessages() {
  const data = readCollection("chat");
  return Array.isArray(data) ? data : [];
}

function saveChatMessages(messages) {
  let list = Array.isArray(messages) ? messages : [];
  if (list.length > 500) list = list.slice(-500);
  writeSync("chat", list);
}

// ─── Statuses (metadata only; media di folder media/) ──────────────
const STATUS_TTL_MS = 24 * 60 * 60 * 1000;

function loadStatuses() {
  const data = readCollection("statuses");
  if (!Array.isArray(data)) return [];
  const now = Date.now();
  const alive = data.filter((s) => s && s.ts && now - s.ts < STATUS_TTL_MS);
  // hydrate media for API consumers (base64)
  return alive.map((s) => hydrateStatus(s));
}

function hydrateStatus(s) {
  const out = { ...s };
  if (s.mediaFile && s.type === "image") {
    out.src = readMediaBase64(s.mediaFile, "image/jpeg");
  }
  if (s.mediaFile && s.type === "video") {
    out.videoData = readMediaBase64(s.mediaFile, "video/mp4");
  }
  if (s.thumbFile) {
    out.thumb = readMediaBase64(s.thumbFile, "image/jpeg");
  }
  return out;
}

function stripStatusForStore(s) {
  // Simpan metadata + nama file media, bukan base64 raksasa
  const stored = {
    id: s.id,
    username: s.username,
    displayName: s.displayName || s.username,
    role: s.role || "Member",
    type: s.type,
    text: s.text || null,
    bg: s.bg || null,
    caption: s.caption || "",
    ts: s.ts,
    mediaFile: s.mediaFile || null,
    thumbFile: s.thumbFile || null,
  };
  return stored;
}

function saveStatuses(list) {
  const now = Date.now();
  let cleaned = (list || [])
    .filter((s) => s && s.ts && now - s.ts < STATUS_TTL_MS)
    .map((s) => {
      // jika masih punya src/videoData base64 → pindah ke file
      if (s.type === "image" && s.src && !s.mediaFile && typeof s.src === "string" && s.src.startsWith("data:")) {
        try {
          s.mediaFile = saveMedia(s.src);
        } catch (e) {
          console.error("[DB] status image save media fail", e.message);
        }
      }
      if (s.type === "video" && s.videoData && !s.mediaFile && typeof s.videoData === "string" && s.videoData.startsWith("data:")) {
        try {
          s.mediaFile = saveMedia(s.videoData);
        } catch (e) {
          console.error("[DB] status video save media fail", e.message);
        }
      }
      if (s.thumb && !s.thumbFile && typeof s.thumb === "string" && s.thumb.startsWith("data:")) {
        try {
          s.thumbFile = saveMedia(s.thumb, "jpg");
        } catch (_) {}
      }
      return stripStatusForStore(s);
    });
  if (cleaned.length > 100) {
    const removed = cleaned.slice(0, cleaned.length - 100);
    cleaned = cleaned.slice(-100);
    removed.forEach((s) => {
      deleteMedia(s.mediaFile);
      deleteMedia(s.thumbFile);
    });
  }
  writeSync("statuses", cleaned);
}

function createStatus(payload) {
  const s = { ...payload };
  if (s.type === "image" && s.src && typeof s.src === "string") {
    s.mediaFile = saveMedia(s.src);
    delete s.src;
  }
  if (s.type === "video" && s.videoData && typeof s.videoData === "string") {
    s.mediaFile = saveMedia(s.videoData);
    delete s.videoData;
  }
  if (s.thumb && typeof s.thumb === "string" && s.thumb.startsWith("data:")) {
    s.thumbFile = saveMedia(s.thumb, "jpg");
    delete s.thumb;
  }
  const list = readCollection("statuses");
  const arr = Array.isArray(list) ? list : [];
  arr.push(stripStatusForStore(s));
  // prune expired
  const now = Date.now();
  const kept = [];
  for (const item of arr) {
    if (item && item.ts && now - item.ts < STATUS_TTL_MS) kept.push(item);
    else {
      deleteMedia(item && item.mediaFile);
      deleteMedia(item && item.thumbFile);
    }
  }
  writeSync("statuses", kept.length > 100 ? kept.slice(-100) : kept);
  return hydrateStatus(stripStatusForStore(s));
}

function deleteStatus(statusId, username, isOwner) {
  const list = Array.isArray(readCollection("statuses")) ? readCollection("statuses") : [];
  const target = list.find((s) => s.id === statusId);
  if (!target) return { ok: false, error: "Status tidak ditemukan." };
  if (target.username !== username && !isOwner) {
    return { ok: false, error: "Tidak punya izin hapus status ini." };
  }
  const next = list.filter((s) => s.id !== statusId);
  deleteMedia(target.mediaFile);
  deleteMedia(target.thumbFile);
  writeSync("statuses", next);
  return { ok: true };
}

// ─── Pending invites ───────────────────────────────────────────────
function loadPendingInvites() {
  const data = readCollection("pendingInvites");
  return data && typeof data === "object" ? data : {};
}

function savePendingInvites(data) {
  writeSync("pendingInvites", data && typeof data === "object" ? data : {});
}

// ─── Chat with optional media file ─────────────────────────────────
function createChatMessage(msg) {
  const m = { ...msg };
  if (m.photo && typeof m.photo === "string" && m.photo.startsWith("data:")) {
    try {
      m.photoFile = saveMedia(m.photo);
      // keep small? for chat we still embed base64 in response but store file
      // to avoid huge rewrites, store only photoFile in DB
      delete m.photo;
    } catch (e) {
      console.error("[DB] chat photo media fail", e.message);
    }
  }
  const list = loadChatMessages();
  list.push(m);
  saveChatMessages(list);
  return hydrateChatMessage(m);
}

function hydrateChatMessage(m) {
  const out = { ...m };
  if (m.photoFile && !m.photo) {
    out.photo = readMediaBase64(m.photoFile, "image/jpeg");
  }
  return out;
}

function loadChatMessagesHydrated() {
  return loadChatMessages().map(hydrateChatMessage);
}

function deleteChatMessage(messageId, username, isOwner) {
  let messages = loadChatMessages();
  const target = messages.find((m) => m.id === messageId);
  if (!target) return { ok: false, error: "Pesan tidak ditemukan." };
  if (target.username !== username && !isOwner) {
    return { ok: false, error: "Tidak punya izin hapus pesan ini." };
  }
  if (target.photoFile) deleteMedia(target.photoFile);
  messages = messages.filter((m) => m.id !== messageId);
  saveChatMessages(messages);
  return { ok: true };
}

// Run migration on load
migrateLegacy();

module.exports = {
  getUsers,
  saveUsers,
  findUser,
  upsertUser,
  deleteUser,
  loadAkses,
  saveAkses,
  loadUserSessions,
  saveUserSessions,
  loadChatMessages,
  loadChatMessagesHydrated,
  saveChatMessages,
  createChatMessage,
  deleteChatMessage,
  loadStatuses,
  saveStatuses,
  createStatus,
  deleteStatus,
  loadPendingInvites,
  savePendingInvites,
  saveMedia,
  readMediaBase64,
  deleteMedia,
  mediaPath,
  MEDIA_DIR,
  STATUS_TTL_MS,
};
