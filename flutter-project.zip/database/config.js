module.exports = {
  // isi token bot dari @BotFather
  tokens: "9273359881:9141145705:AAH7DQjbMWx2ThHWq4qbDIxhYU7FW-XwBQo", 
  
  // isi id telegram lu cek di @userinfobo
  owners: ["392836663"], 
  
// port panel ( sesuai addres panel ) 
  port: "4200", 
  
  // link panel http jangan pakai https
  ipvps: "http://felix-private.web.id" 
};
