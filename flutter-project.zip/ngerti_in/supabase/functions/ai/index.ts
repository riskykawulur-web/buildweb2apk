// Deploy: tempel di Supabase > Edge Functions > ai.  Secret wajib: GEMINI_API_KEY
// Opsional: GEMINI_MODEL_FREE (default gemini-2.5-flash-lite), GEMINI_MODEL_PREMIUM (default gemini-2.5-flash)
import { createClient } from "npm:@supabase/supabase-js@2";

const KEY = Deno.env.get("GEMINI_API_KEY")!;
const MODEL_FREE = Deno.env.get("GEMINI_MODEL_FREE") ?? "gemini-2.5-flash-lite";
const MODEL_PREMIUM = Deno.env.get("GEMINI_MODEL_PREMIUM") ?? "gemini-2.5-flash";
const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const LIMITS: Record<string, number> = { process: 10, followup: 10 };
const LANGS: Record<string, string> = {
  id: "Bahasa Indonesia", ms: "Bahasa Melayu", en: "English", ar: "Arabic", zh: "Simplified Chinese", tr: "Turkish",
};
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const out = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

class HttpError extends Error {
  constructor(public status: number, msg: string, public extra: Record<string, unknown> = {}) { super(msg); }
}
// Hari kuota mengikuti WIB, reset pukul 00:00.
const wib = (back = 0) => new Date(Date.now() + 7 * 3600e3 - back * 86400e3).toISOString().slice(0, 10);
const langRule = (l: string) =>
  `\nTulis semua teks yang ditujukan ke siswa dalam bahasa: ${LANGS[l] ?? LANGS.id}. Rumus matematika ditulis dengan LaTeX: gunakan tanda dolar tunggal untuk inline dan dua tanda dolar untuk blok.`;

const TUTOR_SYS = `Kamu adalah Ngerti.in, tutor AI yang sabar untuk pelajar (SD sampai mahasiswa, semua mata pelajaran).
1. Nilai apakah input adalah soal/teks pelajaran. Jika bukan (foto wajah, meme, pemandangan, dll) set is_question=false.
2. Jika input berupa foto, tulis ulang teks soal ke extracted_text dalam Markdown (rumus dalam LaTeX).
3. Hitung jawaban akhir dengan teliti untuk final_answer (ringkas).
4. Tulis penjelasan yang MENGAJAR, bukan memberi jawaban. ATURAN KERAS: explanation dan steps TIDAK BOLEH memuat jawaban akhir atau hasil perhitungan terakhir.
5. Urutan: penjelasan konsep dasar, lalu langkah-langkah, lalu satu pertanyaan pemantik di akhir.
Balas HANYA JSON: {"is_question":boolean,"title":"maks 6 kata","extracted_text":"","final_answer":"","explanation":"","steps":[""],"question_for_student":""}`;

const SUMMARY_SYS = `Kamu Ngerti.in. Rangkum materi (topik, catatan foto, video, atau artikel) untuk pelajar agar mudah dipahami.
Jika input berupa foto yang BUKAN materi/teks pelajaran, set valid=false. Untuk foto, tulis ulang isi catatan ke extracted_text (Markdown).
Untuk topik singkat, jelaskan konsep intinya dengan contoh.
Balas HANYA JSON: {"valid":boolean,"title":"","extracted_text":"","paragraph":"1-3 paragraf mudah dibaca","points":["4-8 poin penting"]}`;

const QUIZ_SYS = `Kamu Ngerti.in. Buat kuis pilihan ganda tepat 4 soal dari materi yang diberikan.
Jika input berupa foto yang BUKAN materi/teks pelajaran, set valid=false. Untuk foto, tulis ulang isi catatan ke extracted_text.
Tiap soal punya 4 opsi (tanpa awalan huruf A-D), pengecoh masuk akal, posisi jawaban benar bervariasi. hint adalah petunjuk yang mengarahkan tanpa menyebut jawabannya.
Balas HANYA JSON: {"valid":boolean,"title":"","extracted_text":"","questions":[{"q":"","options":["","","",""],"answer":0,"hint":"","explanation":""}]}`;

const JUDGE_SYS = `Kamu menilai jawaban siswa terhadap kunci jawaban. Anggap benar jika setara secara matematis/makna (format, satuan, urutan boleh berbeda).
Feedback maksimal 2 kalimat, ramah. Jika salah, JANGAN menyebut kunci jawaban.
Balas HANYA JSON: {"correct":boolean,"feedback":""}`;

const HINT_SYS = `Kamu tutor Ngerti.in. Siswa sudah salah 3 kali atau lebih. Berikan satu petunjuk spesifik yang sangat mengarahkan ke jawaban akhir, tetapi jangan menuliskan jawaban akhirnya secara langsung. Maksimal 3 kalimat.`;
const CHAT_SYS = `Kamu Ngerti.in, tutor AI. Jawab pertanyaan lanjutan siswa dengan jelas dan ringkas. Dorong siswa memahami, bukan menyalin.`;

async function gemini(model: string, contents: unknown[], system: string, json = true) {
  const body = JSON.stringify({
    systemInstruction: { parts: [{ text: system }] },
    contents,
    generationConfig: {
      temperature: 0.4,
      responseMimeType: json ? "application/json" : "text/plain",
      thinkingConfig: { thinkingBudget: 1024 },
    },
  });
  let last = "";
  for (let i = 0; i < 2; i++) {
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": KEY },
      signal: AbortSignal.timeout(55000),
      body,
    });
    if (r.ok) {
      const d = await r.json();
      const t: string = d.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "";
      if (!t) throw new Error("gemini kosong");
      return json ? JSON.parse(t) : t.trim();
    }
    last = `gemini ${r.status}: ${await r.text()}`;
    if (r.status !== 429 && r.status !== 503) break;
    await new Promise((res) => setTimeout(res, 1200));
  }
  throw new Error(last);
}

async function isPremium(uid: string) {
  const { data } = await admin.from("profiles").select("is_premium,premium_until").eq("id", uid).maybeSingle();
  return !!data?.is_premium && (!data.premium_until || new Date(data.premium_until) > new Date());
}
const modelFor = (premium: boolean) => (premium ? MODEL_PREMIUM : MODEL_FREE);

async function charge(uid: string, premium: boolean, kind: string) {
  if (premium) return false;
  const { data, error } = await admin.rpc("consume_quota", { p_user: uid, p_kind: kind, p_limit: LIMITS[kind], p_day: wib() });
  if (error) throw new HttpError(500, "Gagal memeriksa kuota.");
  if (!data) throw new HttpError(429, "Kuota harian habis.", { kind });
  return true;
}
const refund = (uid: string, kind: string) => admin.rpc("refund_quota", { p_user: uid, p_kind: kind, p_day: wib() });

async function touchStreak(uid: string) {
  const { data: p } = await admin.from("profiles").select("streak,last_study_date").eq("id", uid).maybeSingle();
  if (!p || p.last_study_date === wib()) return;
  await admin.from("profiles").update({ streak: p.last_study_date === wib(1) ? p.streak + 1 : 1, last_study_date: wib() }).eq("id", uid);
}
async function addScore(uid: string, correct: boolean) {
  const { data: p } = await admin.from("profiles").select("answers_total,answers_correct").eq("id", uid).maybeSingle();
  if (p) await admin.from("profiles").update({ answers_total: p.answers_total + 1, answers_correct: p.answers_correct + (correct ? 1 : 0) }).eq("id", uid);
}

async function loadSession(uid: string, id: string) {
  const { data } = await admin.from("sessions").select("*").eq("id", id).eq("user_id", uid).maybeSingle();
  if (!data) throw new HttpError(404, "Sesi tidak ditemukan.");
  return data;
}
async function secretOf(id: string) {
  const { data } = await admin.from("session_secrets").select("final_answer,quiz_key").eq("session_id", id).maybeSingle();
  return data ?? { final_answer: null, quiz_key: null };
}
const COLS = "id,type,kind,title,source,messages,attempts,solved,quiz,quiz_answers,created_at";

// ---------- input helpers ----------
function parseYoutube(raw: unknown): string {
  const m = String(raw ?? "").trim().match(/^https?:\/\/(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/);
  if (!m) throw new HttpError(400, "Link YouTube tidak valid.");
  return `https://www.youtube.com/watch?v=${m[1]}`;
}

function normalizeWebUrl(raw: unknown): string {
  let u: URL;
  try { u = new URL(String(raw ?? "").trim()); } catch { throw new HttpError(400, "Link artikel tidak valid."); }
  const h = u.hostname.toLowerCase();
  const bad = !/^https?:$/.test(u.protocol) || (u.port !== "" && u.port !== "80" && u.port !== "443") ||
    h === "localhost" || h.endsWith(".local") || h.endsWith(".internal") || h.includes(":") || !h.includes(".") ||
    /^(0|10|127)\./.test(h) || /^169\.254\./.test(h) || /^192\.168\./.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h);
  if (bad) throw new HttpError(400, "Link artikel tidak valid.");
  return u.toString();
}

function htmlToText(html: string) {
  return html
    .replace(/<(script|style|noscript|svg|nav|footer|header|form|iframe)[\s\S]*?<\/\1>/gi, " ")
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<(br|\/p|\/div|\/li|\/h[1-6])\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim();
}

async function fetchPage(url: string): Promise<string> {
  let r: Response;
  try {
    r = await fetch(url, {
      redirect: "follow",
      signal: AbortSignal.timeout(10000),
      headers: { "User-Agent": "Mozilla/5.0 (compatible; NgertiBot/1.0)", Accept: "text/html,text/plain" },
    });
  } catch { throw new HttpError(422, "Halaman tidak bisa dibuka."); }
  if (!r.ok) throw new HttpError(422, "Halaman tidak bisa dibuka.");
  const ct = r.headers.get("content-type") ?? "";
  if (!ct.includes("text/html") && !ct.includes("text/plain")) throw new HttpError(422, "Link ini bukan artikel teks.");
  const text = htmlToText((await r.text()).slice(0, 1_500_000)).slice(0, 30000);
  if (text.length < 300) throw new HttpError(422, "Isi artikel tidak terbaca (mungkin butuh login atau memakai JavaScript).");
  return text;
}

function cleanQuiz(qs: any): { q: string; options: string[]; answer: number; hint: string; explanation: string }[] {
  if (!Array.isArray(qs)) return [];
  return qs
    .filter((x) => x && typeof x.q === "string" && Array.isArray(x.options) && x.options.length === 4 && Number.isInteger(x.answer) && x.answer >= 0 && x.answer <= 3)
    .slice(0, 4)
    .map((x) => ({ q: x.q, options: x.options.map(String), answer: x.answer, hint: String(x.hint ?? ""), explanation: String(x.explanation ?? "") }));
}

function groundParts(s: any): unknown[] {
  if (s.kind === "youtube") return [{ fileData: { fileUri: s.source } }, { text: "Ini video yang kita bahas." }];
  return [{ text: s.context ? `Materi/soal:\n${s.context}` : `Topik/soal: ${s.source ?? ""}` }];
}

// ---------- actions ----------
async function create(uid: string, premium: boolean, b: any) {
  const source = String(b.source), mode = String(b.mode);
  const lang = LANGS[b.lang] ? b.lang : "id";
  if (!["photo", "text", "topic", "youtube", "web"].includes(source) || !["tutor", "summary", "quiz"].includes(mode)) throw new HttpError(400, "Permintaan tidak valid.");
  if (mode === "tutor" && !["photo", "text"].includes(source)) throw new HttpError(400, "Permintaan tidak valid.");
  const text = String(b.text ?? "").trim().slice(0, 4000);
  const img: string | undefined = b.image_base64 || undefined;
  let url = "", context = "";
  const parts: unknown[] = [];

  if (source === "photo") {
    if (!img) throw new HttpError(400, "Kirim foto dulu.");
    if (img.length > 8_000_000) throw new HttpError(413, "Gambar terlalu besar.");
    parts.push({ inlineData: { mimeType: b.mime || "image/jpeg", data: img } }, { text: text ? `Konteks tambahan siswa: ${text}` : "Input ada pada gambar." });
  } else if (source === "text" || source === "topic") {
    if (!text) throw new HttpError(400, "Tulis dulu isinya.");
    context = text;
    parts.push({ text: source === "topic" ? `Topik: ${text}` : `Soal dari siswa:\n${text}` });
  } else if (source === "youtube") {
    url = parseYoutube(b.url);
    parts.push({ fileData: { fileUri: url } }, { text: "Proses video ini." });
  } else {
    url = normalizeWebUrl(b.url);
    context = await fetchPage(url);
    parts.push({ text: `Artikel dari ${url}:\n${context}` });
  }

  const charged = await charge(uid, premium, "process");
  try {
    const sys = (mode === "tutor" ? TUTOR_SYS : mode === "summary" ? SUMMARY_SYS : QUIZ_SYS) +
      (b.force ? "\nSiswa menegaskan input ini valid. Set valid/is_question=true." : "") + langRule(lang);
    const r = await gemini(modelFor(premium), [{ role: "user", parts }], sys);
    const ok = mode === "tutor" ? r.is_question === true : r.valid !== false;
    if (!ok) {
      if (charged) await refund(uid, "process");
      return { rejected: true };
    }
    if (source === "photo") context = String(r.extracted_text ?? "").slice(0, 8000);

    let messages: unknown[], quiz: unknown = null, quizKey: unknown = null, finalAnswer: string | null = null;
    if (mode === "tutor") {
      const steps = (r.steps ?? []).map((s: string, i: number) => `${i + 1}. ${s}`).join("\n");
      messages = [{ role: "ai", text: `${r.explanation}\n\n**Langkah**\n${steps}\n\n**${r.question_for_student}**` }];
      finalAnswer = String(r.final_answer ?? "");
    } else if (mode === "summary") {
      const points = (r.points ?? []).map((p: string) => `- ${p}`).join("\n");
      messages = [{ role: "ai", text: `${r.paragraph}\n\n${points}` }];
    } else {
      const qs = cleanQuiz(r.questions);
      if (!qs.length) throw new Error("kuis kosong");
      quiz = qs.map(({ q, options }) => ({ q, options }));
      quizKey = qs.map(({ answer, hint, explanation }) => ({ answer, hint, explanation }));
      messages = [{ role: "ai", text: `**${r.title ?? ""}**` }];
    }

    const { data: s, error } = await admin.from("sessions").insert({
      user_id: uid, type: mode === "tutor" ? "solve" : "material", kind: source, title: r.title || "Ngerti.in",
      source: url || (source === "photo" ? null : text), context: context || null, messages, quiz,
    }).select(COLS).single();
    if (error) throw error;
    if (finalAnswer !== null || quizKey) await admin.from("session_secrets").insert({ session_id: s.id, final_answer: finalAnswer, quiz_key: quizKey });
    await touchStreak(uid);
    return { session: s };
  } catch (e) {
    if (charged) await refund(uid, "process");
    if (e instanceof HttpError) throw e;
    if (source === "youtube") throw new HttpError(422, "Video tidak bisa diproses (mungkin privat, dibatasi umur, atau terlalu panjang).");
    throw e;
  }
}

async function solveAnswer(uid: string, premium: boolean, b: any) {
  const s = await loadSession(uid, b.session_id);
  if (s.type !== "solve") throw new HttpError(400, "Bukan sesi soal.");
  if (s.solved) throw new HttpError(400, "Soal ini sudah terjawab.");
  if (s.attempts >= 20) throw new HttpError(400, "Batas percobaan tercapai, gunakan Tanya lanjut.");
  const ans = String(b.answer ?? "").trim().slice(0, 2000);
  if (!ans) throw new HttpError(400, "Jawaban kosong.");
  const lang = LANGS[b.lang] ? b.lang : "id";
  const key = (await secretOf(s.id)).final_answer ?? "";
  const ctx = `Soal: ${s.context ?? s.source ?? ""}\nPenjelasan tutor: ${s.messages[0]?.text ?? ""}\nKunci jawaban: ${key}\nJawaban siswa: ${ans}`;
  const m = modelFor(premium);
  const j = await gemini(m, [{ role: "user", parts: [{ text: ctx }] }], JUDGE_SYS + langRule(lang));
  const attempts = s.attempts + 1;
  const solved = !!j.correct;
  let t: string;
  if (solved) t = `${j.feedback}\n\n**${key}**`;
  else if (attempts >= 3) {
    const hint = await gemini(m, [{ role: "user", parts: [{ text: ctx }] }], HINT_SYS + langRule(lang), false);
    t = `${j.feedback}\n\n${hint}`;
  } else t = String(j.feedback);
  const ai = [{ role: "ai", text: t, tag: solved ? "correct" : attempts >= 3 ? "hint" : "wrong" }];
  await admin.from("sessions").update({ messages: [...s.messages, { role: "user", text: ans }, ...ai], attempts, solved }).eq("id", s.id);
  await addScore(uid, solved);
  await touchStreak(uid);
  return { ai, solved, attempts };
}

async function chat(uid: string, premium: boolean, b: any) {
  const s = await loadSession(uid, b.session_id);
  const msg = String(b.message ?? "").trim().slice(0, 2000);
  if (!msg) throw new HttpError(400, "Pesan kosong.");
  const lang = LANGS[b.lang] ? b.lang : "id";
  const charged = await charge(uid, premium, "followup");
  try {
    const hist = (s.messages as { role: string; text: string }[]).slice(-20)
      .map((m) => ({ role: m.role === "ai" ? "model" : "user", parts: [{ text: m.text }] }));
    let sys = CHAT_SYS;
    if (s.type === "solve") {
      const key = (await secretOf(s.id)).final_answer ?? "";
      sys += s.solved ? `\nSiswa sudah menjawab benar; jawaban akhir: ${key}. Boleh dibahas.` : `\nKunci jawaban (RAHASIA, jangan disebut atau diselesaikan tuntas untuk siswa): ${key}`;
    }
    const reply = await gemini(modelFor(premium), [{ role: "user", parts: groundParts(s) }, ...hist, { role: "user", parts: [{ text: msg }] }], sys + langRule(lang), false);
    await admin.from("sessions").update({ messages: [...s.messages, { role: "user", text: msg }, { role: "ai", text: reply }] }).eq("id", s.id);
    await touchStreak(uid);
    return { reply };
  } catch (e) {
    if (charged) await refund(uid, "followup");
    throw e;
  }
}

async function quizMake(uid: string, premium: boolean, b: any) {
  const s = await loadSession(uid, b.session_id);
  if (s.type !== "material") throw new HttpError(400, "Kuis hanya untuk materi.");
  if (s.quiz) return { quiz: s.quiz, quiz_answers: s.quiz_answers };
  const lang = LANGS[b.lang] ? b.lang : "id";
  const charged = await charge(uid, premium, "followup");
  try {
    const r = await gemini(modelFor(premium), [{ role: "user", parts: [...groundParts(s), { text: "Buat kuis dari materi ini." }] }], QUIZ_SYS + langRule(lang));
    const qs = cleanQuiz(r.questions);
    if (!qs.length) throw new Error("kuis kosong");
    const quiz = qs.map(({ q, options }) => ({ q, options }));
    await admin.from("sessions").update({ quiz, quiz_answers: [] }).eq("id", s.id);
    await admin.from("session_secrets").upsert({ session_id: s.id, quiz_key: qs.map(({ answer, hint, explanation }) => ({ answer, hint, explanation })) }, { onConflict: "session_id" });
    return { quiz, quiz_answers: [] };
  } catch (e) {
    if (charged) await refund(uid, "followup");
    throw e;
  }
}

async function quizCheck(uid: string, b: any) {
  const s = await loadSession(uid, b.session_id);
  const idx = Number(b.index), choice = Number(b.choice);
  if (!Array.isArray(s.quiz) || !Number.isInteger(idx) || idx < 0 || idx >= s.quiz.length || !Number.isInteger(choice) || choice < 0 || choice > 3) throw new HttpError(400, "Permintaan tidak valid.");
  const answers: any[] = Array.isArray(s.quiz_answers) ? [...s.quiz_answers] : [];
  while (answers.length < s.quiz.length) answers.push(null);
  if (answers[idx]) return answers[idx];
  const k = (await secretOf(s.id)).quiz_key?.[idx];
  if (!k) throw new HttpError(500, "Kunci kuis tidak ditemukan.");
  const res = { choice, correct: choice === k.answer, answer: k.answer, explanation: k.explanation ?? "" };
  answers[idx] = res;
  await admin.from("sessions").update({ quiz_answers: answers }).eq("id", s.id);
  await addScore(uid, res.correct);
  await touchStreak(uid);
  return res;
}

async function quizHint(uid: string, premium: boolean, b: any) {
  const s = await loadSession(uid, b.session_id);
  const idx = Number(b.index);
  if (!Array.isArray(s.quiz) || !Number.isInteger(idx) || idx < 0 || idx >= s.quiz.length) throw new HttpError(400, "Permintaan tidak valid.");
  const k = (await secretOf(s.id)).quiz_key?.[idx];
  if (!k) throw new HttpError(500, "Petunjuk tidak ditemukan.");
  await charge(uid, premium, "followup");
  return { hint: k.hint };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const token = (req.headers.get("Authorization") ?? "").replace("Bearer ", "");
    const { data: { user }, error } = await admin.auth.getUser(token);
    if (error || !user) throw new HttpError(401, "Silakan masuk lagi.");
    const b = await req.json();
    const premium = await isPremium(user.id);
    switch (b.action) {
      case "create": return out(await create(user.id, premium, b));
      case "solve_answer": return out(await solveAnswer(user.id, premium, b));
      case "chat": return out(await chat(user.id, premium, b));
      case "quiz_make": return out(await quizMake(user.id, premium, b));
      case "quiz_check": return out(await quizCheck(user.id, b));
      case "quiz_hint": return out(await quizHint(user.id, premium, b));
      default: throw new HttpError(400, "Aksi tidak dikenal.");
    }
  } catch (e) {
    if (e instanceof HttpError) return out({ error: e.status === 429 ? "quota" : e.message, ...e.extra }, e.status);
    console.error(e);
    return out({ error: "Layanan AI sedang sibuk, coba lagi sebentar." }, 500);
  }
});
