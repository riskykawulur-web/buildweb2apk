// Dipanggil payment gateway (atau server kamu) setelah pembayaran sukses.
// Deploy: supabase functions deploy premium-webhook --no-verify-jwt
// Body: { "user_id": "<uuid>", "days": 30 }  Header: x-webhook-secret
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.headers.get("x-webhook-secret") !== Deno.env.get("WEBHOOK_SECRET")) {
    return new Response("forbidden", { status: 403 });
  }
  const { user_id, days } = await req.json();
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: p } = await admin.from("profiles").select("premium_until").eq("id", user_id).single();
  const base = p?.premium_until && new Date(p.premium_until) > new Date() ? new Date(p.premium_until) : new Date();
  base.setDate(base.getDate() + Number(days));
  await admin.from("profiles").update({ is_premium: true, premium_until: base.toISOString() }).eq("id", user_id);
  return new Response("ok");
});
