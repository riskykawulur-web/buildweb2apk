-- Versi 3. Aman dijalankan di project baru MAUPUN project yang sudah pernah menjalankan versi lama.
create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  display_name text,
  is_premium boolean not null default false,
  premium_until timestamptz,
  streak int not null default 0,
  last_study_date date,
  answers_total int not null default 0,
  answers_correct int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.usage_daily (
  user_id uuid not null references auth.users on delete cascade,
  day date not null,
  kind text not null,
  count int not null default 0,
  primary key (user_id, day, kind)
);

create table if not exists public.sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  type text not null,
  title text not null default '',
  source text,
  image_path text,
  messages jsonb not null default '[]',
  attempts int not null default 0,
  solved boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists sessions_user_created on public.sessions (user_id, created_at desc);

alter table public.sessions add column if not exists kind text;
alter table public.sessions add column if not exists context text;
alter table public.sessions add column if not exists quiz jsonb;
alter table public.sessions add column if not exists quiz_answers jsonb not null default '[]';
alter table public.sessions drop constraint if exists sessions_type_check;
update public.sessions set type = 'material', kind = 'youtube' where type = 'video';
alter table public.sessions add constraint sessions_type_check check (type in ('solve', 'material'));

-- Kunci jawaban & kunci kuis: tanpa policy select, hanya edge function (service role) yang bisa baca.
create table if not exists public.session_secrets (
  session_id uuid primary key references public.sessions on delete cascade,
  final_answer text
);
alter table public.session_secrets alter column final_answer drop not null;
alter table public.session_secrets add column if not exists quiz_key jsonb;

create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete set null,
  message text not null check (char_length(message) between 1 and 2000),
  app_version text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.usage_daily enable row level security;
alter table public.sessions enable row level security;
alter table public.session_secrets enable row level security;
alter table public.feedback enable row level security;

drop policy if exists "profil sendiri" on public.profiles;
create policy "profil sendiri" on public.profiles for select using (auth.uid() = id);
drop policy if exists "kuota sendiri" on public.usage_daily;
create policy "kuota sendiri" on public.usage_daily for select using (auth.uid() = user_id);
drop policy if exists "sesi sendiri baca" on public.sessions;
create policy "sesi sendiri baca" on public.sessions for select using (auth.uid() = user_id);
drop policy if exists "sesi sendiri hapus" on public.sessions;
create policy "sesi sendiri hapus" on public.sessions for delete using (auth.uid() = user_id);
drop policy if exists "kirim masukan" on public.feedback;
create policy "kirim masukan" on public.feedback for insert with check (auth.uid() = user_id);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)))
  on conflict do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.consume_quota(p_user uuid, p_kind text, p_limit int, p_day date)
returns boolean language plpgsql security definer set search_path = public as $$
declare c int;
begin
  insert into usage_daily (user_id, day, kind, count) values (p_user, p_day, p_kind, 0)
  on conflict do nothing;
  update usage_daily set count = count + 1
  where user_id = p_user and day = p_day and kind = p_kind and count < p_limit
  returning count into c;
  return c is not null;
end $$;

create or replace function public.refund_quota(p_user uuid, p_kind text, p_day date)
returns void language sql security definer set search_path = public as $$
  update usage_daily set count = greatest(count - 1, 0)
  where user_id = p_user and day = p_day and kind = p_kind;
$$;

revoke execute on function public.consume_quota(uuid, text, int, date) from public, anon, authenticated;
revoke execute on function public.refund_quota(uuid, text, date) from public, anon, authenticated;
