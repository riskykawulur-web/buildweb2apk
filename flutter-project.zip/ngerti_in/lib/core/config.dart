/// Isi lewat --dart-define saat run/build (lihat README).
class Config {
  static const appVersion = '1.0.0';
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  static const googleWebClientId = String.fromEnvironment('GOOGLE_WEB_CLIENT_ID');
  static const googleIosClientId = String.fromEnvironment('GOOGLE_IOS_CLIENT_ID');
  static const checkoutMonthly = String.fromEnvironment('CHECKOUT_MONTHLY_URL');
  static const checkoutYearly = String.fromEnvironment('CHECKOUT_YEARLY_URL');
  // Kosong = pakai iklan TES milik Google (aman untuk uji coba).
  static const bannerUnit = String.fromEnvironment('ADMOB_BANNER_UNIT');
  static const interUnit = String.fromEnvironment('ADMOB_INTERSTITIAL_UNIT');
}
