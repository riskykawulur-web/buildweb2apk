import 'package:flutter/material.dart';

@immutable
class AppColors extends ThemeExtension<AppColors> {
  final Color bg, ink, onInk, muted, line, soft, disabled;
  const AppColors({
    required this.bg,
    required this.ink,
    required this.onInk,
    required this.muted,
    required this.line,
    required this.soft,
    required this.disabled,
  });

  static const light = AppColors(
    bg: Color(0xFFFFFFFF),
    ink: Color(0xFF000000),
    onInk: Color(0xFFFFFFFF),
    muted: Color(0xFF6B6B6B),
    line: Color(0xFFDADADA),
    soft: Color(0xFFF4F4F4),
    disabled: Color(0xFFD0D0D0),
  );
  static const dark = AppColors(
    bg: Color(0xFF000000),
    ink: Color(0xFFFFFFFF),
    onInk: Color(0xFF000000),
    muted: Color(0xFF9B9B9B),
    line: Color(0xFF2C2C2C),
    soft: Color(0xFF151515),
    disabled: Color(0xFF3A3A3A),
  );

  @override
  AppColors copyWith({Color? bg, Color? ink, Color? onInk, Color? muted, Color? line, Color? soft, Color? disabled}) => AppColors(
        bg: bg ?? this.bg,
        ink: ink ?? this.ink,
        onInk: onInk ?? this.onInk,
        muted: muted ?? this.muted,
        line: line ?? this.line,
        soft: soft ?? this.soft,
        disabled: disabled ?? this.disabled,
      );

  @override
  AppColors lerp(ThemeExtension<AppColors>? other, double t) => other is AppColors ? (t < .5 ? this : other) : this;
}

extension AppCtx on BuildContext {
  AppColors get c => Theme.of(this).extension<AppColors>()!;
}

ThemeData buildTheme(Brightness b) {
  final k = b == Brightness.dark ? AppColors.dark : AppColors.light;
  final scheme = ColorScheme(
    brightness: b,
    primary: k.ink,
    onPrimary: k.onInk,
    secondary: k.ink,
    onSecondary: k.onInk,
    error: const Color(0xFFB3261E),
    onError: Colors.white,
    surface: k.bg,
    onSurface: k.ink,
  );
  OutlineInputBorder ob(Color col, [double w = 1]) =>
      OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: col, width: w));
  return ThemeData(
    useMaterial3: true,
    brightness: b,
    colorScheme: scheme,
    scaffoldBackgroundColor: k.bg,
    extensions: [k],
    appBarTheme: AppBarTheme(
      backgroundColor: k.bg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      foregroundColor: k.ink,
      centerTitle: false,
      titleTextStyle: TextStyle(color: k.ink, fontSize: 18, fontWeight: FontWeight.w700),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: k.soft,
      hintStyle: TextStyle(color: k.muted),
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      border: ob(k.line),
      enabledBorder: ob(k.line),
      focusedBorder: ob(k.ink, 1.6),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: k.ink,
        foregroundColor: k.onInk,
        disabledBackgroundColor: k.disabled,
        disabledForegroundColor: k.muted,
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: k.ink,
        minimumSize: const Size.fromHeight(52),
        side: BorderSide(color: k.ink, width: 1.4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
      ),
    ),
    textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: k.ink)),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: k.bg,
      surfaceTintColor: Colors.transparent,
      indicatorColor: k.soft,
      labelTextStyle: WidgetStateProperty.all(TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: k.ink)),
      iconTheme: WidgetStateProperty.all(IconThemeData(color: k.ink)),
    ),
    dividerTheme: DividerThemeData(color: k.line),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: k.ink,
      contentTextStyle: TextStyle(color: k.onInk),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
