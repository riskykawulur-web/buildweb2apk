import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import '../widgets/common.dart';
import 'l10n.dart';

/// Ambil foto (kamera/galeri), lalu potong & putar. Mengembalikan byte JPEG atau null.
Future<Uint8List?> pickAndCrop(BuildContext context, ImageSource src) async {
  final title = context.tr('crop_title');
  final fail = context.tr('cam_fail');
  try {
    final x = await ImagePicker().pickImage(source: src, maxWidth: 1800, imageQuality: 85);
    if (x == null) return null;
    final c = await ImageCropper().cropImage(
      sourcePath: x.path,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: title,
          toolbarColor: Colors.black,
          toolbarWidgetColor: Colors.white,
          activeControlsWidgetColor: Colors.black,
          lockAspectRatio: false,
          hideBottomControls: false,
        ),
        IOSUiSettings(title: title, rotateButtonsHidden: false, rotateClockwiseButtonHidden: false),
      ],
    );
    return await File(c?.path ?? x.path).readAsBytes();
  } catch (_) {
    if (context.mounted) snack(context, fail);
    return null;
  }
}
