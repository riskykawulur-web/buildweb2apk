import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'l10n.dart';

typedef Json = Map<String, dynamic>;

class QuotaException implements Exception {}

class ApiException implements Exception {
  final String message; // '__offline' = tidak ada koneksi
  ApiException(this.message);
  String text(BuildContext c) => message == '__offline' ? c.tr('no_internet') : message;
}

class Api {
  static SupabaseClient get sb => Supabase.instance.client;
  static String? get uid => sb.auth.currentUser?.id;

  static const limits = {'process': 10, 'followup': 10};
  static bool offline = false;

  /// Hari kuota (WIB), cocok dengan reset pukul 00:00 di server.
  static String today() => DateTime.now().toUtc().add(const Duration(hours: 7)).toIso8601String().substring(0, 10);

  static Future<Json> _call(Json body) async {
    body['lang'] = AppState.lang.value;
    try {
      final res = await sb.functions.invoke('ai', body: body);
      return Json.from(res.data as Map);
    } on FunctionException catch (e) {
      final d = e.details;
      final m = d is Map ? d : <String, dynamic>{};
      if (e.status == 429) throw QuotaException();
      throw ApiException('${m['error'] ?? 'Terjadi kesalahan, coba lagi.'}');
    } catch (_) {
      throw ApiException('__offline');
    }
  }

  /// source: photo|text|topic|youtube|web   mode: tutor|summary|quiz
  static Future<Json> create({required String source, required String mode, String? text, String? url, Uint8List? image, bool force = false}) =>
      _call({
        'action': 'create',
        'source': source,
        'mode': mode,
        'text': text,
        'url': url,
        'image_base64': image == null ? null : base64Encode(image),
        'mime': 'image/jpeg',
        'force': force,
      });

  static Future<Json> solveAnswer(String id, String answer) => _call({'action': 'solve_answer', 'session_id': id, 'answer': answer});
  static Future<Json> chat(String id, String message) => _call({'action': 'chat', 'session_id': id, 'message': message});
  static Future<Json> quizMake(String id) => _call({'action': 'quiz_make', 'session_id': id});
  static Future<Json> quizCheck(String id, int index, int choice) => _call({'action': 'quiz_check', 'session_id': id, 'index': index, 'choice': choice});
  static Future<Json> quizHint(String id, int index) => _call({'action': 'quiz_hint', 'session_id': id, 'index': index});

  /// Riwayat; jika offline memakai cache terakhir.
  static Future<List<Json>> sessions() async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'history_$uid';
    try {
      final rows = await sb
          .from('sessions')
          .select('id,type,kind,title,source,messages,attempts,solved,quiz,quiz_answers,created_at')
          .order('created_at', ascending: false)
          .limit(200);
      await prefs.setString(key, jsonEncode(rows));
      offline = false;
      return List<Json>.from(rows);
    } catch (_) {
      offline = true;
      final raw = prefs.getString(key);
      if (raw == null) return [];
      return List<Json>.from(jsonDecode(raw));
    }
  }

  static Future<void> deleteSession(String id) => sb.from('sessions').delete().eq('id', id);

  static Future<void> sendFeedback(String message) =>
      sb.from('feedback').insert({'user_id': uid, 'message': message, 'app_version': Config.appVersion});

  static Future<Json?> profile() async {
    try {
      final p = await sb.from('profiles').select().eq('id', uid!).maybeSingle();
      AppState.premium.value = isPremium(p);
      return p;
    } catch (_) {
      return null;
    }
  }

  static bool isPremium(Json? p) {
    if (p == null || p['is_premium'] != true) return false;
    final until = p['premium_until'];
    return until == null || DateTime.parse(until).isAfter(DateTime.now());
  }

  static Future<Map<String, int>> usage() async {
    try {
      final rows = await sb.from('usage_daily').select('kind,count').eq('day', today());
      return {for (final r in rows) r['kind'] as String: r['count'] as int};
    } catch (_) {
      return {};
    }
  }

  static int effectiveStreak(Json? p) {
    if (p == null || p['last_study_date'] == null) return 0;
    final last = DateTime.parse(p['last_study_date']);
    final t = DateTime.parse(today());
    return t.difference(last).inDays <= 1 ? (p['streak'] as int) : 0;
  }
}
