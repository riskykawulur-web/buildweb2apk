import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'config.dart';
import 'l10n.dart';

/// Iklan hanya untuk pengguna gratis. ID kosong = iklan tes Google.
class Ads {
  static bool _ready = false;
  static int _count = 0;
  static InterstitialAd? _inter;

  static Future<void> init() async {
    if (!(Platform.isAndroid || Platform.isIOS)) return;
    try {
      await MobileAds.instance.initialize();
      await MobileAds.instance.updateRequestConfiguration(RequestConfiguration(maxAdContentRating: MaxAdContentRating.g));
      _ready = true;
      _loadInter();
    } catch (_) {}
  }

  static String get bannerId => Config.bannerUnit.isNotEmpty
      ? Config.bannerUnit
      : (Platform.isAndroid ? 'ca-app-pub-3940256099942544/6300978111' : 'ca-app-pub-3940256099942544/2934735716');
  static String get interId => Config.interUnit.isNotEmpty
      ? Config.interUnit
      : (Platform.isAndroid ? 'ca-app-pub-3940256099942544/1033173712' : 'ca-app-pub-3940256099942544/4411468910');

  static void _loadInter() {
    InterstitialAd.load(
      adUnitId: interId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(onAdLoaded: (a) => _inter = a, onAdFailedToLoad: (_) => _inter = null),
    );
  }

  /// Panggil setelah materi baru berhasil diproses. Tampil tiap 3x untuk pengguna gratis.
  static void afterProcess() {
    if (!_ready || AppState.premium.value) return;
    _count++;
    if (_count % 3 == 0 && _inter != null) {
      final a = _inter!;
      _inter = null;
      a.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (x) {
          x.dispose();
          _loadInter();
        },
        onAdFailedToShowFullScreenContent: (x, e) {
          x.dispose();
          _loadInter();
        },
      );
      a.show();
    }
  }
}

class BannerSlot extends StatefulWidget {
  const BannerSlot({super.key});
  @override
  State<BannerSlot> createState() => _BannerSlotState();
}

class _BannerSlotState extends State<BannerSlot> {
  BannerAd? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    if (Ads._ready) {
      _ad = BannerAd(
        adUnitId: Ads.bannerId,
        size: AdSize.banner,
        request: const AdRequest(),
        listener: BannerAdListener(
          onAdLoaded: (_) {
            if (mounted) setState(() => _loaded = true);
          },
          onAdFailedToLoad: (a, e) => a.dispose(),
        ),
      )..load();
    }
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<bool>(
        valueListenable: AppState.premium,
        builder: (_, premium, __) => (premium || !_loaded || _ad == null)
            ? const SizedBox.shrink()
            : Center(child: SizedBox(width: 320, height: 50, child: AdWidget(ad: _ad!))),
      );
}
