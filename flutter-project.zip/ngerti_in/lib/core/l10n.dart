import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Status global: bahasa, mode gelap, status premium.
class AppState {
  static final lang = ValueNotifier<String>('id');
  static final dark = ValueNotifier<bool>(false);
  static final premium = ValueNotifier<bool>(false);

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    lang.value = p.getString('lang') ?? 'id';
    dark.value = p.getBool('dark') ?? false;
  }

  static Future<void> setLang(String v) async {
    lang.value = v;
    (await SharedPreferences.getInstance()).setString('lang', v);
  }

  static Future<void> setDark(bool v) async {
    dark.value = v;
    (await SharedPreferences.getInstance()).setBool('dark', v);
  }
}

const languages = [
  ('id', 'Bahasa Indonesia'),
  ('ms', 'Bahasa Melayu'),
  ('en', 'English'),
  ('ar', 'العربية'),
  ('zh', '中文'),
  ('tr', 'Türkçe'),
];

class LangScope extends InheritedNotifier<ValueNotifier<String>> {
  const LangScope({super.key, required ValueNotifier<String> notifier, required super.child}) : super(notifier: notifier);
  static String of(BuildContext c) => c.dependOnInheritedWidgetOfExactType<LangScope>()?.notifier?.value ?? 'id';
}

extension Tr on BuildContext {
  /// Terjemahan. Urutan cadangan: bahasa pilihan, Inggris, Indonesia, lalu nama kuncinya.
  String tr(String key, [Map<String, String> args = const {}]) {
    final lang = LangScope.of(this);
    var s = _s[lang]?[key] ?? _s['en']![key] ?? _s['id']![key] ?? key;
    args.forEach((k, v) => s = s.replaceAll('{$k}', v));
    return s;
  }
}

const _s = <String, Map<String, String>>{
  'id': {
    'nav_home': 'Beranda', 'nav_tutor': 'Tutor', 'nav_profile': 'Profil', 'hello': 'Halo',
    'scan_title': 'Foto & Jawab', 'scan_sub': 'Foto soalmu, dapatkan penjelasan langkah demi langkah.',
    'ask_hint': 'Tanyakan Ngerti.in...', 'left': 'Sisa {n} proses',
    'm_quiz': 'Kuis', 'm_flash': 'Kartu Belajar', 'm_calc': 'Kalkulator', 'm_summary': 'Rangkuman', 'm_write': 'Asisten Menulis',
    'soon': 'Segera hadir', 'email': 'Email', 'password': 'Kata sandi', 'login': 'Masuk', 'register': 'Daftar',
    'no_acc': 'Belum punya akun? Daftar', 'has_acc': 'Sudah punya akun? Masuk', 'or': 'atau',
    'g_login': 'Lanjut dengan Google', 'a_login': 'Lanjut dengan Apple', 'tagline': 'Belajar sampai benar-benar ngerti.',
    'check_email': 'Cek emailmu untuk konfirmasi, lalu masuk.', 'auth_fail': 'Gagal masuk. Periksa data dan koneksimu.',
    'auth_input': 'Isi email valid dan kata sandi minimal 6 karakter.',
    'start_title': 'Mari kita mulai', 's_topic': 'Masukkan Topik', 's_scan': 'Pindai Catatan/Foto', 's_yt': 'Tautan YouTube',
    's_web': 'Impor dari Situs Web', 'topic_hint': 'Contoh: Fungsi Kuadrat', 'yt_hint': 'Tempel link YouTube',
    'web_hint': 'Tempel link artikel', 'paste': 'Tempel', 'process': 'Proses', 'working': 'Ngerti.in sedang memproses...',
    'camera': 'Kamera', 'gallery': 'Galeri', 'type_hint': 'Tulis soal di sini...', 'or_type': 'Atau ketik soalnya',
    'no_input': 'Foto atau ketik soalnya dulu ya.', 'send': 'Kirim', 'cam_fail': 'Tidak bisa membuka kamera/galeri. Cek izin aplikasi.',
    'crop_title': 'Potong & putar',
    'not_problem': 'Sepertinya ini bukan soal pelajaran. Yuk, coba foto ulang!',
    'not_material': 'Sepertinya ini bukan materi pelajaran. Yuk, coba foto ulang!',
    'retry_photo': 'Foto ulang', 'force_it': 'Tetap proses',
    'answer_mode': 'Jawab soal', 'ask_more': 'Tanya lanjut', 'type_answer': 'Ketik jawabanmu...',
    'ask_problem': 'Tanya soal ini...', 'ask_content': 'Tanya isi materi...', 'make_quiz': 'Buat kuis', 'quiz_making': 'Membuat kuis...',
    'quiz': 'Kuis', 'flashcard': 'Flashcard', 'tldr': 'TLDR', 'hint': 'Petunjuk', 'check': 'Periksa', 'next': 'Lanjut',
    'finish': 'Selesai', 'score': 'Skor', 'correct': 'Benar!', 'wrong': 'Belum tepat.',
    'history': 'Riwayat', 'no_history': 'Belum ada riwayat. Mulai dengan foto soal atau rangkum materi.',
    'offline_cache': 'Mode offline, menampilkan riwayat tersimpan',
    'stat_solved': 'Materi diproses', 'stat_streak': 'Streak hari', 'stat_acc': 'Akurasi',
    'upgrade': 'Upgrade ke Premium', 'premium_on': 'Kamu pengguna Premium', 'logout': 'Keluar', 'settings': 'Pengaturan',
    'dark_mode': 'Mode gelap', 'language': 'Bahasa', 'feedback': 'Masukan', 'version': 'Versi aplikasi',
    'feedback_hint': 'Tulis bug atau saranmu...', 'send_feedback': 'Kirim masukan', 'thanks': 'Terima kasih atas masukanmu!',
    'free': 'Gratis', 'premium': 'Premium', 'unlimited': 'Unlimited', 'per_day': '/ hari',
    'r_process': 'Proses materi baru', 'r_followup': 'Tanya AI', 'r_model': 'Kecerdasan AI', 'std': 'Standar', 'adv': 'Lanjutan',
    'r_ads': 'Iklan', 'yes': 'Ada', 'none': 'Tidak ada', 'monthly': 'Bulanan', 'yearly': 'Tahunan',
    'price_m': 'Rp 19.000 / bulan', 'price_y': 'Rp 149.000 / tahun (hemat ~34%)',
    'after_pay': 'Setelah pembayaran berhasil, tarik layar Profil ke bawah untuk memperbarui status.',
    'pay_missing': 'Pembayaran belum dikonfigurasi.',
    'quota_title': 'Kuota hari ini habis', 'quota_body': 'Kuota gratis direset setiap pukul 00:00. Upgrade ke Premium untuk akses tanpa batas.',
    'later': 'Nanti saja', 'see_premium': 'Lihat Premium', 'no_internet': 'Tidak ada koneksi internet',
  },
  'en': {
    'nav_home': 'Home', 'nav_tutor': 'Tutor', 'nav_profile': 'Profile', 'hello': 'Hi',
    'scan_title': 'Snap & Solve', 'scan_sub': 'Snap your question and get a step-by-step explanation.',
    'ask_hint': 'Ask Ngerti.in...', 'left': '{n} runs left',
    'm_quiz': 'Quiz', 'm_flash': 'Flashcards', 'm_calc': 'Calculator', 'm_summary': 'Summary', 'm_write': 'Writing Assistant',
    'soon': 'Coming soon', 'email': 'Email', 'password': 'Password', 'login': 'Log in', 'register': 'Sign up',
    'no_acc': 'No account? Sign up', 'has_acc': 'Already have an account? Log in', 'or': 'or',
    'g_login': 'Continue with Google', 'a_login': 'Continue with Apple', 'tagline': 'Learn until you truly get it.',
    'check_email': 'Check your email to confirm, then log in.', 'auth_fail': 'Could not sign in. Check your details and connection.',
    'auth_input': 'Enter a valid email and a password of at least 6 characters.',
    'start_title': "Let's get started", 's_topic': 'Enter a Topic', 's_scan': 'Scan Notes/Photo', 's_yt': 'YouTube Link',
    's_web': 'Import from Website', 'topic_hint': 'Example: Quadratic Functions', 'yt_hint': 'Paste a YouTube link',
    'web_hint': 'Paste an article link', 'paste': 'Paste', 'process': 'Process', 'working': 'Ngerti.in is working...',
    'camera': 'Camera', 'gallery': 'Gallery', 'type_hint': 'Type your question here...', 'or_type': 'Or type the question',
    'no_input': 'Take a photo or type the question first.', 'send': 'Send', 'cam_fail': 'Cannot open camera/gallery. Check app permissions.',
    'crop_title': 'Crop & rotate',
    'not_problem': "This doesn't look like a study question. Try taking the photo again!",
    'not_material': "This doesn't look like study material. Try taking the photo again!",
    'retry_photo': 'Retake', 'force_it': 'Process anyway',
    'answer_mode': 'Answer', 'ask_more': 'Ask more', 'type_answer': 'Type your answer...',
    'ask_problem': 'Ask about this question...', 'ask_content': 'Ask about this material...', 'make_quiz': 'Make quiz', 'quiz_making': 'Making quiz...',
    'quiz': 'Quiz', 'flashcard': 'Flashcards', 'tldr': 'TLDR', 'hint': 'Hint', 'check': 'Check', 'next': 'Next',
    'finish': 'Finish', 'score': 'Score', 'correct': 'Correct!', 'wrong': 'Not quite.',
    'history': 'History', 'no_history': 'No history yet. Start by snapping a question or summarizing material.',
    'offline_cache': 'Offline mode, showing saved history',
    'stat_solved': 'Items processed', 'stat_streak': 'Day streak', 'stat_acc': 'Accuracy',
    'upgrade': 'Upgrade to Premium', 'premium_on': 'You are a Premium user', 'logout': 'Log out', 'settings': 'Settings',
    'dark_mode': 'Dark mode', 'language': 'Language', 'feedback': 'Feedback', 'version': 'App version',
    'feedback_hint': 'Write a bug report or suggestion...', 'send_feedback': 'Send feedback', 'thanks': 'Thanks for your feedback!',
    'free': 'Free', 'premium': 'Premium', 'unlimited': 'Unlimited', 'per_day': '/ day',
    'r_process': 'Process new material', 'r_followup': 'Ask AI', 'r_model': 'AI intelligence', 'std': 'Standard', 'adv': 'Advanced',
    'r_ads': 'Ads', 'yes': 'Yes', 'none': 'None', 'monthly': 'Monthly', 'yearly': 'Yearly',
    'price_m': 'Rp 19,000 / month', 'price_y': 'Rp 149,000 / year (save ~34%)',
    'after_pay': 'After payment succeeds, pull down on the Profile screen to refresh your status.',
    'pay_missing': 'Payment is not configured yet.',
    'quota_title': "Today's quota is used up", 'quota_body': 'The free quota resets every day at 00:00. Upgrade to Premium for unlimited access.',
    'later': 'Later', 'see_premium': 'See Premium', 'no_internet': 'No internet connection',
  },
  'ms': {
    'nav_home': 'Utama', 'nav_tutor': 'Tutor', 'nav_profile': 'Profil', 'hello': 'Hai',
    'scan_title': 'Foto & Jawab', 'scan_sub': 'Ambil gambar soalan, dapatkan penjelasan langkah demi langkah.',
    'ask_hint': 'Tanya Ngerti.in...', 'left': 'Baki {n} proses',
    'm_quiz': 'Kuiz', 'm_flash': 'Kad Belajar', 'm_calc': 'Kalkulator', 'm_summary': 'Ringkasan', 'm_write': 'Pembantu Menulis',
    'soon': 'Akan datang', 'email': 'E-mel', 'password': 'Kata laluan', 'login': 'Log masuk', 'register': 'Daftar',
    'no_acc': 'Belum ada akaun? Daftar', 'has_acc': 'Sudah ada akaun? Log masuk', 'or': 'atau',
    'g_login': 'Teruskan dengan Google', 'a_login': 'Teruskan dengan Apple', 'tagline': 'Belajar sehingga benar-benar faham.',
    'start_title': 'Jom mulakan', 's_topic': 'Masukkan Topik', 's_scan': 'Imbas Nota/Foto', 's_yt': 'Pautan YouTube',
    's_web': 'Import dari Laman Web', 'topic_hint': 'Contoh: Fungsi Kuadratik', 'yt_hint': 'Tampal pautan YouTube',
    'web_hint': 'Tampal pautan artikel', 'paste': 'Tampal', 'process': 'Proses',
    'camera': 'Kamera', 'gallery': 'Galeri', 'type_hint': 'Tulis soalan di sini...', 'or_type': 'Atau taip soalan', 'send': 'Hantar',
    'not_problem': 'Nampaknya ini bukan soalan pelajaran. Cuba ambil foto semula!', 'retry_photo': 'Foto semula', 'force_it': 'Tetap proses',
    'answer_mode': 'Jawab soalan', 'ask_more': 'Tanya lagi', 'type_answer': 'Taip jawapanmu...',
    'ask_problem': 'Tanya tentang soalan ini...', 'ask_content': 'Tanya tentang bahan ini...', 'make_quiz': 'Buat kuiz',
    'quiz': 'Kuiz', 'flashcard': 'Kad imbas', 'hint': 'Petunjuk', 'check': 'Semak', 'next': 'Seterusnya',
    'finish': 'Selesai', 'score': 'Skor', 'correct': 'Betul!', 'wrong': 'Belum tepat.',
    'history': 'Sejarah', 'no_history': 'Belum ada sejarah. Mulakan dengan foto soalan atau ringkaskan bahan.',
    'stat_solved': 'Bahan diproses', 'stat_streak': 'Hari berturut', 'stat_acc': 'Ketepatan',
    'upgrade': 'Naik taraf ke Premium', 'premium_on': 'Anda pengguna Premium', 'logout': 'Log keluar', 'settings': 'Tetapan',
    'dark_mode': 'Mod gelap', 'language': 'Bahasa', 'feedback': 'Maklum balas', 'version': 'Versi aplikasi', 'send_feedback': 'Hantar maklum balas',
    'free': 'Percuma', 'unlimited': 'Tanpa had', 'per_day': '/ hari', 'r_process': 'Proses bahan baharu', 'r_followup': 'Tanya AI',
    'r_model': 'Kecerdasan AI', 'std': 'Standard', 'adv': 'Lanjutan', 'r_ads': 'Iklan', 'yes': 'Ada', 'none': 'Tiada',
    'monthly': 'Bulanan', 'yearly': 'Tahunan',
    'quota_title': 'Kuota hari ini habis', 'quota_body': 'Kuota percuma ditetapkan semula setiap 00:00. Naik taraf ke Premium untuk akses tanpa had.',
    'later': 'Nanti', 'see_premium': 'Lihat Premium', 'no_internet': 'Tiada sambungan internet',
  },
  'ar': {
    'nav_home': 'الرئيسية', 'nav_tutor': 'المعلّم', 'nav_profile': 'الملف', 'hello': 'مرحباً',
    'scan_title': 'صوّر وأجب', 'scan_sub': 'صوّر سؤالك واحصل على شرح خطوة بخطوة.',
    'ask_hint': 'اسأل Ngerti.in...', 'left': 'المتبقي {n}',
    'm_quiz': 'اختبار', 'm_flash': 'بطاقات', 'm_calc': 'آلة حاسبة', 'm_summary': 'ملخّص', 'm_write': 'مساعد الكتابة',
    'soon': 'قريباً', 'email': 'البريد الإلكتروني', 'password': 'كلمة المرور', 'login': 'تسجيل الدخول', 'register': 'إنشاء حساب',
    'no_acc': 'ليس لديك حساب؟ سجّل', 'has_acc': 'لديك حساب؟ سجّل الدخول', 'or': 'أو',
    'g_login': 'المتابعة عبر Google', 'a_login': 'المتابعة عبر Apple', 'tagline': 'تعلّم حتى تفهم حقاً.',
    'start_title': 'هيا نبدأ', 's_topic': 'أدخل موضوعاً', 's_scan': 'مسح الملاحظات/الصورة', 's_yt': 'رابط يوتيوب',
    's_web': 'استيراد من موقع', 'topic_hint': 'مثال: الدوال التربيعية', 'yt_hint': 'الصق رابط يوتيوب',
    'web_hint': 'الصق رابط المقال', 'paste': 'لصق', 'process': 'معالجة',
    'camera': 'الكاميرا', 'gallery': 'المعرض', 'type_hint': 'اكتب السؤال هنا...', 'or_type': 'أو اكتب السؤال', 'send': 'إرسال',
    'not_problem': 'يبدو أن هذا ليس سؤالاً دراسياً. جرّب التصوير مرة أخرى!', 'retry_photo': 'إعادة التصوير', 'force_it': 'عالج على أي حال',
    'answer_mode': 'أجب', 'ask_more': 'اسأل المزيد', 'type_answer': 'اكتب إجابتك...',
    'ask_problem': 'اسأل عن هذا السؤال...', 'ask_content': 'اسأل عن هذه المادة...', 'make_quiz': 'أنشئ اختباراً',
    'quiz': 'اختبار', 'flashcard': 'بطاقات', 'hint': 'تلميح', 'check': 'تحقق', 'next': 'التالي',
    'finish': 'إنهاء', 'score': 'النتيجة', 'correct': 'صحيح!', 'wrong': 'ليس تماماً.',
    'history': 'السجل', 'no_history': 'لا يوجد سجل بعد. ابدأ بتصوير سؤال أو تلخيص مادة.',
    'stat_solved': 'مواد معالجة', 'stat_streak': 'أيام متتالية', 'stat_acc': 'الدقة',
    'upgrade': 'الترقية إلى بريميوم', 'premium_on': 'أنت مستخدم بريميوم', 'logout': 'تسجيل الخروج', 'settings': 'الإعدادات',
    'dark_mode': 'الوضع الداكن', 'language': 'اللغة', 'feedback': 'ملاحظات', 'version': 'إصدار التطبيق', 'send_feedback': 'إرسال الملاحظات',
    'free': 'مجاني', 'premium': 'بريميوم', 'unlimited': 'غير محدود', 'per_day': '/ يوم', 'r_process': 'معالجة مادة جديدة',
    'r_followup': 'اسأل الذكاء الاصطناعي', 'r_model': 'ذكاء الذكاء الاصطناعي', 'std': 'عادي', 'adv': 'متقدم', 'r_ads': 'الإعلانات',
    'yes': 'نعم', 'none': 'لا', 'monthly': 'شهري', 'yearly': 'سنوي',
    'quota_title': 'انتهت حصة اليوم', 'quota_body': 'تتجدد الحصة المجانية كل يوم عند 00:00. رقِّ إلى بريميوم للاستخدام غير المحدود.',
    'later': 'لاحقاً', 'see_premium': 'عرض بريميوم', 'no_internet': 'لا يوجد اتصال بالإنترنت',
  },
  'zh': {
    'nav_home': '首页', 'nav_tutor': '辅导', 'nav_profile': '我的', 'hello': '你好',
    'scan_title': '拍照解题', 'scan_sub': '拍下题目，获得一步步的讲解。',
    'ask_hint': '问问 Ngerti.in...', 'left': '剩余 {n} 次',
    'm_quiz': '测验', 'm_flash': '闪卡', 'm_calc': '计算器', 'm_summary': '摘要', 'm_write': '写作助手',
    'soon': '即将推出', 'email': '邮箱', 'password': '密码', 'login': '登录', 'register': '注册',
    'no_acc': '没有账号？注册', 'has_acc': '已有账号？登录', 'or': '或',
    'g_login': '使用 Google 继续', 'a_login': '使用 Apple 继续', 'tagline': '学到真正弄懂为止。',
    'start_title': '开始吧', 's_topic': '输入主题', 's_scan': '扫描笔记/照片', 's_yt': 'YouTube 链接',
    's_web': '从网站导入', 'topic_hint': '例如：二次函数', 'yt_hint': '粘贴 YouTube 链接',
    'web_hint': '粘贴文章链接', 'paste': '粘贴', 'process': '处理',
    'camera': '相机', 'gallery': '相册', 'type_hint': '在此输入题目...', 'or_type': '或输入题目', 'send': '发送',
    'not_problem': '这似乎不是学习题目，请重新拍照！', 'retry_photo': '重新拍照', 'force_it': '仍然处理',
    'answer_mode': '作答', 'ask_more': '继续提问', 'type_answer': '输入你的答案...',
    'ask_problem': '询问这道题...', 'ask_content': '询问这份资料...', 'make_quiz': '生成测验',
    'quiz': '测验', 'flashcard': '闪卡', 'hint': '提示', 'check': '检查', 'next': '下一题',
    'finish': '完成', 'score': '得分', 'correct': '正确！', 'wrong': '还不对。',
    'history': '历史', 'no_history': '还没有记录。先拍一道题或总结一份资料吧。',
    'stat_solved': '已处理内容', 'stat_streak': '连续天数', 'stat_acc': '正确率',
    'upgrade': '升级到高级版', 'premium_on': '你是高级版用户', 'logout': '退出登录', 'settings': '设置',
    'dark_mode': '深色模式', 'language': '语言', 'feedback': '反馈', 'version': '应用版本', 'send_feedback': '提交反馈',
    'free': '免费', 'premium': '高级版', 'unlimited': '无限', 'per_day': '/ 天', 'r_process': '处理新内容',
    'r_followup': '问 AI', 'r_model': 'AI 智能', 'std': '标准', 'adv': '高级', 'r_ads': '广告', 'yes': '有', 'none': '无',
    'monthly': '按月', 'yearly': '按年',
    'quota_title': '今日额度已用完', 'quota_body': '免费额度每天 00:00 重置。升级到高级版即可无限使用。',
    'later': '以后再说', 'see_premium': '查看高级版', 'no_internet': '没有网络连接',
  },
  'tr': {
    'nav_home': 'Ana Sayfa', 'nav_tutor': 'Eğitmen', 'nav_profile': 'Profil', 'hello': 'Merhaba',
    'scan_title': 'Çek & Çöz', 'scan_sub': 'Sorunu çek, adım adım açıklamayı al.',
    'ask_hint': "Ngerti.in'e sor...", 'left': '{n} hak kaldı',
    'm_quiz': 'Test', 'm_flash': 'Kartlar', 'm_calc': 'Hesap Makinesi', 'm_summary': 'Özet', 'm_write': 'Yazma Asistanı',
    'soon': 'Yakında', 'email': 'E-posta', 'password': 'Şifre', 'login': 'Giriş yap', 'register': 'Kayıt ol',
    'no_acc': 'Hesabın yok mu? Kayıt ol', 'has_acc': 'Hesabın var mı? Giriş yap', 'or': 'veya',
    'g_login': 'Google ile devam et', 'a_login': 'Apple ile devam et', 'tagline': 'Gerçekten anlayana kadar öğren.',
    'start_title': 'Hadi başlayalım', 's_topic': 'Konu Gir', 's_scan': 'Not/Fotoğraf Tara', 's_yt': 'YouTube Bağlantısı',
    's_web': 'Web Sitesinden Al', 'topic_hint': 'Örnek: İkinci Dereceden Fonksiyonlar', 'yt_hint': 'YouTube bağlantısını yapıştır',
    'web_hint': 'Makale bağlantısını yapıştır', 'paste': 'Yapıştır', 'process': 'İşle',
    'camera': 'Kamera', 'gallery': 'Galeri', 'type_hint': 'Sorunu buraya yaz...', 'or_type': 'Veya soruyu yaz', 'send': 'Gönder',
    'not_problem': 'Bu bir ders sorusu gibi görünmüyor. Fotoğrafı tekrar çek!', 'retry_photo': 'Tekrar çek', 'force_it': 'Yine de işle',
    'answer_mode': 'Cevapla', 'ask_more': 'Daha fazla sor', 'type_answer': 'Cevabını yaz...',
    'ask_problem': 'Bu soru hakkında sor...', 'ask_content': 'Bu içerik hakkında sor...', 'make_quiz': 'Test oluştur',
    'quiz': 'Test', 'flashcard': 'Kartlar', 'hint': 'İpucu', 'check': 'Kontrol et', 'next': 'Sonraki',
    'finish': 'Bitir', 'score': 'Puan', 'correct': 'Doğru!', 'wrong': 'Tam değil.',
    'history': 'Geçmiş', 'no_history': 'Henüz geçmiş yok. Bir soru çekerek veya içerik özetleyerek başla.',
    'stat_solved': 'İşlenen içerik', 'stat_streak': 'Gün serisi', 'stat_acc': 'Doğruluk',
    'upgrade': "Premium'a yükselt", 'premium_on': 'Premium kullanıcısısın', 'logout': 'Çıkış yap', 'settings': 'Ayarlar',
    'dark_mode': 'Karanlık mod', 'language': 'Dil', 'feedback': 'Geri bildirim', 'version': 'Uygulama sürümü', 'send_feedback': 'Geri bildirim gönder',
    'free': 'Ücretsiz', 'unlimited': 'Sınırsız', 'per_day': '/ gün', 'r_process': 'Yeni içerik işle', 'r_followup': "Yapay zekaya sor",
    'r_model': 'Yapay zeka zekası', 'std': 'Standart', 'adv': 'Gelişmiş', 'r_ads': 'Reklamlar', 'yes': 'Var', 'none': 'Yok',
    'monthly': 'Aylık', 'yearly': 'Yıllık',
    'quota_title': 'Bugünkü hakkın bitti', 'quota_body': "Ücretsiz hak her gün 00:00'da yenilenir. Sınırsız erişim için Premium'a yükselt.",
    'later': 'Sonra', 'see_premium': "Premium'u gör", 'no_internet': 'İnternet bağlantısı yok',
  },
};
