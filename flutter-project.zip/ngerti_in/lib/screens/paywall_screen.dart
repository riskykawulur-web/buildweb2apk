import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/api.dart';
import '../core/config.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';

Future<void> showQuotaDialog(BuildContext context) => showDialog(
      context: context,
      builder: (dc) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        icon: const Icon(Icons.hourglass_bottom_rounded, size: 36),
        title: Text(context.tr('quota_title'), textAlign: TextAlign.center),
        content: Text(context.tr('quota_body'), textAlign: TextAlign.center),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dc), child: Text(context.tr('later'))),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(120, 44)),
            onPressed: () {
              Navigator.pop(dc);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const PaywallScreen()));
            },
            child: Text(context.tr('see_premium')),
          ),
        ],
      ),
    );

class PaywallScreen extends StatelessWidget {
  const PaywallScreen({super.key});

  Future<void> _buy(BuildContext c, String base) async {
    if (base.isEmpty) {
      snack(c, c.tr('pay_missing'));
      return;
    }
    final u = Uri.parse(base);
    final link = u.replace(queryParameters: {...u.queryParameters, 'uid': Api.uid ?? ''});
    if (!await launchUrl(link, mode: LaunchMode.externalApplication) && c.mounted) snack(c, c.tr('pay_missing'));
  }

  @override
  Widget build(BuildContext context) {
    final k = context.c;
    final day = context.tr('per_day');
    final rows = <(String, String, String)>[
      (context.tr('r_process'), '10x $day', context.tr('unlimited')),
      (context.tr('r_followup'), '10x $day', context.tr('unlimited')),
      (context.tr('r_model'), context.tr('std'), context.tr('adv')),
      (context.tr('r_ads'), context.tr('yes'), context.tr('none')),
    ];
    Widget cell(String t, {bool bold = false, Color? color}) =>
        Padding(padding: const EdgeInsets.all(9), child: Text(t, style: TextStyle(fontSize: 13, fontWeight: bold ? FontWeight.w800 : FontWeight.w500, color: color)));
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('premium'))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Box(
          strong: true,
          padding: const EdgeInsets.all(8),
          child: Table(
            columnWidths: const {0: FlexColumnWidth(1.7), 1: FlexColumnWidth(1), 2: FlexColumnWidth(1)},
            children: [
              TableRow(children: [const SizedBox(), cell(context.tr('free'), bold: true), cell(context.tr('premium'), bold: true)]),
              for (final r in rows) TableRow(children: [cell(r.$1), cell(r.$2, color: k.muted), cell(r.$3, bold: true)]),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Box(
          strong: true,
          inverse: true,
          onTap: () => _buy(context, Config.checkoutYearly),
          child: Row(children: [
            const Icon(Icons.stars_rounded, size: 30),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(context.tr('yearly'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text(context.tr('price_y'), style: const TextStyle(fontSize: 13)),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        Box(
          strong: true,
          onTap: () => _buy(context, Config.checkoutMonthly),
          child: Row(children: [
            const Icon(Icons.calendar_month_outlined, size: 30),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(context.tr('monthly'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text(context.tr('price_m'), style: TextStyle(fontSize: 13, color: k.muted)),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 16),
        Text(context.tr('after_pay'), textAlign: TextAlign.center, style: TextStyle(color: k.muted, fontSize: 12.5)),
      ]),
    );
  }
}
