import 'package:flutter/material.dart';
import '../core/api.dart';
import '../core/config.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _fb = TextEditingController();
  bool _sending = false;

  String _langName() => languages.firstWhere((l) => l.$1 == AppState.lang.value).$2;

  Future<void> _pickLang() async {
    final k = context.c;
    final code = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: k.bg,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final l in languages)
            ListTile(
              title: Text(l.$2),
              trailing: l.$1 == AppState.lang.value ? const Icon(Icons.check_rounded) : null,
              onTap: () => Navigator.pop(context, l.$1),
            ),
        ]),
      ),
    );
    if (code != null) {
      await AppState.setLang(code);
      if (mounted) setState(() {});
    }
  }

  Future<void> _send() async {
    final t = _fb.text.trim();
    if (t.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      await Api.sendFeedback(t);
      _fb.clear();
      if (mounted) snack(context, context.tr('thanks'));
    } catch (_) {
      if (mounted) snack(context, context.tr('no_internet'));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final k = context.c;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('settings'))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Box(
          padding: EdgeInsets.zero,
          child: Column(children: [
            ValueListenableBuilder<bool>(
              valueListenable: AppState.dark,
              builder: (_, dark, __) => SwitchListTile(
                secondary: const Icon(Icons.dark_mode_outlined),
                title: Text(context.tr('dark_mode')),
                value: dark,
                onChanged: AppState.setDark,
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.translate_rounded),
              title: Text(context.tr('language')),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [Text(_langName(), style: TextStyle(color: k.muted)), const Icon(Icons.chevron_right_rounded)]),
              onTap: _pickLang,
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.info_outline_rounded),
              title: Text(context.tr('version')),
              trailing: Text(Config.appVersion, style: TextStyle(color: k.muted)),
            ),
          ]),
        ),
        const SizedBox(height: 22),
        Text(context.tr('feedback'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        TextField(controller: _fb, minLines: 4, maxLines: 8, maxLength: 2000, decoration: InputDecoration(hintText: context.tr('feedback_hint'))),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: _sending ? null : _send,
          icon: const Icon(Icons.send_rounded),
          label: Text(context.tr('send_feedback')),
        ),
      ]),
    );
  }
}
