import 'package:flutter/material.dart';
import '../core/api.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'paywall_screen.dart';

/// UI Kuis: tab Kuis | Flashcard | TLDR, kartu soal A-D, tombol Periksa (abu-abu lalu hitam).
class QuizScreen extends StatefulWidget {
  final Json session;
  const QuizScreen({super.key, required this.session});
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late final List<Json> _qs;
  late final List<Json?> _ans;
  int _i = 0;
  int? _sel;
  String? _hint;
  bool _busy = false;

  String get _id => widget.session['id'];

  @override
  void initState() {
    super.initState();
    _qs = [for (final q in (widget.session['quiz'] as List)) Json.from(q)];
    final saved = (widget.session['quiz_answers'] as List?) ?? [];
    _ans = List.generate(_qs.length, (i) => i < saved.length && saved[i] != null ? Json.from(saved[i]) : null);
    final first = _ans.indexWhere((a) => a == null);
    _i = first == -1 ? _qs.length : first;
  }

  Future<void> _guard(Future<void> Function() job) async {
    setState(() => _busy = true);
    try {
      await job();
    } on QuotaException {
      if (mounted) await showQuotaDialog(context);
    } on ApiException catch (e) {
      if (mounted) snack(context, e.text(context));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _check() => _guard(() async {
        final r = await Api.quizCheck(_id, _i, _sel!);
        _ans[_i] = Json.from(r);
        widget.session['quiz_answers'] = _ans;
      });

  Future<void> _getHint() => _guard(() async {
        final r = await Api.quizHint(_id, _i);
        _hint = '${r['hint']}';
      });

  void _next() => setState(() {
        _i++;
        _sel = null;
        _hint = null;
      });

  Widget _tabs() {
    final k = context.c;
    Widget tab(String key, bool active) => Expanded(
          child: GestureDetector(
            onTap: active ? null : () => snack(context, context.tr('soon')),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: active ? k.ink : Colors.transparent,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: active ? k.ink : k.line),
              ),
              child: Column(children: [
                Text(context.tr(key), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5, color: active ? k.onInk : k.muted)),
                if (!active) Text(context.tr('soon'), style: TextStyle(fontSize: 10, color: k.muted)),
              ]),
            ),
          ),
        );
    return Row(children: [tab('quiz', true), const SizedBox(width: 8), tab('flashcard', false), const SizedBox(width: 8), tab('tldr', false)]);
  }

  Widget _option(int j) {
    final k = context.c;
    final a = _ans[_i];
    final checked = a != null;
    final picking = a == null && _sel == j;
    final isAnswer = a != null && a['answer'] == j;
    final wrongPick = a != null && a['choice'] == j && a['answer'] != j;
    final bold = picking || isAnswer || wrongPick;
    final fg = isAnswer ? k.onInk : k.ink;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(
            color: isAnswer ? k.ink : k.bg,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: bold ? k.ink : k.line, width: bold ? 2 : 1),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: checked || _busy ? null : () => setState(() => _sel = j),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                CircleAvatar(
                  radius: 14,
                  backgroundColor: isAnswer ? k.onInk : k.soft,
                  child: Text('ABCD'[j], style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: k.ink)),
                ),
                const SizedBox(width: 12),
                Expanded(child: MathText('${(_qs[_i]['options'] as List)[j]}', style: TextStyle(color: fg, fontSize: 15, height: 1.35))),
                if (isAnswer) Icon(Icons.check_circle_rounded, color: fg),
                if (wrongPick) Icon(Icons.cancel_outlined, color: fg),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _question() {
    final k = context.c;
    final a = _ans[_i];
    final checked = a != null;
    final last = _i == _qs.length - 1;
    return ListView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 24), children: [
      _tabs(),
      const SizedBox(height: 16),
      Box(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text('${_i + 1}/${_qs.length}', style: TextStyle(fontWeight: FontWeight.w800, color: k.muted)),
            const Spacer(),
            TextButton.icon(
              onPressed: checked || _busy ? null : _getHint,
              icon: const Icon(Icons.lightbulb_outline_rounded, size: 18),
              label: Text(context.tr('hint')),
            ),
          ]),
          MathText('${_qs[_i]['q']}', style: TextStyle(color: k.ink, fontSize: 17, height: 1.45, fontWeight: FontWeight.w600)),
          if (_hint != null && !checked)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: k.soft, borderRadius: BorderRadius.circular(14), border: Border.all(color: k.line)),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(Icons.lightbulb_outline_rounded, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: MathText(_hint!)),
                ]),
              ),
            ),
        ]),
      ),
      const SizedBox(height: 14),
      for (var j = 0; j < 4; j++) _option(j),
      if (a != null)
        Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: Box(
            fill: k.soft,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(a['correct'] == true ? Icons.check_circle_outline_rounded : Icons.highlight_off_rounded),
                const SizedBox(width: 8),
                Text(context.tr(a['correct'] == true ? 'correct' : 'wrong'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              ]),
              if ('${a['explanation']}'.isNotEmpty) ...[const SizedBox(height: 8), MathText('${a['explanation']}')],
            ]),
          ),
        ),
      FilledButton(
        onPressed: checked ? (last ? () => setState(() => _i++) : _next) : (_sel == null || _busy ? null : _check),
        child: _busy
            ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: k.muted))
            : Text(context.tr(checked ? (last ? 'finish' : 'next') : 'check')),
      ),
    ]);
  }

  Widget _result() {
    final k = context.c;
    final good = _ans.where((a) => a?['correct'] == true).length;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.emoji_events_outlined, size: 64),
          const SizedBox(height: 14),
          Text(context.tr('score'), style: TextStyle(color: k.muted, fontSize: 15)),
          Text('$good / ${_qs.length}', style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w800)),
          const SizedBox(height: 28),
          FilledButton(onPressed: () => Navigator.pop(context), child: Text(context.tr('finish'))),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('${widget.session['title']}', maxLines: 1, overflow: TextOverflow.ellipsis)),
        body: _i >= _qs.length ? _result() : _question(),
      );
}
