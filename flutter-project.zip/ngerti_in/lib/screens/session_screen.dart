import 'package:flutter/material.dart';
import '../core/api.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'paywall_screen.dart';
import 'quiz_screen.dart';

/// Chat tutor / materi. Soal: mode Jawab + Tanya lanjut. Materi: Tanya + tombol Kuis.
class SessionScreen extends StatefulWidget {
  final Json session;
  const SessionScreen({super.key, required this.session});
  @override
  State<SessionScreen> createState() => _SessionScreenState();
}

class _SessionScreenState extends State<SessionScreen> {
  late final List<Json> _msgs;
  late bool _solved;
  late bool _answerMode;
  bool _busy = false;
  bool _makingQuiz = false;
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();

  String get _id => widget.session['id'];
  bool get _isSolve => widget.session['type'] == 'solve';

  @override
  void initState() {
    super.initState();
    _msgs = [for (final m in (widget.session['messages'] as List)) Json.from(m)];
    _solved = widget.session['solved'] == true;
    _answerMode = _isSolve && !_solved;
  }

  void _down() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) {
          _scroll.animateTo(_scroll.position.maxScrollExtent + 200, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
        }
      });

  Future<void> _send() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty || _busy) return;
    setState(() {
      _busy = true;
      _msgs.add({'role': 'user', 'text': t});
      _ctrl.clear();
    });
    _down();
    try {
      if (_answerMode) {
        final r = await Api.solveAnswer(_id, t);
        for (final m in (r['ai'] as List)) {
          _msgs.add(Json.from(m));
        }
        if (r['solved'] == true) {
          _solved = true;
          _answerMode = false;
        }
      } else {
        final r = await Api.chat(_id, t);
        _msgs.add({'role': 'ai', 'text': '${r['reply']}'});
      }
    } on QuotaException {
      _msgs.removeLast();
      _ctrl.text = t;
      if (mounted) await showQuotaDialog(context);
    } on ApiException catch (e) {
      _msgs.removeLast();
      _ctrl.text = t;
      if (mounted) snack(context, e.text(context));
    } finally {
      if (mounted) setState(() => _busy = false);
      _down();
    }
  }

  Future<void> _openQuiz() async {
    if (_makingQuiz) return;
    if (widget.session['quiz'] == null) {
      setState(() => _makingQuiz = true);
      try {
        final r = await Api.quizMake(_id);
        widget.session['quiz'] = r['quiz'];
        widget.session['quiz_answers'] = r['quiz_answers'] ?? [];
      } on QuotaException {
        if (mounted) await showQuotaDialog(context);
      } on ApiException catch (e) {
        if (mounted) snack(context, e.text(context));
      } finally {
        if (mounted) setState(() => _makingQuiz = false);
      }
    }
    if (widget.session['quiz'] != null && mounted) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(session: widget.session)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final k = context.c;
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.session['title']}', maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          if (_solved) const Padding(padding: EdgeInsets.only(right: 16), child: Icon(Icons.check_circle_outline_rounded)),
          if (!_isSolve)
            _makingQuiz
                ? const Padding(padding: EdgeInsets.only(right: 16), child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5)))
                : IconButton(tooltip: context.tr('make_quiz'), icon: const Icon(Icons.quiz_outlined), onPressed: _openQuiz),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
            controller: _scroll,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            itemCount: _msgs.length + (_busy ? 1 : 0),
            itemBuilder: (_, i) => i == _msgs.length
                ? Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Padding(padding: const EdgeInsets.all(12), child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: k.ink))),
                  )
                : MessageBubble(mine: _msgs[i]['role'] == 'user', text: '${_msgs[i]['text']}', tag: _msgs[i]['tag'] as String?),
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (_isSolve)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(children: [
                    SegChip(label: context.tr('answer_mode'), icon: Icons.edit_outlined, selected: _answerMode, onTap: _solved ? null : () => setState(() => _answerMode = true)),
                    const SizedBox(width: 8),
                    SegChip(label: context.tr('ask_more'), icon: Icons.help_outline_rounded, selected: !_answerMode, onTap: () => setState(() => _answerMode = false)),
                  ]),
                ),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    minLines: 1,
                    maxLines: 4,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _send(),
                    decoration: InputDecoration(hintText: context.tr(_answerMode ? 'type_answer' : (_isSolve ? 'ask_problem' : 'ask_content'))),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  style: IconButton.styleFrom(backgroundColor: k.ink, minimumSize: const Size(50, 50)),
                  onPressed: _busy ? null : _send,
                  icon: Icon(Icons.arrow_upward_rounded, color: k.onInk),
                ),
              ]),
            ]),
          ),
        ),
      ]),
    );
  }
}
