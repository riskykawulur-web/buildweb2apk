import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../core/ads.dart';
import '../core/api.dart';
import '../core/image_util.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'paywall_screen.dart';
import 'quiz_screen.dart';
import 'session_screen.dart';

/// Bottom sheet "Mari kita mulai". mode: 'quiz' atau 'summary'.
Future<void> showStartSheet(BuildContext context, String mode) async {
  final k = context.c;
  final session = await showModalBottomSheet<Json>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    backgroundColor: k.bg,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (_) => StartSheet(mode: mode),
  );
  if (session != null && context.mounted) {
    Ads.afterProcess();
    Navigator.push(context, MaterialPageRoute(builder: (_) => mode == 'quiz' ? QuizScreen(session: session) : SessionScreen(session: session)));
  }
}

class StartSheet extends StatefulWidget {
  final String mode;
  const StartSheet({super.key, required this.mode});
  @override
  State<StartSheet> createState() => _StartSheetState();
}

class _StartSheetState extends State<StartSheet> {
  String _stage = 'menu'; // menu | topic | youtube | web | photo
  final _ctrl = TextEditingController();
  Uint8List? _img;
  bool _busy = false;

  void _stageTo(String s) => setState(() {
        _stage = s;
        _ctrl.clear();
        _img = null;
      });

  Future<void> _pick(ImageSource src) async {
    final b = await pickAndCrop(context, src);
    if (b != null && mounted) setState(() => _img = b);
  }

  Future<void> _submit({bool force = false}) async {
    final v = _ctrl.text.trim();
    if (_stage != 'photo' && v.isEmpty) return;
    if (_stage == 'photo' && _img == null) return;
    setState(() => _busy = true);
    try {
      final r = await Api.create(
        source: _stage,
        mode: widget.mode,
        text: _stage == 'topic' ? v : null,
        url: _stage == 'youtube' || _stage == 'web' ? v : null,
        image: _img,
        force: force,
      );
      if (!mounted) return;
      if (r['rejected'] == true) {
        await _rejected();
        return;
      }
      Navigator.pop(context, Json.from(r['session']));
    } on QuotaException {
      if (mounted) await showQuotaDialog(context);
    } on ApiException catch (e) {
      if (mounted) snack(context, e.text(context));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _rejected() async {
    final force = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        icon: const Icon(Icons.image_search_rounded, size: 36),
        content: Text(context.tr(_stage == 'photo' ? 'not_material' : 'not_problem'), textAlign: TextAlign.center),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(context.tr('retry_photo'))),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(120, 44)),
            onPressed: () => Navigator.pop(context, true),
            child: Text(context.tr('force_it')),
          ),
        ],
      ),
    );
    if (force == true) _submit(force: true);
  }

  Widget _tile(IconData icon, String key, String stage) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Box(
          onTap: () => _stageTo(stage),
          child: Row(children: [
            Icon(icon, size: 26),
            const SizedBox(width: 14),
            Expanded(child: Text(context.tr(key), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
            const Icon(Icons.chevron_right_rounded),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final k = context.c;
    final inset = MediaQuery.of(context).viewInsets.bottom;
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + inset),
      child: _stage == 'menu'
          ? Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(context.tr('start_title'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              _tile(Icons.menu_book_outlined, 's_topic', 'topic'),
              _tile(Icons.document_scanner_outlined, 's_scan', 'photo'),
              _tile(Icons.smart_display_outlined, 's_yt', 'youtube'),
              _tile(Icons.language_rounded, 's_web', 'web'),
            ])
          : Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                IconButton(onPressed: _busy ? null : () => _stageTo('menu'), icon: const Icon(Icons.arrow_back_rounded)),
                Expanded(
                  child: Text(
                    context.tr({'topic': 's_topic', 'photo': 's_scan', 'youtube': 's_yt', 'web': 's_web'}[_stage]!),
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              if (_stage == 'photo') ...[
                if (_img == null)
                  Row(children: [
                    Expanded(child: _srcBtn(Icons.photo_camera_outlined, 'camera', ImageSource.camera)),
                    const SizedBox(width: 12),
                    Expanded(child: _srcBtn(Icons.photo_library_outlined, 'gallery', ImageSource.gallery)),
                  ])
                else
                  ClipRRect(borderRadius: BorderRadius.circular(20), child: Image.memory(_img!, height: 200, fit: BoxFit.cover)),
              ] else if (_stage == 'topic')
                TextField(controller: _ctrl, minLines: 2, maxLines: 4, decoration: InputDecoration(hintText: context.tr('topic_hint')))
              else
                TextField(
                  controller: _ctrl,
                  keyboardType: TextInputType.url,
                  decoration: InputDecoration(
                    hintText: context.tr(_stage == 'youtube' ? 'yt_hint' : 'web_hint'),
                    prefixIcon: const Icon(Icons.link_rounded),
                    suffixIcon: IconButton(
                      tooltip: context.tr('paste'),
                      icon: const Icon(Icons.content_paste_rounded),
                      onPressed: () async {
                        final d = await Clipboard.getData('text/plain');
                        if (d?.text != null) setState(() => _ctrl.text = d!.text!.trim());
                      },
                    ),
                  ),
                ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: _busy || (_stage == 'photo' && _img == null) ? null : _submit,
                child: _busy
                    ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.5, color: k.muted)),
                        const SizedBox(width: 10),
                        Text(context.tr('working')),
                      ])
                    : Text(context.tr('process')),
              ),
            ]),
    );
  }

  Widget _srcBtn(IconData i, String key, ImageSource s) => Box(
        padding: const EdgeInsets.symmetric(vertical: 26),
        onTap: () => _pick(s),
        child: Column(children: [Icon(i, size: 32), const SizedBox(height: 8), Text(context.tr(key), style: const TextStyle(fontWeight: FontWeight.w700))]),
      );
}
