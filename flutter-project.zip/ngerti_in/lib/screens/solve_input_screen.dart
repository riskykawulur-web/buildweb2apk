import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../core/ads.dart';
import '../core/api.dart';
import '../core/image_util.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'paywall_screen.dart';
import 'session_screen.dart';

/// Foto & Jawab (mode tutor): foto soal atau ketik soal.
class SolveInputScreen extends StatefulWidget {
  final bool focusText;
  const SolveInputScreen({super.key, this.focusText = false});
  @override
  State<SolveInputScreen> createState() => _SolveInputScreenState();
}

class _SolveInputScreenState extends State<SolveInputScreen> {
  final _text = TextEditingController();
  Uint8List? _img;
  bool _busy = false;

  Future<void> _pick(ImageSource src) async {
    final b = await pickAndCrop(context, src);
    if (b != null && mounted) setState(() => _img = b);
  }

  Future<void> _submit({bool force = false}) async {
    final t = _text.text.trim();
    if (_img == null && t.isEmpty) {
      snack(context, context.tr('no_input'));
      return;
    }
    setState(() => _busy = true);
    try {
      final r = await Api.create(source: _img != null ? 'photo' : 'text', mode: 'tutor', text: t.isEmpty ? null : t, image: _img, force: force);
      if (!mounted) return;
      if (r['rejected'] == true) {
        await _rejected();
        return;
      }
      Ads.afterProcess();
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SessionScreen(session: Json.from(r['session']))));
    } on QuotaException {
      if (mounted) await showQuotaDialog(context);
    } on ApiException catch (e) {
      if (mounted) snack(context, e.text(context));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _rejected() async {
    final force = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        icon: const Icon(Icons.image_search_rounded, size: 36),
        content: Text(context.tr('not_problem'), textAlign: TextAlign.center),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(context.tr('retry_photo'))),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(120, 44)),
            onPressed: () => Navigator.pop(context, true),
            child: Text(context.tr('force_it')),
          ),
        ],
      ),
    );
    if (force == true) _submit(force: true);
  }

  Widget _src(IconData i, String key, VoidCallback f) => Box(
        padding: const EdgeInsets.symmetric(vertical: 28),
        onTap: f,
        child: Column(children: [Icon(i, size: 34), const SizedBox(height: 8), Text(context.tr(key), style: const TextStyle(fontWeight: FontWeight.w700))]),
      );

  @override
  Widget build(BuildContext context) {
    final k = context.c;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('scan_title'))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        if (_img != null)
          Stack(children: [
            ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.memory(_img!, fit: BoxFit.cover, width: double.infinity, height: 240)),
            Positioned(
              top: 8,
              right: 8,
              child: IconButton.filled(
                style: IconButton.styleFrom(backgroundColor: k.ink),
                onPressed: () => setState(() => _img = null),
                icon: Icon(Icons.close_rounded, color: k.onInk),
              ),
            ),
          ])
        else
          Row(children: [
            Expanded(child: _src(Icons.photo_camera_outlined, 'camera', () => _pick(ImageSource.camera))),
            const SizedBox(width: 12),
            Expanded(child: _src(Icons.photo_library_outlined, 'gallery', () => _pick(ImageSource.gallery))),
          ]),
        const SizedBox(height: 18),
        Text(context.tr('or_type'), style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        TextField(controller: _text, autofocus: widget.focusText, minLines: 4, maxLines: 8, decoration: InputDecoration(hintText: context.tr('type_hint'))),
        const SizedBox(height: 22),
        FilledButton.icon(
          onPressed: _busy ? null : _submit,
          icon: _busy ? SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.5, color: k.muted)) : const Icon(Icons.send_rounded),
          label: Text(_busy ? context.tr('working') : context.tr('send')),
        ),
      ]),
    );
  }
}
