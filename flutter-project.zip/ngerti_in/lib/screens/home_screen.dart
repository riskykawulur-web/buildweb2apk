import 'package:flutter/material.dart';
import '../core/api.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'input_sheet.dart';
import 'paywall_screen.dart';
import 'solve_input_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Json? _profile;
  Map<String, int> _usage = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await Api.profile();
    final u = await Api.usage();
    if (mounted) {
      setState(() {
        _profile = p;
        _usage = u;
      });
    }
  }

  Future<void> _go(Widget w) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    _load();
  }

  Future<void> _sheet(String mode) async {
    await showStartSheet(context, mode);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final k = context.c;
    final premium = Api.isPremium(_profile);
    final left = (Api.limits['process']! - (_usage['process'] ?? 0)).clamp(0, 99);
    final name = (_profile?['display_name'] ?? '').toString();
    final menu = <(IconData, String, VoidCallback)>[
      (Icons.quiz_outlined, 'm_quiz', () => _sheet('quiz')),
      (Icons.style_outlined, 'm_flash', () => snack(context, context.tr('soon'))),
      (Icons.calculate_outlined, 'm_calc', () => snack(context, context.tr('soon'))),
      (Icons.summarize_outlined, 'm_summary', () => _sheet('summary')),
      (Icons.edit_note_rounded, 'm_write', () => snack(context, context.tr('soon'))),
    ];
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          RefreshIndicator(
            onRefresh: _load,
            child: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 110), children: [
              Row(children: [
                const AppLogo(size: 40),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Ngerti.in', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                    if (name.isNotEmpty) Text('${context.tr('hello')}, $name', style: TextStyle(fontSize: 13, color: k.muted)),
                  ]),
                ),
                Pill(
                  icon: premium ? Icons.workspace_premium_outlined : Icons.bolt_rounded,
                  label: premium ? context.tr('premium') : context.tr('left', {'n': '$left'}),
                  onTap: () => _go(const PaywallScreen()),
                ),
              ]),
              const SizedBox(height: 22),
              Box(
                inverse: true,
                padding: const EdgeInsets.all(22),
                onTap: () => _go(const SolveInputScreen()),
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(context.tr('scan_title'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      Text(context.tr('scan_sub'), style: const TextStyle(fontSize: 14, height: 1.35)),
                    ]),
                  ),
                  const SizedBox(width: 12),
                  const Icon(Icons.photo_camera_outlined, size: 40),
                ]),
              ),
              const SizedBox(height: 20),
              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: .95,
                children: [
                  for (final m in menu)
                    Box(
                      padding: const EdgeInsets.all(10),
                      onTap: m.$3,
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(m.$1, size: 30),
                        const SizedBox(height: 8),
                        Text(context.tr(m.$2), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
                      ]),
                    ),
                ],
              ),
            ]),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 12,
            child: Material(
              color: k.bg,
              shape: StadiumBorder(side: BorderSide(color: k.ink, width: 1.5)),
              child: InkWell(
                customBorder: const StadiumBorder(),
                onTap: () => _go(const SolveInputScreen(focusText: true)),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                  child: Row(children: [
                    Icon(Icons.chat_bubble_outline_rounded, color: k.muted),
                    const SizedBox(width: 10),
                    Expanded(child: Text(context.tr('ask_hint'), style: TextStyle(color: k.muted, fontSize: 15))),
                    const Icon(Icons.arrow_upward_rounded),
                  ]),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
