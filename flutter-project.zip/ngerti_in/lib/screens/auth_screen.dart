import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/api.dart';
import '../core/config.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _register = false, _busy = false, _hide = true;

  Future<void> _run(Future<void> Function() job) async {
    setState(() => _busy = true);
    try {
      await job();
    } on AuthException catch (e) {
      if (mounted) snack(context, e.message);
    } catch (_) {
      if (mounted) snack(context, context.tr('auth_fail'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _emailAuth() => _run(() async {
        final e = _email.text.trim(), p = _pass.text;
        if (!e.contains('@') || p.length < 6) {
          snack(context, context.tr('auth_input'));
          return;
        }
        if (_register) {
          final r = await Api.sb.auth.signUp(email: e, password: p);
          if (r.session == null && mounted) snack(context, context.tr('check_email'));
        } else {
          await Api.sb.auth.signInWithPassword(email: e, password: p);
        }
      });

  Future<void> _google() => _run(() async {
        final g = GoogleSignIn(
          clientId: Platform.isIOS && Config.googleIosClientId.isNotEmpty ? Config.googleIosClientId : null,
          serverClientId: Config.googleWebClientId.isEmpty ? null : Config.googleWebClientId,
        );
        final acc = await g.signIn();
        if (acc == null) return;
        final a = await acc.authentication;
        if (a.idToken == null) throw Exception('no token');
        await Api.sb.auth.signInWithIdToken(provider: OAuthProvider.google, idToken: a.idToken!, accessToken: a.accessToken);
      });

  Future<void> _apple() => _run(() async {
        final raw = base64UrlEncode(List<int>.generate(32, (_) => Random.secure().nextInt(256)));
        final hashed = sha256.convert(utf8.encode(raw)).toString();
        final cred = await SignInWithApple.getAppleIDCredential(
          scopes: [AppleIDAuthorizationScopes.email, AppleIDAuthorizationScopes.fullName],
          nonce: hashed,
        );
        if (cred.identityToken == null) throw Exception('no token');
        await Api.sb.auth.signInWithIdToken(provider: OAuthProvider.apple, idToken: cred.identityToken!, nonce: raw);
      });

  @override
  Widget build(BuildContext context) {
    final k = context.c;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const Center(child: AppLogo(size: 76)),
              const SizedBox(height: 18),
              const Text('Ngerti.in', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(context.tr('tagline'), textAlign: TextAlign.center, style: TextStyle(color: k.muted, fontSize: 15)),
              const SizedBox(height: 32),
              TextField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                autofillHints: const [AutofillHints.email],
                decoration: InputDecoration(hintText: context.tr('email'), prefixIcon: const Icon(Icons.mail_outline_rounded)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _pass,
                obscureText: _hide,
                decoration: InputDecoration(
                  hintText: context.tr('password'),
                  prefixIcon: const Icon(Icons.lock_outline_rounded),
                  suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility_off_rounded : Icons.visibility_rounded), onPressed: () => setState(() => _hide = !_hide)),
                ),
              ),
              const SizedBox(height: 18),
              FilledButton(
                onPressed: _busy ? null : _emailAuth,
                child: _busy
                    ? SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: k.onInk))
                    : Text(context.tr(_register ? 'register' : 'login')),
              ),
              TextButton(
                onPressed: () => setState(() => _register = !_register),
                child: Text(context.tr(_register ? 'has_acc' : 'no_acc'), style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 8),
              Row(children: [
                const Expanded(child: Divider()),
                Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text(context.tr('or'), style: TextStyle(color: k.muted))),
                const Expanded(child: Divider()),
              ]),
              const SizedBox(height: 16),
              OutlinedButton.icon(onPressed: _busy ? null : _google, icon: const FaIcon(FontAwesomeIcons.google, size: 18), label: Text(context.tr('g_login'))),
              if (Platform.isIOS) ...[
                const SizedBox(height: 12),
                OutlinedButton.icon(onPressed: _busy ? null : _apple, icon: const FaIcon(FontAwesomeIcons.apple, size: 20), label: Text(context.tr('a_login'))),
              ],
            ]),
          ),
        ),
      ),
    );
  }
}
