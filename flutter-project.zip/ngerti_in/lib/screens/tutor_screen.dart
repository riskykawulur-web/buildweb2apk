import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/api.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'input_sheet.dart';
import 'quiz_screen.dart';
import 'session_screen.dart';
import 'solve_input_screen.dart';

class TutorScreen extends StatefulWidget {
  const TutorScreen({super.key});
  @override
  State<TutorScreen> createState() => _TutorScreenState();
}

class _TutorScreenState extends State<TutorScreen> {
  List<Json>? _rows;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await Api.sessions();
    if (mounted) setState(() => _rows = r);
  }

  Future<void> _open(Widget w) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    _load();
  }

  IconData _icon(Json s) {
    if (s['type'] == 'solve') return Icons.photo_camera_outlined;
    return switch (s['kind']) {
      'youtube' => Icons.smart_display_outlined,
      'web' => Icons.language_rounded,
      'photo' => Icons.document_scanner_outlined,
      _ => Icons.menu_book_outlined,
    };
  }

  String _date(String iso) => DateFormat.yMMMd(LangScope.of(context)).format(DateTime.parse(iso).toLocal());

  @override
  Widget build(BuildContext context) {
    final k = context.c;
    final rows = _rows;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('nav_tutor'))),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 24), children: [
          Row(children: [
            Expanded(child: _action(Icons.photo_camera_outlined, 'scan_title', () => _open(const SolveInputScreen()))),
            const SizedBox(width: 12),
            Expanded(child: _action(Icons.summarize_outlined, 'm_summary', () async {
              await showStartSheet(context, 'summary');
              _load();
            })),
          ]),
          const SizedBox(height: 22),
          Text(context.tr('history'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          if (Api.offline)
            Padding(padding: const EdgeInsets.only(top: 8), child: Pill(icon: Icons.cloud_off_rounded, label: context.tr('offline_cache'))),
          const SizedBox(height: 10),
          if (rows == null)
            Padding(padding: const EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(color: k.ink)))
          else if (rows.isEmpty)
            Padding(padding: const EdgeInsets.all(40), child: Center(child: Text(context.tr('no_history'), textAlign: TextAlign.center, style: TextStyle(color: k.muted))))
          else
            for (final s in rows)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Dismissible(
                  key: ValueKey(s['id']),
                  direction: Api.offline ? DismissDirection.none : DismissDirection.endToStart,
                  background: Container(
                    alignment: AlignmentDirectional.centerEnd,
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    decoration: BoxDecoration(color: k.soft, borderRadius: BorderRadius.circular(20)),
                    child: const Icon(Icons.delete_outline_rounded),
                  ),
                  onDismissed: (_) async {
                    setState(() => rows.remove(s));
                    try {
                      await Api.deleteSession(s['id']);
                    } catch (_) {
                      if (mounted) snack(context, context.tr('no_internet'));
                      _load();
                    }
                  },
                  child: Box(
                    onTap: () => _open(SessionScreen(session: s)),
                    child: Row(children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(color: k.soft, borderRadius: BorderRadius.circular(14)),
                        child: Icon(_icon(s), size: 22),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${s['title']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 2),
                          Text(_date(s['created_at']), style: TextStyle(fontSize: 12.5, color: k.muted)),
                        ]),
                      ),
                      if (s['quiz'] != null)
                        IconButton(icon: const Icon(Icons.quiz_outlined), onPressed: () => _open(QuizScreen(session: s))),
                      if (s['solved'] == true) const Icon(Icons.check_circle_outline_rounded),
                    ]),
                  ),
                ),
              ),
        ]),
      ),
    );
  }

  Widget _action(IconData i, String key, VoidCallback f) => Box(
        onTap: f,
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(children: [Icon(i, size: 30), const SizedBox(height: 8), Text(context.tr(key), style: const TextStyle(fontWeight: FontWeight.w700))]),
      );
}
