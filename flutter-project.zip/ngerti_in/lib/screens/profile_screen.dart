import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../core/api.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'paywall_screen.dart';
import 'settings_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Json? _p;
  int _count = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await Api.profile();
    final s = await Api.sessions();
    if (mounted) {
      setState(() {
        _p = p;
        _count = s.length;
      });
    }
  }

  Future<void> _logout() async {
    try {
      await GoogleSignIn().signOut();
    } catch (_) {}
    await Api.sb.auth.signOut();
  }

  Widget _stat(IconData i, String v, String l) {
    final k = context.c;
    return Box(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      child: Column(children: [
        Icon(i),
        const SizedBox(height: 6),
        Text(v, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        Text(l, textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5, color: k.muted)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final k = context.c;
    final p = _p;
    final premium = Api.isPremium(p);
    final total = (p?['answers_total'] ?? 0) as int;
    final ok = (p?['answers_correct'] ?? 0) as int;
    final acc = total == 0 ? '-' : '${(ok * 100 / total).round()}%';
    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('nav_profile')),
        actions: [
          IconButton(
            tooltip: context.tr('settings'),
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 24), children: [
          Box(
            child: Row(children: [
              CircleAvatar(radius: 28, backgroundColor: k.soft, child: Icon(Icons.person_outline_rounded, color: k.ink, size: 30)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${p?['display_name'] ?? ''}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                  Text(Api.sb.auth.currentUser?.email ?? '', style: TextStyle(color: k.muted, fontSize: 13)),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: _stat(Icons.task_alt_rounded, '$_count', context.tr('stat_solved'))),
            const SizedBox(width: 10),
            Expanded(child: _stat(Icons.local_fire_department_outlined, '${Api.effectiveStreak(p)}', context.tr('stat_streak'))),
            const SizedBox(width: 10),
            Expanded(child: _stat(Icons.insights_rounded, acc, context.tr('stat_acc'))),
          ]),
          const SizedBox(height: 16),
          Box(
            strong: true,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PaywallScreen())).then((_) => _load()),
            child: Row(children: [
              const Icon(Icons.workspace_premium_outlined, size: 30),
              const SizedBox(width: 12),
              Expanded(child: Text(context.tr(premium ? 'premium_on' : 'upgrade'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
              const Icon(Icons.chevron_right_rounded),
            ]),
          ),
          const SizedBox(height: 24),
          OutlinedButton.icon(onPressed: _logout, icon: const Icon(Icons.logout_rounded), label: Text(context.tr('logout'))),
        ]),
      ),
    );
  }
}
