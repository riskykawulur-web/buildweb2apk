import 'package:flutter/material.dart';
import 'package:gpt_markdown/gpt_markdown.dart';
import '../core/l10n.dart';
import '../core/theme.dart';

/// Ubah $...$ dan $$...$$ menjadi format LaTeX yang dibaca renderer.
String normalizeMath(String t) {
  var s = t.replaceAllMapped(RegExp(r'\$\$([\s\S]+?)\$\$'), (m) => '\n\\[${m[1]}\\]\n');
  s = s.replaceAllMapped(RegExp(r'(?<![\\$])\$([^\$\n]+?)\$'), (m) => '\\(${m[1]}\\)');
  return s;
}

class MathText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  const MathText(this.text, {super.key, this.style});
  @override
  Widget build(BuildContext context) =>
      GptMarkdown(normalizeMath(text), style: style ?? TextStyle(color: context.c.ink, fontSize: 15, height: 1.45));
}

class AppLogo extends StatelessWidget {
  final double size;
  const AppLogo({super.key, this.size = 40});
  @override
  Widget build(BuildContext context) {
    final k = context.c;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: k.ink, borderRadius: BorderRadius.circular(size * .3)),
      child: Icon(Icons.lightbulb_outline_rounded, color: k.onInk, size: size * .58),
    );
  }
}

/// Kartu bergaris tipis, tanpa gradien. strong = garis tebal, inverse = hitam penuh.
class Box extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final bool strong, inverse;
  final Color? fill;
  const Box({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap, this.strong = false, this.inverse = false, this.fill});
  @override
  Widget build(BuildContext context) {
    final k = context.c;
    Widget body = child;
    if (inverse) {
      body = DefaultTextStyle.merge(style: TextStyle(color: k.onInk), child: IconTheme.merge(data: IconThemeData(color: k.onInk), child: child));
    }
    return Material(
      color: Colors.transparent,
      child: Ink(
        decoration: BoxDecoration(
          color: inverse ? k.ink : (fill ?? k.bg),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: strong || inverse ? k.ink : k.line, width: strong ? 2 : 1),
        ),
        child: InkWell(borderRadius: BorderRadius.circular(20), onTap: onTap, child: Padding(padding: padding, child: body)),
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  const Pill({super.key, required this.icon, required this.label, this.onTap});
  @override
  Widget build(BuildContext context) {
    final k = context.c;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), border: Border.all(color: k.ink, width: 1.2)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 16, color: k.ink),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: k.ink)),
        ]),
      ),
    );
  }
}

/// Tombol pilihan dua sisi (hitam = aktif).
class SegChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback? onTap;
  const SegChip({super.key, required this.label, required this.icon, required this.selected, this.onTap});
  @override
  Widget build(BuildContext context) {
    final k = context.c;
    final fg = selected ? k.onInk : (onTap == null ? k.muted : k.ink);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? k.ink : Colors.transparent,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: selected ? k.ink : k.line, width: 1.2),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 16, color: fg),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: fg)),
        ]),
      ),
    );
  }
}

class MessageBubble extends StatelessWidget {
  final bool mine;
  final String text;
  final String? tag; // correct | wrong | hint
  const MessageBubble({super.key, required this.mine, required this.text, this.tag});
  @override
  Widget build(BuildContext context) {
    final k = context.c;
    final w = MediaQuery.of(context).size.width * .86;
    final head = switch (tag) {
      'correct' => (Icons.check_circle_outline_rounded, context.tr('correct')),
      'wrong' => (Icons.highlight_off_rounded, context.tr('wrong')),
      'hint' => (Icons.lightbulb_outline_rounded, context.tr('hint')),
      _ => null,
    };
    return Align(
      alignment: mine ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
      child: Container(
        constraints: BoxConstraints(maxWidth: w),
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: mine ? k.ink : k.soft,
          borderRadius: BorderRadius.circular(20),
          border: mine ? null : Border.all(color: k.line),
        ),
        child: mine
            ? Text(text, style: TextStyle(color: k.onInk, fontSize: 15, height: 1.4))
            : Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                if (head != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(head.$1, size: 18, color: k.ink),
                      const SizedBox(width: 6),
                      Text(head.$2, style: TextStyle(fontWeight: FontWeight.w800, color: k.ink)),
                    ]),
                  ),
                MathText(text),
              ]),
      ),
    );
  }
}

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))));
}
