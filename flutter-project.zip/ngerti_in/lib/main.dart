import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/ads.dart';
import 'core/config.dart';
import 'core/l10n.dart';
import 'core/theme.dart';
import 'screens/auth_screen.dart';
import 'screens/shell.dart';
import 'widgets/common.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const Boot());
}

/// Splash screen sambil inisialisasi (Supabase, pengaturan, iklan).
class Boot extends StatefulWidget {
  const Boot({super.key});
  @override
  State<Boot> createState() => _BootState();
}

class _BootState extends State<Boot> {
  late final Future<void> _init = _initAll();

  Future<void> _initAll() async {
    if (Config.supabaseUrl.isEmpty || Config.supabaseAnonKey.isEmpty) {
      throw 'SUPABASE_URL / SUPABASE_ANON_KEY belum diisi.\nJalankan app dengan --dart-define (lihat panduan).';
    }
    await Future.wait([
      AppState.load(),
      initializeDateFormatting(),
      Supabase.initialize(url: Config.supabaseUrl, anonKey: Config.supabaseAnonKey),
      Future.delayed(const Duration(milliseconds: 900)),
    ]);
    Ads.init();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<void>(
        future: _init,
        builder: (_, s) => s.connectionState == ConnectionState.done && !s.hasError ? const NgertiApp() : _Splash(error: s.error),
      );
}

class _Splash extends StatelessWidget {
  final Object? error;
  const _Splash({this.error});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: buildTheme(Brightness.light),
        home: Builder(
          builder: (c) => Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const AppLogo(size: 72),
                  const SizedBox(height: 16),
                  const Text('Ngerti.in', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 24),
                  if (error == null)
                    const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                  else
                    Text('$error', textAlign: TextAlign.center, style: TextStyle(color: c.c.muted)),
                ]),
              ),
            ),
          ),
        ),
      );
}

class NgertiApp extends StatelessWidget {
  const NgertiApp({super.key});
  @override
  Widget build(BuildContext context) {
    final auth = Supabase.instance.client.auth;
    return LangScope(
      notifier: AppState.lang,
      child: ValueListenableBuilder<bool>(
        valueListenable: AppState.dark,
        builder: (_, dark, __) => ValueListenableBuilder<String>(
          valueListenable: AppState.lang,
          builder: (_, lang, __) => MaterialApp(
            title: 'Ngerti.in',
            debugShowCheckedModeBanner: false,
            theme: buildTheme(Brightness.light),
            darkTheme: buildTheme(Brightness.dark),
            themeMode: dark ? ThemeMode.dark : ThemeMode.light,
            locale: Locale(lang),
            supportedLocales: const [Locale('id'), Locale('ms'), Locale('en'), Locale('ar'), Locale('zh'), Locale('tr')],
            localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
            home: StreamBuilder<AuthState>(
              stream: auth.onAuthStateChange,
              builder: (_, __) => auth.currentSession == null ? const AuthScreen() : const Shell(),
            ),
          ),
        ),
      ),
    );
  }
}
