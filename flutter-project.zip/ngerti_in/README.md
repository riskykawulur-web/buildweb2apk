# Ngerti.in v3 (PRD 3.0) - proyek siap gabung

Flutter (Android + iOS) + Supabase (Auth, DB, Edge Functions) + Gemini API.
Kunci AI, kuota harian, kunci jawaban soal dan kunci kuis hanya ada di server.

## Susunan file
pubspec.yaml
supabase/schema.sql                    (aman dijalankan ulang; juga untuk yang sudah pernah menjalankan versi lama)
supabase/functions/ai/index.ts         (deploy ulang ke fungsi `ai`)
supabase/functions/premium-webhook/index.ts
lib/main.dart
lib/core/{config,theme,l10n,api,ads,image_util}.dart
lib/widgets/common.dart
lib/screens/{auth,shell,home,input_sheet,solve_input,session,quiz,tutor,profile,settings,paywall}_screen.dart

## Langkah singkat
1. Supabase SQL Editor: jalankan supabase/schema.sql
2. Edge Functions > secrets: GEMINI_API_KEY  (opsional: GEMINI_MODEL_FREE, GEMINI_MODEL_PREMIUM)
3. Edge Functions > ai: tempel isi supabase/functions/ai/index.ts, Deploy
4. flutter create . --org com.ngertiin --project-name ngerti_in ; flutter pub get
5. AndroidManifest.xml (android/app/src/main/AndroidManifest.xml):
   - di atas <application>:  <uses-permission android:name="android.permission.INTERNET"/>
   - di dalam <application> (WAJIB, kalau tidak app crash karena iklan):
       <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-3940256099942544~3347511713"/>
       <activity android:name="com.yalantis.ucrop.UCropActivity" android:screenOrientation="portrait" android:theme="@style/Theme.AppCompat.Light.NoActionBar"/>
   (ID di atas adalah ID TES Google. Ganti dengan ID AdMob milikmu sebelum rilis.)
6. Jika build error soal minSdk: di android/app/build.gradle(.kts) set minSdk ke 23.
7. flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
   Opsional: GOOGLE_WEB_CLIENT_ID, GOOGLE_IOS_CLIENT_ID, CHECKOUT_MONTHLY_URL, CHECKOUT_YEARLY_URL,
             ADMOB_BANNER_UNIT, ADMOB_INTERSTITIAL_UNIT (kosong = iklan tes)
8. iOS: Info.plist NSCameraUsageDescription, NSPhotoLibraryUsageDescription, GADApplicationIdentifier; capability Sign in with Apple.
