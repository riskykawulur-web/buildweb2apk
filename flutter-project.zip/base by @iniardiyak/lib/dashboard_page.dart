// ============ KIZZY - SHARE YATIM LU ============

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:ui' as dart_ui;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:xml/xml.dart' as xml;

import 'login_page.dart';
import 'home_page.dart';
import 'info_page.dart';
import 'tools_gateway.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'owner_page.dart';
import 'riwayat_page.dart';
import 'islamic_page.dart';
import 'games_page.dart';
import 'audio_service.dart';
import 'backsound_setting.dart';

// ============ NEOBRUTALISM PALETTE ============
const Color _bgPrimary = Color(0xFFF5F0E8);  // krem/off-white
const Color _bgCard = Color(0xFFFFFFFF);
const Color _bgDark = Color(0xFF1A1A1A);
const Color _black = Color(0xFF000000);
const Color _white = Color(0xFFFFFFFF);
const Color _neonYellow = Color(0xFFFFD700);
const Color _neonPink = Color(0xFFFF4D6D);
const Color _neonBlue = Color(0xFF4D6BFF);
const Color _neonGreen = Color(0xFF00E676);
const Color _neonOrange = Color(0xFFFF6B35);
const Color _neonPurple = Color(0xFFB44DFF);
const Color _borderColor = Color(0xFF000000);
const double _borderWidth = 3.0;

// ============ WARNA BACKGROUND FITUR ============
const Color _bgFeatureBlue = Color(0xFF4D6BFF);   // Biru neon
const Color _bgFeatureGreen = Color(0xFF00E676); // Hijau neon
// ============================================================

// ============================================================
// 🕐 WIDGET JAM - NEOBRUTALISM
// ============================================================
class LiveClockWidget extends StatefulWidget {
  const LiveClockWidget({super.key});

  @override
  State<LiveClockWidget> createState() => _LiveClockWidgetState();
}

class _LiveClockWidgetState extends State<LiveClockWidget> {
  String _time = "00:00:00";
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _updateTime();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) _updateTime();
    });
  }

  void _updateTime() {
    final now = DateTime.now();
    _time = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: _bgCard,
        border: Border.all(color: _black, width: _borderWidth),
        boxShadow: const [
          BoxShadow(
            color: _black,
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.access_time_rounded, color: _black, size: 16),
          const SizedBox(width: 8),
          Text(
            _time,
            style: const TextStyle(
              color: _black,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              fontFamily: 'ShareTechMono',
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// ============ SHOLAT SERVICE (SAMA) ============
class SholatService {
  String _getTimeZone(double longitude) {
    if (longitude >= 105 && longitude < 120) return "WIB";
    else if (longitude >= 120 && longitude < 135) return "WITA";
    else if (longitude >= 135 && longitude <= 150) return "WIT";
    else return "WIB";
  }

  Future<Map<String, dynamic>> getJadwalSholat(String cityId) async {
    try {
      final now = DateTime.now();
      final date = "${now.year}/${now.month.toString().padLeft(2, '0')}/${now.day.toString().padLeft(2, '0')}";
      final response = await http.get(
        Uri.parse('https://api.myquran.com/v1/sholat/jadwal/$cityId/$date'),
        headers: {'Accept': 'application/json'},
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
    } catch (e) { print('Error: $e'); }
    return {};
  }

  Future<List<dynamic>> searchKota(String query) async {
    try {
      final response = await http.get(
        Uri.parse('https://api.myquran.com/v1/sholat/kota/cari/$query'),
        headers: {'Accept': 'application/json'},
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['data'] ?? [];
      }
    } catch (e) { print('Error: $e'); }
    return [];
  }

  Future<List<dynamic>> getKotaList() async {
    try {
      final response = await http.get(
        Uri.parse('https://api.myquran.com/v1/sholat/kota/cari/'),
        headers: {'Accept': 'application/json'},
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['data'] ?? [];
      }
    } catch (e) { print('Error: $e'); }
    return [];
  }

  Future<Map<String, dynamic>?> getCurrentLocationCity() async {
    try {
      final status = await Permission.location.request();
      if (status != PermissionStatus.granted) return null;
      if (!await Geolocator.isLocationServiceEnabled()) return null;
      final position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.medium);
      final timeZone = _getTimeZone(position.longitude);
      final places = await placemarkFromCoordinates(position.latitude, position.longitude);
      if (places.isEmpty) return null;
      final place = places.first;
      String? cityName = place.locality ?? place.subLocality ?? place.subAdministrativeArea ?? place.administrativeArea;
      if (cityName == null) return null;
      String cleanName = cityName.toLowerCase()
          .replaceAll('kabupaten', '').replaceAll('kab.', '').replaceAll('kota', '')
          .replaceAll('kab', '').replaceAll('kot', '').trim();
      var searchResults = await searchKota(cleanName);
      if (searchResults.isEmpty && cleanName.contains(' ')) {
        final parts = cleanName.split(' ');
        for (var part in parts) {
          if (part.length > 3) {
            searchResults = await searchKota(part);
            if (searchResults.isNotEmpty) break;
          }
        }
      }
      if (searchResults.isEmpty && cleanName.contains(' ')) {
        final firstWord = cleanName.split(' ')[0];
        if (firstWord.length > 2) searchResults = await searchKota(firstWord);
      }
      if (searchResults.isEmpty) {
        final allCities = await getKotaList();
        Map<String, dynamic>? nearestCity;
        double minDistance = double.infinity;
        for (var city in allCities) {
          final cityLat = double.tryParse(city['lintang']?.toString() ?? '0') ?? 0;
          final cityLong = double.tryParse(city['bujur']?.toString() ?? '0') ?? 0;
          if (cityLat != 0 && cityLong != 0) {
            final distance = calculateDistance(position.latitude, position.longitude, cityLat, cityLong);
            if (distance < minDistance) { minDistance = distance; nearestCity = city; }
          }
        }
        if (nearestCity != null) {
          return {
            'cityId': nearestCity['id'].toString(),
            'cityName': nearestCity['lokasi']?.toString() ?? cityName,
            'timeZone': timeZone,
            'latitude': position.latitude,
            'longitude': position.longitude,
          };
        }
      }
      if (searchResults.isNotEmpty) {
        final cityData = searchResults[0];
        return {
          'cityId': cityData['id'].toString(),
          'cityName': cityData['lokasi']?.toString() ?? cityName,
          'timeZone': timeZone,
          'latitude': position.latitude,
          'longitude': position.longitude,
        };
      }
      return null;
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const R = 6371;
    final dLat = _toRadians(lat2 - lat1);
    final dLon = _toRadians(lon2 - lon1);
    final a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_toRadians(lat1)) * cos(_toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2);
    final c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return R * c;
  }

  double _toRadians(double degree) => degree * pi / 180;
}

// ============ DASHBOARD PAGE ============
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();

  int onlineUsers = 0;
  int activeConnections = 0;

  late PageController _newsPageController;
  double _currentNewsPage = 0.0;
  Timer? _newsTimer;

  // 🕌 JADWAL SHOLAT
  Map<String, dynamic>? _jadwalSholat;
  List<dynamic> _cityList = [];
  String _selectedCityId = "1227";
  String _selectedCityName = "Jakarta";
  bool _isLoadingSholat = true;
  bool _useCurrentLocation = false;
  final SholatService _sholatService = SholatService();

  // 🎌 ANIME
  List<Map<String, dynamic>> _animeData = [];
  bool _isLoadingAnime = true;

  // 📰 RSS NEWS
  final String _newsUrl = "https://www.antaranews.com/rss/terkini.xml";
  List<Map<String, dynamic>> _newsData = [];
  bool _isLoadingNews = true;
  String _newsError = "";

  // 🌤️ WEATHER
  Map<String, dynamic>? weatherData;
  bool isLoadingWeather = true;
  String weatherErrorMsg = "";

  late PageController _quickAccessController;
  double _currentQuickAccessPage = 0.0;

  // ============ BACKGROUND MUSIC ============
  final AudioService _audioService = AudioService();
  bool _isSoundOn = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _initNewsBanner();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _controller.forward();

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _fetchSholatTimes();
    _fetchAnimeData();
    _initWeather();

    _quickAccessController = PageController(viewportFraction: 0.85);
    _quickAccessController.addListener(() {
      if (_quickAccessController.hasClients && _quickAccessController.page != null) {
        _currentQuickAccessPage = _quickAccessController.page!;
      }
    });

    _selectedPage = _buildNewsPage();
    _fetchRssNews();
    _initBackgroundMusic();
  }

  void _initBackgroundMusic() {
    _isSoundOn = _audioService.isEnabled;
    if (_isSoundOn) _audioService.resume();
    setState(() {});
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _newsTimer?.cancel();
    _newsPageController.dispose();
    _quickAccessController.dispose();
    _controller.dispose();
    channel.sink.close(status.goingAway);
    _audioService.pause();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _audioService.pause();
    } else if (state == AppLifecycleState.resumed) {
      if (_isSoundOn) _audioService.resume();
    }
  }

  // ============================================================
  // 📰 RSS NEWS
  // ============================================================
  Future<void> _fetchRssNews() async {
    setState(() { _isLoadingNews = true; _newsError = ""; });
    try {
      final response = await http.get(Uri.parse(_newsUrl)).timeout(
        const Duration(seconds: 8),
        onTimeout: () => http.Response('Timeout', 408),
      );
      if (response.statusCode == 200) {
        final document = xml.XmlDocument.parse(response.body);
        final items = document.findAllElements('item');
        List<Map<String, dynamic>> tempNews = [];
        for (var item in items) {
          if (tempNews.length >= 10) break;
          final title = item.findElements('title').singleOrNull?.innerText ?? '';
          final pubDate = item.findElements('pubDate').singleOrNull?.innerText ?? '';
          final description = item.findElements('description').singleOrNull?.innerText ?? '';
          final link = item.findElements('link').singleOrNull?.innerText ?? '';
          final enclosure = item.findElements('enclosure').singleOrNull;
          String imageUrl = '';
          if (enclosure != null) imageUrl = enclosure.getAttribute('url') ?? '';
          if (imageUrl.isEmpty && description.contains('src="')) {
            final match = RegExp(r'src="(.*?)"').firstMatch(description);
            if (match != null) imageUrl = match.group(1) ?? '';
          }
          final cleanDesc = description.replaceAll(RegExp(r'<[^>]*>'), '').replaceAll('&nbsp;', ' ').trim();
          tempNews.add({
            'title': title,
            'pubDate': pubDate,
            'description': cleanDesc,
            'imageUrl': imageUrl,
            'link': link,
          });
        }
        if (mounted) setState(() { _newsData = tempNews; _isLoadingNews = false; });
      } else {
        if (mounted) setState(() { _newsError = "Server sibuk"; _isLoadingNews = false; });
      }
    } catch (e) {
      if (mounted) setState(() { _newsError = "Gagal memuat berita"; _isLoadingNews = false; });
    }
  }

  // ============================================================
  // 🌤️ WEATHER
  // ============================================================
  Future<void> _initWeather() async {
    setState(() { isLoadingWeather = true; weatherErrorMsg = ""; });
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() { isLoadingWeather = false; weatherErrorMsg = "GPS tidak aktif"; });
      return;
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() { isLoadingWeather = false; weatherErrorMsg = "Izin lokasi ditolak"; });
        return;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      setState(() { isLoadingWeather = false; weatherErrorMsg = "Izin lokasi ditolak permanen"; });
      return;
    }
    try {
      Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.medium);
      await _fetchWeather(position.latitude, position.longitude);
    } catch (e) {
      setState(() { isLoadingWeather = false; weatherErrorMsg = "Gagal mendapatkan lokasi"; });
    }
  }

  Future<void> _fetchWeather(double lat, double lon) async {
    try {
      final String apiKey = "68296d0a3a5d6ee2b5cb993918d19ef9";
      final url = Uri.parse("https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey&units=metric");
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() { weatherData = jsonDecode(response.body); isLoadingWeather = false; });
      } else {
        setState(() { isLoadingWeather = false; weatherErrorMsg = "Gagal load data cuaca"; });
      }
    } catch (e) {
      setState(() { isLoadingWeather = false; weatherErrorMsg = "Terjadi kesalahan"; });
    }
  }

  IconData _getWeatherIcon(String condition) {
    final cond = condition.toLowerCase();
    if (cond.contains('clear')) return FontAwesomeIcons.sun;
    if (cond.contains('clouds')) return FontAwesomeIcons.cloud;
    if (cond.contains('rain') || cond.contains('drizzle')) return FontAwesomeIcons.cloudRain;
    if (cond.contains('thunderstorm')) return FontAwesomeIcons.cloudBolt;
    if (cond.contains('snow')) return FontAwesomeIcons.snowflake;
    if (cond.contains('mist') || cond.contains('fog') || cond.contains('haze')) return FontAwesomeIcons.smog;
    return FontAwesomeIcons.cloudSun;
  }

  // ============================================================
  // 🕌 SHOLAT
  // ============================================================
  Future<void> _fetchSholatTimes() async {
    setState(() { _isLoadingSholat = true; });
    try {
      final locationData = await _sholatService.getCurrentLocationCity();
      if (locationData != null && mounted) {
        final cityId = locationData['cityId'];
        final cityName = locationData['cityName'];
        setState(() { _selectedCityId = cityId; _selectedCityName = cityName; _useCurrentLocation = true; });
        await _fetchSholatSchedule(cityId);
        _saveLocationPreference(cityId, cityName);
      } else {
        await _loadSavedLocation();
      }
    } catch (e) {
      print('Error: $e');
      _setDefaultSholatSchedule();
    } finally {
      if (mounted) setState(() { _isLoadingSholat = false; });
    }
  }

  Future<void> _fetchSholatSchedule(String cityId) async {
    if (!mounted) return;
    try {
      final data = await _sholatService.getJadwalSholat(cityId).timeout(
        const Duration(seconds: 8),
        onTimeout: () => {},
      );
      if (mounted && data.isNotEmpty && data['status'] == true) {
        setState(() { _jadwalSholat = data['data']; });
      } else {
        _setDefaultSholatSchedule();
      }
    } catch (e) {
      _setDefaultSholatSchedule();
    } finally {
      if (mounted) setState(() { _isLoadingSholat = false; });
    }
  }

  Future<void> _saveLocationPreference(String cityId, String cityName) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('last_city_id', cityId);
      await prefs.setString('last_city_name', cityName);
      await prefs.setBool('use_current_location', true);
    } catch (e) { print('Error: $e'); }
  }

  Future<void> _loadSavedLocation() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedCityId = prefs.getString('last_city_id');
      final savedCityName = prefs.getString('last_city_name');
      final useCurrentLocation = prefs.getBool('use_current_location') ?? false;
      if (savedCityId != null && savedCityName != null) {
        setState(() { _selectedCityId = savedCityId; _selectedCityName = savedCityName; _useCurrentLocation = useCurrentLocation; });
        await _fetchSholatSchedule(savedCityId);
      } else {
        _setDefaultSholatSchedule();
      }
    } catch (e) { _setDefaultSholatSchedule(); }
  }

  void _setDefaultSholatSchedule() {
    if (mounted) {
      setState(() {
        _jadwalSholat = {
          'lokasi': 'Jakarta',
          'daerah': 'DKI Jakarta',
          'jadwal': {
            'imsak': '04:22',
            'subuh': '04:32',
            'terbit': '05:46',
            'dzuhur': '12:08',
            'ashar': '15:30',
            'maghrib': '18:20',
            'isya': '19:33',
          }
        };
        _isLoadingSholat = false;
      });
    }
  }

  String _getNextSholatTime() {
    if (_jadwalSholat == null || _jadwalSholat!['jadwal'] == null) return "Mengambil jadwal...";
    final jadwal = _jadwalSholat!['jadwal'];
    final now = DateTime.now();
    final currentTime = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final sholatTimes = [
      {'name': 'Subuh', 'time': jadwal['subuh']?.toString() ?? '04:32'},
      {'name': 'Dzuhur', 'time': jadwal['dzuhur']?.toString() ?? '12:08'},
      {'name': 'Ashar', 'time': jadwal['ashar']?.toString() ?? '15:30'},
      {'name': 'Maghrib', 'time': jadwal['maghrib']?.toString() ?? '18:20'},
      {'name': 'Isya', 'time': jadwal['isya']?.toString() ?? '19:33'},
    ];
    for (var sholat in sholatTimes) {
      if (_isTimeLater(sholat['time']!, currentTime)) {
        return "Menuju ${sholat['name']} : ${sholat['time']}";
      }
    }
    return "Menuju Imsak : ${jadwal['imsak']?.toString() ?? '04:22'}";
  }

  bool _isTimeLater(String time1, String time2) {
    try {
      final t1 = time1.split(':'); final t2 = time2.split(':');
      final h1 = int.tryParse(t1[0]) ?? 0; final m1 = int.tryParse(t1[1]) ?? 0;
      final h2 = int.tryParse(t2[0]) ?? 0; final m2 = int.tryParse(t2[1]) ?? 0;
      return h1 > h2 || (h1 == h2 && m1 > m2);
    } catch (e) { return false; }
  }

  bool _isCurrentSholat(String sholatName, String? sholatTime) {
    if (sholatTime == null) return false;
    try {
      final now = DateTime.now();
      final currentTime = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
      final st = sholatTime.length >= 5 ? sholatTime.substring(0, 5) : sholatTime;
      return st == currentTime;
    } catch (e) { return false; }
  }

  // ============================================================
  // 🏙️ CITY SELECTOR - NEOBRUTALISM
  // ============================================================
  void _showCitySelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Container(
              height: MediaQuery.of(context).size.height * 0.8,
              decoration: BoxDecoration(
                color: _bgPrimary,
                border: Border.all(color: _black, width: _borderWidth),
                boxShadow: const [
                  BoxShadow(
                    color: _black,
                    offset: Offset(8, -8),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: _black,
                      border: Border(bottom: BorderSide(color: _white, width: 2)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.location_on, color: _neonYellow),
                            const SizedBox(width: 12),
                            const Text(
                              'Pilih Lokasi Sholat',
                              style: TextStyle(
                                color: _white,
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: _white),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _neonYellow,
                              foregroundColor: _black,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                              ),
                              side: const BorderSide(color: _black, width: _borderWidth),
                              textStyle: const TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                              ),
                            ),
                            onPressed: () async {
                              Navigator.pop(context);
                              await _fetchSholatTimes();
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.gps_fixed, color: _black),
                                SizedBox(width: 10),
                                Text('Gunakan Lokasi Saat Ini'),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          style: const TextStyle(color: _black),
                          decoration: InputDecoration(
                            hintText: 'Cari kota/kabupaten...',
                            hintStyle: const TextStyle(color: Colors.grey),
                            filled: true,
                            fillColor: _white,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.zero,
                              borderSide: const BorderSide(color: _black, width: _borderWidth),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.zero,
                              borderSide: const BorderSide(color: _black, width: _borderWidth),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.zero,
                              borderSide: const BorderSide(color: _black, width: _borderWidth),
                            ),
                            prefixIcon: const Icon(Icons.search, color: _black),
                          ),
                          onChanged: (value) async {
                            if (value.length > 2) {
                              final results = await _sholatService.searchKota(value);
                              setState(() { _cityList = results; });
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _cityList.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.search, color: Colors.grey.shade600, size: 50),
                                const SizedBox(height: 16),
                                const Text(
                                  'Cari kota atau kabupaten',
                                  style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
                                ),
                                const Text(
                                  'Minimal 3 karakter',
                                  style: TextStyle(color: Colors.grey, fontSize: 12),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            itemCount: _cityList.length,
                            itemBuilder: (context, index) {
                              final city = _cityList[index];
                              return Container(
                                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _white,
                                  border: Border.all(color: _black, width: _borderWidth),
                                ),
                                child: ListTile(
                                  title: Text(
                                    city['lokasi']?.toString() ?? 'Unknown',
                                    style: const TextStyle(color: _black, fontWeight: FontWeight.w700),
                                  ),
                                  subtitle: city['daerah'] != null
                                      ? Text(city['daerah'].toString(), style: const TextStyle(color: Colors.grey))
                                      : null,
                                  trailing: _selectedCityId == city['id'].toString()
                                      ? const Icon(Icons.check, color: _neonGreen)
                                      : null,
                                  onTap: () async {
                                    if (mounted) {
                                      setState(() {
                                        _selectedCityId = city['id'].toString();
                                        _selectedCityName = city['lokasi']?.toString() ?? 'Jakarta';
                                        _useCurrentLocation = false;
                                        _isLoadingSholat = true;
                                      });
                                    }
                                    await _fetchSholatSchedule(city['id'].toString());
                                    if (mounted) {
                                      setState(() { _isLoadingSholat = false; });
                                      Navigator.pop(context);
                                    }
                                  },
                                ),
                              );
                            },
                          ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(16),
                    color: _black,
                    child: Row(
                      children: [
                        const Icon(Icons.info_outline, color: _white, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Pilih kota untuk mendapatkan jadwal sholat yang akurat',
                            style: TextStyle(color: _white, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ============================================================
  // 🎌 FETCH ANIME
  // ============================================================
  Future<void> _fetchAnimeData() async {
    setState(() => _isLoadingAnime = true);
    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/home'),
      ).timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        if (jsonData is Map && jsonData.containsKey('data')) {
          final data = jsonData['data'];
          if (data is Map && data.containsKey('ongoing')) {
            final ongoing = data['ongoing'];
            if (ongoing is Map && ongoing.containsKey('animeList')) {
              final animeList = ongoing['animeList'] as List;
              _animeData = List<Map<String, dynamic>>.from(animeList.take(10));
            }
          }
        }
      }
      setState(() => _isLoadingAnime = false);
    } catch (e) {
      setState(() => _isLoadingAnime = false);
    }
  }

  void _initNewsBanner() {
    _newsPageController = PageController(initialPage: 0, viewportFraction: 0.92);
    _newsPageController.addListener(() {
      if (_newsPageController.hasClients && _newsPageController.page != null) {
        _currentNewsPage = _newsPageController.page!;
      }
    });
    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
        if (_newsPageController.hasClients) {
          int targetIndex = (_currentNewsPage + 1).round() % newsList.length;
          _newsPageController.animateToPage(
            targetIndex,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
          );
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() { _profileImage = File(imagePath); });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(Uri.parse('wss://ws-dark.strideoryx.my.id'));
      channel.sink.add(jsonEncode({"type": "validate", "key": sessionKey, "androidId": androidId}));
      channel.sink.add(jsonEncode({"type": "stats"}));
      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == false) {
          String message = data['reason'] == 'androidIdMismatch'
              ? "Your account has logged on another device."
              : "Key is not valid. Please login again.";
          _handleInvalidSession(message);
        }
        if (data['type'] == 'stats') {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      }, onError: (error) {
        debugPrint('WebSocket error: $error');
      });
    } catch (e) {
      debugPrint('Failed to connect WebSocket: $e');
    }
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _bgPrimary,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
        ),
        title: Row(
          children: const [
            Icon(Icons.warning_amber_rounded, color: _neonPink, size: 28),
            SizedBox(width: 12),
            Expanded(child: Text("Session Expired", style: TextStyle(color: _black, fontWeight: FontWeight.w900, fontSize: 18))),
          ],
        ),
        content: Text(message, style: const TextStyle(color: _black, fontSize: 14)),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _neonYellow,
              foregroundColor: _black,
              shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              side: const BorderSide(color: _black, width: _borderWidth),
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
              textStyle: const TextStyle(fontWeight: FontWeight.w900),
            ),
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const LoginPage()),
              (route) => false,
            ),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    if (index == 1) { _showWhatsAppMenu(); return; }
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
        if (_isSoundOn) _audioService.resume();
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
        _audioService.pause();
      } else if (index == 3) {
        _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
        _audioService.pause();
      }
    });
  }

  void _showWhatsAppMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: _bgPrimary,
            border: Border.all(color: _black, width: _borderWidth),
            boxShadow: const [
              BoxShadow(
                color: _black,
                offset: Offset(8, -8),
                blurRadius: 0,
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60,
                height: 6,
                margin: const EdgeInsets.only(bottom: 24),
                color: _black,
              ),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _black,
                      border: Border.all(color: _neonGreen, width: 2),
                    ),
                    child: const Icon(FontAwesomeIcons.whatsapp, color: _neonGreen, size: 24),
                  ),
                  const SizedBox(width: 16),
                  const Text(
                    "WHATSAPP TOOLS",
                    style: TextStyle(
                      color: _black,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              _buildSheetItem(
                icon: Icons.bug_report_rounded,
                iconColor: _neonPink,
                title: "WhatsApp Crash",
                subtitle: "Send payloads & crash codes",
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _bottomNavIndex = 1;
                    _selectedPage = HomePage(
                      username: username,
                      password: password,
                      listBug: listBug,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                    );
                  });
                  _audioService.pause();
                },
              ),
              const SizedBox(height: 12),
              Container(
                height: 2,
                color: _black,
              ),
              const SizedBox(height: 12),
              _buildSheetItem(
                icon: Icons.devices_rounded,
                iconColor: _neonBlue,
                title: "Manage Sender",
                subtitle: "Pair devices & manage sessions",
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)));
                  _audioService.pause();
                },
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSheetItem({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        splashColor: _neonYellow.withOpacity(0.3),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _white,
            border: Border.all(color: _black, width: _borderWidth),
            boxShadow: const [
              BoxShadow(
                color: _black,
                offset: Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                color: _black,
                child: Icon(icon, color: iconColor, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: _black,
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, color: _black, size: 16),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🕌 PRAYER TIME CARD - NEOBRUTALISM
  // ============================================================
  Widget _buildPrayerTimeCard({
    required String prayerName,
    required String time,
    required IconData icon,
    required Color color,
    required bool isNext,
  }) {
    return Container(
      width: 110,
      decoration: BoxDecoration(
        color: _white,
        border: Border.all(color: _black, width: _borderWidth),
        boxShadow: const [
          BoxShadow(
            color: _black,
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  color: _black,
                  child: Icon(icon, color: color, size: 18),
                ),
                const Spacer(),
                if (isNext)
                  Container(
                    width: 12,
                    height: 12,
                    color: _neonGreen,
                  ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              prayerName.toUpperCase(),
              style: const TextStyle(
                color: _black,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              time,
              style: const TextStyle(
                color: _black,
                fontSize: 20,
                fontWeight: FontWeight.w900,
                fontFamily: 'ShareTechMono',
              ),
            ),
            const SizedBox(height: 6),
            Container(
              width: 30,
              height: 4,
              color: isNext ? _neonGreen : _black,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animation,
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: _bgPrimary,
        drawer: _buildCustomDrawer(),
        body: Container(
          color: _bgPrimary,
          child: _selectedPage,
        ),
        bottomNavigationBar: _buildBottomNav(),
      ),
    );
  }

  // ============================================================
  // BOTTOM NAV - NEOBRUTALISM
  // ============================================================
  Widget _buildBottomNav() {
    return Container(
      height: 72,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: _white,
        border: Border.all(color: _black, width: _borderWidth),
        boxShadow: const [
          BoxShadow(
            color: _black,
            offset: Offset(6, 6),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildNavIcon(index: 0, icon: Icons.home_filled),
          _buildNavIcon(index: 1, icon: FontAwesomeIcons.whatsapp),
          _buildNavIcon(index: 2, icon: Icons.notifications_none_rounded),
          _buildNavIcon(index: 3, icon: Icons.build_outlined),
        ],
      ),
    );
  }

  Widget _buildNavIcon({required int index, required IconData icon}) {
    final bool isActive = _bottomNavIndex == index;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _onBottomNavTapped(index),
        splashColor: _neonYellow.withOpacity(0.3),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: isActive ? _neonYellow : Colors.transparent,
            border: isActive ? Border.all(color: _black, width: _borderWidth) : null,
          ),
          child: Icon(
            icon,
            size: 24,
            color: isActive ? _black : Colors.grey,
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 📄 BUILD NEWS PAGE
  // ============================================================
  Widget _buildNewsPage() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 10),

          // ============ HEADER ============
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  color: _white,
                  child: IconButton(
                    icon: const Icon(Icons.menu, color: _black, size: 24),
                    onPressed: () => _scaffoldKey.currentState?.openDrawer(),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: _black,
                    border: Border.all(color: _neonYellow, width: 2),
                  ),
                  child: const Text(
                    "CRASH VOID",
                    style: TextStyle(
                      color: _neonYellow,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                      letterSpacing: 2.0,
                    ),
                  ),
                ),
                Row(
                  children: [
                    // Music toggle
                    GestureDetector(
                      onTap: () {
                        _audioService.pause();
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const SettingPage()),
                        ).then((_) {
                          setState(() { _isSoundOn = _audioService.isEnabled; });
                          if (_isSoundOn) _audioService.resume();
                        });
                      },
                      child: Container(
                        color: _white,
                        padding: const EdgeInsets.all(8),
                        child: Icon(
                          _isSoundOn ? Icons.music_note_rounded : Icons.music_off_rounded,
                          color: _black,
                          size: 20,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      color: _white,
                      child: IconButton(
                        icon: const Icon(Icons.headset_mic_outlined, color: _black, size: 20),
                        onPressed: () {
                          _audioService.pause();
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage()));
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      color: _white,
                      child: IconButton(
                        icon: const Icon(Icons.account_circle_outlined, color: _black, size: 24),
                        onPressed: () {
                          _audioService.pause();
                          Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(
                            username: username,
                            password: password,
                            role: role,
                            expiredDate: expiredDate,
                            sessionKey: sessionKey,
                          )));
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // ============ PROFILE CARD - NEOBRUTALISM ============
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              width: double.infinity,
              height: 250,
              decoration: BoxDecoration(
                color: _white,
                border: Border.all(color: _black, width: _borderWidth),
                boxShadow: const [
                  BoxShadow(
                    color: _black,
                    offset: Offset(8, 8),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: ClipRRect(
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    const _ProfileVideoBackground(
                      videoPath: 'assets/videos/bg_profile.mp4',
                    ),
                    Container(
                      color: Colors.black.withOpacity(0.5),
                    ),
                    Positioned(
                      top: 20,
                      left: 20,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                color: _neonYellow,
                                child: const Icon(
                                  Icons.waving_hand,
                                  color: _black,
                                  size: 16,
                                ),
                              ),
                              const SizedBox(width: 8),
                              const Text(
                                "Welcome Back,",
                                style: TextStyle(
                                  color: _white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "Hai, ${username.toUpperCase()}",
                            style: const TextStyle(
                              color: _white,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.5,
                              shadows: [
                                Shadow(
                                  color: _black,
                                  blurRadius: 10,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Center(
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.88,
                        height: 115,
                        margin: const EdgeInsets.only(top: 65),
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                        decoration: BoxDecoration(
                          color: _white,
                          border: Border.all(color: _black, width: _borderWidth),
                          boxShadow: const [
                            BoxShadow(
                              color: _black,
                              offset: Offset(6, 6),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              color: _black,
                              child: const Text(
                                "ACCOUNT STATUS",
                                style: TextStyle(
                                  color: _neonYellow,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.2,
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  color: _black,
                                  child: const Icon(Icons.security, color: _neonYellow, size: 14),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    "Role: ${role.toUpperCase()}",
                                    style: const TextStyle(
                                      color: _black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  color: _black,
                                  child: const Icon(Icons.access_time, color: _neonYellow, size: 14),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    "Expired: $expiredDate",
                                    style: const TextStyle(
                                      color: _black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 32),

          // ============ BERITA TERKINI + JAM (Hijau) ============
          _buildNewsWithClockCard(),
          const SizedBox(height: 32),

          // ============ THANX TO - BIZZ (Biru) ============
          _buildThanksAndDeveloper(),
          const SizedBox(height: 32),

          // ============ WEATHER (Biru) ============
          _buildWeatherCard(),
          const SizedBox(height: 32),

          // ============ SHOLAT (Hijau) ============
          _buildSholatCard(),
          const SizedBox(height: 32),

          // ============ LATEST ANIME (Biru) ============
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: _bgFeatureBlue,
                border: Border.all(color: _black, width: _borderWidth),
                boxShadow: const [
                  BoxShadow(
                    color: _black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        color: _black,
                        child: const Icon(Icons.live_tv_rounded, color: _neonYellow, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "LATEST ANIME",
                        style: TextStyle(
                          color: _black,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const Spacer(),
                      if (_animeData.isNotEmpty)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          color: _black,
                          child: Text(
                            "${_animeData.length} Anime",
                            style: const TextStyle(
                              color: _neonYellow,
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  if (_isLoadingAnime)
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Column(
                          children: [
                            SizedBox(
                              width: 30,
                              height: 30,
                              child: CircularProgressIndicator(
                                color: _black,
                                strokeWidth: 3,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              "Memuat anime...",
                              style: TextStyle(
                                color: Colors.black54,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  else if (_animeData.isEmpty)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        child: Text(
                          "No anime data available",
                          style: TextStyle(
                            color: Colors.black54,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    )
                  else
                    SizedBox(
                      height: 210,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: _animeData.length,
                        itemBuilder: (context, index) {
                          final anime = _animeData[index];
                          final title = anime['title'] ?? 'Unknown';
                          final poster = anime['poster'] ?? '';
                          final episode = anime['episodes']?.toString() ?? '?';

                          return Container(
                            width: 140,
                            margin: const EdgeInsets.only(right: 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(color: _black, width: _borderWidth),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: _black,
                                        offset: Offset(3, 3),
                                        blurRadius: 0,
                                      ),
                                    ],
                                  ),
                                  child: ClipRRect(
                                    child: Stack(
                                      children: [
                                        Image.network(
                                          poster,
                                          height: 160,
                                          width: 140,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) => Container(
                                            height: 160,
                                            width: 140,
                                            color: Colors.grey.shade300,
                                            child: const Icon(Icons.image_not_supported, color: Colors.grey, size: 40),
                                          ),
                                        ),
                                        Positioned(
                                          top: 8,
                                          right: 8,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                            color: _black,
                                            child: Text(
                                              "EP $episode",
                                              style: const TextStyle(
                                                color: _neonYellow,
                                                fontSize: 9,
                                                fontWeight: FontWeight.w900,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  title,
                                  style: const TextStyle(
                                    color: _black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 32),

          // ============ COMMUNITY HUB (Hijau) ============
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: _bgFeatureGreen,
                border: Border.all(color: _black, width: _borderWidth),
                boxShadow: const [
                  BoxShadow(
                    color: _black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        color: _black,
                        child: const Icon(Icons.groups_rounded, color: _neonBlue, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "COMMUNITY HUB",
                        style: TextStyle(
                          color: _black,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Stay connected with the CRASH VOID community. Get real-time updates, access exclusive payloads, and participate in discussions with other members.",
                    style: TextStyle(
                      color: Colors.black87,
                      fontSize: 13,
                      height: 1.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),

          // ============ JOIN TELEGRAM - NEOBRUTALISM ============
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              height: 60,
              decoration: BoxDecoration(
                color: _black,
                border: Border.all(color: _neonYellow, width: _borderWidth),
                boxShadow: const [
                  BoxShadow(
                    color: _black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: TextButton(
                style: TextButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
                ),
                onPressed: () => _openUrl("https://t.me/KENZZZXD"),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(FontAwesomeIcons.telegram, color: _neonYellow, size: 22),
                    SizedBox(width: 12),
                    Text(
                      "Join Telegram Channel",
                      style: TextStyle(
                        color: _neonYellow,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),

          // ============ QUICK ACCESS (Biru) ============
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: _bgFeatureBlue,
                border: Border.all(color: _black, width: _borderWidth),
                boxShadow: const [
                  BoxShadow(
                    color: _black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        color: _black,
                        child: const Icon(Icons.bolt_rounded, color: _neonYellow, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "QUICK ACCESS",
                        style: TextStyle(
                          color: _black,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        color: _black,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: const [
                            Icon(Icons.circle, color: _neonGreen, size: 8),
                            SizedBox(width: 6),
                            Text(
                              "READY",
                              style: TextStyle(
                                color: _neonGreen,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    height: 160,
                    child: PageView.builder(
                      controller: _quickAccessController,
                      itemCount: 5,
                      itemBuilder: (context, index) {
                        final List<Map<String, dynamic>> quickActions = [
                          {
                            "icon": FontAwesomeIcons.whatsapp,
                            "title": "WHATSAPP ATTACK",
                            "subtitle": "Send payloads & crash codes",
                            "color": _neonGreen,
                            "onTap": () {
                              setState(() {
                                _selectedPage = HomePage(
                                  username: username,
                                  password: password,
                                  listBug: listBug,
                                  role: role,
                                  expiredDate: expiredDate,
                                  sessionKey: sessionKey,
                                );
                              });
                              _audioService.pause();
                            },
                          },
                          {
                            "icon": Icons.devices_rounded,
                            "title": "MANAGEMENT SENDER",
                            "subtitle": "Pair devices & manage sessions",
                            "color": _neonBlue,
                            "onTap": () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => BugSenderPage(
                                    sessionKey: sessionKey,
                                    username: username,
                                    role: role,
                                  ),
                                ),
                              );
                              _audioService.pause();
                            },
                          },
                          {
                            "icon": Icons.build_outlined,
                            "title": "TOOLS",
                            "subtitle": "Open tools page",
                            "color": _neonOrange,
                            "onTap": () {
                              setState(() {
                                _selectedPage = ToolsPage(
                                  sessionKey: sessionKey,
                                  userRole: role,
                                  listDoos: listDoos,
                                );
                              });
                              _audioService.pause();
                            },
                          },
                          {
                            "icon": Icons.mosque_rounded,
                            "title": "ISLAMIC AREA",
                            "subtitle": "Prayer times & Quran",
                            "color": _neonGreen,
                            "onTap": () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const IslamicPage(),
                                ),
                              );
                              _audioService.pause();
                            },
                          },
                          {
                            "icon": Icons.sports_esports_rounded,
                            "title": "ARCADE HUB",
                            "subtitle": "15+ mini games",
                            "color": _neonPurple,
                            "onTap": () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const GamesPage(),
                                ),
                              );
                              _audioService.pause();
                            },
                          },
                        ];

                        final action = quickActions[index];
                        final Color color = action['color'] as Color;

                        return GestureDetector(
                          onTap: action['onTap'],
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 8),
                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                            decoration: BoxDecoration(
                              color: _bgPrimary,
                              border: Border.all(color: _black, width: _borderWidth),
                              boxShadow: const [
                                BoxShadow(
                                  color: _black,
                                  offset: Offset(4, 4),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  right: -20,
                                  bottom: -20,
                                  child: Icon(
                                    action['icon'],
                                    size: 80,
                                    color: Colors.grey.shade300,
                                  ),
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.all(10),
                                          color: _black,
                                          child: Icon(
                                            action['icon'],
                                            color: color,
                                            size: 22,
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 12,
                                            vertical: 6,
                                          ),
                                          color: _black,
                                          child: const Text(
                                            "OPEN →",
                                            style: TextStyle(
                                              color: _neonYellow,
                                              fontSize: 9,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const Spacer(),
                                    Text(
                                      action['title'],
                                      style: const TextStyle(
                                        color: _black,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      action['subtitle'],
                                      style: TextStyle(
                                        color: Colors.grey.shade600,
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(5, (index) {
                      double diff = (index - _currentQuickAccessPage).abs();
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        height: 6,
                        width: diff < 0.5 ? 24 : 6,
                        color: diff < 0.5 ? _black : Colors.grey.shade300,
                      );
                    }),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  // ============================================================
  // 🔥 THANX TO - NEOBRUTALISM (Biru)
  // ============================================================
  Widget _buildThanksAndDeveloper() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _bgFeatureBlue,
          border: Border.all(color: _black, width: _borderWidth),
          boxShadow: const [
            BoxShadow(
              color: _black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 4,
                  height: 18,
                  color: _neonPink,
                ),
                const SizedBox(width: 10),
                const Text(
                  "THANX TO",
                  style: TextStyle(
                    color: _black,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildContactCard(
              name: "KENZZZXD",
              subtitle: "Developer",
              username: "KENZZZXD",
              link: "https://t.me/KENZZZXD",
              photoUrl: "",
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactCard({
    required String name,
    required String subtitle,
    required String username,
    required String link,
    required String photoUrl,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _bgPrimary,
        border: Border.all(color: _black, width: _borderWidth),
        boxShadow: const [
          BoxShadow(
            color: _black,
            offset: Offset(3, 3),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              border: Border.all(color: _black, width: 2),
            ),
            child: ClipRRect(
              child: Image.network(
                photoUrl,
                width: 44,
                height: 44,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: _neonPink.withOpacity(0.2),
                    child: Center(
                      child: Text(
                        name[0],
                        style: const TextStyle(
                          color: _black,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: _black,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
          InkWell(
            onTap: () => _openUrl(link),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              color: _black,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    FontAwesomeIcons.telegram,
                    color: _neonYellow,
                    size: 14,
                  ),
                  const SizedBox(width: 6),
                  const Text(
                    "Contact",
                    style: TextStyle(
                      color: _neonYellow,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 📰 BERITA TERKINI + JAM - NEOBRUTALISM (Hijau)
  // ============================================================
  Widget _buildNewsWithClockCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _bgFeatureGreen,
          border: Border.all(color: _black, width: _borderWidth),
          boxShadow: const [
            BoxShadow(
              color: _black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  color: _black,
                  child: const Icon(FontAwesomeIcons.newspaper, color: _neonPink, size: 18),
                ),
                const SizedBox(width: 10),
                const Text(
                  "BERITA TERKINI",
                  style: TextStyle(
                    color: _black,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
                const Spacer(),
                const LiveClockWidget(),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              color: _black,
              child: const Text(
                "ANTARA NEWS",
                style: TextStyle(
                  color: _neonYellow,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (_isLoadingNews)
              const SizedBox(
                height: 130,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        color: _black,
                        strokeWidth: 3,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Memuat berita...",
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              )
            else if (_newsError.isNotEmpty)
              SizedBox(
                height: 130,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, color: _neonPink, size: 30),
                      const SizedBox(height: 8),
                      Text(
                        _newsError,
                        style: const TextStyle(
                          color: _neonPink,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            else if (_newsData.isEmpty)
              const SizedBox(
                height: 130,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.newspaper_rounded, color: Colors.black38, size: 30),
                      SizedBox(height: 8),
                      Text(
                        "Tidak ada berita",
                        style: TextStyle(
                          color: Colors.black38,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else
              SizedBox(
                height: 135,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: _newsData.length > 5 ? 5 : _newsData.length,
                  separatorBuilder: (context, index) => const SizedBox(width: 10),
                  itemBuilder: (context, index) {
                    return _buildCompactNewsItem(_newsData[index]);
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 📰 COMPACT NEWS ITEM - NEOBRUTALISM
  // ============================================================
  Widget _buildCompactNewsItem(Map<String, dynamic> news) {
    String formattedTime = "";
    try {
      if (news['pubDate'].toString().isNotEmpty) {
        final dateTime = DateTime.parse(news['pubDate'].toString());
        formattedTime = "${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}";
      }
    } catch (e) {
      final raw = news['pubDate'].toString();
      formattedTime = raw.length >= 16 ? raw.substring(11, 16) : raw;
    }

    return GestureDetector(
      onTap: () {
        if (news['link'].toString().isNotEmpty) _openUrl(news['link']);
      },
      child: Container(
        width: 140,
        decoration: BoxDecoration(
          color: _bgPrimary,
          border: Border.all(color: _black, width: _borderWidth),
          boxShadow: const [
            BoxShadow(
              color: _black,
              offset: Offset(3, 3),
              blurRadius: 0,
            ),
          ],
        ),
        child: ClipRRect(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 70,
                width: double.infinity,
                color: Colors.grey.shade300,
                child: news['imageUrl'].toString().isNotEmpty
                    ? Image.network(
                        news['imageUrl'],
                        fit: BoxFit.cover,
                        width: double.infinity,
                        errorBuilder: (_, __, ___) => const Center(
                          child: Icon(Icons.image_not_supported_outlined, color: Colors.grey, size: 20),
                        ),
                      )
                    : const Center(
                        child: Icon(Icons.article_outlined, color: Colors.grey, size: 24),
                      ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        news['title'] ?? 'Tidak ada judul',
                        style: const TextStyle(
                          color: _black,
                          fontSize: 8,
                          fontWeight: FontWeight.w800,
                          height: 1.2,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Row(
                        children: [
                          const Icon(Icons.access_time_rounded, color: _neonPink, size: 8),
                          const SizedBox(width: 4),
                          Text(
                            formattedTime,
                            style: const TextStyle(color: _neonPink, fontSize: 7, fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🌤️ WEATHER CARD - NEOBRUTALISM (Biru)
  // ============================================================
  Widget _buildWeatherCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _bgFeatureBlue,
          border: Border.all(color: _black, width: _borderWidth),
          boxShadow: const [
            BoxShadow(
              color: _black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  color: _black,
                  child: const Icon(FontAwesomeIcons.cloudSun, color: _neonYellow, size: 18),
                ),
                const SizedBox(width: 10),
                const Text(
                  "CUACA",
                  style: TextStyle(
                    color: _black,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    setState(() => isLoadingWeather = true);
                    _initWeather();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    color: _black,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.refresh_rounded, color: _neonYellow, size: 12),
                        SizedBox(width: 4),
                        Text(
                          "UPDATE",
                          style: TextStyle(
                            color: _neonYellow,
                            fontSize: 8,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (isLoadingWeather)
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Column(
                    children: [
                      SizedBox(
                        width: 30,
                        height: 30,
                        child: CircularProgressIndicator(
                          color: _black,
                          strokeWidth: 3,
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Memuat cuaca...",
                        style: TextStyle(
                          color: Colors.black54,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else if (weatherData != null)
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            color: _black,
                            child: FaIcon(
                              _getWeatherIcon(weatherData!['weather'][0]['main']),
                              color: _neonYellow,
                              size: 28,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "${weatherData!['main']['temp'].round()}\u00B0C",
                                style: const TextStyle(
                                  color: _black,
                                  fontSize: 28,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'ShareTechMono',
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                weatherData!['name'] ?? 'Lokasi',
                                style: const TextStyle(
                                  color: Colors.black87,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        color: _black,
                        child: Text(
                          weatherData!['weather'][0]['main'] ?? '--',
                          style: const TextStyle(
                            color: _neonYellow,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: _bgPrimary,
                      border: Border.all(color: _black, width: _borderWidth),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _weatherDetailItem(
                          FontAwesomeIcons.droplet,
                          "Kelembaban",
                          "${weatherData!['main']['humidity']}%",
                          _neonBlue,
                        ),
                        Container(width: 1, height: 30, color: _black),
                        _weatherDetailItem(
                          FontAwesomeIcons.wind,
                          "Angin",
                          "${(weatherData!['wind']['speed'] * 3.6).round()} km/h",
                          _neonGreen,
                        ),
                        Container(width: 1, height: 30, color: _black),
                        _weatherDetailItem(
                          FontAwesomeIcons.eye,
                          "Visibilitas",
                          "${((weatherData!['visibility'] ?? 10000) / 1000).round()} km",
                          _neonOrange,
                        ),
                        Container(width: 1, height: 30, color: _black),
                        _weatherDetailItem(
                          FontAwesomeIcons.temperatureHalf,
                          "Terasa",
                          "${weatherData!['main']['feels_like'].round()}\u00B0C",
                          _neonPink,
                        ),
                      ],
                    ),
                  ),
                ],
              )
            else if (weatherErrorMsg.isNotEmpty)
              SizedBox(
                height: 80,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.location_off, color: Colors.black38, size: 20),
                      const SizedBox(height: 6),
                      Text(
                        weatherErrorMsg,
                        style: const TextStyle(
                          color: Colors.black54,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            else
              const SizedBox(
                height: 80,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          color: _black,
                          strokeWidth: 3,
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Menunggu data cuaca...",
                        style: TextStyle(
                          color: Colors.black54,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _weatherDetailItem(IconData icon, String label, String value, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(height: 3),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey.shade600,
            fontSize: 8,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            color: _black,
            fontSize: 11,
            fontWeight: FontWeight.w900,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ],
    );
  }

  // ============================================================
  // 🕌 WAKTU SHOLAT CARD - NEOBRUTALISM (Hijau)
  // ============================================================
  Widget _buildSholatCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: _bgFeatureGreen,
          border: Border.all(color: _black, width: _borderWidth),
          boxShadow: const [
            BoxShadow(
              color: _black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  color: _black,
                  child: const Icon(Icons.mosque_rounded, color: _neonYellow, size: 20),
                ),
                const SizedBox(width: 12),
                const Text(
                  "WAKTU SHOLAT",
                  style: TextStyle(
                    color: _black,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _showCitySelector,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    color: _black,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _useCurrentLocation ? Icons.gps_fixed : Icons.edit_location_alt_rounded,
                          color: _neonYellow,
                          size: 14,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _useCurrentLocation ? _selectedCityName : "GANTI",
                          style: const TextStyle(
                            color: _neonYellow,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 8),
              child: Text(
                _useCurrentLocation
                    ? "📍 Lokasi saat ini: $_selectedCityName"
                    : "📍 $_selectedCityName",
                style: const TextStyle(
                  color: Colors.black87,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 2),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: _bgPrimary,
                border: Border.all(color: _black, width: _borderWidth),
              ),
              child: Row(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    color: _neonGreen,
                  ),
                  const SizedBox(width: 12),
                  if (_isLoadingSholat)
                    const Text(
                      "Memuat jadwal...",
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    )
                  else
                    Text(
                      _getNextSholatTime(),
                      style: const TextStyle(
                        color: _black,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    color: _black,
                    child: const Text(
                      "CRASH VOID",
                      style: TextStyle(
                        color: _neonYellow,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            if (_isLoadingSholat)
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Column(
                    children: [
                      SizedBox(
                        width: 30,
                        height: 30,
                        child: CircularProgressIndicator(
                          color: _black,
                          strokeWidth: 3,
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Memuat jadwal sholat...",
                        style: TextStyle(
                          color: Colors.black54,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else if (_jadwalSholat == null || _jadwalSholat!['jadwal'] == null)
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: Column(
                    children: [
                      Icon(Icons.error_outline, color: Colors.black38, size: 40),
                      const SizedBox(height: 8),
                      const Text(
                        "Gagal memuat jadwal sholat",
                        style: TextStyle(
                          color: Colors.black54,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _black,
                          foregroundColor: _neonYellow,
                          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
                          side: const BorderSide(color: _neonYellow, width: _borderWidth),
                          textStyle: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        onPressed: () => _fetchSholatTimes(),
                        child: const Text("Coba Lagi"),
                      ),
                    ],
                  ),
                ),
              )
            else
              SizedBox(
                height: 130,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.only(bottom: 10),
                  children: [
                    const SizedBox(width: 8),
                    _buildPrayerTimeCard(
                      prayerName: "Subuh",
                      time: _jadwalSholat!['jadwal']['subuh']?.toString() ?? '--:--',
                      icon: Icons.nights_stay_rounded,
                      color: _neonBlue,
                      isNext: _isCurrentSholat(
                        "Subuh",
                        _jadwalSholat!['jadwal']['subuh']?.toString(),
                      ),
                    ),
                    const SizedBox(width: 12),
                    _buildPrayerTimeCard(
                      prayerName: "Dzuhur",
                      time: _jadwalSholat!['jadwal']['dzuhur']?.toString() ?? '--:--',
                      icon: Icons.wb_sunny_rounded,
                      color: _neonOrange,
                      isNext: _isCurrentSholat(
                        "Dzuhur",
                        _jadwalSholat!['jadwal']['dzuhur']?.toString(),
                      ),
                    ),
                    const SizedBox(width: 12),
                    _buildPrayerTimeCard(
                      prayerName: "Ashar",
                      time: _jadwalSholat!['jadwal']['ashar']?.toString() ?? '--:--',
                      icon: Icons.wb_cloudy_rounded,
                      color: _neonPink,
                      isNext: _isCurrentSholat(
                        "Ashar",
                        _jadwalSholat!['jadwal']['ashar']?.toString(),
                      ),
                    ),
                    const SizedBox(width: 12),
                    _buildPrayerTimeCard(
                      prayerName: "Maghrib",
                      time: _jadwalSholat!['jadwal']['maghrib']?.toString() ?? '--:--',
                      icon: Icons.nightlight_round,
                      color: _neonPurple,
                      isNext: _isCurrentSholat(
                        "Maghrib",
                        _jadwalSholat!['jadwal']['maghrib']?.toString(),
                      ),
                    ),
                    const SizedBox(width: 12),
                    _buildPrayerTimeCard(
                      prayerName: "Isya",
                      time: _jadwalSholat!['jadwal']['isya']?.toString() ?? '--:--',
                      icon: Icons.bedtime_rounded,
                      color: _neonGreen,
                      isNext: _isCurrentSholat(
                        "Isya",
                        _jadwalSholat!['jadwal']['isya']?.toString(),
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // CUSTOM DRAWER - NEOBRUTALISM
  // ============================================================
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: _bgPrimary,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(24, 50, 24, 24),
            decoration: BoxDecoration(
              color: _black,
              border: Border(bottom: BorderSide(color: _neonYellow, width: 2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: _white,
                        border: Border.all(color: _neonYellow, width: 3),
                      ),
                      child: ClipRect(
                        child: _profileImage != null
                            ? Image.file(_profileImage!, fit: BoxFit.cover)
                            : const Icon(Icons.person, size: 40, color: _black),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            username,
                            style: const TextStyle(
                              color: _neonYellow,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                            maxLines: 1,
                          ),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            color: _neonYellow,
                            child: Text(
                              role.toUpperCase(),
                              style: const TextStyle(
                                color: _black,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8),
              children: [
                if (role == "owner")
                  _buildDrawerMenuItem(
                    icon: Icons.workspace_premium,
                    label: "Owner Panel",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
                      });
                      _audioService.pause();
                    },
                  ),
                if (role == "admin")
                  _buildDrawerMenuItem(
                    icon: Icons.admin_panel_settings,
                    label: "Admin Panel",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        _selectedPage = AdminPage(sessionKey: sessionKey);
                      });
                      _audioService.pause();
                    },
                  ),
                if (role == "partner")
                  _buildDrawerMenuItem(
                    icon: Icons.handshake_outlined,
                    label: "Partner Panel",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
                      });
                      _audioService.pause();
                    },
                  ),
                if (role == "moderator")
                  _buildDrawerMenuItem(
                    icon: Icons.gavel_rounded,
                    label: "Moderator Panel",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
                      });
                      _audioService.pause();
                    },
                  ),
                if (role == "seller" || role == "reseller")
                  _buildDrawerMenuItem(
                    icon: Icons.storefront_rounded,
                    label: "Seller Panel",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        _selectedPage = SellerPage(keyToken: sessionKey);
                      });
                      _audioService.pause();
                    },
                  ),
                _buildDrawerMenuItem(
                  icon: Icons.history,
                  label: "Activity History",
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role),
                      ),
                    );
                    _audioService.pause();
                  },
                ),
                _buildDrawerMenuItem(
                  icon: Icons.person_outline,
                  label: "My Profile",
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ProfilePage(
                          username: username,
                          password: password,
                          role: role,
                          expiredDate: expiredDate,
                          sessionKey: sessionKey,
                        ),
                      ),
                    );
                    _audioService.pause();
                  },
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Container(
              decoration: BoxDecoration(
                color: _black,
                border: Border.all(color: _neonPink, width: _borderWidth),
                boxShadow: const [
                  BoxShadow(
                    color: _black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14),
                ),
                onPressed: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  _audioService.stop();
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
                  );
                },
                child: const Text(
                  "LOGOUT",
                  style: TextStyle(
                    color: _neonPink,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.0,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Container(
        decoration: BoxDecoration(
          color: _white,
          border: Border.all(color: _black, width: _borderWidth),
          boxShadow: const [
            BoxShadow(
              color: _black,
              offset: Offset(3, 3),
              blurRadius: 0,
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            splashColor: _neonYellow.withOpacity(0.3),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    color: _black,
                    child: Icon(icon, color: _neonYellow, size: 20),
                  ),
                  const SizedBox(width: 14),
                  Text(
                    label,
                    style: const TextStyle(
                      color: _black,
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                    ),
                  ),
                  const Spacer(),
                  const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 12),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============ VIDEO BACKGROUND ============
class _ProfileVideoBackground extends StatefulWidget {
  final String videoPath;
  const _ProfileVideoBackground({required this.videoPath});

  @override
  State<_ProfileVideoBackground> createState() => _ProfileVideoBackgroundState();
}

class _ProfileVideoBackgroundState extends State<_ProfileVideoBackground> {
  late VideoPlayerController _videoController;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.asset(widget.videoPath)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _isInitialized = true);
          _videoController.setVolume(0);
          _videoController.setLooping(true);
          _videoController.play();
        }
      }).catchError((e) {
        debugPrint("Video background error: $e");
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return Container(
        color: _bgPrimary,
        child: const Center(
          child: SizedBox(
            width: 30,
            height: 30,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              color: _black,
            ),
          ),
        ),
      );
    }
    return FittedBox(
      fit: BoxFit.cover,
      child: SizedBox(
        width: _videoController.value.size.width,
        height: _videoController.value.size.height,
        child: VideoPlayer(_videoController),
      ),
    );
  }
}