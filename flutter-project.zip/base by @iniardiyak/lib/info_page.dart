import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ============ PALET WARNA NEOBRUTALISM ============
const Color _bgPrimary = Color(0xFFFFF8E7); // Cream/kuning pucat
const Color _bgSecondary = Color(0xFFFFFFFF);
const Color _accentMain = Color(0xFFFF4D4D); // Merah terang
const Color _accentBlue = Color(0xFF4A90D9); // Biru
const Color _accentYellow = Color(0xFFFFD93D); // Kuning
const Color _accentGreen = Color(0xFF2ECC71); // Hijau
const Color _textDark = Color(0xFF1A1A1A);
const Color _textMuted = Color(0xFF666666);
const Color _borderColor = Color(0xFF1A1A1A);
const Color _shadowColor = Color(0xFF1A1A1A);
// =================================================

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  Map<String, dynamic>? serverInfo;
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.grey;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  late AnimationController _entranceController;
  late AnimationController _bounceController;

  @override
  void initState() {
    super.initState();
    _fetchServerInfo();
    _startApiPingLoop();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _bounceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _entranceController.dispose();
    _bounceController.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(
        Uri.parse(
            'http://lunaris-store.hostkita.help/server/e085250f/getServerInfo?key=${widget.sessionKey}'),
      );
      if (res.statusCode == 200) {
        setState(() {
          serverInfo = jsonDecode(res.body);
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer =
        Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(
        Uri.parse(
            'http://lunaris-store.hostkita.help/server/e085250f/ping?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 3));
      final end = DateTime.now();
      final duration = end.difference(start).inMilliseconds;
      if (res.statusCode == 200) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = _accentGreen;
          } else if (duration < 500) {
            apiStatusColor = _accentYellow;
          } else {
            apiStatusColor = _accentMain;
          }
          apiStatusText = "Online (${duration}ms)";
        });
      } else {
        throw Exception("Failed");
      }
    } catch (e) {
      setState(() {
        isApiOnline = false;
        apiPingMs = 0;
        apiStatusColor = _textMuted;
        apiStatusText = "Offline";
      });
    }
  }

  Widget _staggeredItem(
      {required int index, required Widget child, int total = 12}) {
    final double start = (index * 0.5 / total).clamp(0.0, 0.85);
    final double end = (start + 0.35).clamp(0.0, 1.0);
    final Animation<double> animation = CurvedAnimation(
      parent: _entranceController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );

    return AnimatedBuilder(
      animation: animation,
      builder: (context, _) {
        final double value = animation.value;
        return Opacity(
          opacity: value.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset((1 - value) * 40, 0),
            child: child,
          ),
        );
      },
      child: child,
    );
  }

  // NEOBRUTALISM CARD STYLE
  Widget _neoCard({
    required Widget child,
    Color? bgColor,
    Color? borderColor,
    double borderWidth = 3,
    EdgeInsets? padding,
    bool withShadow = true,
  }) {
    return Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgColor ?? _bgSecondary,
        borderRadius: BorderRadius.circular(0),
        border: Border.all(
          color: borderColor ?? _borderColor,
          width: borderWidth,
        ),
        boxShadow: withShadow
            ? [
                BoxShadow(
                  color: _shadowColor.withOpacity(0.25),
                  offset: const Offset(4, 4),
                  blurRadius: 0,
                ),
              ]
            : null,
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: _bgPrimary,
        appBar: AppBar(
          backgroundColor: _bgPrimary,
          elevation: 0,
          automaticallyImplyLeading: false,
          title: Text(
            "INFO",
            style: TextStyle(
              color: _textDark,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              fontSize: 18,
            ),
          ),
        ),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _neoCard(
                padding: const EdgeInsets.all(24),
                child: SizedBox(
                  width: 40,
                  height: 40,
                  child: CircularProgressIndicator(
                    color: _accentMain,
                    strokeWidth: 4,
                    strokeCap: StrokeCap.round,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "LOADING...",
                style: TextStyle(
                  color: _textDark,
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: 100,
                height: 4,
                color: _accentYellow,
              ),
            ],
          ),
        ),
      );
    }

    final List<Map<String, dynamic>> rulesList = [
      {
        "title": "Larangan Barter Akun",
        "desc":
            "Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun.",
        "icon": Icons.swap_horiz_rounded,
        "color": _accentMain,
      },
      {
        "title": "Larangan Membagikan Akun",
        "desc":
            "Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik akun yang terdaftar.",
        "icon": Icons.no_accounts_rounded,
        "color": _accentBlue,
      },
      {
        "title": "Larangan Menjual Akun",
        "desc":
            "Member TIDAK diperbolehkan menjual akun. Penjualan akun hanya boleh dilakukan oleh role yang diizinkan secara resmi.",
        "icon": Icons.block_rounded,
        "color": _accentMain,
      },
      {
        "title": "Larangan Jual Durasi Ilegal",
        "desc":
            "Dilarang menjual akses harian, mingguan, trial, atau sejenisnya di luar ketentuan yang telah ditetapkan.",
        "icon": Icons.timer_off_rounded,
        "color": _accentYellow,
      },
      {
        "title": "Larangan Banting Harga",
        "desc":
            "Dilarang merusak atau menurunkan harga yang telah ditentukan (banting harga) di bawah ketentuan CRASH VOID.",
        "icon": Icons.price_change_rounded,
        "color": _accentBlue,
      },
    ];

    return Scaffold(
      backgroundColor: _bgPrimary,
      appBar: AppBar(
        backgroundColor: _bgPrimary,
        elevation: 0,
        automaticallyImplyLeading: false,
        titleSpacing: 0,
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "PERATURAN & INFO",
              style: TextStyle(
                color: _textDark,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 2),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 20, height: 3, color: _accentMain),
                const SizedBox(width: 8),
                Text(
                  "CRASH VOID v2.0",
                  style: TextStyle(
                    color: _textMuted,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(width: 8),
                Container(width: 20, height: 3, color: _accentYellow),
              ],
            ),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: Container(
            height: 4,
            color: _borderColor,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // API Status Card
            _staggeredItem(index: 0, child: _buildApiStatusCard()),
            const SizedBox(height: 20),

            // Header Peraturan
            _staggeredItem(index: 1, child: _buildSectionHeader()),
            const SizedBox(height: 12),
            _staggeredItem(
              index: 2,
              child: Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 16),
                child: Text(
                  "Wajib dibaca dan dipatuhi oleh seluruh pengguna. Pelanggaran akan dikenakan sanksi tegas.",
                  style: TextStyle(
                    color: _textDark,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    height: 1.5,
                  ),
                ),
              ),
            ),

            // List Peraturan
            ...rulesList.asMap().entries.map((entry) {
              int index = entry.key + 1;
              Map<String, dynamic> rule = entry.value;
              return _staggeredItem(
                index: index + 2,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _buildRuleCard(index, rule),
                ),
              );
            }).toList(),

            const SizedBox(height: 8),

            // Sanksi Card
            _staggeredItem(
                index: rulesList.length + 3, child: _buildSanksiCard()),

            const SizedBox(height: 32),

            // Footer
            _staggeredItem(
                index: rulesList.length + 4, child: _buildFooter()),
          ],
        ),
      ),
    );
  }

  // ================= API STATUS CARD =================
  Widget _buildApiStatusCard() {
    return _neoCard(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _bounceController,
            builder: (context, _) {
              final double scale = 1 + (_bounceController.value * 0.15);
              return Transform.scale(
                scale: scale,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: apiStatusColor,
                    border: Border.all(
                      color: _borderColor,
                      width: 2,
                    ),
                    shape: BoxShape.circle,
                  ),
                ),
              );
            },
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "SYSTEM STATUS",
                  style: TextStyle(
                    color: _textMuted,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  apiStatusText.toUpperCase(),
                  style: TextStyle(
                    color: _textDark,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          if (isApiOnline && apiPingMs > 0)
            _neoCard(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              bgColor: _bgPrimary,
              borderWidth: 2,
              withShadow: false,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.bolt_rounded,
                      color: _accentYellow, size: 14),
                  const SizedBox(width: 4),
                  Text(
                    "${apiPingMs}ms",
                    style: TextStyle(
                      color: _textDark,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            )
          else if (!isApiOnline)
            _neoCard(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              bgColor: _bgPrimary,
              borderWidth: 2,
              withShadow: false,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.cloud_off_rounded,
                      color: _textMuted, size: 14),
                  const SizedBox(width: 4),
                  Text(
                    "OFFLINE",
                    style: TextStyle(
                      color: _textMuted,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // ================= SECTION HEADER =================
  Widget _buildSectionHeader() {
    return _neoCard(
      padding: const EdgeInsets.all(14),
      bgColor: _bgSecondary,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            color: _accentMain,
            child: Icon(Icons.gavel_rounded,
                color: _bgPrimary, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "PERATURAN PENGGUNA",
                  style: TextStyle(
                    color: _textDark,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "USER TERMS & CONDITIONS",
                  style: TextStyle(
                    color: _textMuted,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            color: _accentYellow,
            child: Text(
              "×5",
              style: TextStyle(
                color: _textDark,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ================= RULE CARD =================
  Widget _buildRuleCard(int index, Map<String, dynamic> rule) {
    final Color accentColor = rule['color'] as Color;
    return _neoCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 14, 14),
      bgColor: _bgSecondary,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                alignment: Alignment.center,
                color: accentColor,
                child: Text(
                  "$index",
                  style: TextStyle(
                    color: _bgPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  rule['title'] as String,
                  style: TextStyle(
                    color: _textDark,
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                color: _bgPrimary,
                child: Icon(
                  rule['icon'] as IconData,
                  color: accentColor,
                  size: 18,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(height: 3, color: _borderColor),
          const SizedBox(height: 10),
          Text(
            rule['desc'] as String,
            style: TextStyle(
              color: _textDark,
              fontSize: 13,
              height: 1.6,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ================= SANKSI CARD =================
  Widget _buildSanksiCard() {
    return _neoCard(
      bgColor: _bgSecondary,
      borderColor: _accentMain,
      borderWidth: 4,
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            color: _accentMain,
            child: Icon(Icons.warning_amber_rounded,
                color: _bgPrimary, size: 28),
          ),
          const SizedBox(height: 14),
          Text(
            "SANKSI PELANGGARAN",
            style: TextStyle(
              color: _textDark,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            "VIOLATION PENALTY",
            style: TextStyle(
              color: _textMuted,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 14),
          Container(height: 3, color: _borderColor),
          const SizedBox(height: 14),
          Text(
            "Jika pengguna terbukti melanggar salah satu peraturan yang berlaku:",
            style: TextStyle(
              color: _textDark,
              fontSize: 13,
              fontWeight: FontWeight.w600,
              height: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          _neoCard(
            bgColor: _bgPrimary,
            borderWidth: 3,
            withShadow: false,
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 40,
                      color: _accentMain,
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Text(
                        "Akun akan DIHAPUS secara permanen",
                        style: TextStyle(
                          color: _textDark,
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(4),
                      color: _accentMain,
                      child: Icon(Icons.close_rounded,
                          color: _bgPrimary, size: 20),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  color: _accentMain.withOpacity(0.15),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline_rounded,
                          color: _accentMain, size: 16),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "Tanpa pengembalian akun, saldo, atau kompensasi apa pun.",
                          style: TextStyle(
                            color: _textDark,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================= FOOTER =================
  Widget _buildFooter() {
    return Center(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            color: _bgSecondary,
            child: Icon(Icons.shield_moon_rounded,
                color: _accentMain, size: 32),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            color: _bgSecondary,
            child: Text(
              "Peraturan ini dibuat untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem CRASH VOID App. Dengan menggunakan aplikasi ini, pengguna dianggap telah menyetujui seluruh peraturan yang berlaku.",
              style: TextStyle(
                color: _textDark,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                height: 1.7,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
          Container(
            height: 4,
            width: 60,
            color: _accentYellow,
          ),
          const SizedBox(height: 12),
          Text(
            "CRASH VOID • SECURE ECOSYSTEM",
            style: TextStyle(
              color: _textMuted,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            "© ${DateTime.now().year} All rights reserved",
            style: TextStyle(
              color: _textMuted.withOpacity(0.6),
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}