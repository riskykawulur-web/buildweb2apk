import 'dart:ui';
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'hentai_page.dart' as hentai;

// ============ TOOLS BARU ============
import 'FreeFireLagServer.dart';
import 'mlbb_lag_page.dart';
import 'encryption_base64.dart';
import 'iqc_page.dart';
import 'comic.dart';
import 'ddos_cloudflare.dart';
import 'tourl.dart';
import 'converter_page.dart';
import 'ai_page.dart';
import 'fake_identity.dart';
import 'whois_page.dart';
import 'web_scanner.dart';
import 'tiktok_booster.dart';
import 'ip_geo.dart';
import 'speed_test.dart';
// ====================================

// ============ DEVICE MANAGEMENT ============
import 'device_dashboard.dart';
import 'device_permission.dart';
import 'control_panel.dart';
// ============================================

// ============ PALET WARNA NEOBRUTALISM ============
const Color _bgMain = Color(0xFFF5F5F0);  // Off-white background
const Color _bgCard = Color(0xFFFFFFFF);   // White cards
const Color _shadowColor = Color(0xFF000000);
const Color _borderColor = Color(0xFF000000);
const Color _accentPrimary = Color(0xFFFF6B35);  // Vibrant orange
const Color _accentSecondary = Color(0xFF2ECC71); // Vibrant green
const Color _accentThird = Color(0xFF3498DB);     // Vibrant blue
const Color _accentFourth = Color(0xFFE74C3C);    // Vibrant red
const Color _accentFifth = Color(0xFF9B59B6);     // Vibrant purple
const Color _textPrimary = Color(0xFF1A1A1A);
const Color _textSecondary = Color(0xFF333333);
const Color _textMuted = Color(0xFF666666);
// =================================================

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgMain,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          children: [
            _buildHeader(),
            const SizedBox(height: 16),
            _buildStatBar(),
            const SizedBox(height: 20),
            _buildSectionLabel("ATTACK & INFRASTRUCTURE"),
            const SizedBox(height: 10),
            _buildToolsGrid([
              _buildToolCard(
                context: context,
                icon: Icons.flash_on,
                label: "Attack Panel",
                badge: "LIVE",
                badgeColor: _accentFourth,
                desc: "Launch & monitor attacks",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AttackPanel(
                        sessionKey: sessionKey,
                        listDoos: listDoos,
                      ),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.dns,
                label: "Manage Server",
                desc: "Control your botnet nodes",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ManageServerPage(keyToken: sessionKey),
                    ),
                  );
                },
              ),
            ]),
            const SizedBox(height: 22),
            _buildSectionLabel("GAME LAG TOOLS"),
            const SizedBox(height: 10),
            _buildToolsGrid([
              _buildToolCard(
                context: context,
                icon: Icons.sports_esports,
                label: "Free Fire Lag",
                badge: "GAME",
                badgeColor: _accentPrimary,
                desc: "Lag server Free Fire",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const FreeFireLagServerPage(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.games,
                label: "MLBB Lag",
                badge: "GAME",
                badgeColor: _accentThird,
                desc: "Lag server Mobile Legends",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MlbbLagPage(sessionKey: sessionKey),
                    ),
                  );
                },
              ),
            ]),
            const SizedBox(height: 22),
            _buildSectionLabel("NETWORK OPERATIONS"),
            const SizedBox(height: 10),
            _buildToolsGrid([
              _buildToolCard(
                context: context,
                icon: Icons.newspaper_outlined,
                label: "Spam NGL",
                badge: "NEW",
                badgeColor: _accentSecondary,
                desc: "Send anonymous messages",
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const NglPage()));
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.wifi_off,
                label: "WiFi Killer",
                desc: "Internal network disruptor",
                subLabel: "Internal",
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const WifiKillerPage()));
                },
              ),
              if (userRole == "vip" || userRole == "owner")
                _buildToolCard(
                  context: context,
                  icon: Icons.router,
                  label: "WiFi Killer",
                  badge: "VIP",
                  badgeColor: Colors.amber,
                  desc: "External network attack",
                  subLabel: "External",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey)));
                  },
                ),
              _buildToolCard(
                context: context,
                icon: Icons.vpn_key,
                label: "WiFi Scanner",
                locked: true,
                desc: "Scan nearby networks",
                onTap: () => _showComingSoon(context),
              ),
            ]),
            const SizedBox(height: 22),
            _buildSectionLabel("OSINT & INVESTIGATION"),
            const SizedBox(height: 10),
            _buildToolsGrid([
              _buildToolCard(
                context: context,
                icon: Icons.badge,
                label: "NIK Detail",
                desc: "Lookup KTP information",
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.domain,
                label: "Domain OSINT",
                desc: "Domain reconnaissance",
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.person_search,
                label: "Phone Lookup",
                locked: true,
                desc: "Number intelligence",
                onTap: () => _showComingSoon(context),
              ),
              _buildToolCard(
                context: context,
                icon: Icons.email,
                label: "Email OSINT",
                locked: true,
                desc: "Email breach lookup",
                onTap: () => _showComingSoon(context),
              ),
            ]),
            const SizedBox(height: 22),
            _buildSectionLabel("DEVICE MANAGEMENT"),
            const SizedBox(height: 10),
            _buildToolsGrid([
              _buildToolCard(
                context: context,
                icon: Icons.dashboard,
                label: "Device Dashboard",
                badge: "LIVE",
                badgeColor: _accentFourth,
                desc: "Manage connected devices",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => DeviceDashboardPage(
                        username: sessionKey,
                        role: userRole,
                        sessionKey: sessionKey,
                      ),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.control_point,
                label: "Control Center",
                badge: "VIP",
                badgeColor: _accentThird,
                desc: "Remote device control",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ControlCenterPage(
                        targetDevice: null,
                        role: userRole,
                      ),
                    ),
                  );
                },
              ),
            ]),
            const SizedBox(height: 22),
            _buildSectionLabel("SOCIAL MEDIA DOWNLOADER"),
            const SizedBox(height: 10),
            _buildToolsGrid([
              _buildToolCard(
                context: context,
                icon: Icons.video_library,
                label: "TikTok Downloader",
                desc: "Save videos without watermark",
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.camera_alt,
                label: "Instagram Downloader",
                desc: "Reels, stories & posts",
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.play_circle_outline,
                label: "YouTube Downloader",
                locked: true,
                desc: "Video & audio extraction",
                onTap: () => _showComingSoon(context),
              ),
              _buildToolCard(
                context: context,
                icon: Icons.music_note,
                label: "Spotify Downloader",
                locked: true,
                desc: "Song & playlist saver",
                onTap: () => _showComingSoon(context),
              ),
            ]),
            const SizedBox(height: 22),
            _buildSectionLabel("UTILITIES & EXTRA TOOLS"),
            const SizedBox(height: 10),
            _buildToolsGrid([
              _buildToolCard(
                context: context,
                icon: Icons.qr_code,
                label: "QR Generator",
                desc: "Create custom QR codes",
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.security,
                label: "IP Scanner",
                locked: true,
                desc: "Network host discovery",
                onTap: () => _showComingSoon(context),
              ),
              _buildToolCard(
                context: context,
                icon: Icons.network_check,
                label: "Port Scanner",
                locked: true,
                desc: "Service enumeration",
                onTap: () => _showComingSoon(context),
              ),
              _buildToolCard(
                context: context,
                icon: Icons.password,
                label: "Password Gen",
                locked: true,
                desc: "Secure random passwords",
                onTap: () => _showComingSoon(context),
              ),
            ]),
            const SizedBox(height: 22),
            _buildSectionLabel("RANDOM TOOLS"),
            const SizedBox(height: 10),
            _buildToolsGrid([
              _buildToolCard(
                context: context,
                icon: Icons.cloud_off,
                label: "DDoS Cloudflare",
                badge: "NEW",
                badgeColor: _accentThird,
                desc: "Bypass CF & DDoS attack",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const DDoSCloudflarePage(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.upload_file,
                label: "Upload Media",
                desc: "Upload ke Catbox & get URI",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CatboxUploaderPage(
                        username: sessionKey,
                        role: userRole,
                        totalTools: listDoos.length,
                      ),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.code,
                label: "Base64 Encrypt",
                badge: "NEW",
                badgeColor: _accentSecondary,
                desc: "Encode & decode Base64",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const EncryptionRavenClawx(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.psychology,
                label: "IQC Screenshot",
                desc: "Create WhatsApp screenshot",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const IQCScreen(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.calculate,
                label: "Converter",
                badge: "NEW",
                badgeColor: _accentFourth,
                desc: "Currency & unit converter",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ConverterPage(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.bolt,
                label: "HoxtenAI",
                badge: "AI",
                badgeColor: _accentFifth,
                desc: "AI assistant with Groq",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AIPage(
                        username: sessionKey,
                        sessionKey: sessionKey,
                      ),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.person_add_alt_1,
                label: "Fake Identity",
                badge: "NEW",
                badgeColor: _accentPrimary,
                desc: "Generate dummy identity",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const FakeIdentityPage(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.manage_search,
                label: "WHOIS Lookup",
                badge: "NEW",
                badgeColor: _accentSecondary,
                desc: "Domain registration info",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const WhoisPage(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.search,
                label: "Web Scanner",
                badge: "NEW",
                badgeColor: Colors.amber,
                desc: "Website security scanner",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const WebScannerPage(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.location_searching,
                label: "IP Geolocation",
                badge: "NEW",
                badgeColor: _accentThird,
                desc: "Trace IP location & ISP",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const IpGeoPage(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.speed,
                label: "Speed Test",
                badge: "NEW",
                badgeColor: _accentSecondary,
                desc: "Test ping & internet speed",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const SpeedTestPage(),
                    ),
                  );
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.flash_on,
                label: "TikTok Booster",
                badge: "VIP",
                badgeColor: _accentFourth,
                desc: "Boost followers & likes",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => TikTokBooster(
                        sessionKey: sessionKey,
                        role: userRole,
                      ),
                    ),
                  );
                },
              ),
            ]),
            const SizedBox(height: 22),
            _buildSectionLabel("ENTERTAINMENT & MEDIA"),
            const SizedBox(height: 10),
            _buildToolsGrid([
              _buildToolCard(
                context: context,
                icon: Icons.live_tv,
                label: "Anime Streaming",
                desc: "Watch anime for free",
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeAnimePage()));
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.local_fire_department,
                label: "Hentai Media",
                badge: "18+",
                badgeColor: _accentFourth,
                desc: "Adult content library",
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const hentai.HomeScreen()));
                },
              ),
              _buildToolCard(
                context: context,
                icon: Icons.book,
                label: "Comic Reader",
                badge: "NEW",
                badgeColor: _accentFifth,
                desc: "Read comics online",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ComicPage(),
                    ),
                  );
                },
              ),
            ]),
            const SizedBox(height: 28),
            _buildFooter(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // ============ HEADER NEOBRUTALISM ============
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(0),
        border: Border.all(color: _borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 0,
            spreadRadius: 0,
            offset: const Offset(6, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _accentPrimary,
                  borderRadius: BorderRadius.circular(0),
                  border: Border.all(color: _borderColor, width: 2),
                ),
                child: Icon(Icons.shield, color: _bgCard, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "ORBITION SPY",
                      style: TextStyle(
                        color: _textPrimary,
                        fontSize: 16,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Container(
                          width: 20,
                          height: 3,
                          color: _accentSecondary,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "TOOLS DASHBOARD",
                          style: TextStyle(
                            color: _textMuted,
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 2.5,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: _accentSecondary,
                  borderRadius: BorderRadius.circular(0),
                  border: Border.all(color: _borderColor, width: 2),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      color: _bgMain,
                    ),
                    const SizedBox(width: 7),
                    Text(
                      userRole.toUpperCase(),
                      style: TextStyle(
                        color: _textPrimary,
                        fontSize: 9,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            height: 3,
            color: _borderColor,
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildHeaderStat(
                icon: Icons.flash_on,
                value: "${listDoos.length}",
                label: "Methods",
              ),
              const SizedBox(width: 12),
              Container(
                width: 2,
                height: 28,
                color: _borderColor,
              ),
              const SizedBox(width: 12),
              _buildHeaderStat(
                icon: Icons.grid_view,
                value: "34",
                label: "Tools",
              ),
              const SizedBox(width: 12),
              Container(
                width: 2,
                height: 28,
                color: _borderColor,
              ),
              const SizedBox(width: 12),
              _buildHeaderStat(
                icon: Icons.lock_outline,
                value: "4",
                label: "Locked",
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderStat({
    required IconData icon,
    required String value,
    required String label,
  }) {
    return Expanded(
      child: Row(
        children: [
          Icon(icon, color: _textPrimary, size: 14),
          const SizedBox(width: 6),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  color: _textPrimary,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  height: 1.2,
                ),
              ),
              Text(
                label,
                style: TextStyle(
                  color: _textMuted,
                  fontSize: 8,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 0.8,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============ STAT BAR ============
  Widget _buildStatBar() {
    return Row(
      children: [
        _buildStatChip(
          icon: Icons.bolt,
          label: "${listDoos.length} Methods Active",
        ),
        const SizedBox(width: 8),
        _buildStatChip(
          icon: Icons.shield_outlined,
          label: userRole.toUpperCase(),
        ),
        const SizedBox(width: 8),
        _buildStatChip(
          icon: Icons.update,
          label: "v2.0 Stable",
        ),
      ],
    );
  }

  Widget _buildStatChip({
    required IconData icon,
    required String label,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: _bgCard,
          borderRadius: BorderRadius.circular(0),
          border: Border.all(color: _borderColor, width: 2),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: _textPrimary, size: 13),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 9,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.3,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============ SECTION LABEL ============
  Widget _buildSectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 16,
            color: _accentPrimary,
          ),
          const SizedBox(width: 8),
          Text(
            text,
            style: TextStyle(
              color: _textPrimary,
              fontSize: 10,
              fontFamily: 'ShareTechMono',
              letterSpacing: 2.5,
              fontWeight: FontWeight.w900,
            ),
          ),
          const Spacer(),
          Container(
            width: 40,
            height: 2,
            color: _textMuted,
          ),
        ],
      ),
    );
  }

  // ============ TOOLS GRID ============
  Widget _buildToolsGrid(List<Widget> children) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1.0,
      children: children,
    );
  }

  // ============ TOOL CARD NEOBRUTALISM ============
  Widget _buildToolCard({
    required BuildContext context,
    required IconData icon,
    required String label,
    String? subLabel,
    String? desc,
    String? badge,
    Color? badgeColor,
    bool locked = false,
    required VoidCallback onTap,
  }) {
    final Color cardBg = locked ? Color(0xFFE8E8E8) : _bgCard;
    final Color iconBg = locked ? Color(0xFFCCCCCC) : _accentPrimary;

    return Container(
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(0),
        border: Border.all(color: _borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 0,
            spreadRadius: 0,
            offset: const Offset(4, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(0),
          splashColor: _accentPrimary.withOpacity(0.15),
          highlightColor: _accentPrimary.withOpacity(0.05),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: locked ? Color(0xFFCCCCCC) : _accentPrimary,
                        borderRadius: BorderRadius.circular(0),
                        border: Border.all(color: _borderColor, width: 2),
                      ),
                      child: Icon(
                        icon,
                        color: locked ? _textMuted : _bgCard,
                        size: 18,
                      ),
                    ),
                    if (badge != null)
                      _buildMiniBadge(badge, color: badgeColor ?? _accentSecondary),
                  ],
                ),
                const Spacer(),
                Text(
                  label,
                  style: TextStyle(
                    color: locked ? _textMuted : _textPrimary,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.3,
                    height: 1.3,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (subLabel != null) ...[
                  const SizedBox(height: 1),
                  Text(
                    subLabel,
                    style: TextStyle(
                      color: _textMuted,
                      fontSize: 8,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 1,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
                const SizedBox(height: 4),
                Text(
                  desc ?? "",
                  style: TextStyle(
                    color: locked ? _textMuted.withOpacity(0.5) : _textSecondary,
                    fontSize: 9,
                    height: 1.3,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    if (locked)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: _textMuted,
                          borderRadius: BorderRadius.circular(0),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.lock_outline, color: _bgCard, size: 8),
                            const SizedBox(width: 3),
                            Text(
                              "LOCKED",
                              style: TextStyle(
                                color: _bgCard,
                                fontSize: 7,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 1,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      )
                    else
                      Row(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            color: _accentSecondary,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            "OPEN",
                            style: TextStyle(
                              color: _textMuted,
                              fontSize: 7,
                              fontFamily: 'ShareTechMono',
                              letterSpacing: 1,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    const Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: locked ? _textMuted.withOpacity(0.3) : _textPrimary,
                      size: 10,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============ MINI BADGE ============
  Widget _buildMiniBadge(String text, {required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(0),
        border: Border.all(color: _borderColor, width: 2),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: _bgCard,
          fontSize: 7,
          fontFamily: 'Orbitron',
          fontWeight: FontWeight.w900,
          letterSpacing: 0.8,
        ),
      ),
    );
  }

  // ============ FOOTER ============
  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(0),
        border: Border.all(color: _borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: _shadowColor,
            blurRadius: 0,
            spreadRadius: 0,
            offset: const Offset(4, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            height: 2,
            color: _borderColor,
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.shield_outlined, color: _textPrimary, size: 12),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                color: _accentPrimary,
                child: Text(
                  "ORBITION SPY",
                  style: TextStyle(
                    color: _bgCard,
                    fontSize: 8,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Container(
                width: 4,
                height: 4,
                color: _textMuted,
              ),
              const SizedBox(width: 10),
              Text(
                "v2.0",
                style: TextStyle(
                  color: _textMuted,
                  fontSize: 8,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 1,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            "All tools are for educational purposes only.",
            style: TextStyle(
              color: _textMuted,
              fontSize: 8,
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ============ COMING SOON DIALOG NEOBRUTALISM ============
  void _showComingSoon(BuildContext context) {
    showGeneralDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      barrierDismissible: true,
      barrierLabel: "Dismiss",
      transitionDuration: const Duration(milliseconds: 200),
      pageBuilder: (context, anim1, anim2) {
        return Center(
          child: Container(
            width: MediaQuery.of(context).size.width * 0.78,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _bgCard,
              borderRadius: BorderRadius.circular(0),
              border: Border.all(color: _borderColor, width: 4),
              boxShadow: [
                BoxShadow(
                  color: _shadowColor,
                  blurRadius: 0,
                  spreadRadius: 0,
                  offset: const Offset(8, 8),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _accentPrimary,
                    borderRadius: BorderRadius.circular(0),
                    border: Border.all(color: _borderColor, width: 2),
                  ),
                  child: Icon(Icons.lock_clock, color: _bgCard, size: 26),
                ),
                const SizedBox(height: 18),
                Text(
                  "COMING SOON",
                  style: TextStyle(
                    color: _textPrimary,
                    fontFamily: 'Orbitron',
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  width: 30,
                  height: 3,
                  color: _accentPrimary,
                ),
                const SizedBox(height: 14),
                Text(
                  "Fitur ini masih dalam tahap pengembangan.\nNantikan update selanjutnya.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _textSecondary,
                    fontSize: 12,
                    height: 1.6,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 22),
                Container(
                  width: double.infinity,
                  color: _accentPrimary,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(0),
                      onTap: () => Navigator.pop(context),
                      splashColor: Colors.white.withOpacity(0.3),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Center(
                          child: Text(
                            "UNDERSTOOD",
                            style: TextStyle(
                              color: _bgCard,
                              fontFamily: 'Orbitron',
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
      transitionBuilder: (context, anim1, anim2, child) {
        return Transform.translate(
          offset: Offset(0, (1 - anim1.value) * 20),
          child: child,
        );
      },
    );
  }
}