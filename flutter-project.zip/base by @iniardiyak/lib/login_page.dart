import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'video_splash_page.dart';

const String baseUrl = "http://lunaris-store.hostkita.help/server/e085250f";

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<Offset> _slideAnim;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;

  // ===== NEOBRUTALISM PALETTE =====
  static const Color bgMain = Color(0xFFF5F0E8);
  static const Color bgSurface = Color(0xFFE8E0D6);
  static const Color bgCard = Color(0xFFFFFFFF);
  static const Color bgInput = Color(0xFFF5F0E8);
  static const Color accentColor = Color(0xFFFF6B35);
  static const Color accentDark = Color(0xFFD9531E);
  static const Color accentLight = Color(0xFFFF8A5C);
  static const Color secondaryText = Color(0xFF4A4A4A);
  static const Color borderDim = Color(0xFF2D2D2D);
  static const Color borderInput = Color(0xFF2D2D2D);
  static const Color textWhite = Color(0xFF1A1A1A);
  static const Color textHint = Color(0xFF888888);
  static const Color shadowColor = Color(0xFF2D2D2D);
  // =====================================

  @override
  void initState() {
    super.initState();
    _initAnim();
    initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.4),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    ));

    _fadeAnim = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.5, curve: Curves.easeIn),
    );

    _scaleAnim = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.1, 0.6, curve: Curves.easeOutBack),
    );

    _controller.forward();
  }

  void _navigateToVideoSplash(Map<String, dynamic> args) {
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => VideoSplashPage(dashboardArgs: args),
      ),
    );
  }

  Map<String, dynamic> _buildArgs(
      dynamic data, String username, String password) {
    return {
      "username": username,
      "password": password,
      "role": data['role'],
      "key": data['key'],
      "expiredDate": data['expiredDate'],
      "listBug": (data['listBug'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList(),
      "listDoos": (data['listDDoS'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList(),
      "news": (data['news'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList(),
    };
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          _navigateToVideoSplash(_buildArgs(data, savedUser, savedPass));
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userController.text.trim();
    final password = passController.text.trim();
    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );
      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(
          title: "Access Expired",
          message: "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        final String errorMsg = (validData['message'] ?? "").toLowerCase();
        if (errorMsg.contains("perangkat") ||
            errorMsg.contains("device") ||
            errorMsg.contains("another")) {
          _showPopup(
            title: "Sesi Aktif",
            message:
                "Akun ini sedang login di perangkat lain.\nSilakan logout di perangkat lama.",
          );
        } else {
          _showPopup(
            title: "Login Gagal",
            message: "Username atau password salah.",
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);
        _navigateToVideoSplash(_buildArgs(validData, username, password));
      }
    } catch (e) {
      _showPopup(
        title: "Connection Error",
        message: "Gagal terhubung ke server.",
      );
    }

    setState(() => isLoading = false);
  }

  void _showPopup({
    required String title,
    required String message,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
          side: const BorderSide(color: borderDim, width: 3),
        ),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: accentColor, size: 20),
            const SizedBox(width: 8),
            Text(
              title,
              style: const TextStyle(
                  color: textWhite, fontWeight: FontWeight.bold, fontSize: 17),
            ),
          ],
        ),
        content: Text(
          message,
          style: const TextStyle(color: secondaryText, fontSize: 14, height: 1.5),
        ),
        actions: [
          if (showContact)
            Container(
              decoration: BoxDecoration(
                border: Border.all(color: accentColor, width: 2),
                borderRadius: BorderRadius.zero,
              ),
              child: TextButton(
                onPressed: () async {
                  await launchUrl(Uri.parse("https://t.me/InfoChDarkness"),
                      mode: LaunchMode.externalApplication);
                },
                child: Text(
                  "Contact Admin",
                  style: TextStyle(
                      color: accentColor, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Close",
              style: TextStyle(color: secondaryText.withOpacity(0.7)),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: bgMain,
      body: Stack(
        children: [
          // Background pattern - diagonal stripes
          Positioned.fill(
            child: CustomPaint(
              painter: _NeoBrutalistBgPainter(),
            ),
          ),

          // Konten Utama
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.symmetric(
                  horizontal: size.width * 0.04,
                  vertical: size.height * 0.03,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ScaleTransition(
                      scale: _scaleAnim,
                      child: SlideTransition(
                        position: _slideAnim,
                        child: Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(maxWidth: 400),
                          child: Container(
                            decoration: BoxDecoration(
                              color: bgCard,
                              borderRadius: BorderRadius.zero,
                              border: Border.all(
                                  color: borderDim, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: shadowColor,
                                  blurRadius: 0,
                                  spreadRadius: 0,
                                  offset: const Offset(8, 8),
                                ),
                              ],
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 28, vertical: 36),
                              child: Column(
                                children: [
                                  // Area Logo - Neo Brutalist
                                  Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        width: 120,
                                        height: 120,
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                              color: borderDim, width: 3),
                                          color: bgSurface,
                                        ),
                                        child: Center(
                                          child: Container(
                                            width: 90,
                                            height: 90,
                                            padding: const EdgeInsets.all(8),
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: borderDim, width: 2),
                                              color: bgMain,
                                            ),
                                            child: ClipRect(
                                              child: Image.asset(
                                                'assets/images/logo.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      // Decorative corner marks
                                      Positioned(
                                        top: -6,
                                        left: -6,
                                        child: _buildCornerMark(),
                                      ),
                                      Positioned(
                                        top: -6,
                                        right: -6,
                                        child: _buildCornerMark(),
                                      ),
                                      Positioned(
                                        bottom: -6,
                                        left: -6,
                                        child: _buildCornerMark(),
                                      ),
                                      Positioned(
                                        bottom: -6,
                                        right: -6,
                                        child: _buildCornerMark(),
                                      ),
                                    ],
                                  ),

                                  const SizedBox(height: 12),

                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16, vertical: 4),
                                    color: accentColor,
                                    child: const Text(
                                      "AUTHENTICATION",
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 4,
                                      ),
                                    ),
                                  ),

                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 24),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: Container(
                                            height: 3,
                                            color: borderDim,
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 16),
                                          child: Icon(
                                            Icons.fingerprint,
                                            color: accentColor,
                                            size: 22,
                                          ),
                                        ),
                                        Expanded(
                                          child: Container(
                                            height: 3,
                                            color: borderDim,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  Form(
                                    key: _formKey,
                                    child: Column(
                                      children: [
                                        _buildInput(
                                          controller: userController,
                                          hint: "Username",
                                          icon: Icons.person_outline_rounded,
                                          obscure: false,
                                        ),
                                        const SizedBox(height: 16),
                                        _buildInput(
                                          controller: passController,
                                          hint: "Password",
                                          icon: Icons.lock_outline_rounded,
                                          obscure: _obscurePassword,
                                          suffix: IconButton(
                                            icon: Icon(
                                              _obscurePassword
                                                  ? Icons
                                                      .visibility_off_outlined
                                                  : Icons
                                                      .visibility_outlined,
                                              color: secondaryText
                                                  .withOpacity(0.5),
                                              size: 20,
                                            ),
                                            onPressed: () {
                                              setState(() =>
                                                  _obscurePassword =
                                                      !_obscurePassword);
                                            },
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  const SizedBox(height: 32),

                                  _buildLoginButton(),

                                  const SizedBox(height: 24),

                                  // Link beli akses - Neo Brutalist
                                  GestureDetector(
                                    onTap: () async {
                                      final url =
                                          Uri.parse("https://t.me/kizzypdf");
                                      if (await canLaunchUrl(url)) {
                                        await launchUrl(url,
                                            mode: LaunchMode
                                                .externalApplication);
                                      }
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 16, vertical: 8),
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: accentColor, width: 2),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            "Need access?",
                                            style: TextStyle(
                                              color: secondaryText,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            "GET PREMIUM",
                                            style: TextStyle(
                                              color: accentColor,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 2,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Icon(
                                            Icons.arrow_forward,
                                            color: accentColor,
                                            size: 16,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 40),

                    // --- FOOTER ---
                    FadeTransition(
                      opacity: _fadeAnim,
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: List.generate(
                              5,
                              (index) => Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 4),
                                child: Container(
                                  width: index == 2 ? 16 : 6,
                                  height: 4,
                                  decoration: BoxDecoration(
                                    color: index == 2
                                        ? accentColor
                                        : borderDim.withOpacity(0.3),
                                    borderRadius: BorderRadius.zero,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            "SECURED CONNECTION ESTABLISHED",
                            style: TextStyle(
                              color: secondaryText,
                              fontSize: 9,
                              letterSpacing: 2,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 2),
                            color: accentColor,
                            child: Text(
                              "v7.5",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 3,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCornerMark() {
    return Container(
      width: 16,
      height: 16,
      decoration: BoxDecoration(
        border: Border.all(color: accentColor, width: 3),
      ),
    );
  }

  Widget _buildInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    required bool obscure,
    Widget? suffix,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: bgInput,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: borderInput, width: 2),
      ),
      child: TextFormField(
        controller: controller,
        obscureText: obscure,
        style: const TextStyle(
          color: textWhite,
          fontSize: 15,
          fontWeight: FontWeight.w600,
        ),
        cursorColor: accentColor,
        cursorWidth: 3,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(
            color: textHint,
            fontSize: 14,
            fontWeight: FontWeight.w400,
          ),
          prefixIcon: Icon(icon, color: accentColor, size: 22),
          suffixIcon: suffix,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Required';
          }
          return null;
        },
      ),
    );
  }

  Widget _buildLoginButton() {
    return Container(
      height: 54,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.zero,
        border: Border.all(color: borderDim, width: 3),
        boxShadow: isLoading
            ? []
            : [
                BoxShadow(
                  color: accentColor,
                  blurRadius: 0,
                  spreadRadius: 0,
                  offset: const Offset(6, 6),
                ),
              ],
      ),
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              color: accentColor,
              borderRadius: BorderRadius.zero,
            ),
          ),
          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.zero,
              onTap: isLoading ? null : login,
              child: Center(
                child: isLoading
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 3,
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      )
                    : const Text(
                        "→  LOGIN  →",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 4,
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ===== PAINTER: Neo Brutalist Background =====
class _NeoBrutalistBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF2D2D2D)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    // Diagonal stripes
    const spacing = 40.0;
    final double maxDim = size.width + size.height;

    for (double i = -maxDim; i < maxDim; i += spacing) {
      canvas.drawLine(
        Offset(i, 0),
        Offset(i + size.height, size.height),
        paint,
      );
    }

    // Random dots
    final random = Random(42);
    final dotPaint = Paint()
      ..color = const Color(0xFF2D2D2D).withOpacity(0.15);

    for (int i = 0; i < 50; i++) {
      final x = random.nextDouble() * size.width;
      final y = random.nextDouble() * size.height;
      final radius = random.nextDouble() * 2 + 1;
      canvas.drawCircle(Offset(x, y), radius, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}