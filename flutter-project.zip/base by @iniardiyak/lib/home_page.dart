import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final testController = TextEditingController();
  late AnimationController _pulseController;
  late VideoPlayerController _videoController;
  String selectedBugId = "";

  String _selectedBugMode = "number";
  String _senderMode = "private";
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isSending = false;
  bool _isTestSending = false;

  bool _showSenderPopup = false;
  bool _showTargetPopup = false;
  bool _isPrivateActive = true;

  // ==================== HISTORY ====================
  List<Map<String, dynamic>> _history = [];
  bool _isLoadingHistory = false;

  // ==================== NEOBRUTALISM COLOR PALETTE ====================
  static const Color _bgPrimary = Color(0xFFF5F0EB);
  static const Color _bgCard = Color(0xFFFFFFFF);
  static const Color _accentYellow = Color(0xFFFFD93D);
  static const Color _accentOrange = Color(0xFFFF6B35);
  static const Color _accentPink = Color(0xFFFF2E63);
  static const Color _accentBlue = Color(0xFF4A6CF7);
  static const Color _textDark = Color(0xFF1A1A1A);
  static const Color _textGray = Color(0xFF555555);
  static const Color _borderDark = Color(0xFF1A1A1A);
  static const Color _shadowColor = Color(0xFF1A1A1A);
  static const Color _successGreen = Color(0xFF00C853);
  static const Color _errorRed = Color(0xFFFF1744);

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
      }).catchError((e) {
        debugPrint("Video init error: $e");
      });

    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
      }
    }

    _fetchSenderStats();
    _fetchHistory();
  }

  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "http://lunaris-store.hostkita.help/server/e085250f/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
            _isPrivateActive = data['private_active'] ?? true;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  Future<void> _fetchHistory() async {
    setState(() => _isLoadingHistory = true);
    try {
      final res = await http.get(Uri.parse(
          "http://lunaris-store.hostkita.help/server/e085250f/getHistory?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['history'] != null) {
          setState(() {
            _history = List<Map<String, dynamic>>.from(data['history']);
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching history: $e");
    } finally {
      setState(() => _isLoadingHistory = false);
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _videoController.dispose();
    targetController.dispose();
    testController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() { selectedBugId = currentBugs[0]['bug_id']; });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() { _isSending = true; });

    final effectiveSenderMode = (widget.role == 'owner' || widget.role == 'vip') ? _senderMode : 'private';

    try {
      final res = await http.get(Uri.parse(
          "http://lunaris-store.hostkita.help/server/e085250f/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
        _addToHistory(rawInput, selectedBugId, "Cooldown", false);
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
        _addToHistory(rawInput, selectedBugId, "Invalid Key", false);
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server sedang maintenance atau terjadi kegagalan.");
        _addToHistory(rawInput, selectedBugId, "Failed", false);
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
        _addToHistory(rawInput, selectedBugId, "Success", true);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan pada sistem. Coba lagi nanti.");
      _addToHistory(rawInput, selectedBugId, "Error", false);
    } finally {
      setState(() { _isSending = false; });
    }
  }

  void _addToHistory(String target, String bugId, String status, bool success) {
    setState(() {
      _history.insert(0, {
        'target': target,
        'bug_id': bugId,
        'status': status,
        'success': success,
        'time': DateTime.now().toIso8601String(),
      });
      if (_history.length > 50) {
        _history.removeLast();
      }
    });
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => AlertDialog(
        backgroundColor: _bgCard,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: _borderDark, width: 3),
        ),
        title: Text(title, style: const TextStyle(color: _textDark, fontWeight: FontWeight.w900, fontSize: 18)),
        content: Text(msg, style: const TextStyle(color: _textGray, fontSize: 14)),
        actions: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: _accentYellow,
              border: Border.all(color: _borderDark, width: 2),
            ),
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK", style: TextStyle(color: _textDark, fontWeight: FontWeight.w800, fontSize: 14)),
            ),
          ),
        ],
        shadowColor: _shadowColor.withValues(alpha: 0.3),
        elevation: 12,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoContainer({required Widget child, Color? bgColor, double borderRadius = 12, bool withShadow = true}) {
    return Container(
      decoration: BoxDecoration(
        color: bgColor ?? _bgCard,
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(color: _borderDark, width: 2),
        boxShadow: withShadow ? [
          BoxShadow(
            color: _shadowColor.withValues(alpha: 0.15),
            blurRadius: 0,
            offset: const Offset(4, 4),
          ),
        ] : null,
      ),
      child: child,
    );
  }

  Widget _neoSectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              color: _accentYellow,
              border: Border.all(color: _borderDark, width: 2),
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Icon(Icons.bolt_rounded, color: _borderDark, size: 12),
          ),
          const SizedBox(width: 10),
          Text(
            text,
            style: const TextStyle(
              color: _textDark,
              fontWeight: FontWeight.w900,
              fontSize: 11,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _neoBadge(String text, Color bgColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: _borderDark, width: 2),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: _textDark,
          fontWeight: FontWeight.w800,
          fontSize: 9,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  // ==================== POPUP SENDER SELECTION ====================
  void _showSenderSelectionPopup() {
    if (widget.role != 'owner' && widget.role != 'vip') {
      _showAlert("Akses Terbatas", "Mode pengirim global hanya untuk Owner/VIP.");
      return;
    }
    setState(() { _showSenderPopup = true; });
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateBottomSheet) {
          return Container(
            margin: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _bgCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _borderDark, width: 3),
              boxShadow: [
                BoxShadow(
                  color: _shadowColor.withValues(alpha: 0.2),
                  blurRadius: 0,
                  offset: const Offset(8, 8),
                ),
              ],
            ),
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: _textGray,
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: _borderDark, width: 1),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Center(
                  child: Text(
                    "PILIH SENDER",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      color: _textDark,
                      letterSpacing: 2,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const Divider(color: _borderDark, thickness: 2),
                const SizedBox(height: 12),
                _buildSenderOption(
                  context: context,
                  setStateBS: setStateBottomSheet,
                  mode: "private",
                  icon: Icons.lock_outline,
                  title: "PRIVATE",
                  isActive: _isPrivateActive,
                  count: _privateSenderCount,
                ),
                const SizedBox(height: 10),
                _buildSenderOption(
                  context: context,
                  setStateBS: setStateBottomSheet,
                  mode: "global",
                  icon: Icons.public,
                  title: "GLOBAL",
                  isActive: _globalSenderCount > 0,
                  count: _globalSenderCount,
                ),
                const SizedBox(height: 16),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildSenderOption({required BuildContext context, required StateSetter setStateBS, required String mode, required IconData icon, required String title, required bool isActive, required int count}) {
    final selected = _senderMode == mode;
    final statusColor = isActive ? _successGreen : _errorRed;
    
    return GestureDetector(
      onTap: () {
        setStateBS(() { _senderMode = mode; _showSenderPopup = false; });
        setState(() {});
        Navigator.pop(context);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: selected ? _accentYellow : _bgCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? _accentOrange : _borderDark,
            width: selected ? 3 : 2,
          ),
          boxShadow: selected ? [
            BoxShadow(
              color: _shadowColor.withValues(alpha: 0.15),
              blurRadius: 0,
              offset: const Offset(4, 4),
            ),
          ] : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: statusColor,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _borderDark, width: 2),
                  ),
                  child: Icon(icon, color: _bgCard, size: 18),
                ),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: _textDark)),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Container(width: 8, height: 8, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle, border: Border.all(color: _borderDark, width: 1))),
                        const SizedBox(width: 6),
                        Text(
                          "${isActive ? 'Active' : 'Inactive'} • $count Sender",
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _textGray),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            if (selected)
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: _accentOrange,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _borderDark, width: 2),
                ),
                child: const Icon(Icons.check, color: _bgCard, size: 16),
              ),
          ],
        ),
      ),
    );
  }

  // ==================== POPUP TARGET SELECTION ====================
  void _showTargetSelectionPopup() {
    setState(() { _showTargetPopup = true; });
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateBottomSheet) {
          return Container(
            margin: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _bgCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _borderDark, width: 3),
              boxShadow: [
                BoxShadow(
                  color: _shadowColor.withValues(alpha: 0.2),
                  blurRadius: 0,
                  offset: const Offset(8, 8),
                ),
              ],
            ),
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: _textGray,
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: _borderDark, width: 1),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Center(
                  child: Text(
                    "PILIH TARGET",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      color: _textDark,
                      letterSpacing: 2,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const Divider(color: _borderDark, thickness: 2),
                const SizedBox(height: 12),
                _buildTargetOption(
                  context: context,
                  setStateBS: setStateBottomSheet,
                  mode: "number",
                  icon: Icons.person_rounded,
                  title: "BUG NOMOR",
                  desc: "Kirim bug ke nomor personal",
                ),
                const SizedBox(height: 10),
                _buildTargetOption(
                  context: context,
                  setStateBS: setStateBottomSheet,
                  mode: "group",
                  icon: Icons.group_rounded,
                  title: "BUG GROUP",
                  desc: "Kirim bug ke link grup",
                ),
                const SizedBox(height: 16),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildTargetOption({required BuildContext context, required StateSetter setStateBS, required String mode, required IconData icon, required String title, required String desc}) {
    final selected = _selectedBugMode == mode;
    return GestureDetector(
      onTap: () {
        setStateBS(() {
          _selectedBugMode = mode;
          _showTargetPopup = false;
          targetController.clear();
          final newBugs = _getFilteredBugs();
          if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
        });
        setState(() {});
        Navigator.pop(context);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: selected ? _accentYellow : _bgCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? _accentOrange : _borderDark,
            width: selected ? 3 : 2,
          ),
          boxShadow: selected ? [
            BoxShadow(
              color: _shadowColor.withValues(alpha: 0.15),
              blurRadius: 0,
              offset: const Offset(4, 4),
            ),
          ] : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _accentBlue,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _borderDark, width: 2),
                  ),
                  child: Icon(icon, color: _bgCard, size: 18),
                ),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: _textDark)),
                    const SizedBox(height: 3),
                    Text(desc, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _textGray)),
                  ],
                ),
              ],
            ),
            if (selected)
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: _accentOrange,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _borderDark, width: 2),
                ),
                child: const Icon(Icons.check, color: _bgCard, size: 16),
              ),
          ],
        ),
      ),
    );
  }

  // ==================== WIDGET: TEST FUNCTION ====================
  Widget _buildTestFunctionWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _neoSectionLabel("TEST FUNCTION"),
        _neoContainer(
          borderRadius: 14,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _accentYellow.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _borderDark, width: 2),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.science_rounded, color: _textDark, size: 16),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          "Tempel teks untuk test payload",
                          style: TextStyle(
                            color: _textGray,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _accentOrange,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: _borderDark, width: 2),
                        ),
                        child: const Text(
                          "BETA",
                          style: TextStyle(
                            color: _bgCard,
                            fontSize: 8,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: testController,
                  style: const TextStyle(color: _textDark, fontSize: 13, fontWeight: FontWeight.w700),
                  cursorColor: _accentOrange,
                  maxLines: 3,
                  minLines: 2,
                  decoration: InputDecoration(
                    hintText: "Tempel teks test di sini...",
                    hintStyle: const TextStyle(color: _textGray, fontSize: 13, fontWeight: FontWeight.w500),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: _borderDark, width: 2),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: _borderDark, width: 2),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: _accentOrange, width: 2),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    suffixIcon: testController.text.isNotEmpty
                        ? GestureDetector(
                            onTap: () => testController.clear(),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Container(
                                padding: const EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                  color: _errorRed,
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(color: _borderDark, width: 2),
                                ),
                                child: Icon(Icons.close_rounded, color: _bgCard, size: 14),
                              ),
                            ),
                          )
                        : null,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: _accentBlue.withValues(alpha: 0.2),
                              blurRadius: 0,
                              offset: const Offset(3, 3),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: _isTestSending || testController.text.isEmpty
                              ? null
                              : () async {
                                  setState(() {
                                    _isTestSending = true;
                                  });

                                  try {
                                    final testText = testController.text.trim();
                                    
                                    _addToHistory(
                                      "TEST: ${testText.length > 20 ? '${testText.substring(0, 20)}...' : testText}",
                                      "TEST_PAYLOAD",
                                      "Test Success",
                                      true
                                    );

                                    _showAlert(
                                      "✅ Test Success",
                                      "Test payload berhasil dikirim!\n\nTeks: ${testText.length > 50 ? '${testText.substring(0, 50)}...' : testText}"
                                    );
                                    
                                    testController.clear();
                                  } catch (e) {
                                    _showAlert("❌ Test Failed", "Terjadi kesalahan saat test: $e");
                                  } finally {
                                    setState(() {
                                      _isTestSending = false;
                                    });
                                  }
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _accentBlue,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: const BorderSide(color: _borderDark, width: 2),
                            ),
                            elevation: 0,
                            disabledBackgroundColor: _textGray,
                            minimumSize: const Size(double.infinity, 44),
                          ),
                          child: _isTestSending
                              ? Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: 18,
                                      width: 18,
                                      child: CircularProgressIndicator(
                                        color: _bgCard,
                                        strokeWidth: 3,
                                        strokeCap: StrokeCap.round,
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    const Text(
                                      "TESTING...",
                                      style: TextStyle(
                                        color: _bgCard,
                                        fontWeight: FontWeight.w900,
                                        fontSize: 12,
                                        letterSpacing: 1.5,
                                      ),
                                    ),
                                  ],
                                )
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: _bgCard,
                                        borderRadius: BorderRadius.circular(6),
                                        border: Border.all(color: _borderDark, width: 2),
                                      ),
                                      child: const Icon(Icons.play_arrow_rounded, color: _accentBlue, size: 14),
                                    ),
                                    const SizedBox(width: 10),
                                    const Text(
                                      "RUN TEST",
                                      style: TextStyle(
                                        color: _bgCard,
                                        fontWeight: FontWeight.w900,
                                        fontSize: 12,
                                        letterSpacing: 1.5,
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _bgCard,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _borderDark, width: 2),
                      ),
                      child: IconButton(
                        onPressed: () {
                          setState(() {
                            _history.removeWhere((item) => item['bug_id'] == 'TEST_PAYLOAD');
                          });
                          _showAlert("✅ Cleared", "Semua history test telah dihapus.");
                        },
                        icon: const Icon(Icons.delete_sweep_rounded, color: _errorRed, size: 20),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _bgPrimary,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _borderDark.withValues(alpha: 0.3), width: 1),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline_rounded, color: _textGray.withValues(alpha: 0.5), size: 12),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          "Test function akan menambahkan entri ke history tanpa mengirim ke WhatsApp",
                          style: TextStyle(
                            color: _textGray.withValues(alpha: 0.5),
                            fontSize: 9,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ==================== WIDGET: STATISTIK ====================
  Widget _buildStatsWidget() {
    return _neoContainer(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildStatItem(widget.listBug.length.toString(), "Total Bugs", Icons.bug_report_outlined),
            Container(width: 2, height: 32, color: _borderDark),
            _buildStatItem("GACOR", "Success Rate", Icons.trending_up_rounded),
            Container(width: 2, height: 32, color: _borderDark),
            _buildStatItem("ACTIVE", "Status", Icons.radio_button_checked_rounded),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String mainText, String subtitle, IconData icon) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: _accentYellow,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: _borderDark, width: 2),
          ),
          child: Icon(icon, color: _textDark, size: 18),
        ),
        const SizedBox(height: 6),
        Text(mainText, style: const TextStyle(color: _textDark, fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 0.8)),
        const SizedBox(height: 2),
        Text(subtitle, style: const TextStyle(color: _textGray, fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
      ],
    );
  }

  // ==================== WIDGET: TOP APP BAR ====================
  Widget _buildTopAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
          decoration: BoxDecoration(
            color: _accentYellow,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _borderDark, width: 3),
            boxShadow: [
              BoxShadow(
                color: _shadowColor.withValues(alpha: 0.15),
                blurRadius: 0,
                offset: const Offset(4, 4),
              ),
            ],
          ),
          child: const Text(
            "ORBITION",
            style: TextStyle(
              color: _textDark,
              fontWeight: FontWeight.w900,
              fontSize: 22,
              letterSpacing: 3.0,
            ),
          ),
        ),
      ),
    );
  }

  // ==================== WIDGET: HEADER CARD ====================
  Widget _buildTopHeader() {
    return _neoContainer(
      borderRadius: 14,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _accentYellow,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _borderDark, width: 2),
              ),
              child: const Icon(Icons.bug_report_rounded, color: _textDark, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "WHATSAPP CRASH",
                    style: TextStyle(
                      color: _textDark,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "Advanced Payload Injection",
                    style: TextStyle(
                      color: _textGray,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _neoBadge(widget.role.toUpperCase(), _accentYellow),
                      const SizedBox(width: 8),
                      _neoBadge(widget.expiredDate, _accentBlue),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== WIDGET: VIDEO BOX ====================
  Widget _buildVideoBox() {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _borderDark, width: 3),
        boxShadow: [
          BoxShadow(
            color: _shadowColor.withValues(alpha: 0.15),
            blurRadius: 0,
            offset: const Offset(4, 4),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned.fill(
            child: _videoController.value.isInitialized
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController.value.size.width,
                      height: _videoController.value.size.height,
                      child: VideoPlayer(_videoController),
                    ),
                  )
                : const Center(child: CircularProgressIndicator(color: _accentYellow, strokeWidth: 3)),
          ),
          Positioned.fill(
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withValues(alpha: 0.4),
                      Colors.transparent,
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.5),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 10,
            left: 10,
            child: AnimatedBuilder(
              animation: _pulseController,
              builder: (context, child) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: _errorRed,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _borderDark, width: 2),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: _bgCard,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 5),
                      const Text(
                        "LIVE",
                        style: TextStyle(
                          color: _bgCard,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Positioned(
            top: 10,
            right: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: _bgCard,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: _borderDark, width: 2),
              ),
              child: const Text(
                "HD",
                style: TextStyle(
                  color: _textDark,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 10,
            left: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: _bgCard.withValues(alpha: 0.9),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: _borderDark, width: 2),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(width: 6, height: 6, decoration: BoxDecoration(color: _accentYellow, shape: BoxShape.circle, border: Border.all(color: _borderDark, width: 1))),
                  const SizedBox(width: 5),
                  Text(
                    "REC ${DateTime.now().second}s",
                    style: const TextStyle(
                      color: _textDark,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== WIDGET: HISTORY ====================
  Widget _buildHistoryWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _neoSectionLabel("RIWAYAT PENGIRIMAN"),
            GestureDetector(
              onTap: _fetchHistory,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _accentBlue,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _borderDark, width: 2),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.refresh_rounded, color: _bgCard, size: 14),
                    const SizedBox(width: 4),
                    const Text(
                      "REFRESH",
                      style: TextStyle(
                        color: _bgCard,
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        _neoContainer(
          borderRadius: 14,
          child: _isLoadingHistory
              ? const Padding(
                  padding: EdgeInsets.all(32.0),
                  child: Center(
                    child: CircularProgressIndicator(color: _accentYellow, strokeWidth: 3),
                  ),
                )
              : _history.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Center(
                        child: Column(
                          children: [
                            Icon(Icons.history_rounded, color: _textGray.withValues(alpha: 0.3), size: 48),
                            const SizedBox(height: 8),
                            Text(
                              "Belum ada riwayat",
                              style: TextStyle(
                                color: _textGray.withValues(alpha: 0.5),
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                              ),
                            ),
                            Text(
                              "Kirim bug pertama Anda!",
                              style: TextStyle(
                                color: _textGray.withValues(alpha: 0.3),
                                fontWeight: FontWeight.w500,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _history.length > 10 ? 10 : _history.length,
                      separatorBuilder: (_, __) => Divider(
                        color: _borderDark.withValues(alpha: 0.1),
                        thickness: 1,
                        height: 1,
                      ),
                      itemBuilder: (context, index) {
                        final item = _history[index];
                        final isSuccess = item['success'] ?? false;
                        final statusColor = isSuccess ? _successGreen : _errorRed;
                        final time = DateTime.tryParse(item['time'] ?? '');
                        final timeStr = time != null
                            ? "${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}"
                            : '--:--';

                        return Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            color: index.isEven ? _bgPrimary : _bgCard,
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                  color: statusColor,
                                  shape: BoxShape.circle,
                                  border: Border.all(color: _borderDark, width: 1),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                flex: 3,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item['target'] ?? 'Unknown',
                                      style: const TextStyle(
                                        color: _textDark,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w800,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      item['bug_id'] ?? 'Unknown Bug',
                                      style: TextStyle(
                                        color: _textGray.withValues(alpha: 0.6),
                                        fontSize: 9,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: statusColor,
                                  borderRadius: BorderRadius.circular(4),
                                  border: Border.all(color: _borderDark, width: 1),
                                ),
                                child: Text(
                                  item['status'] ?? 'Unknown',
                                  style: const TextStyle(
                                    color: _bgCard,
                                    fontSize: 8,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                timeStr,
                                style: TextStyle(
                                  color: _textGray.withValues(alpha: 0.4),
                                  fontSize: 9,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
        ),
        if (_history.length > 10)
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Center(
              child: Text(
                "+ ${_history.length - 10} riwayat lainnya",
                style: TextStyle(
                  color: _textGray.withValues(alpha: 0.4),
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
      ],
    );
  }

  // ==================== WIDGET: SELECTOR CARDS ====================
  Widget _buildTargetTypeSelector() {
    return GestureDetector(
      onTap: _showTargetSelectionPopup,
      child: _neoContainer(
        borderRadius: 14,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _accentOrange,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _borderDark, width: 2),
                ),
                child: Icon(_selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.group_rounded, color: _bgCard, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("TARGET TYPE", style: TextStyle(color: _textGray, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Text(_selectedBugMode == "number" ? "BUG NOMOR" : "BUG GROUP", style: const TextStyle(color: _textDark, fontWeight: FontWeight.w900, fontSize: 14)),
                        const SizedBox(width: 8),
                        _neoBadge(_selectedBugMode == "number" ? "Personal" : "Group", _accentYellow),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _bgCard,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _borderDark, width: 2),
                ),
                child: const Icon(Icons.unfold_more_rounded, color: _textGray, size: 18),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSenderModeSelector() {
    final isActive = _senderMode == "private" ? _isPrivateActive : _globalSenderCount > 0;
    final count = _senderMode == "private" ? _privateSenderCount : _globalSenderCount;
    final statusColor = isActive ? _successGreen : _errorRed;

    return GestureDetector(
      onTap: _showSenderSelectionPopup,
      child: _neoContainer(
        borderRadius: 14,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _borderDark, width: 2),
                ),
                child: Icon(_senderMode == "private" ? Icons.lock_outline_rounded : Icons.public_rounded, color: _bgCard, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text("SENDER MODE", style: TextStyle(color: _textGray, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
                        const SizedBox(width: 8),
                        _neoBadge(isActive ? "Active" : "Inactive", isActive ? _successGreen : _errorRed),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(_senderMode == "private" ? "PRIVATE SENDER" : "GLOBAL SENDER", style: const TextStyle(color: _textDark, fontWeight: FontWeight.w900, fontSize: 14)),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Container(width: 6, height: 6, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle, border: Border.all(color: _borderDark, width: 1))),
                        const SizedBox(width: 5),
                        Text("$count Sender Active", style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _bgCard,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _borderDark, width: 2),
                ),
                child: const Icon(Icons.unfold_more_rounded, color: _textGray, size: 18),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== WIDGET: INPUT PANEL ====================
  Widget _buildInputPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _neoSectionLabel(_selectedBugMode == "number" ? "TARGET NUMBER" : "WHATSAPP GROUP LINK"),
        _neoContainer(
          borderRadius: 14,
          child: TextField(
            controller: targetController,
            style: const TextStyle(color: _textDark, fontSize: 14, fontWeight: FontWeight.w700),
            cursorColor: _accentOrange,
            keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
            decoration: InputDecoration(
              hintText: _selectedBugMode == "number" ? "e.g. +628xxxxxxxx" : "e.g. https://chat.whatsapp.com/...",
              hintStyle: const TextStyle(color: _textGray, fontSize: 13, fontWeight: FontWeight.w500),
              border: InputBorder.none,
              prefixIcon: Padding(
                padding: const EdgeInsets.all(14),
                child: Icon(_selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link_rounded, color: _textGray, size: 20),
              ),
              suffixIcon: targetController.text.isNotEmpty
                  ? GestureDetector(
                      onTap: () => setState(() => targetController.clear()),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: _errorRed,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: _borderDark, width: 2),
                          ),
                          child: Icon(Icons.close_rounded, color: _bgCard, size: 14),
                        ),
                      ),
                    )
                  : null,
              contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
            ),
          ),
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Row(
            children: [
              Icon(Icons.info_outline_rounded, color: _textGray.withValues(alpha: 0.5), size: 14),
              const SizedBox(width: 4),
              Text(
                _selectedBugMode == "number" ? "Format: +[kode negara][nomor]" : "Paste link grup WhatsApp yang valid",
                style: TextStyle(color: _textGray.withValues(alpha: 0.5), fontSize: 10, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ==================== WIDGET: PAYLOAD DROPDOWN ====================
  Widget _buildPayloadDropdown() {
    final availableBugs = _getFilteredBugs();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _neoSectionLabel("SELECT PAYLOAD BUG"),
        _neoContainer(
          borderRadius: 14,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: _bgCard,
                value: selectedBugId.isNotEmpty ? selectedBugId : null,
                isExpanded: true,
                icon: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: _bgCard,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _borderDark, width: 2),
                  ),
                  child: const Icon(Icons.keyboard_arrow_down_rounded, color: _textGray, size: 20),
                ),
                style: const TextStyle(color: _textDark, fontSize: 13, fontWeight: FontWeight.w700),
                items: availableBugs.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            color: _accentYellow,
                            borderRadius: BorderRadius.circular(3),
                            border: Border.all(color: _borderDark, width: 2),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(bug['bug_name']),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() { selectedBugId = value ?? ""; });
                },
              ),
            ),
          ),
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Row(
            children: [
              Icon(Icons.layers_outlined, color: _textGray.withValues(alpha: 0.5), size: 14),
              const SizedBox(width: 4),
              Text(
                "${availableBugs.length} payload tersedia untuk mode ini",
                style: TextStyle(color: _textGray.withValues(alpha: 0.5), fontSize: 10, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ==================== WIDGET: LAUNCH BUTTON ====================
  Widget _buildLaunchButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: _accentOrange.withValues(alpha: 0.3 + _pulseController.value * 0.3),
                blurRadius: 0,
                offset: const Offset(4, 4),
              ),
            ],
          ),
          child: SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: _isSending ? null : _sendBug,
              style: ElevatedButton.styleFrom(
                backgroundColor: _accentOrange,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                  side: const BorderSide(color: _borderDark, width: 3),
                ),
                elevation: 0,
                disabledBackgroundColor: _textGray,
              ),
              child: _isSending
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: 22,
                          width: 22,
                          child: CircularProgressIndicator(
                            color: _bgCard,
                            strokeWidth: 3,
                            strokeCap: StrokeCap.round,
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          "PROCESSING...",
                          style: TextStyle(
                            color: _bgCard,
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: _bgCard,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: _borderDark, width: 2),
                          ),
                          child: const Icon(Icons.send_rounded, color: _accentOrange, size: 18),
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          "LAUNCH ATTACK",
                          style: TextStyle(
                            color: _bgCard,
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                            letterSpacing: 2.5,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  // ==================== WIDGET: FOOTER INFO ====================
  Widget _buildFooterInfo() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _borderDark, width: 2),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: _accentYellow,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: _borderDark, width: 1),
            ),
            child: Icon(Icons.key_rounded, color: _textDark, size: 12),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              "Session: ${widget.expiredDate}  •  P($_privateSenderCount)  G($_globalSenderCount)",
              style: const TextStyle(color: _textGray, fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: 0.3),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: _successGreen,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: _borderDark, width: 2),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 6, height: 6, decoration: BoxDecoration(color: _bgCard, shape: BoxShape.circle)),
                const SizedBox(width: 4),
                const Text(
                  "ONLINE",
                  style: TextStyle(
                    color: _bgCard,
                    fontSize: 8,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==================== MAIN BUILD ====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgPrimary,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 4),
              _buildTopAppBar(),
              const SizedBox(height: 16),
              _buildTopHeader(),
              const SizedBox(height: 16),
              _buildVideoBox(),
              const SizedBox(height: 16),
              _buildHistoryWidget(),
              const SizedBox(height: 16),
              _buildStatsWidget(),
              const SizedBox(height: 16),
              _buildTargetTypeSelector(),
              const SizedBox(height: 10),
              _buildSenderModeSelector(),
              const SizedBox(height: 16),
              _buildTestFunctionWidget(),
              const SizedBox(height: 16),
              _buildInputPanel(),
              const SizedBox(height: 16),
              _buildPayloadDropdown(),
              const SizedBox(height: 20),
              _buildLaunchButton(),
              const SizedBox(height: 16),
              _buildFooterInfo(),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}