// Smoke-test manual: npm run check memvalidasi sintaks file JavaScript utama.
console.log('Gunakan npm run check sebelum menjalankan bot.');
