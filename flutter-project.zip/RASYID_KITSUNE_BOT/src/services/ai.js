import { GoogleGenerativeAI } from '@google/generative-ai';
import { db, audit } from '../db/database.js';

const keys = [1,2,3,4].map(n => process.env[`GEMINI_API_KEY_${n}`]).filter(Boolean);
let cursor = 0;
const cooldown = new Map();

export async function askGemini(prompt, telegramId) {
  if (!keys.length) throw new Error('AI_NOT_CONFIGURED: Owner belum memasang Gemini API Key.');
  const errors = [];
  for (let attempt=0; attempt<keys.length; attempt++) {
    const index = (cursor + attempt) % keys.length;
    const key = keys[index];
    if ((cooldown.get(index) || 0) > Date.now()) continue;
    try {
      const client = new GoogleGenerativeAI(key);
      const model = client.getGenerativeModel({ model: process.env.GEMINI_MODEL || 'gemini-2.0-flash' });
      const result = await model.generateContent({
        contents: [{ role: 'user', parts: [{ text: String(prompt).slice(0, 20000) }] }],
        generationConfig: { maxOutputTokens: 2000, temperature: 0.7 }
      });
      cursor = (index + 1) % keys.length;
      db.prepare('INSERT INTO usage(telegram_id,feature) VALUES(?,?)').run(String(telegramId), `gemini_key_${index+1}`);
      audit(telegramId, 'AI_REQUEST', `key_slot=${index+1}`);
      return result.response.text();
    } catch (err) {
      const status = Number(err?.status || err?.httpStatusCode || 0);
      const msg = String(err?.message || err);
      errors.push(`Key ${index+1}: ${msg.slice(0,180)}`);
      // Cool down transient rate/quota/server failures; do not mislabel auth/config errors.
      if ([429, 500, 502, 503, 504].includes(status) || /quota|rate.?limit|resource.?exhausted/i.test(msg)) {
        cooldown.set(index, Date.now() + 60_000);
      } else if ([400,401,403].includes(status) || /api key|permission|unauthorized|invalid argument/i.test(msg)) {
        cooldown.set(index, Date.now() + 10 * 60_000);
      }
    }
  }
  throw new Error(`Semua Gemini API Key gagal atau sedang cooldown. ${errors.join(' | ')}`);
}
