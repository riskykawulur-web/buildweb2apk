import 'dotenv/config';
import { Telegraf } from 'telegraf';
import { registerTelegram } from './handlers/telegram.js';

if (!process.env.BOT_TOKEN) {
  console.error('BOT_TOKEN belum diisi. Salin .env.example menjadi .env lalu isi token.');
  process.exit(1);
}
if (!process.env.OWNER_TELEGRAM_ID) {
  console.error('OWNER_TELEGRAM_ID belum diisi. Isi Telegram ID Angga di .env.');
  process.exit(1);
}
const bot = new Telegraf(process.env.BOT_TOKEN);
registerTelegram(bot);

let stopping=false;
async function shutdown(signal) {
  if (stopping) return; stopping=true;
  console.log(`${signal}: menghentikan bot...`);
  try { bot.stop(signal); } catch {}
  process.exit(0);
}
process.once('SIGINT',()=>shutdown('SIGINT'));
process.once('SIGTERM',()=>shutdown('SIGTERM'));
await bot.launch();
console.log('RASYID KITSUNE BOT aktif.');
