import { Markup } from 'telegraf';
import { db, getSetting, setSetting, recordUser, audit } from '../db/database.js';
import { askGemini } from '../services/ai.js';

export const CATEGORIES = [
  'AI Assistant','AI Chat & Conversation','AI Writing','AI Translator','AI Image Tools',
  'AI Document Assistant','WhatsApp Connection','WhatsApp Auto Reply','WhatsApp Group Management',
  'WhatsApp Broadcast','WhatsApp Message Scheduler','Downloader','Media Converter','Image Tools',
  'Video Tools','Audio Tools','File Manager','QR Generator','Link Generator','Information Tools',
  'Utility Tools','Group Administration','Telegram Management','User Dashboard','Help & Documentation'
];

const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'');
const isOwner = ctx => String(ctx.from?.id) === String(process.env.OWNER_TELEGRAM_ID || '');

function mainKeyboard() {
  const rows=[];
  for (let i=0;i<CATEGORIES.length;i+=2) rows.push(CATEGORIES.slice(i,i+2).map(name =>
    Markup.button.callback(name, `menu:${slug(name)}`)));
  rows.push([Markup.button.callback('👑 OWNER PANEL','owner:home')]);
  return Markup.inlineKeyboard(rows);
}
async function memberStatus(ctx, chatId) {
  if (!chatId) return true;
  try {
    const m = await ctx.telegram.getChatMember(chatId, ctx.from.id);
    return ['creator','administrator','member'].includes(m.status) ||
      (m.status === 'restricted' && m.is_member);
  } catch { return false; }
}
async function gate(ctx) {
  const groupId = process.env.REQUIRED_GROUP_ID;
  const channelId = process.env.REQUIRED_CHANNEL_ID;
  const needGroup = Boolean(groupId && process.env.REQUIRED_GROUP_URL);
  const needChannel = Boolean(channelId && process.env.REQUIRED_CHANNEL_URL);
  const groupOk = !needGroup || await memberStatus(ctx, groupId);
  const channelOk = !needChannel || await memberStatus(ctx, channelId);
  if (groupOk && channelOk) return true;
  const rows=[];
  if (!groupOk) rows.push([Markup.button.url('JOIN GROUP',process.env.REQUIRED_GROUP_URL)]);
  if (!channelOk) rows.push([Markup.button.url('JOIN CHANNEL',process.env.REQUIRED_CHANNEL_URL)]);
  if (process.env.WHATSAPP_CHANNEL_URL) rows.push([Markup.button.url('BUKA WHATSAPP CHANNEL',process.env.WHATSAPP_CHANNEL_URL)]);
  rows.push([Markup.button.callback('🔄 CEK KEANGGOTAAN','gate:check')]);
  await ctx.reply('🔒 Akses belum dibuka. Ikuti persyaratan Telegram di atas, lalu tekan CEK KEANGGOTAAN.\n\nWhatsApp Channel ditampilkan sebagai tautan; keanggotaannya tidak dapat diverifikasi otomatis melalui Bot API Telegram.', Markup.inlineKeyboard(rows));
  return false;
}
async function sendConfiguredVideo(ctx, key, caption) {
  const url = getSetting(key, '');
  if (!url) return false;
  try {
    await ctx.replyWithVideo(url, { caption, supports_streaming: true });
    return true;
  } catch (e) {
    console.error(`Video ${key} gagal:`, e.message);
    return false;
  }
}
async function showStart(ctx) {
  const body = `${getSetting('start_caption','🦊 Selamat datang di RASYID KITSUNE BOT')}\n\n📜 RULES\n${getSetting('rules','Gunakan bot dengan bijak. Dilarang spam dan menyalahgunakan layanan.')}\n\n🤖 RASYID KITSUNE BOT\nPembuat: Angga\nOwner: Angga`;
  const videoOn = getSetting('start_video_enabled','true') === 'true';
  if (videoOn && getSetting('start_video_url','')) {
    try { await ctx.replyWithVideo(getSetting('start_video_url'), { caption: body, supports_streaming:true, ...mainKeyboard() }); }
    catch { await ctx.reply(body + '\n\n(Video Start gagal dimuat; menu tetap tersedia.)', mainKeyboard()); }
  } else await ctx.reply(body, mainKeyboard());
}
async function showCategory(ctx, category) {
  const title = CATEGORIES.find(c=>slug(c)===category);
  if (!title) return ctx.answerCbQuery('Kategori tidak ditemukan.');
  const allowed = getSetting(`feature_enabled_${category}`,'true') === 'true';
  if (!allowed) return ctx.answerCbQuery('Kategori sedang dinonaktifkan.',{show_alert:true});
  const tutorialOn = getSetting(`tutorial_enabled_${category}`,'true') === 'true';
  if (tutorialOn) await sendConfiguredVideo(ctx, `tutorial_${category}_url`, `🎬 Tutorial: ${title}`);
  const text = `🦊 ${title}\n\nPilih tindakan yang tersedia. Video tutorial kategori ditampilkan jika Owner sudah memasang URL-nya.`;
  const rows = [];
  if (category.startsWith('ai_')) rows.push([Markup.button.callback('💬 Tanya AI','action:ai')]);
  if (category === 'user_dashboard') rows.push([Markup.button.callback('📊 Statistik akun','action:stats')]);
  if (category === 'help_documentation') rows.push([Markup.button.callback('📖 Panduan dasar','action:help')]);
  if (category === 'utility_tools') rows.push([Markup.button.callback('🆔 Info Telegram saya','action:myid')]);
  rows.push([Markup.button.callback('⬅️ Menu utama','menu:home')]);
  await ctx.reply(text, Markup.inlineKeyboard(rows));
}
async function ownerHome(ctx) {
  if (!isOwner(ctx)) return ctx.answerCbQuery('⚠️ AKSES DITOLAK! Khusus OWNER RASYID KITSUNE BOT.',{show_alert:true});
  await ctx.reply('👑 OWNER PANEL — Angga\n\nPerintah konfigurasi tersedia melalui chat pribadi:\n/setstartvideo URL\n/setstartvideooff\n/settutorial nama_kategori URL\n/settutorialoff nama_kategori\n/setrules teks\n/setcaption teks\n/status', Markup.inlineKeyboard([[Markup.button.callback('⬅️ Menu utama','menu:home')]]));
}
export function registerTelegram(bot) {
  bot.start(async ctx => {
    recordUser(ctx.from);
    if (db.prepare('SELECT banned FROM users WHERE telegram_id=?').get(String(ctx.from.id))?.banned) return ctx.reply('Akses akun ini dibatasi.');
    if (await gate(ctx)) await showStart(ctx);
  });
  bot.command('menu', async ctx => { if (await gate(ctx)) await ctx.reply('Pilih kategori:',mainKeyboard()); });
  bot.command('status', async ctx => {
    if (!isOwner(ctx)) return ctx.reply('Akses ditolak.');
    await ctx.reply(`Users: ${db.prepare('SELECT COUNT(*) n FROM users').get().n}\nGemini key slots configured: ${[1,2,3,4].filter(n=>process.env[`GEMINI_API_KEY_${n}`]).length}`);
  });
  bot.command('setstartvideo', async ctx => {
    if (!isOwner(ctx)) return ctx.reply('Akses ditolak.');
    const url=ctx.message.text.split(/\s+/).slice(1).join(' ').trim();
    if (!/^https:\/\//i.test(url)) return ctx.reply('Format: /setstartvideo https://... (URL MP4 Catbox)');
    setSetting('start_video_url',url); setSetting('start_video_enabled','true'); audit(ctx.from.id,'SET_START_VIDEO','URL updated');
    return ctx.reply('URL video Start disimpan. Gunakan /start untuk preview.');
  });
  bot.command('setstartvideooff', ctx => {
    if (!isOwner(ctx)) return ctx.reply('Akses ditolak.');
    setSetting('start_video_enabled','false'); return ctx.reply('Video Start dinonaktifkan.');
  });
  bot.command('setrules', ctx => {
    if (!isOwner(ctx)) return ctx.reply('Akses ditolak.');
    const value=ctx.message.text.split(/\s+/).slice(1).join(' ');
    if (!value) return ctx.reply('Format: /setrules teks rules');
    setSetting('rules',value); return ctx.reply('Rules diperbarui.');
  });
  bot.command('setcaption', ctx => {
    if (!isOwner(ctx)) return ctx.reply('Akses ditolak.');
    const value=ctx.message.text.split(/\s+/).slice(1).join(' ');
    if (!value) return ctx.reply('Format: /setcaption teks sambutan');
    setSetting('start_caption',value); return ctx.reply('Caption diperbarui.');
  });
  bot.command('settutorial', ctx => {
    if (!isOwner(ctx)) return ctx.reply('Akses ditolak.');
    const parts=ctx.message.text.split(/\s+/);
    const category=parts[1]; const url=parts.slice(2).join(' ');
    if (!category || !/^https:\/\//i.test(url)) return ctx.reply('Format: /settutorial ai_assistant https://...mp4');
    if (!CATEGORIES.some(c=>slug(c)===category)) return ctx.reply('Kategori tidak dikenal. Gunakan slug kategori dari daftar /categories.');
    setSetting(`tutorial_${category}_url`,url); setSetting(`tutorial_enabled_${category}`,'true');
    return ctx.reply(`Video tutorial ${category} disimpan.`);
  });
  bot.command('settutorialoff', ctx => {
    if (!isOwner(ctx)) return ctx.reply('Akses ditolak.');
    const category=ctx.message.text.split(/\s+/)[1];
    if (!category || !CATEGORIES.some(c=>slug(c)===category)) return ctx.reply('Format: /settutorialoff ai_assistant');
    setSetting(`tutorial_enabled_${category}`,'false'); return ctx.reply('Video tutorial kategori dinonaktifkan.');
  });
  bot.command('categories', ctx => ctx.reply(CATEGORIES.map(c=>`${c} — ${slug(c)}`).join('\n')));
  bot.action('gate:check', async ctx => {
    await ctx.answerCbQuery();
    if (await gate(ctx)) await showStart(ctx);
  });
  bot.action('menu:home', async ctx => { await ctx.answerCbQuery(); await ctx.reply('Pilih kategori:',mainKeyboard()); });
  bot.action(/^menu:(.+)$/, async ctx => { await ctx.answerCbQuery(); await showCategory(ctx,ctx.match[1]); });
  bot.action('owner:home', ownerHome);
  bot.action('action:myid', ctx => ctx.answerCbQuery(`Telegram ID: ${ctx.from.id}`,{show_alert:true}));
  bot.action('action:stats', async ctx => {
    const n=db.prepare('SELECT COUNT(*) n FROM users WHERE telegram_id=?').get(String(ctx.from.id)).n;
    await ctx.answerCbQuery(`ID: ${ctx.from.id} • Terdaftar: ${n}`,{show_alert:true});
  });
  bot.action('action:help', ctx => ctx.answerCbQuery('Gunakan /start untuk menu dan /menu untuk membuka kategori.',{show_alert:true}));
  bot.action('action:ai', async ctx => {
    await ctx.answerCbQuery();
    await ctx.reply('Kirim pertanyaan dengan format: /ask pertanyaan');
  });
  bot.command('ask', async ctx => {
    if (!(await gate(ctx))) return;
    const prompt=ctx.message.text.replace(/^\/ask\s*/,'').trim();
    if (!prompt) return ctx.reply('Format: /ask Apa itu AI?');
    const msg=await ctx.reply('⏳ AI sedang berpikir...');
    try {
      const answer=await askGemini(prompt,ctx.from.id);
      await ctx.telegram.editMessageText(ctx.chat.id,msg.message_id,undefined,answer.slice(0,4000));
    } catch(e) {
      await ctx.telegram.editMessageText(ctx.chat.id,msg.message_id,undefined,`AI gagal: ${e.message.slice(0,800)}`);
    }
  });
  bot.on('text', async ctx => {
    recordUser(ctx.from);
  });
  bot.catch(err => console.error('Telegram handler error:',err));
}
