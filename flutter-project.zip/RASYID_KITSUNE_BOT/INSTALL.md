# INSTALL — Termux

```bash
pkg update && pkg upgrade
pkg install nodejs-lts unzip
unzip RASYID_KITSUNE_BOT.zip
cd RASYID_KITSUNE_BOT
npm install
cp .env.example .env
nano .env
npm run check
npm start
```

Isi minimal:
- `BOT_TOKEN`: token bot dari @BotFather.
- `OWNER_TELEGRAM_ID`: Telegram numeric ID Angga.

Untuk mengaktifkan AI, isi satu atau lebih `GEMINI_API_KEY_1` sampai `_4`.
Jangan pernah mengirim token atau API key ke orang lain.
