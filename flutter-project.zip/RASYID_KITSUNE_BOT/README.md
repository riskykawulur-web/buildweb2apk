# RASYID KITSUNE BOT

Fondasi awal Telegram bot modular. Identitas: Pembuat Angga, Owner Angga.

## Yang sudah diimplementasikan pada paket ini
- 25 kategori menu utama dengan navigasi inline.
- Video Start MP4 melalui URL HTTPS yang dapat diatur Owner.
- Video tutorial terpisah per kategori; video ditampilkan saat kategori dibuka jika URL sudah dipasang.
- Rules, caption, dan URL video disimpan di SQLite.
- Owner authorization berbasis `OWNER_TELEGRAM_ID` di backend.
- Gate keanggotaan Telegram Group dan Telegram Channel (perlu bot menjadi anggota/admin agar `getChatMember` dapat diandalkan).
- WhatsApp Channel disediakan sebagai tautan/instruksi; keanggotaan tidak diklaim terverifikasi otomatis.
- Gemini dengan sampai empat API key, rotasi, cooldown dasar, dan batas output 2.000 token.
- Pencatatan pengguna, pemakaian AI, dan audit sederhana.

## Status penting
Ini adalah **fondasi tahap pertama**, bukan klaim bahwa seluruh 100+ fitur, panel lisensi pelanggan, atau WhatsApp Bridge sudah selesai. Menu yang belum memiliki backend khusus belum dinyatakan aktif. WhatsApp Baileys, customer license, role granular, video per subfitur, broadcast, backup/restore, dan pengujian integrasi menyeluruh masih perlu tahap implementasi dan uji terpisah.

## Instalasi Android Termux
1. Pasang Node.js LTS dan unzip:
   ```bash
   pkg update && pkg upgrade
   pkg install nodejs-lts unzip
   ```
2. Ekstrak ZIP lalu masuk folder proyek.
3. Install dependency:
   ```bash
   npm install
   ```
4. Siapkan konfigurasi:
   ```bash
   cp .env.example .env
   nano .env
   ```
5. Isi `BOT_TOKEN` dari BotFather dan `OWNER_TELEGRAM_ID` milik Angga. Isi key Gemini jika ingin AI aktif. Jangan kirim token/API key ke chat.
6. Jalankan:
   ```bash
   npm run check
   npm start
   ```

## Perintah Owner
- `/setstartvideo https://...` — set video Start (MP4 URL HTTPS).
- `/setstartvideooff` — nonaktifkan video Start.
- `/setrules teks rules` — ubah Rules.
- `/setcaption teks sambutan` — ubah caption Start.
- `/categories` — lihat slug 25 kategori.
- `/settutorial ai_assistant https://...` — set video tutorial kategori.
- `/settutorialoff ai_assistant` — nonaktifkan video tutorial kategori.
- `/status` — status ringkas.

Semua perintah Owner memeriksa Telegram ID di backend.

## Catatan video
Telegram menerima URL video langsung bila URL dapat diakses Telegram dan mengarah ke media yang kompatibel. Gunakan URL MP4 Catbox langsung, bukan halaman HTML/halaman preview. Audio asli dipertahankan karena bot mengirim video, bukan GIF. Uji URL melalui `/start` dan tiap kategori.

## Membership
Isi `REQUIRED_GROUP_ID`, `REQUIRED_GROUP_URL`, `REQUIRED_CHANNEL_ID`, `REQUIRED_CHANNEL_URL`. Tambahkan bot ke grup/channel dan berikan izin yang diperlukan. Kosongkan ID+URL bila syarat tersebut tidak digunakan.
WhatsApp Channel hanya berupa tombol tautan pada tahap ini karena Telegram Bot API tidak menyediakan verifikasi keanggotaan WhatsApp Channel.

## Keamanan
- `.env` tidak boleh dibagikan atau dimasukkan ke Git.
- Jangan menaruh API key di pesan Telegram.
- Gunakan perangkat/server yang aman; Termux dapat dihentikan Android saat baterai/ram dibatasi.
- SQLite file berada di `data/`; backup file tersebut saat bot berhenti.
