package com.example.aplikasiku

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val background = Color.rgb(16, 24, 39)
        val white = Color.WHITE
        val muted = Color.rgb(203, 213, 225)
        val blue = Color.rgb(37, 99, 235)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "AplikasiKu"
            textSize = 32f
            setTextColor(white)
            gravity = Gravity.CENTER
        }

        val description = TextView(this).apply {
            text = "Aplikasi Android native Kotlin sudah siap dikembangkan."
            textSize = 16f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 28)
        }

        val button = Button(this).apply {
            text = "Tekan saya"
            setTextColor(white)
            setBackgroundColor(blue)
            setOnClickListener {
                description.text = "Berhasil! Tombol aplikasi berfungsi."
            }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(button)
        setContentView(layout)
    }
}
