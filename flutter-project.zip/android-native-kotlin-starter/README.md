# AplikasiKu — Android Native Kotlin

Proyek starter Android native. Tidak menggunakan HTML, CSS, JavaScript, WebView, atau Capacitor.

## Build di Android Studio
1. Ekstrak ZIP.
2. Buka Android Studio, pilih **Open**, lalu pilih folder proyek ini.
3. Tunggu Gradle sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Build otomatis melalui GitHub Actions
1. Upload seluruh isi folder proyek ke repository GitHub pada branch `main`.
2. Buka tab **Actions**.
3. Pilih workflow **Build Native Android Debug APK**.
4. Setelah selesai, unduh artifact **AplikasiKu-debug-apk**.

## Kustomisasi
- Ubah nama aplikasi pada `app/src/main/AndroidManifest.xml`.
- Ubah package/application ID pada `app/build.gradle.kts` dan sesuaikan deklarasi package Kotlin serta struktur folder jika diperlukan.
- UI awal berada di `MainActivity.kt`.

Ini adalah template native awal, belum berupa APK hasil kompilasi. Build memerlukan Android SDK dan koneksi untuk mengunduh dependensi Gradle.
