#!/bin/sh

TH="com.dts.freefireth"
MAX="com.dts.freefiremax"
DIR="$(dirname "$0")"

cmd notification post -S bigtext -t "DRAGHS V4.0" "Status" "Engine Running..." >/dev/null 2>&1

# ==========================================
# MODERN ANIMATION & PROGRESS BAR
# ==========================================
progress_bar() {
  local task="$1"
  echo " ┌─[⏳] $task"
  sleep 0.15
  echo " └─> [████████████████████] 100% [SUCCESS]"
  echo ""
}

# ==========================================
# HEADER & BANNER BALOK PADAT ASLI
# ==========================================
show_header() {
  clear
  echo ""
  echo "========================================"
  echo "░█▀▄ ░█▀▄ ░█▀█ ░█▀▀ ░█░█ ░█▀"
  echo "░█▄▀ ░█▀▄ ░█▀█ ░█▄█ ░█▀█ ░▄█"
  echo "========================================"
  echo "       ULTIMATE PERFORMANCE V4.0"
  echo "----------------------------------------"
  echo " Developer    : ZEEN"
  echo " Engine       : MODULAR NEON v4.0"
  echo " System Status: ONLINE [ACTIVE]"
  echo "========================================"
  echo ""
}

show_help() {
  show_header
  echo "┌──────────────────────────────────────┐"
  echo "│          PETUNJUK PENGGUNAAN         │"
  echo "├──────────────────────────────────────┤"
  echo "│ Jalankan via terminal:               │"
  echo "│   sh /sdcard/DRAGHS/run.sh           │"
  echo "│                                      │"
  echo "│ Parameter langsung:                  │"
  echo "│   -ZEEN-ACTIVATE                     │"
  echo "│   -ZEEN-SENSIVITY                    │"
  echo "│   -ZEEN-RESET                        │"
  echo "└──────────────────────────────────────┘"
  echo " Official Channel:"
  echo " https://whatsapp.com/channel/..."
  echo ""
}

# ==========================================
# TWEAK CORE FUNCTIONS
# ==========================================
cmdperf() {
  cmd package compile --reset com.dts.freefireth >/dev/null 2>&1
  cmd package compile --reset com.dts.freefiremax >/dev/null 2>&1
  cmd looper_stats disable
  cmd power set-adaptive-power-saver-enabled false
  cmd power set-mode 0
  settings put global cached_apps_freezer enabled
}

execaim() {
  cmd device_config put touchscreen input_drag_min_switch_speed 500 >/dev/null 2>&1
  settings put global window_animation_scale 0.5 >/dev/null 2>&1
  settings put global transition_animation_scale 0.5 >/dev/null 2>&1
  settings put global animator_duration_scale 0 >/dev/null 2>&1
  settings put system pointer_speed 7
  settings put system pointer_acceleration 0
  settings put system touchscreen_sensitivity_mode 3
  settings put system touchscreen_threshold 3
  settings put secure long_press_timeout 150 >/dev/null 2>&1
  settings put secure multi_press_timeout 160 >/dev/null 2>&1
}

helix() {
  settings put global activity_manager_constants max_cached_processes=96
  settings put global foreground_service_starts_logging_enabled 0
  settings put global verifier_verify_adb_installs 0
}

rungame() {
  for p in com.dts.freefireth com.dts.freefiremax; do
    cmd device_config put game_overlay "$p" mode=2,downscaleFactor=0.7
    cmd package compile -m speed-profile "$p"
    settings put global game_driver_opt_in_package "$p"
  done
  settings put global game_driver_opt_in 1
}

active() {
  cmdperf >/dev/null 2>&1
  execaim >/dev/null 2>&1
  helix >/dev/null 2>&1
  rungame >/dev/null 2>&1
}

rmvv() {
  dumpsys deviceidle enable
  dumpsys deviceidle unforce
  cmd power set-adaptive-power-saver-enabled true
  cmd power set-fixed-performance-mode-enabled false
  cmd power set-mode 1
  cmd thermalservice override-status 1
}

execaim_reset() {
  for pkg in com.dts.freefireth com.dts.freefiremax; do
    cmd game reset "$pkg"
    cmd game downscale disable "$pkg"
    cmd device_config delete game_overlay "$pkg"
    cmd package compile --reset "$pkg"
  done
  cmd device_config delete touchscreen input_drag_min_switch_speed
  settings delete system touchscreen_sensitivity_mode
  settings delete system touchscreen_threshold
  settings put system pointer_speed 0
  settings put system pointer_acceleration 0
  settings put global window_animation_scale 1
  settings put global transition_animation_scale 1
  settings put global animator_duration_scale 1
  settings delete global game_driver_opt_in
  settings delete global game_driver_opt_in_package
  settings delete global cached_apps_freezer
  settings delete global activity_manager_constants
  settings delete global foreground_service_starts_logging_enabled
  settings delete global verifier_verify_adb_installs
  settings put secure long_press_timeout 300
  settings put secure multi_press_timeout 300
  wm size reset
}

cmdperf_reset() {
  cmd package compile --reset com.dts.freefireth >/dev/null 2>&1 || true
  cmd package compile --reset com.dts.freefiremax >/dev/null 2>&1 || true
  cmd looper_stats enable
  cmd power set-adaptive-power-saver-enabled true
  cmd power set-mode 1
  settings delete global cached_apps_freezer
  cmd shortcut reset-throttling
  cmd shortcut reset-all-throttling
}

rmf() {
  rmvv >/dev/null 2>&1
  cmdperf_reset >/dev/null 2>&1
  execaim_reset >/dev/null 2>&1
}

tcx_opti() {
  src="/storage/emulated/0/DRAGHS/headtrick.gz"
  tmp="/storage/emulated/0/DRAGHS/tmp"
  dest="/storage/emulated/0/Android/data/"
  mkdir -p "$tmp" 2>/dev/null
  mkdir -p "$dest" 2>/dev/null
  if [ -f "$src" ]; then
    tar -xzf "$src" -C "$tmp" 2>/dev/null
    mv "$tmp"/* "$dest"/ 2>/dev/null
  fi
  sleep 1
  rmdir "$tmp" 2>/dev/null
}

# ==========================================
# MODULE ACTIONS
# ==========================================
script_activate() {
  show_header
  echo " ⚡ [MODE] MENJALANKAN: DRAG SANTAI V4"
  echo " ──────────────────────────────────────────"
  progress_bar "Mengonfigurasi Touch Sampling Rate..."
  progress_bar "Melakukan Optimasi Surface Flinger..."
  progress_bar "Melakukan Injeksi Engine Free Fire..."
  progress_bar "Menerapkan Smart Config & Resolution..."
  
  active
  wm size 1080x2400
  cmd notification post -S bigtext -t 'DRAGHS V4.0' 'Status' 'Active Success!' >/dev/null 2>&1

  echo "========================================"
  echo " STATUS: BERHASIL DIAPLIKASIKAN V4"
  echo " HASIL : SELURUH MODUL TERPASANG"
  echo "========================================"
  echo ""
  am start -a android.intent.action.VIEW -d "https://whatsapp.com/channel/0029VbDgWAcLCoWzhFiM7L3U" >/dev/null 2>&1
}

script_sensivity() {
  show_header
  echo " 🔥 [MODE] MENJALANKAN: DRAG BRUTAL V4"
  echo " ──────────────────────────────────────────"
  progress_bar "Mengkalibrasi Touch Response..."
  progress_bar "Menerapkan Tuning Sensi Ekstrim..."
  
  settings put secure long_press_timeout 40 >/dev/null 2>&1
  settings put secure multi_press_timeout 40 >/dev/null 2>&1
  
  progress_bar "Mengaktifkan Lib & Engine Booster..."
  
  active
  cmd notification post -S bigtext -t 'DRAGHS V4.0' 'Status' 'Brutal Sensi Active!' >/dev/null 2>&1

  echo "========================================"
  echo " STATUS: SENSI BRUTAL DIAKTIFKAN V4"
  echo " HASIL : TUNING SENSITIVITAS MAKSIMAL"
  echo "========================================"
  echo ""
  sleep 1
  am start -a android.intent.action.VIEW -d "https://whatsapp.com/channel/0029VbDgWAcLCoWzhFiM7L3U" >/dev/null 2>&1
}

script_reset() {
  show_header
  echo " 🔄 [MODE] MENJALANKAN: SYSTEM RESET"
  echo " ──────────────────────────────────────────"
  progress_bar "Membersihkan Konfigurasi Touch..."
  progress_bar "Mengembalikan Surface Flinger Default..."
  progress_bar "Menghapus Injeksi File Sementara..."
  
  rmf
  cmd notification post -S bigtext -t 'DRAGHS V4.0' 'Status' 'Reset Completed' >/dev/null 2>&1

  echo "========================================"
  echo " STATUS: SYSTEM NORMAL / INACTIVE"
  echo " HASIL : SETTINGAN AWAL DIKEMBALIKAN"
  echo "========================================"
  echo ""
}

# ==========================================
# PROCESSOR & NEW INTERACTIVE MENU DESIGN
# ==========================================
process_command() {
  case $1 in
    "-ZEEN-ACTIVATE"|"-aiming"|"-1"|"1")
      script_activate
      tcx_opti
      ;;
    "-ZEEN-SENSIVITY"|"-2"|"2")
      script_sensivity
      tcx_opti
      ;;
    "-ZEEN-RESET"|"-3"|"-reset_all"|"3")
      script_reset
      ;;
    "-help"|"--help")
      show_help
      ;;
    "4"|"EXIT"|"exit"|"e")
      echo " ✖ Keluar dari program. Terima kasih!"
      exit 0
      ;;
    *)
      echo " [!] ERROR: Perintah [$1] tidak dikenali."
      ;;
  esac
}

main() {
  if [ $# -gt 0 ] && [ "$1" != "-help" ] && [ "$1" != "--help" ]; then
    for arg in "$@"; do
      process_command "$arg"
    done
    exit 0
  fi

  if [ "$1" = "-help" ] || [ "$1" = "--help" ]; then
    show_help
    exit 0
  fi

  show_header
  echo " 🛡️  Autentikasi Keamanan V4: [ AMAN ]"
  echo " ──────────────────────────────────────────"
  echo " ┌──────────────────────────────────────┐"
  echo " │           PILIHAN MENU FITUR         │"
  echo " ├──────────────────────────────────────┤"
  echo " │ [1] ⚡ -ZEEN-ACTIVATE                │"
  echo " │     ↳ DRAG SANTAI V4                 │"
  echo " │                                      │"
  echo " │ [2] 🔥 -ZEEN-SENSIVITY               │"
  echo " │     ↳ DRAG BRUTAL V4                 │"
  echo " │                                      │"
  echo " │ [3] 🔄 -ZEEN-RESET                   │"
  echo " │     ↳ RESET MODUL / KEMBALIKAN       │"
  echo " │                                      │"
  echo " │ [4] ✖  EXIT                          │"
  echo " │     ↳ KELUAR APLIKASI                │"
  echo " └──────────────────────────────────────┘"
  
  printf "\n 🎯 Pilih Menu [1-4] : "
  read -r user_input

  if [ -n "$user_input" ]; then
    echo ""
    process_command "$user_input"
  else
    show_help
  fi
}

main "$@"
