# BRORAS PROJECT V1

Starter full-stack Flutter + Node.js untuk dijalankan di Android/Termux.

## Fitur backend V1
- Login JWT dan password hash bcrypt.
- Owner awal dibuat dari `.env`.
- Telegram owner bot: `/create username password 1d`, `/users`, `/delete username`.
- Durasi akun: `1d`, `30d`, `365d`, `permanent`.
- Akun user terhapus otomatis setelah kedaluwarsa.
- API status, Gemini chat, WhatsApp pairing code.
- SQLite lokal memakai sql.js (tanpa kompilasi native addon).

## 1. Persiapan Termux
Gunakan Termux dari sumber resmi. Jalankan:

```bash
pkg update && pkg upgrade -y
pkg install nodejs-lts git nano -y
node -v
npm -v
```

Salin folder `backend` ke penyimpanan Termux, lalu:

```bash
cd ~/BRORAS/backend
npm install
cp .env.example .env
nano .env
```

Isi minimal:
- `JWT_SECRET`: string acak panjang minimal 32 karakter.
- `OWNER_USERNAME` dan `OWNER_PASSWORD`: kredensial owner.
- `OWNER_TELEGRAM_ID`: ID numerik akun Telegram owner.
- `TELEGRAM_BOT_TOKEN`: token bot dari BotFather.
- `GEMINI_API_KEY`: API key Gemini (opsional sampai fitur AI digunakan).

Jangan bagikan `.env`, token Telegram, API key, password, atau folder `data/wa-auth`.

Jalankan backend:

```bash
npm start
```

Tes dari browser HP yang sama:
`http://127.0.0.1:3000/health`

## 2. Perintah Telegram
Kirim `/start` ke bot dari akun Telegram owner.

```text
/create user01 PasswordAman123 1d
/create pelanggan02 PasswordAman123 30d
/create pelanggan03 PasswordAman123 365d
/create vip01 PasswordAman123 permanent
/users
/delete user01
```

Gunakan password unik dan kirim kredensial lewat chat pribadi, bukan grup. Perintah `/create` hanya menerima pesan dari `OWNER_TELEGRAM_ID`.

## 3. Flutter

Setelah `flutter create .`, buka `android/app/src/main/AndroidManifest.xml` dan tambahkan atribut `android:usesCleartextTraffic="true"` pada tag `<application>` untuk pengujian HTTP lokal. Jangan gunakan konfigurasi HTTP tanpa TLS untuk server yang diekspos ke jaringan/internet.
Pasang Flutter SDK dan Android SDK sesuai panduan resmi Flutter. Dari folder `mobile`:

```bash
cd mobile
cd broras_app
flutter create .
flutter pub get
flutter run
```

Build APK:

```bash
flutter build apk --release
```

APK dan backend pada HP yang sama menggunakan `http://127.0.0.1:3000`.

Jika memakai emulator Android, alamat host biasanya `10.0.2.2`. Jika memakai HP lain, `127.0.0.1` tidak menunjuk ke HP server; perlu alamat LAN dan konfigurasi bind/firewall yang aman.

## 4. WhatsApp pairing
Login sebagai owner di APK, lalu panggil `POST /api/whatsapp/pair` dengan JSON:

```json
{"phoneNumber":"628123456789"}
```

Sertakan header `Authorization: Bearer TOKEN`. Kode pairing akan dikembalikan oleh API. Masukkan kode tersebut pada perangkat WhatsApp milik sendiri melalui menu Perangkat tertaut. Jangan bagikan kode pairing kepada orang lain.

## API
- `GET /health` (publik)
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/status`
- `POST /api/ai/chat`
- `POST /api/whatsapp/pair` (owner)
- `GET /api/whatsapp/status` (owner)
- `POST /api/whatsapp/disconnect` (owner)

## Batasan V1 dan catatan keamanan
- Ini fondasi awal yang dapat dijalankan, bukan aplikasi produksi yang sudah diaudit.
- Telegram create/delete dan masa aktif akun aktif di backend.
- Modul dashboard Flutter saat ini masih kartu navigasi kerangka; halaman detail, intro video, animasi lanjutan, kalender dinamis, dan seluruh fitur bisnis perlu tahap implementasi berikutnya.
- WhatsApp Baileys adalah integrasi tidak resmi dan dapat berubah saat WhatsApp memperbarui sistemnya. Gunakan hanya untuk akun/perangkat yang kamu kendalikan dan patuhi ketentuan WhatsApp.
- Termux dapat menghentikan proses saat Android menghemat baterai. Nonaktifkan optimasi baterai untuk Termux jika sesuai, dan jangan menganggap HP sebagai server 24/7.
- Untuk akses selain localhost, gunakan HTTPS, firewall, rate limit, dan jangan mengekspos API langsung ke internet.
- Akun yang kedaluwarsa dihapus dari tabel SQLite oleh scheduler. Buat backup database sebelum mengoperasikan data penting.
