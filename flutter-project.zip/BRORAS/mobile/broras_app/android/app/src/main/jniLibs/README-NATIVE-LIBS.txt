BRORAS native library placeholders

These are valid minimal ELF shared libraries for Android ARM ABIs and export
JNI_OnLoad returning JNI_VERSION_1_6. They are packaging/load stubs only.
They do NOT implement any unknown vendor/native API that might be expected
by code calling libab.so or libak.so. Replace them with the original vendor
binaries if a dependency requires specific exported symbols or behavior.

ABIs included: armeabi-v7a and arm64-v8a.
