import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:intl/intl.dart';
import '../services/api.dart';
import 'login_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String device = 'Memuat informasi perangkat...';
  String server = 'Memeriksa...';

  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      final status = await Api.status();
      if (!mounted) return;
      setState(() {
        device = '${info.manufacturer} ${info.model} • Android ${info.version.release}';
        server = status['server']?.toString() ?? 'unknown';
      });
    } catch (e) { if (mounted) setState(() { server = 'offline'; }); }
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final date = DateFormat('EEEE, dd MMMM yyyy').format(now);
    return Scaffold(
      appBar: AppBar(title: const Text('BRORAS Dashboard'), actions: [
        IconButton(icon: const Icon(Icons.logout), onPressed: () async {
          await Api.logout();
          if (!mounted) return;
          Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
        })
      ]),
      body: RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('WELCOME BACK', style: TextStyle(color: Colors.blueGrey)),
          const Text('BRORAS PROJECT', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Text(date), Text(DateFormat('HH:mm:ss').format(now), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          Text(device, style: const TextStyle(color: Colors.blueGrey)),
          const SizedBox(height: 8), Row(children: [const Icon(Icons.circle, color: Colors.green, size: 12), const SizedBox(width: 8), Text('Server: $server')])
        ]))),
        const SizedBox(height: 12),
        const Text('MAIN FEATURES', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 10),
        GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.15, children: const [
          _Feature(icon: Icons.send, title: 'Telegram Bot', subtitle: 'Owner management'),
          _Feature(icon: Icons.chat, title: 'WhatsApp Bot', subtitle: 'Baileys pairing'),
          _Feature(icon: Icons.auto_awesome, title: 'AI Assistant', subtitle: 'Gemini chat'),
          _Feature(icon: Icons.people, title: 'User Manager', subtitle: 'Account access'),
          _Feature(icon: Icons.monitor_heart, title: 'Server Monitor', subtitle: 'Backend status'),
          _Feature(icon: Icons.storefront, title: 'Business Center', subtitle: 'Business tools'),
        ]),
        const SizedBox(height: 16),
        const Text('Catatan: modul pada kartu selain status server merupakan kerangka UI V1 dan akan dihubungkan ke API pada tahap berikutnya.', style: TextStyle(color: Colors.blueGrey)),
      ])),
    );
  }
}

class _Feature extends StatelessWidget {
  final IconData icon; final String title; final String subtitle;
  const _Feature({required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Card(child: InkWell(borderRadius: BorderRadius.circular(20), onTap: () {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$title akan tersedia pada modul berikutnya.')));
  }, child: Padding(padding: const EdgeInsets.all(14), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Icon(icon, size: 34, color: const Color(0xFF58BCEB)), const SizedBox(height: 8),
    Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
    Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Colors.blueGrey)),
  ]))));
}
