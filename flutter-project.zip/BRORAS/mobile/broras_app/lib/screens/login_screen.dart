import 'package:flutter/material.dart';
import '../services/api.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final username = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  String? error;

  Future<void> submit() async {
    setState(() { loading = true; error = null; });
    try {
      await Api.login(username.text.trim(), password.text);
      if (!mounted) return;
      showModalBottomSheet(context: context, builder: (_) => const Padding(
        padding: EdgeInsets.all(28), child: Row(children: [
          SizedBox(width: 24, height: 24, child: CircularProgressIndicator()),
          SizedBox(width: 16), Expanded(child: Text('Menghubungi server BRORAS...')),
        ]),
      ));
      await Future.delayed(const Duration(milliseconds: 900));
      if (!mounted) return;
      Navigator.pop(context);
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DashboardScreen()));
    } catch (e) { setState(() => error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => loading = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(
    padding: const EdgeInsets.all(24), child: Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(
      mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.bolt, size: 64, color: Color(0xFF58BCEB)),
        const Text('BRORAS', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
        const Text('Sign in to your workspace'),
        const SizedBox(height: 28),
        TextField(controller: username, decoration: const InputDecoration(labelText: 'Username', prefixIcon: Icon(Icons.person), border: OutlineInputBorder())),
        const SizedBox(height: 14),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock), border: OutlineInputBorder()), onSubmitted: (_) => submit()),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 20),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: loading ? null : submit, child: Text(loading ? 'MEMPROSES...' : 'LOGIN'))),
      ],
    ))),
  ))));
}
