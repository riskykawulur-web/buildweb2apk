import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class Api {
  // Untuk APK dan backend pada HP yang sama.
  // Bisa diganti saat build: --dart-define=API_BASE_URL=http://10.0.2.2:3000
  static const baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://127.0.0.1:3000',
  );
  static Future<String?> token() async => (await SharedPreferences.getInstance()).getString('token');

  static Future<Map<String, dynamic>> login(String username, String password) async {
    final response = await http.post(Uri.parse('$baseUrl/api/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}));
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200) throw Exception(data['error'] ?? 'Login gagal');
    await (await SharedPreferences.getInstance()).setString('token', data['token']);
    return data;
  }

  static Future<Map<String, dynamic>> status() async {
    final t = await token();
    final response = await http.get(Uri.parse('$baseUrl/api/status'), headers: {'Authorization': 'Bearer $t'});
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200) throw Exception(data['error'] ?? 'Gagal mengambil status');
    return data;
  }

  static Future<void> logout() async => (await SharedPreferences.getInstance()).remove('token');
}
