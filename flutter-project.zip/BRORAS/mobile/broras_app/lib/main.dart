import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() => runApp(const BrorasApp());

class BrorasApp extends StatelessWidget {
  const BrorasApp({super.key});

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF69C8F5);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BRORAS',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue, primary: blue),
        scaffoldBackgroundColor: const Color(0xFFF3FAFF),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: Color(0xFF17334A)),
        cardTheme: CardThemeData(color: Colors.white, elevation: 2, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      ),
      home: const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final PageController controller = PageController(viewportFraction: .86);
  int page = 0;
  final titles = ['Welcome to BRORAS', 'Manage your bots', 'AI & Business Center'];
  final details = ['Satu ruang untuk mengelola layanan digital.', 'Hubungkan Telegram dan WhatsApp milikmu.', 'Kelola percakapan AI dan aktivitas bisnis.'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Column(children: [
        Align(alignment: Alignment.centerRight, child: TextButton(onPressed: _goLogin, child: const Text('SKIP'))),
        const Spacer(),
        SizedBox(height: 330, child: PageView.builder(
          controller: controller, itemCount: titles.length,
          onPageChanged: (v) => setState(() => page = v),
          itemBuilder: (_, i) => Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Card(
            child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.auto_awesome, size: 76, color: Color(0xFF58BCEB)),
              const SizedBox(height: 24),
              Text(titles[i], style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
              const SizedBox(height: 12),
              Text(details[i], textAlign: TextAlign.center, style: const TextStyle(color: Colors.blueGrey)),
            ])),
          )),
        )),
        const SizedBox(height: 18),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(3, (i) => Container(
          margin: const EdgeInsets.all(4), width: page == i ? 22 : 8, height: 8,
          decoration: BoxDecoration(color: page == i ? const Color(0xFF58BCEB) : Colors.blueGrey.shade200, borderRadius: BorderRadius.circular(9)),
        ))),
        const Spacer(),
        Padding(padding: const EdgeInsets.all(24), child: SizedBox(width: double.infinity, child: FilledButton(
          onPressed: page == 2 ? _goLogin : () => controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut),
          child: Text(page == 2 ? 'MULAI' : 'LANJUT'),
        ))),
      ])),
    );
  }
  void _goLogin() => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
}
