import { GoogleGenerativeAI } from "@google/generative-ai";

export async function askGemini(message, history = []) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY belum diatur di .env.");
  if (typeof message !== "string" || !message.trim() || message.length > 8000) {
    throw new Error("Pesan kosong atau terlalu panjang (maksimal 8000 karakter).");
  }
  const genAI = new GoogleGenerativeAI(key);
  const model = genAI.getGenerativeModel({ model: process.env.GEMINI_MODEL || "gemini-2.0-flash" });
  const chat = model.startChat({
    history: Array.isArray(history) ? history.slice(-12) : [],
    generationConfig: { maxOutputTokens: 1200, temperature: 0.7 }
  });
  const result = await chat.sendMessage(message);
  return result.response.text();
}
