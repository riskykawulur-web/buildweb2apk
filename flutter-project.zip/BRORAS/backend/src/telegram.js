import { Telegraf, Markup } from "telegraf";
import bcrypt from "bcryptjs";
import { run, queryAll } from "./database.js";

function durationToExpiry(value) {
  if (value === "permanent") return null;
  const match = /^(\d+)(d|h)$/.exec(value || "");
  if (!match) throw new Error("Durasi gunakan 1d, 30d, 365d, atau permanent.");
  const amount = Number(match[1]);
  if (amount < 1 || amount > 3650) throw new Error("Durasi harus 1 sampai 3650 hari/jam.");
  const ms = amount * (match[2] === "d" ? 86400000 : 3600000);
  return new Date(Date.now() + ms).toISOString();
}

const menuKeyboard = () => Markup.inlineKeyboard([
  [
    Markup.button.callback("➕ Buat akun", "menu_create"),
    Markup.button.callback("👥 Daftar akun", "menu_users"),
  ],
  [
    Markup.button.callback("📖 Panduan", "menu_help"),
    Markup.button.callback("ℹ️ Status bot", "menu_status"),
  ],
]);

const HOME_TEXT =
  "🤖 <b>BRORAS • TELEGRAM CONTROL</b>\n" +
  "━━━━━━━━━━━━━━━━━━\n" +
  "Selamat datang di panel pengelolaan akun.\n\n" +
  "Pilih menu di bawah untuk melanjutkan.\n" +
  "🔐 <i>Akses khusus pemilik bot.</i>";

const HELP_TEXT =
  "📖 <b>PANDUAN PERINTAH</b>\n" +
  "━━━━━━━━━━━━━━━━━━\n" +
  "➕ <b>Buat akun</b>\n" +
  "<code>/create username password 1d</code>\n" +
  "Contoh: <code>/create pelanggan01 SandiKuat123 30d</code>\n\n" +
  "👥 <b>Lihat daftar akun</b>\n" +
  "<code>/users</code>\n\n" +
  "🗑️ <b>Hapus akun</b>\n" +
  "<code>/delete username</code>\n\n" +
  "⏳ <b>Pilihan masa aktif</b>\n" +
  "• <code>1d</code> = 1 hari\n" +
  "• <code>30d</code> = 30 hari\n" +
  "• <code>365d</code> = 365 hari\n" +
  "• <code>permanent</code> = permanen\n\n" +
  "⚠️ Gunakan chat pribadi. Jangan kirim password atau token ke grup.";

function formatDate(value) {
  if (!value) return "Permanen";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("id-ID", {
    dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Jakarta"
  }).format(date) + " WIB";
}

export function startTelegramBot() {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const ownerId = String(process.env.OWNER_TELEGRAM_ID || "");
  if (!token || !ownerId) {
    console.log("Telegram bot belum aktif: isi TELEGRAM_BOT_TOKEN dan OWNER_TELEGRAM_ID.");
    return null;
  }

  const bot = new Telegraf(token);
  const isOwner = (ctx) => String(ctx.from?.id || "") === ownerId;
  const denied = (ctx) => ctx.reply(
    "🔒 <b>Akses dibatasi</b>\nBot ini hanya dapat digunakan oleh pemilik.",
    { parse_mode: "HTML" }
  );

  bot.telegram.setMyCommands([
    { command: "start", description: "Buka menu utama BRORAS" },
    { command: "create", description: "Buat akun pengguna" },
    { command: "users", description: "Lihat daftar akun" },
    { command: "delete", description: "Hapus akun pengguna" },
    { command: "help", description: "Lihat panduan penggunaan" },
  ]).catch((err) => console.error("Gagal memasang daftar perintah Telegram:", err.message));

  bot.start(async (ctx) => {
    if (!isOwner(ctx)) return denied(ctx);
    return ctx.reply(HOME_TEXT, { parse_mode: "HTML", ...menuKeyboard() });
  });

  bot.command("help", async (ctx) => {
    if (!isOwner(ctx)) return denied(ctx);
    return ctx.reply(HELP_TEXT, { parse_mode: "HTML", ...menuKeyboard() });
  });

  bot.action("menu_create", async (ctx) => {
    if (!isOwner(ctx)) return ctx.answerCbQuery("Akses ditolak.", { show_alert: true });
    await ctx.answerCbQuery();
    return ctx.reply(
      "➕ <b>BUAT AKUN BARU</b>\n━━━━━━━━━━━━━━━━━━\n" +
      "Kirim perintah dengan format:\n" +
      "<code>/create username password durasi</code>\n\n" +
      "Contoh:\n<code>/create pelanggan01 SandiKuat123 30d</code>\n\n" +
      "Username: 3–32 karakter\nPassword: 8–72 karakter\nDurasi: 1d, 30d, 365d, atau permanent\n\n" +
      "🔐 Buat akun hanya melalui chat pribadi dan gunakan password sementara yang unik.",
      { parse_mode: "HTML" }
    );
  });

  bot.action("menu_users", async (ctx) => {
    if (!isOwner(ctx)) return ctx.answerCbQuery("Akses ditolak.", { show_alert: true });
    await ctx.answerCbQuery();
    return sendUsers(ctx);
  });

  bot.action("menu_help", async (ctx) => {
    if (!isOwner(ctx)) return ctx.answerCbQuery("Akses ditolak.", { show_alert: true });
    await ctx.answerCbQuery();
    return ctx.reply(HELP_TEXT, { parse_mode: "HTML", ...menuKeyboard() });
  });

  bot.action("menu_status", async (ctx) => {
    if (!isOwner(ctx)) return ctx.answerCbQuery("Akses ditolak.", { show_alert: true });
    await ctx.answerCbQuery();
    return ctx.reply(
      "🟢 <b>BRORAS BOT</b>\n━━━━━━━━━━━━━━━━━━\n" +
      "Status: <b>Aktif</b>\nAkses: <b>Owner</b>\nZona waktu: <b>WIB</b>\n\n" +
      "Pilih menu untuk mengelola akun.",
      { parse_mode: "HTML", ...menuKeyboard() }
    );
  });

  async function sendUsers(ctx) {
    const users = queryAll(
      "SELECT username,role,expires_at FROM users ORDER BY id DESC LIMIT 50"
    );
    if (!users.length) {
      return ctx.reply(
        "👥 <b>DAFTAR AKUN</b>\n━━━━━━━━━━━━━━━━━━\nBelum ada akun pengguna.",
        { parse_mode: "HTML", ...menuKeyboard() }
      );
    }
    const lines = users.map((u, i) =>
      `${i + 1}. <b>${escapeHtml(u.username)}</b>\n   Role: ${escapeHtml(u.role)}\n   Masa aktif: ${escapeHtml(formatDate(u.expires_at))}`
    );
    return ctx.reply(
      `👥 <b>DAFTAR AKUN (${users.length})</b>\n━━━━━━━━━━━━━━━━━━\n\n${lines.join("\n\n")}\n\n<i>Maksimal 50 akun terbaru ditampilkan.</i>`,
      { parse_mode: "HTML", ...menuKeyboard() }
    );
  }

  bot.command("create", async (ctx) => {
    if (!isOwner(ctx)) return denied(ctx);
    const parts = ctx.message.text.trim().split(/\s+/);
    if (parts.length !== 4) {
      return ctx.reply(
        "⚠️ <b>Format belum benar</b>\nGunakan:\n<code>/create username password 1d</code>\n\nKetik /help untuk melihat panduan.",
        { parse_mode: "HTML" }
      );
    }
    const [, username, password, duration] = parts;
    if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username)) {
      return ctx.reply("⚠️ Username harus 3–32 karakter (huruf, angka, titik, _ atau -).");
    }
    if (password.length < 8 || password.length > 72) {
      return ctx.reply("⚠️ Password harus 8–72 karakter.");
    }
    try {
      const expiresAt = durationToExpiry(duration);
      const hash = await bcrypt.hash(password, 12);
      run(
        "INSERT INTO users(username,password_hash,role,created_at,expires_at) VALUES(?,?,?,?,?)",
        [username, hash, "user", new Date().toISOString(), expiresAt]
      );
      return ctx.reply(
        "✅ <b>AKUN BERHASIL DIBUAT</b>\n━━━━━━━━━━━━━━━━━━\n" +
        `👤 Username: <code>${escapeHtml(username)}</code>\n` +
        `⏳ Masa aktif: <b>${escapeHtml(duration)}</b>\n` +
        `📅 Berakhir: <b>${escapeHtml(formatDate(expiresAt))}</b>\n\n` +
        "Demi keamanan, password tidak ditampilkan ulang oleh bot. Sampaikan password kepada pengguna melalui jalur pribadi yang aman.\n\n" +
        "Gunakan /users untuk melihat daftar akun.",
        { parse_mode: "HTML", ...menuKeyboard() }
      );
    } catch (e) {
      return ctx.reply(
        e.message.includes("UNIQUE")
          ? "⚠️ Username sudah digunakan. Coba username lain."
          : `❌ Gagal membuat akun: ${escapeHtml(e.message)}`,
        { parse_mode: "HTML" }
      );
    }
  });

  bot.command("users", async (ctx) => {
    if (!isOwner(ctx)) return denied(ctx);
    try {
      return await sendUsers(ctx);
    } catch (e) {
      return ctx.reply(`❌ Gagal mengambil daftar akun: ${escapeHtml(e.message)}`);
    }
  });

  bot.command("delete", async (ctx) => {
    if (!isOwner(ctx)) return denied(ctx);
    const username = ctx.message.text.trim().split(/\s+/)[1];
    if (!username) {
      return ctx.reply(
        "🗑️ <b>HAPUS AKUN</b>\nGunakan format:\n<code>/delete username</code>\n\nContoh: <code>/delete pelanggan01</code>",
        { parse_mode: "HTML" }
      );
    }
    const changed = run("DELETE FROM users WHERE username = ? AND role != 'owner'", [username]);
    return ctx.reply(
      changed
        ? `✅ Akun <code>${escapeHtml(username)}</code> berhasil dihapus.`
        : "⚠️ Akun tidak ditemukan atau akun tersebut merupakan owner.",
      { parse_mode: "HTML", ...menuKeyboard() }
    );
  });

  bot.catch((err) => console.error("Telegram bot error:", err.message));
  bot.launch().then(() => console.log("Telegram owner bot aktif."))
    .catch(err => console.error("Telegram bot gagal:", err.message));
  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
  return bot;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}
