import { deleteExpiredUsers } from "./database.js";

export function startExpiryScheduler() {
  deleteExpiredUsers();
  setInterval(deleteExpiredUsers, 60 * 1000);
  console.log("Pemeriksa masa aktif akun berjalan setiap 60 detik.");
}
