import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { queryOne } from "./database.js";

const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) {
  throw new Error("JWT_SECRET harus diisi dengan minimal 32 karakter.");
}

export async function loginUser(username, password) {
  const user = queryOne("SELECT * FROM users WHERE username = ?", [username]);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return null;
  if (user.expires_at && new Date(user.expires_at) <= new Date()) return null;

  const token = jwt.sign({ sub: String(user.id) }, secret, { expiresIn: "12h" });
  return {
    token,
    user: { id: user.id, username: user.username, role: user.role, expiresAt: user.expires_at }
  };
}

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    const payload = jwt.verify(token, secret);
    const user = queryOne("SELECT id,username,role,expires_at FROM users WHERE id = ?", [Number(payload.sub)]);
    if (!user || (user.expires_at && new Date(user.expires_at) <= new Date())) {
      return res.status(401).json({ error: "Sesi tidak valid atau akun kedaluwarsa." });
    }
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: "Token tidak valid atau sudah kedaluwarsa." });
  }
}

export function requireOwner(req, res, next) {
  if (req.user?.role !== "owner") return res.status(403).json({ error: "Khusus owner." });
  next();
}
