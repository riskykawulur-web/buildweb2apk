import initSqlJs from "sql.js";
import fs from "node:fs";
import path from "node:path";
import bcrypt from "bcryptjs";

const dataDir = path.resolve("data");
const dbPath = path.join(dataDir, "broras.sqlite");
fs.mkdirSync(dataDir, { recursive: true });

const SQL = await initSqlJs();
let db = fs.existsSync(dbPath)
  ? new SQL.Database(new Uint8Array(fs.readFileSync(dbPath)))
  : new SQL.Database();

db.run(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    created_at TEXT NOT NULL,
    expires_at TEXT
  );
`);

function persist() {
  const bytes = db.export();
  fs.writeFileSync(dbPath, Buffer.from(bytes));
}

export function queryOne(sql, params = []) {
  const stmt = db.prepare(sql);
  try {
    stmt.bind(params);
    return stmt.step() ? stmt.getAsObject() : null;
  } finally { stmt.free(); }
}

export function queryAll(sql, params = []) {
  const stmt = db.prepare(sql);
  const rows = [];
  try {
    stmt.bind(params);
    while (stmt.step()) rows.push(stmt.getAsObject());
    return rows;
  } finally { stmt.free(); }
}

export function run(sql, params = []) {
  db.run(sql, params);
  persist();
  return db.getRowsModified();
}

export async function ensureOwner(username, password) {
  if (!username || !password) throw new Error("OWNER_USERNAME dan OWNER_PASSWORD wajib diisi.");
  const existing = queryOne("SELECT id FROM users WHERE username = ?", [username]);
  if (!existing) {
    const hash = await bcrypt.hash(password, 12);
    run(
      "INSERT INTO users(username,password_hash,role,created_at,expires_at) VALUES(?,?,?,?,NULL)",
      [username, hash, "owner", new Date().toISOString()]
    );
    console.log(`Owner awal dibuat: ${username}`);
  }
}

export function deleteExpiredUsers() {
  const result = run(
    "DELETE FROM users WHERE role != 'owner' AND expires_at IS NOT NULL AND expires_at <= ?",
    [new Date().toISOString()]
  );
  if (result) console.log(`${result} akun kedaluwarsa dihapus.`);
}
