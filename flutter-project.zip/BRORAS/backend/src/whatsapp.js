import makeWASocket, { useMultiFileAuthState, DisconnectReason } from "@whiskeysockets/baileys";
import pino from "pino";
import fs from "node:fs";

let socket = null;
let connectionState = "disconnected";
let latestPairingCode = null;

export async function connectWhatsApp(phoneNumber) {
  if (!phoneNumber || !/^\d{8,15}$/.test(phoneNumber)) {
    throw new Error("Masukkan nomor internasional angka saja, contoh 628123456789.");
  }
  fs.mkdirSync("data/wa-auth", { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState("data/wa-auth");
  socket = makeWASocket({
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    browser: ["BRORAS", "Chrome", "1.0.0"]
  });

  connectionState = "connecting";
  socket.ev.on("creds.update", saveCreds);
  socket.ev.on("connection.update", ({ connection, lastDisconnect }) => {
    if (connection === "open") connectionState = "connected";
    if (connection === "close") {
      connectionState = "disconnected";
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) {
        setTimeout(() => connectWhatsApp(phoneNumber).catch(console.error), 5000);
      }
    }
  });

  if (!state.creds.registered) {
    await new Promise(resolve => setTimeout(resolve, 1500));
    latestPairingCode = await socket.requestPairingCode(phoneNumber);
  }
  return { state: connectionState, pairingCode: latestPairingCode };
}

export function getWhatsAppStatus() {
  return { state: connectionState, pairingCode: latestPairingCode };
}

export async function disconnectWhatsApp() {
  if (socket) {
    try { await socket.logout(); } catch {}
    socket = null;
  }
  connectionState = "disconnected";
  latestPairingCode = null;
  return getWhatsAppStatus();
}
