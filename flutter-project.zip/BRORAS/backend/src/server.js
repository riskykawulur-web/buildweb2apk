import "dotenv/config";
import express from "express";
import cors from "cors";
import { ensureOwner } from "./database.js";
import { loginUser, requireAuth, requireOwner } from "./auth.js";
import { startTelegramBot } from "./telegram.js";
import { connectWhatsApp, getWhatsAppStatus, disconnectWhatsApp } from "./whatsapp.js";
import { askGemini } from "./gemini.js";
import { startExpiryScheduler } from "./scheduler.js";

const app = express();
app.use(cors({ origin: true }));
app.use(express.json({ limit: "1mb" }));

app.get("/health", (_req, res) => res.json({ ok: true, app: "BRORAS", time: new Date().toISOString() }));

app.post("/api/auth/login", async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ error: "Username dan password wajib diisi." });
    const result = await loginUser(username, password);
    if (!result) return res.status(401).json({ error: "Username/password salah atau akun kedaluwarsa." });
    res.json(result);
  } catch (e) { res.status(500).json({ error: "Login gagal." }); }
});

app.get("/api/auth/me", requireAuth, (req, res) => {
  res.json({ user: { id: req.user.id, username: req.user.username, role: req.user.role, expiresAt: req.user.expires_at } });
});

app.get("/api/status", requireAuth, (_req, res) => {
  res.json({ server: "online", telegram: Boolean(process.env.TELEGRAM_BOT_TOKEN), whatsapp: getWhatsAppStatus() });
});

app.post("/api/whatsapp/pair", requireAuth, requireOwner, async (req, res) => {
  try {
    const result = await connectWhatsApp(String(req.body?.phoneNumber || ""));
    res.json(result);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.get("/api/whatsapp/status", requireAuth, requireOwner, (_req, res) => res.json(getWhatsAppStatus()));
app.post("/api/whatsapp/disconnect", requireAuth, requireOwner, async (_req, res) => {
  res.json(await disconnectWhatsApp());
});

app.post("/api/ai/chat", requireAuth, async (req, res) => {
  try {
    const answer = await askGemini(req.body?.message, req.body?.history || []);
    res.json({ answer });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Terjadi kesalahan server." });
});

const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || "127.0.0.1";

await ensureOwner(process.env.OWNER_USERNAME, process.env.OWNER_PASSWORD);
startExpiryScheduler();
startTelegramBot();

app.listen(port, host, () => console.log(`BRORAS API berjalan di http://${host}:${port}`));
