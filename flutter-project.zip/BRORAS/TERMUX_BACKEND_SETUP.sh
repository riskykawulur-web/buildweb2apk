#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

pkg update -y
pkg install nodejs-lts git -y

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/backend"
npm install

if [ ! -f .env ]; then
  cp .env.example .env
  echo "File backend/.env dibuat dari .env.example. Edit nilainya sebelum menjalankan bot."
fi

echo "Persiapan backend selesai. Edit backend/.env, lalu jalankan: cd backend && npm start"
