# BRORAS PROJECT — Build APK Ready

Paket ini menyiapkan project Flutter untuk dibuat menjadi APK. UI Telegram Bot di dalam APK adalah panel aplikasi; bot Telegram sebenarnya tetap dijalankan oleh backend Node.js di Termux/server.

## Build APK otomatis lewat GitHub Actions (disarankan)

1. Ekstrak ZIP ini.
2. Buat repository GitHub baru, lalu upload/push seluruh isi folder `BRORAS` ke branch `main`.
3. Buka repository → tab **Actions** → pilih workflow **Build BRORAS APK** → **Run workflow**.
4. Tunggu proses selesai (status hijau).
5. Buka hasil run → bagian **Artifacts** → unduh `BRORAS-release-apk`.
6. Ekstrak artifact, lalu install `app-release.apk` di Android.

Workflow otomatis membuat folder Android/Gradle yang belum disertakan di ZIP, mengambil dependency Flutter, lalu membangun APK release.

## Build lokal

Pastikan Flutter SDK, Android SDK, Java 17, dan Python 3 tersedia. Jalankan:

```bash
cd BRORAS
bash build_apk.sh
```

Hasil: `mobile/broras_app/build/app/outputs/flutter-apk/app-release.apk`

## Koneksi ke backend

- Default `http://127.0.0.1:3000` hanya cocok jika backend berjalan pada HP Android yang sama.
- Emulator Android biasanya memakai `http://10.0.2.2:3000`.
- Jika backend berada di HP/komputer lain, gunakan alamat IP LAN server, misalnya `http://192.168.1.10:3000` (ganti sesuai alamat sebenarnya).

Contoh build dengan alamat backend khusus:

```bash
API_BASE_URL=http://192.168.1.10:3000 bash build_apk.sh
```

Jangan membuka backend HTTP polos ke internet. Untuk penggunaan jarak jauh, pasang HTTPS dan pengamanan jaringan yang sesuai.

## Jalankan backend Telegram

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env`, isi setidaknya `JWT_SECRET`, `OWNER_USERNAME`, `OWNER_PASSWORD`, `OWNER_TELEGRAM_ID`, dan `TELEGRAM_BOT_TOKEN`, lalu jalankan:

```bash
npm start
```

Jangan mengunggah `.env`, token bot, password, API key, atau database ke repository publik.

## Catatan penting

- Project sumber yang diberikan belum menyertakan folder Android/Gradle; workflow di paket ini membuatnya saat build.
- Dashboard masih berisi kartu kerangka/placeholder. Build APK berhasil tidak berarti seluruh modul kartu sudah aktif.
- Untuk akses API, backend harus hidup dan URL pada saat build harus mengarah ke backend yang benar.
- `usesCleartextTraffic` diaktifkan agar alamat HTTP lokal dapat dipakai untuk pengujian. Jangan gunakan HTTP tanpa TLS untuk server publik.
