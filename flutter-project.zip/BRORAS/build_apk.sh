#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/mobile/broras_app"
command -v flutter >/dev/null 2>&1 || {
  echo "Flutter SDK belum terpasang/tersedia di PATH."
  echo "Untuk build otomatis paling mudah, gunakan GitHub Actions sesuai README."
  exit 1
}
flutter create --platforms=android --project-name broras_app .
python3 - <<'PY'
from pathlib import Path
p = Path("android/app/src/main/AndroidManifest.xml")
s = p.read_text()
s = s.replace("<application", '<application android:usesCleartextTraffic="true"', 1)
if "android.permission.INTERNET" not in s:
    s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET" />\\n    <application', 1)
p.write_text(s)
PY
flutter pub get
flutter build apk --release --dart-define=API_BASE_URL="${API_BASE_URL:-http://127.0.0.1:3000}"
echo
echo "APK selesai: $(pwd)/build/app/outputs/flutter-apk/app-release.apk"
