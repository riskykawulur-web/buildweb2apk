# Kebutuhan build APK BRORAS

## Build otomatis (disarankan)

Tidak perlu mengunduh Android SDK ke HP atau memasukkan SDK ke ZIP. GitHub Actions memasang komponen berikut saat workflow berjalan:

- Java 17 (Temurin)
- Android SDK command-line tools melalui `android-actions/setup-android`
- Android platform 35
- Android build-tools 35.0.0
- Android platform-tools
- Flutter stable

Langkah: unggah **isi folder BRORAS** ke root repository GitHub, buka Actions, pilih `Build BRORAS APK`, lalu jalankan `Run workflow`. Unduh artifact `BRORAS-release-apk` setelah workflow selesai.

## Build lokal

Diperlukan Flutter stable, Android SDK, Android platform 35, build-tools 35.0.0, Java 17, dan Python 3. Jalankan `bash build_apk.sh` dari root project.

## Tentang libab.so / libak.so

Kedua file itu tidak ada pada source ZIP yang diberikan dan tidak dapat dibuat secara benar tanpa mengetahui library/dependency asalnya. Jangan membuat file kosong atau mengganti nama library lain menjadi `libab.so`/`libak.so`; aplikasi dapat gagal dimuat atau crash. Jika suatu dependency benar-benar meminta library tersebut, minta nama package/vendor dan ABI yang diperlukan (misalnya `arm64-v8a` atau `armeabi-v7a`), lalu gunakan binary resmi dari dependency itu.

Jika tidak ada pesan error yang menyebut `libab.so` atau `libak.so`, keduanya tidak perlu ditambahkan untuk build saat ini.
