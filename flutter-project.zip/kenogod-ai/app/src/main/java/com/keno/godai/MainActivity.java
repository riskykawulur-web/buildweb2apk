package com.keno.godai;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Dibuat oleh NexDeploy (by RafzX).
 * Aplikasi pembungkus WebView tanpa library tambahan.
 */
public class MainActivity extends Activity {

    // ===== DIISI OTOMATIS OLEH NexDeploy =====
    private static final String START_URL = "";
    private static final boolean LOCAL_SITE = true;
    private static final boolean FULLSCREEN = true;
    private static final boolean KEEP_SCREEN_ON = true;
    private static final String[] RUNTIME_PERMISSIONS = {};
    // ===========================================

    private static final String LOCAL_HOST = "appassets.local";
    private static final int REQ_FILE = 11;
    private static final int REQ_PERM = 12;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (KEEP_SCREEN_ON) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        web = new WebView(this);
        setContentView(web, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setupWeb();
        askPermissions();
        if (b == null || web.restoreState(b) == null) {
            web.loadUrl(LOCAL_SITE ? "https://" + LOCAL_HOST + "/index.html" : START_URL);
        }
    }

    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                try {
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType(mime);
                    r.addRequestHeader("User-Agent", ua);
                    String ck = CookieManager.getInstance().getCookie(url);
                    if (ck != null) r.addRequestHeader("Cookie", ck);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                            URLUtil.guessFileName(url, cd, mime));
                    ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                    Toast.makeText(MainActivity.this, "Mengunduh...", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) {
                    }
                }
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (LOCAL_SITE && u != null && LOCAL_HOST.equals(u.getHost())) return serveAsset(u);
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return handleUrl(r.getUrl());
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showOffline(v);
            }

            @Override
            @SuppressWarnings("deprecation")
            public void onReceivedError(WebView v, int code, String desc, String failingUrl) {
                if (Build.VERSION.SDK_INT < 23) showOffline(v);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        List<String> ok = new ArrayList<String>();
                        String[] wanted = req.getResources();
                        for (int i = 0; i < wanted.length; i++) {
                            String w = wanted[i];
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(w) && has(Manifest.permission.CAMERA)) ok.add(w);
                            else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(w) && has(Manifest.permission.RECORD_AUDIO)) ok.add(w);
                        }
                        if (ok.isEmpty()) req.deny();
                        else req.grant(ok.toArray(new String[ok.size()]));
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                boolean ok = has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION);
                cb.invoke(origin, ok, false);
            }
        });
    }

    private boolean has(String perm) {
        return checkCallingOrSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void askPermissions() {
        if (Build.VERSION.SDK_INT < 23) return;
        List<String> need = new ArrayList<String>();
        for (int i = 0; i < RUNTIME_PERMISSIONS.length; i++) {
            String p = RUNTIME_PERMISSIONS[i];
            if (p.equals("android.permission.WRITE_EXTERNAL_STORAGE") && Build.VERSION.SDK_INT > 28) continue;
            if (p.equals("android.permission.POST_NOTIFICATIONS") && Build.VERSION.SDK_INT < 33) continue;
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[need.size()]), REQ_PERM);
    }

    /** true = sudah ditangani aplikasi (bukan http/https), false = biarkan WebView membukanya. */
    private boolean handleUrl(Uri u) {
        String sc = u.getScheme();
        if (sc == null) return false;
        sc = sc.toLowerCase(Locale.US);
        if (sc.equals("http") || sc.equals("https") || sc.equals("about")
                || sc.equals("data") || sc.equals("blob") || sc.equals("javascript")) {
            return false;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception e) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka link ini", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private void showOffline(WebView v) {
        String retry = LOCAL_SITE ? "https://" + LOCAL_HOST + "/index.html" : START_URL;
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='margin:0;background:#0a0a0a;color:#fff;font-family:sans-serif;"
                + "display:flex;align-items:center;justify-content:center;height:100vh;text-align:center'>"
                + "<div><h2>Tidak ada koneksi</h2><p style='color:#999'>Periksa internet lalu coba lagi.</p>"
                + "<a href='" + retry + "' style='display:inline-block;margin-top:12px;padding:12px 24px;"
                + "background:#fff;color:#0a0a0a;border-radius:6px;text-decoration:none'>COBA LAGI</a></div></body></html>";
        v.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    // ---------- isi website lokal (folder assets/www) ----------
    private WebResourceResponse serveAsset(Uri u) {
        String p = u.getPath();
        if (p == null || p.length() <= 1) p = "/index.html";
        if (p.endsWith("/")) p = p + "index.html";
        p = p.substring(1);
        if (p.indexOf("..") >= 0) return notFound();
        try {
            InputStream in = getAssets().open("www/" + p);
            String mime = mimeOf(p);
            boolean text = mime.startsWith("text/") || mime.indexOf("javascript") >= 0 || mime.indexOf("json") >= 0
                    || mime.indexOf("xml") >= 0 || mime.indexOf("svg") >= 0;
            return new WebResourceResponse(mime, text ? "utf-8" : null, in);
        } catch (Exception e) {
            return notFound();
        }
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream("404 Not Found".getBytes()));
    }

    private static String mimeOf(String path) {
        String x = path.toLowerCase(Locale.US);
        int dot = x.lastIndexOf('.');
        String e = dot >= 0 ? x.substring(dot + 1) : "";
        if (e.equals("html") || e.equals("htm")) return "text/html";
        if (e.equals("css")) return "text/css";
        if (e.equals("js") || e.equals("mjs")) return "application/javascript";
        if (e.equals("json") || e.equals("map")) return "application/json";
        if (e.equals("png")) return "image/png";
        if (e.equals("jpg") || e.equals("jpeg")) return "image/jpeg";
        if (e.equals("gif")) return "image/gif";
        if (e.equals("webp")) return "image/webp";
        if (e.equals("svg")) return "image/svg+xml";
        if (e.equals("ico")) return "image/x-icon";
        if (e.equals("txt")) return "text/plain";
        if (e.equals("xml")) return "application/xml";
        if (e.equals("woff")) return "font/woff";
        if (e.equals("woff2")) return "font/woff2";
        if (e.equals("ttf")) return "font/ttf";
        if (e.equals("otf")) return "font/otf";
        if (e.equals("mp3")) return "audio/mpeg";
        if (e.equals("wav")) return "audio/wav";
        if (e.equals("ogg")) return "audio/ogg";
        if (e.equals("mp4")) return "video/mp4";
        if (e.equals("webm")) return "video/webm";
        if (e.equals("wasm")) return "application/wasm";
        return "application/octet-stream";
    }

    // ---------- siklus hidup ----------
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.stopLoading();
            web.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus && FULLSCREEN) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
}
