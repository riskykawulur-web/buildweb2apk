KenoGOD Ai
Project Android dibuat oleh NexDeploy (by RafzX).

CARA MEMBUAT APK
1) Ekstrak ZIP ini.
2) Buka folder project di Android Studio atau AndroidIDE (aplikasi IDE di HP).
3) Tunggu Gradle sync selesai (butuh internet saat pertama kali).
4) Menu Build > Build APK(s)  (atau jalankan:  gradle assembleDebug).
5) APK ada di: app/build/outputs/apk/debug/app-debug.apk  -> pasang di HP.

CATATAN
- Package: com.keno.godai  |  Versi: 6.1 (1)
- Sumber: kode dari tab EDITOR
- APK debug sudah otomatis ditandatangani. Untuk dipublikasikan ke Play Store,
  buat keystore sendiri lewat Build > Generate Signed Bundle / APK.
- Isi aplikasi dimuat lewat WebView. Izin (permission) yang aktif ada di
  app/src/main/AndroidManifest.xml.
