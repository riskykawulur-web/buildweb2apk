extends CharacterBody3D

var game: Node
var health := 100.0
var speed := 7.0
var mouse_sensitivity := 0.0022
var gravity := 18.0
var fire_cooldown := 0.0
var ammo := 30
var max_ammo := 30
var reload_time := 0.0
var yaw := 0.0
var pitch := 0.0
var mobile_move := Vector2.ZERO
var mobile_look := Vector2.ZERO
var mobile_fire := false
var camera: Camera3D
var gun_ray: RayCast3D
var muzzle: MeshInstance3D

func _ready() -> void:
	_setup_input()
	floor_snap_length = 0.25
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.38
	capsule.height = 1.8
	shape.shape = capsule
	shape.position.y = 0.9
	add_child(shape)
	camera = Camera3D.new()
	camera.position = Vector3(0, 1.55, 0)
	camera.fov = 85
	add_child(camera)
	camera.current = true
	gun_ray = RayCast3D.new()
	gun_ray.target_position = Vector3(0, 0, -100)
	gun_ray.enabled = true
	camera.add_child(gun_ray)
	_build_weapon()
	if not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _setup_input() -> void:
	var actions := ["move_forward", "move_back", "move_left", "move_right", "jump", "fire", "reload"]
	for action in actions:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
	_add_key("move_forward", KEY_W)
	_add_key("move_back", KEY_S)
	_add_key("move_left", KEY_A)
	_add_key("move_right", KEY_D)
	_add_key("jump", KEY_SPACE)
	_add_key("reload", KEY_R)
	var mouse_fire := InputEventMouseButton.new()
	mouse_fire.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("fire", mouse_fire)

func _add_key(action: String, keycode: Key) -> void:
	var key_event := InputEventKey.new()
	key_event.physical_keycode = keycode
	InputMap.action_add_event(action, key_event)

func _build_weapon() -> void:
	var gun := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.18, 0.18, 0.65)
	gun.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.10, 0.13, 0.15)
	gun.material_override = mat
	gun.position = Vector3(0.32, -0.25, -0.55)
	camera.add_child(gun)
	muzzle = MeshInstance3D.new()
	var flash := SphereMesh.new()
	flash.radius = 0.07
	flash.height = 0.14
	muzzle.mesh = flash
	muzzle.position = Vector3(0.32, -0.25, -0.9)
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(1.0, 0.72, 0.18)
	fm.emission_enabled = true
	fm.emission = Color(1.0, 0.35, 0.05)
	muzzle.material_override = fm
	muzzle.visible = false
	camera.add_child(muzzle)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		yaw -= event.relative.x * mouse_sensitivity
		pitch = clampf(pitch - event.relative.y * mouse_sensitivity, -1.35, 1.35)
		rotation.y = yaw
		camera.rotation.x = pitch
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _physics_process(delta: float) -> void:
	fire_cooldown = maxf(0.0, fire_cooldown - delta)
	if reload_time > 0.0:
		reload_time -= delta
		if reload_time <= 0.0:
			ammo = max_ammo
	if not is_on_floor():
		velocity.y -= gravity * delta
	var input_vec := Vector2.ZERO
	input_vec.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
	input_vec.y = Input.get_action_strength("move_forward") - Input.get_action_strength("move_back")
	input_vec += mobile_move
	input_vec = input_vec.limit_length(1.0)
	var direction := (transform.basis * Vector3(input_vec.x, 0, -input_vec.y)).normalized()
	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = 6.5
	move_and_slide()
	if Input.is_action_pressed("fire") or mobile_fire:
		shoot()
	if Input.is_action_just_pressed("reload"):
		reload()
	if mobile_look.length() > 0.0:
		yaw -= mobile_look.x * mouse_sensitivity * 2.0
		pitch = clampf(pitch - mobile_look.y * mouse_sensitivity * 2.0, -1.35, 1.35)
		rotation.y = yaw
		camera.rotation.x = pitch
		mobile_look = Vector2.ZERO

func shoot() -> void:
	if fire_cooldown > 0.0 or reload_time > 0.0:
		return
	if ammo <= 0:
		reload()
		return
	ammo -= 1
	fire_cooldown = 0.105
	muzzle.visible = true
	get_tree().create_timer(0.045).timeout.connect(func(): if is_instance_valid(muzzle): muzzle.visible = false)
	gun_ray.force_raycast_update()
	if gun_ray.is_colliding():
		var target := gun_ray.get_collider()
		if target and target.has_method("take_damage"):
			target.take_damage(25.0)

func reload() -> void:
	if ammo < max_ammo and reload_time <= 0.0:
		reload_time = 1.35

func take_damage(amount: float) -> void:
	health -= amount
	if health <= 0.0:
		health = 0.0
		if game:
			game.call("on_player_killed")

func respawn() -> void:
	health = 100.0
	ammo = max_ammo
	reload_time = 0.0
	global_position = Vector3(0, 1.2, 8)
	velocity = Vector3.ZERO
