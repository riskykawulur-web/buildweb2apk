extends Node3D

const PlayerScript = preload("res://scripts/Player.gd")
const BotScript = preload("res://scripts/Bot.gd")
const HudScript = preload("res://scripts/HUD.gd")

var player: CharacterBody3D
var hud: CanvasLayer
var bots: Array[CharacterBody3D] = []
var mode := "TDM"
var score := 0
var enemy_score := 0
var match_over := false
var zone_radius := 38.0
var zone_timer := 0.0

func _ready() -> void:
	_setup_world()
	_setup_lighting()
	_setup_map()
	_spawn_player()
	_spawn_bots(5)
	_setup_hud()
	_update_hud()

func _process(delta: float) -> void:
	if match_over:
		return
	if mode == "BR":
		zone_timer += delta
		if zone_timer > 1.0:
			zone_timer = 0.0
			zone_radius = maxf(10.0, zone_radius - 0.16)
			if player and Vector2(player.global_position.x, player.global_position.z).length() > zone_radius:
				player.take_damage(4.0)
			for bot in bots:
				if is_instance_valid(bot) and Vector2(bot.global_position.x, bot.global_position.z).length() > zone_radius:
					bot.take_damage(3.0)
	_update_hud()

func _setup_world() -> void:
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color(0.39, 0.52, 0.59)
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.72, 0.78, 0.82)
	environment.ambient_light_energy = 0.75
	env.environment = environment
	add_child(env)

func _setup_lighting() -> void:
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -28, 0)
	sun.light_energy = 1.15
	sun.shadow_enabled = false
	add_child(sun)

func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 1.0
	return m

func _box(parent: Node3D, pos: Vector3, size: Vector3, color: Color, collision := true) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.material_override = _mat(color)
	body.add_child(mesh)
	if collision:
		var shape := CollisionShape3D.new()
		var box_shape := BoxShape3D.new()
		box_shape.size = size
		shape.shape = box_shape
		body.add_child(shape)
	parent.add_child(body)
	return body

func _setup_map() -> void:
	_box(self, Vector3(0, -0.6, 0), Vector3(90, 1, 90), Color(0.28, 0.34, 0.30))
	# Low-cost cover blocks and buildings.
	var colors := [Color(0.34,0.39,0.40), Color(0.42,0.39,0.32), Color(0.27,0.34,0.37)]
	var props := [
		[Vector3(-12,1.5,-8), Vector3(8,3,5)],
		[Vector3(12,2,-12), Vector3(9,4,7)],
		[Vector3(-18,1.2,13), Vector3(6,2.4,8)],
		[Vector3(17,1.5,14), Vector3(8,3,6)],
		[Vector3(0,1,-20), Vector3(10,2,4)],
		[Vector3(0,1,18), Vector3(12,2,4)],
		[Vector3(-29,1.4,-22), Vector3(7,2.8,7)],
		[Vector3(29,1.4,23), Vector3(7,2.8,7)],
		[Vector3(-30,1.0,15), Vector3(4,2,12)],
		[Vector3(29,1.0,-13), Vector3(4,2,12)]
	]
	for i in range(props.size()):
		_box(self, props[i][0], props[i][1], colors[i % colors.size()])
	# Boundary walls.
	_box(self, Vector3(0,2,-44), Vector3(90,4,1), Color(0.20,0.25,0.27))
	_box(self, Vector3(0,2,44), Vector3(90,4,1), Color(0.20,0.25,0.27))
	_box(self, Vector3(-44,2,0), Vector3(1,4,90), Color(0.20,0.25,0.27))
	_box(self, Vector3(44,2,0), Vector3(1,4,90), Color(0.20,0.25,0.27))

func _spawn_player() -> void:
	player = CharacterBody3D.new()
	player.set_script(PlayerScript)
	player.name = "Player"
	player.position = Vector3(0, 1.2, 8)
	add_child(player)
	player.set("game", self)

func _spawn_bots(amount: int) -> void:
	for i in range(amount):
		var bot := CharacterBody3D.new()
		bot.set_script(BotScript)
		bot.name = "Bot_%d" % i
		var angle := TAU * float(i) / float(amount)
		bot.position = Vector3(cos(angle) * 25.0, 1.0, sin(angle) * 25.0)
		add_child(bot)
		bot.set("game", self)
		bots.append(bot)

func _setup_hud() -> void:
	hud = CanvasLayer.new()
	hud.set_script(HudScript)
	add_child(hud)
	hud.set("game", self)
	hud.call("build")

func on_bot_killed(bot: Node) -> void:
	bots.erase(bot)
	if mode == "TDM":
		score += 1
		if score >= 20:
			_finish_match("MENANG! Skor 20")
	else:
		score += 1
	_spawn_replacement_bot()

func on_player_killed() -> void:
	if mode == "TDM":
		enemy_score += 1
		if enemy_score >= 20:
			_finish_match("KALAH! Musuh mencapai 20")
		if player:
			player.call_deferred("respawn")
	else:
		_finish_match("KALAH! Kamu tereliminasi")

func _spawn_replacement_bot() -> void:
	if mode == "BR" and bots.is_empty():
		_finish_match("BOOYAH! Semua musuh dikalahkan")
		return
	if mode == "TDM":
		var bot := CharacterBody3D.new()
		bot.set_script(BotScript)
		bot.position = Vector3(randf_range(-30,30), 1.0, randf_range(-30,30))
		add_child(bot)
		bot.set("game", self)
		bots.append(bot)

func _finish_match(message: String) -> void:
	match_over = true
	if hud:
		hud.call("show_result", message)

func set_mode(new_mode: String) -> void:
	mode = new_mode
	score = 0
	enemy_score = 0
	match_over = false
	zone_radius = 38.0
	zone_timer = 0.0
	if hud:
		hud.call("show_result", "")
	if player:
		player.call("respawn")
	for bot in bots:
		if is_instance_valid(bot):
			bot.queue_free()
	bots.clear()
	_spawn_bots(5 if mode == "TDM" else 12)

func _update_hud() -> void:
	if hud:
		hud.call("update_stats", player.get("health") if player else 100.0, score, enemy_score, mode, zone_radius)
