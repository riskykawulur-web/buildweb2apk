extends CanvasLayer

var game: Node
var root: Control
var stats: Label
var result: Label
var move_touch_id := -1
var look_touch_id := -1
var move_origin := Vector2.ZERO
var move_value := Vector2.ZERO
var look_last := Vector2.ZERO
var fire_button: Button
var reload_button: Button
var jump_button: Button
var mode_button: Button

func build() -> void:
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(root)

	stats = Label.new()
	stats.position = Vector2(18, 14)
	stats.add_theme_font_size_override("font_size", 22)
	stats.add_theme_color_override("font_color", Color.WHITE)
	root.add_child(stats)

	result = Label.new()
	result.set_anchors_preset(Control.PRESET_CENTER)
	result.position = Vector2(-180, -50)
	result.size = Vector2(360, 100)
	result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	result.add_theme_font_size_override("font_size", 30)
	result.add_theme_color_override("font_color", Color.YELLOW)
	root.add_child(result)

	var cross := Label.new()
	cross.text = "+"
	cross.set_anchors_preset(Control.PRESET_CENTER)
	cross.position = Vector2(-10, -20)
	cross.add_theme_font_size_override("font_size", 34)
	root.add_child(cross)

	var joystick_hint := Label.new()
	joystick_hint.text = "MOVE"
	joystick_hint.position = Vector2(48, -105)
	joystick_hint.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	root.add_child(joystick_hint)

	fire_button = _button("FIRE", Vector2(-150,-150), Vector2(105,75), Control.PRESET_BOTTOM_RIGHT)
	fire_button.button_down.connect(func(): game.player.mobile_fire = true)
	fire_button.button_up.connect(func(): game.player.mobile_fire = false)

	reload_button = _button("RELOAD", Vector2(-270,-75), Vector2(100,55), Control.PRESET_BOTTOM_RIGHT)
	reload_button.pressed.connect(func(): game.player.reload())

	jump_button = _button("JUMP", Vector2(-145,-65), Vector2(90,55), Control.PRESET_BOTTOM_RIGHT)
	jump_button.pressed.connect(func(): Input.action_press("jump"); Input.action_release("jump"))

	mode_button = _button("MODE", Vector2(18,65), Vector2(90,48), Control.PRESET_TOP_RIGHT)
	mode_button.pressed.connect(func(): game.set_mode("BR" if game.mode == "TDM" else "TDM"))

func _button(text_value: String, offset: Vector2, size_value: Vector2, preset: int) -> Button:
	var b := Button.new()
	b.text = text_value
	b.size = size_value
	b.position = offset
	b.set_anchors_preset(preset)
	b.add_theme_font_size_override("font_size", 16)
	root.add_child(b)
	return b

func _input(event: InputEvent) -> void:
	if not game or not game.player:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().size.x * 0.42 and event.position.y > get_viewport().size.y * 0.48:
				move_touch_id = event.index
				move_origin = event.position
				move_value = Vector2.ZERO
			elif event.position.x >= get_viewport().size.x * 0.42:
				look_touch_id = event.index
				look_last = event.position
		else:
			if event.index == move_touch_id:
				move_touch_id = -1
				move_value = Vector2.ZERO
				game.player.mobile_move = Vector2.ZERO
			if event.index == look_touch_id:
				look_touch_id = -1
	if event is InputEventScreenDrag:
		if event.index == move_touch_id:
			move_value = ((event.position - move_origin) / 65.0).limit_length(1.0)
			game.player.mobile_move = move_value
		elif event.index == look_touch_id:
			game.player.mobile_look += event.relative
			look_last = event.position

func update_stats(health: float, kills: int, enemy_kills: int, mode: String, zone: float) -> void:
	if not stats:
		return
	if mode == "TDM":
		stats.text = "HP %d   |   TDM   |   KILLS %d - %d" % [int(health), kills, enemy_kills]
	else:
		stats.text = "HP %d   |   BATTLE ROYALE   |   ELIMS %d   |   ZONE %.0fm" % [int(health), kills, zone]

func show_result(message: String) -> void:
	if result:
		result.text = message
