extends CharacterBody3D

var game: Node
var health := 100.0
var speed := 3.2
var attack_cooldown := 0.0
var wander_timer := 0.0
var wander_dir := Vector3.ZERO
var player: Node3D

func _ready() -> void:
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.38
	capsule.height = 1.8
	shape.shape = capsule
	shape.position.y = 0.9
	add_child(shape)
	var body_mesh := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = 0.38
	mesh.height = 1.8
	body_mesh.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.65, 0.18, 0.14)
	body_mesh.material_override = mat
	body_mesh.position.y = 0.9
	add_child(body_mesh)
	var head := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.22
	sphere.height = 0.44
	head.mesh = sphere
	head.position.y = 1.85
	head.material_override = mat
	add_child(head)

func _physics_process(delta: float) -> void:
	if not game or game.get("match_over"):
		return
	player = game.get("player")
	if not is_instance_valid(player):
		return
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	var to_player := player.global_position - global_position
	to_player.y = 0
	var distance := to_player.length()
	if distance < 27.0:
		var dir := to_player.normalized()
		look_at(Vector3(player.global_position.x, global_position.y, player.global_position.z), Vector3.UP)
		if distance > 8.0:
			velocity.x = dir.x * speed
			velocity.z = dir.z * speed
		else:
			velocity.x = 0
			velocity.z = 0
		if distance < 23.0 and attack_cooldown <= 0.0:
			attack_cooldown = 0.9
			player.take_damage(7.0)
	else:
		wander_timer -= delta
		if wander_timer <= 0.0:
			wander_timer = randf_range(1.0, 3.0)
			wander_dir = Vector3(randf_range(-1,1), 0, randf_range(-1,1)).normalized()
		velocity.x = wander_dir.x * speed * 0.55
		velocity.z = wander_dir.z * speed * 0.55
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	move_and_slide()

func take_damage(amount: float) -> void:
	health -= amount
	if health <= 0.0:
		if game:
			game.call("on_bot_killed", self)
		queue_free()
