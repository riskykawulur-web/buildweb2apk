# TR4FSLOK SALX — HTML + Android WebView

## Demo credentials
- Username: `SALX`
- Password: `SALX123`

This is a local UI and basic connectivity testing tool. It does not send WhatsApp messages, interact with WhatsApp internals, crash apps, or target another person's device. The login is client-side demo authentication and is not secure for sensitive data.

## Build an APK
1. Install Android Studio and Android SDK.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `TR4FSLOK_SALX_HTML_APK` folder.
4. Wait for Gradle sync. Install SDK 35 / compatible build tools if Android Studio prompts.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Use the notification's **locate** link. Typical debug output: `app/build/outputs/apk/debug/app-debug.apk`.
7. Move the APK to your Android phone and install it. Allow installs from that source if Android asks.

## Connectivity check
The app shows the browser's basic online/offline signal and can attempt an HTTPS request to `www.whatsapp.com`. WebView/CORS/network restrictions may prevent the request; failure is not proof that WhatsApp is down. No network stress testing is performed.
